"""
Concurrency against the REAL application, started from a scratch copy (5.40): many users and many
requests at the same moment. The example tests elsewhere do one thing at a time; this is where a
race between the upload routes, the assembly queue and the file monitor would show up.

OPT-IN (CLOUDINATOR_SLOW_TESTS=1, set by the nightly workflow): the tests start threads, wait for
the background assembly and take several seconds each.

    CLOUDINATOR_SLOW_TESTS=1 python -m pytest tests/reliability/test_concurrency.py -q

If one of these fails, do not just re-run it: a failure here can be a REAL race in routes/uploads.py
or storage.py. Keep scratch_server.log (the failure output prints its tail).

Rules from CODING_GUIDELINES.md 18.1 that apply: the tests wait for the expected CONTENT, never
only for a file to exist; nothing is written outside the scratch copy.
"""

import hashlib
import os
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

import pytest

pytestmark = [
    pytest.mark.reliability,
    pytest.mark.skipif(
        os.environ.get("CLOUDINATOR_SLOW_TESTS") != "1",
        reason="slow and timing-sensitive: set CLOUDINATOR_SLOW_TESTS=1 to run",
    ),
]

USERS = 6
CHUNKS = 12

# 5.43: how long a plain read may take WHILE uploads are being received and assembled. Loose on
# purpose (the idle p95 on the owner's PC is 0.07 s): the opt-in tier also runs on a phone in Termux
# and on shared CI runners, and the test is there to catch a blocked event loop (seconds), not to
# rank machines. The payloads are small for the same reason.
LATENCY_UPLOADERS = 3
LATENCY_CHUNKS = 6
LATENCY_CHUNK_BYTES = 512 * 1024
READ_P95_LIMIT_SECONDS = 2.0
MIN_READ_SAMPLES = 5


@pytest.fixture(scope="module")
def server(scratch_server):
    return scratch_server


def _send_chunk(client, file_id, number, total, name, data, token=None):
    """One chunk, the way the front end sends it. With token=None the client fetches a fresh CSRF
    token first (HttpClient.api). A test that sends from SEVERAL THREADS through ONE client passes
    the token it fetched once: a page holds one token, and twelve token fetches racing on one
    session cookie are not what that test is about."""
    fields = {
        "file_id": file_id,
        "chunk_num": str(number),
        "total_chunks": str(total),
        "filename": name,
        "dest_path": "",
    }
    files = {"chunk": ("blob", data)}
    if token is None:
        return client.api("POST", "/upload", fields=fields, files=files)
    return client.request(
        "POST",
        "/upload",
        fields=fields,
        files=files,
        headers={"Accept": "application/json", "X-CSRFToken": token},
    )


def _wait_for_content(path, expected, timeout=60):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            if path.read_bytes() == expected:
                return True
        except OSError:
            # not there yet, or momentarily busy: poll again
            pass
        time.sleep(0.25)
    return False


def _payload(label, number, size=2048):
    seed = hashlib.sha256(f"{label}-{number}".encode()).digest()
    return (seed * (size // len(seed) + 1))[:size]


def test_many_users_with_the_same_upload_id_each_get_their_own_exact_file(server):
    tag = uuid.uuid4().hex[:8]
    file_id = "fid_1_6144"  # the short id every browser can produce
    accounts = [server.make_user("readwrite") for _ in range(USERS)]
    clients = []
    for name, password in accounts:
        client = server.client()
        assert client.login(name, password).status == 302
        clients.append(client)

    expected = {}

    def upload(index):
        parts = [_payload(f"{tag}-user{index}", n) for n in range(3)]
        filename = f"crowd_{tag}_{index}.bin"
        expected[filename] = b"".join(parts)
        for number, data in enumerate(parts):
            reply = _send_chunk(clients[index], file_id, number, 3, filename, data)
            assert reply.status == 200, (index, number, reply.status, reply.text[:200])

    with ThreadPoolExecutor(max_workers=USERS) as pool:
        for future in [pool.submit(upload, i) for i in range(USERS)]:
            future.result(timeout=120)

    for filename, content in expected.items():
        assert _wait_for_content(
            server.storage / filename, content
        ), f"{filename} is missing or has the wrong bytes\n{server.log_tail()}"


def test_the_chunks_of_one_upload_arriving_at_the_same_moment_assemble_exactly_once(
    server,
):
    tag = uuid.uuid4().hex[:8]
    client = server.login_as("qa_writer")
    filename = f"parallel_{tag}.bin"
    parts = [_payload(tag, n) for n in range(CHUNKS)]

    # Like a browser that has loaded the page: the first authenticated request (it writes the
    # session id into the session cookie) happens BEFORE the burst, and the token is fetched once.
    # HttpClient.api() fetches a token inside every call; twelve threads doing that on one session
    # cookie sometimes got "400 CSRF token missing or incorrect" (2026-11-09: the ubuntu nightly
    # and 2 of 22 local runs, always on one of the first chunks). One fetch before the burst
    # removes that variable; the upload race this test is about is unchanged.
    client.csrf_token()
    token = client.csrf_token()

    def send(number):
        return _send_chunk(
            client, "fid_2_24576", number, CHUNKS, filename, parts[number], token
        )

    with ThreadPoolExecutor(max_workers=CHUNKS) as pool:
        replies = list(pool.map(send, range(CHUNKS)))
    bad = [
        (number, r.status, r.text)
        for number, r in enumerate(replies)
        if r.status != 200
    ]
    assert (
        not bad
    ), f"chunks that were not accepted (number, status, full body): {bad}\n{server.log_tail()}"

    target = server.storage / filename
    assert _wait_for_content(target, b"".join(parts)), server.log_tail()
    time.sleep(3)  # a second, late assembly of the same upload would show up now
    assert target.read_bytes() == b"".join(parts)
    leftovers = [p.name for p in server.storage.iterdir() if p.name.endswith(".part")]
    assert leftovers == [], f"temp files left behind: {leftovers}"


def test_many_logins_at_the_same_moment_all_succeed(server):
    def log_in(_):
        client = server.client()
        return client.login("qa_reader", server.users["qa_reader"][0]).status

    with ThreadPoolExecutor(max_workers=16) as pool:
        statuses = list(pool.map(log_in, range(32)))
    assert statuses == [302] * 32


def test_reads_keep_working_while_uploads_are_being_assembled(server):
    tag = uuid.uuid4().hex[:8]
    writer = server.login_as("qa_writer")
    reader = server.login_as("qa_reader")
    filename = f"busy_{tag}.bin"
    parts = [_payload(tag, n, size=256 * 1024) for n in range(8)]

    def upload():
        for number, data in enumerate(parts):
            assert (
                _send_chunk(writer, "fid_3_big", number, 8, filename, data).status
                == 200
            )

    def read_history():
        statuses = []
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline:
            reply = reader.get(
                f"/api/versions/list?path={filename}",
                headers={"Accept": "application/json"},
            )
            statuses.append(reply.status)
        return statuses

    with ThreadPoolExecutor(max_workers=2) as pool:
        up, reads = pool.submit(upload), pool.submit(read_history)
        up.result(timeout=120)
        statuses = reads.result(timeout=120)
    assert statuses and set(statuses) == {200}, set(statuses)
    assert _wait_for_content(
        server.storage / filename, b"".join(parts)
    ), server.log_tail()


def test_a_read_stays_fast_while_uploads_are_received_and_assembled(
    server, record_property
):
    """The 95th percentile of the time a read request takes, measured from before the first chunk
    until every file is published: the receive, the RAM parse and the assembly must not hold the
    event loop for seconds (5.43 parses upload chunks in RAM by default, on the loop thread).
    """
    tag = uuid.uuid4().hex[:8]
    reader = server.login_as("qa_reader")
    jobs = []
    for index in range(LATENCY_UPLOADERS):
        parts = [
            _payload(f"{tag}-{index}", n, size=LATENCY_CHUNK_BYTES)
            for n in range(LATENCY_CHUNKS)
        ]
        jobs.append(
            (server.login_as("qa_writer"), f"latency_{tag}_{index}.bin", parts, index)
        )
    stop = threading.Event()

    def read_until_stopped():
        timings, statuses = [], []
        while not stop.is_set():
            started = time.perf_counter()
            reply = reader.get(
                "/api/versions/list?path=latency_missing.txt",
                headers={"Accept": "application/json"},
            )
            timings.append(time.perf_counter() - started)
            statuses.append(reply.status)
        return timings, statuses

    def upload(job):
        client, filename, parts, index = job
        file_id = f"fid_{index}_{tag}_lat"
        for number, data in enumerate(parts):
            reply = _send_chunk(client, file_id, number, len(parts), filename, data)
            assert reply.status == 200, (filename, number, reply.status)
        return filename

    with ThreadPoolExecutor(max_workers=LATENCY_UPLOADERS + 1) as pool:
        watching = pool.submit(read_until_stopped)
        try:
            uploads = [pool.submit(upload, job) for job in jobs]
            for future in uploads:
                future.result(timeout=120)
            for _client, filename, parts, _index in jobs:
                assert _wait_for_content(
                    server.storage / filename, b"".join(parts)
                ), f"{filename} was not published\n{server.log_tail()}"
        finally:
            stop.set()
        timings, statuses = watching.result(timeout=60)

    assert set(statuses) == {200}, set(statuses)
    assert len(timings) >= MIN_READ_SAMPLES, f"only {len(timings)} reads were measured"
    ordered = sorted(timings)
    p95 = ordered[min(len(ordered) - 1, int(len(ordered) * 0.95))]
    record_property("read_p95_during_uploads_seconds", f"{p95:.3f} s")
    record_property("read_max_during_uploads_seconds", f"{ordered[-1]:.3f} s")
    print(
        f"[baseline] read_p95_during_uploads: {p95:.3f} s over {len(timings)} reads "
        f"(max {ordered[-1]:.3f} s)"
    )
    assert p95 < READ_P95_LIMIT_SECONDS, (
        f"p95 of a read was {p95:.2f} s while uploads ran "
        f"(limit {READ_P95_LIMIT_SECONDS} s)\n{server.log_tail()}"
    )
