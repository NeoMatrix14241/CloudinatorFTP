"""
Tests for the Quality Assurance section of manage.sh (menu 22-26 and the `qa` command) and for
its Developer Tools section (menu 27-31: `dir-tree`, `smoke --save`, `qa audit`, `qa coverage` and,
since 5.41, `qa lint`). Menu 10 / `purge-versions` (5.44.4) launches tools/purge_missing_versions.py.
Since 5.44.7 the numbers 1..31 are contiguous in print order (a deliberate one-time renumbering: the
entries after 9 moved, the named commands did not). 5.45.1 added the WAL clean-up INSIDE menu 9 /
`version-manage wal` (no new number, so LAST_ENTRY and the numbering did not move).
5.47.7 made the object-compression tools reachable from the `version-manage` menu (its option 7) and
the compression settings from `config` (Version Engine > Engine settings > 13): manage.sh only got
text (menu 9's line, the help, the command map), so LAST_ENTRY and the numbering did not move.

They read the real manage.sh and only run side-effect-free commands (`help`, `qa --version`,
`qa bogus`, `qa layer nope`; `qa audit` and `qa lint` are only checked in the source: audit would use the network, lint would write Ruff's cache); no server is started and nothing is written. The numbering test
guards against the menu drifting from its dispatch table and from `help` (CLAUDE.md records
three earlier renumbering accidents). Raise LAST_ENTRY whenever the menu grows.
"""

import re
import shutil
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent.parent
SCRIPT = ROOT / "manage.sh"
BASH = shutil.which("bash")

pytestmark = pytest.mark.skipif(
    BASH is None or not SCRIPT.is_file(), reason="bash or manage.sh not found"
)

LAST_ENTRY = 31


def _text():
    return SCRIPT.read_text(encoding="utf-8")


def _function(name):
    m = re.search(rf"^{name}\(\) \{{\n.*?^\}}\n", _text(), re.S | re.M)
    assert m, f"{name}() not found in manage.sh"
    return m.group(0)


def _run(*args):
    return subprocess.run(
        [BASH, "manage.sh", *args],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=120,
    )


def test_menu_listing_and_dispatch_cover_the_same_numbers():
    body = _function("cmd_menu")
    listed = set()
    for line in body.splitlines():
        m = re.match(
            r"\t+echo.*?\b(\d{1,2})\) ", line
        )  # 19) sits one level deeper (if is_termux)
        if m:
            listed.add(int(m.group(1)))
    arms = {int(n) for n in re.findall(r"^\t\t(\d{1,2})\) ", body, re.M)}
    assert listed == arms == set(range(1, LAST_ENTRY + 1)), (
        sorted(listed),
        sorted(arms),
    )


def _printed_numbers():
    """The entry numbers in the order cmd_menu prints them. 20 (termux_setup.sh) is printed by
    both branches of its `if is_termux`, hence the consecutive de-duplication."""
    printed = []
    for line in _function("cmd_menu").splitlines():
        entry = re.match(r"\t+echo.*?\b(\d{1,2})\) ", line)
        if entry and (not printed or printed[-1] != int(entry.group(1))):
            printed.append(int(entry.group(1)))
    return printed


def test_menu_numbers_are_printed_exactly_1_to_n_in_ascending_order():
    """No jumps (the old 9, 31, 10), no repeats, no gaps: what the operator reads top to bottom
    is 1, 2, 3 ... LAST_ENTRY."""
    assert _printed_numbers() == list(range(1, LAST_ENTRY + 1))


MENU_BLOCKS = {
    "Servers": list(range(1, 9)),
    "Version Engine": [9, 10],
    "Utilities": list(range(11, 22)),
    "Quality Assurance": list(range(22, 27)),
    "Developer Tools": list(range(27, 32)),
}


def test_menu_blocks_hold_the_documented_entries():
    """Which heading holds which numbers (the order is guarded by the test above)."""
    blocks, current = {}, None
    for line in _function("cmd_menu").splitlines():
        heading = re.match(r'\t+echo -e "  \$\{BOLD\}([^$]+)\$\{NC\}', line)
        if heading:
            current = heading.group(1)
            blocks[current] = []
            continue
        entry = re.match(r"\t+echo.*?\b(\d{1,2})\) ", line)
        if (
            entry
            and current
            and (not blocks[current] or blocks[current][-1] != int(entry.group(1)))
        ):
            blocks[current].append(int(entry.group(1)))
    assert blocks == MENU_BLOCKS


def test_termux_setup_has_the_same_number_in_both_branches():
    body = _function("cmd_menu")
    assert len(re.findall(r"\b20\) termux_setup\.sh", body)) == 2


def test_the_old_numbering_is_gone_from_manage_sh():
    """The menu numbers of 5.44.x (31 = purge, 21-25 = QA, 26-30 = Developer Tools) must not
    survive in comments or messages."""
    text = _text()
    for stale in ("menu #24", "menu #27", "menu 31"):
        assert stale not in text, stale
    assert "menu #21" in text and "menu #25" in text and "menu #28" in text


def test_help_menu_map_lists_every_number():
    out = _run("help").stdout
    block = out.split("COMMAND MAP", 1)[1].split("EXAMPLES", 1)[0]
    numbers = {int(n) for n in re.findall(r"(?<!\d)(\d{1,2})  (?=[a-z])", block)}
    assert numbers == set(range(1, LAST_ENTRY + 1)), sorted(numbers)


def test_menu_arms_run_the_expected_qa_modes():
    body = _function("cmd_menu")
    for num, call in {
        22: "cmd_qa quick",
        23: "cmd_qa static",
        24: "cmd_qa tests",
        25: "_menu_qa_layer",
        26: "cmd_qa ci",
        29: "cmd_qa audit",
        30: "cmd_qa coverage",
        31: "cmd_qa lint",
    }.items():
        assert re.search(
            rf"^\t\t{num}\) _menu_run {re.escape(call)} ;;$", body, re.M
        ), num


def test_menu_arms_run_the_developer_tools():
    body = _function("cmd_menu")
    for num, call in {
        27: 'run_utility "tests/dir_tree.py"',
        28: "_menu_smoke_save",
    }.items():
        assert re.search(
            rf"^\t\t{num}\) _menu_run {re.escape(call)} ;;$", body, re.M
        ), num


def test_qa_is_dispatched_and_launches_the_runner_through_run_utility():
    assert re.search(r"^\tqa\) cmd_qa \"\$@\" ;;$", _function("main"), re.M)
    assert 'run_utility "tests/qa.py"' in _function("cmd_qa")
    assert (ROOT / "tests" / "qa.py").is_file()


def test_developer_tools_are_dispatched_and_launch_their_scripts():
    main = _function("main")
    assert re.search(
        r"^\tdir-tree\) run_utility \"tests/dir_tree.py\" \"\$@\" ;;$", main, re.M
    )
    assert re.search(r"^\tsmoke\) cmd_smoke \"\$@\" ;;$", main, re.M)
    assert 'run_utility "tests/smoke.py"' in _function("cmd_smoke")
    assert (ROOT / "tests" / "dir_tree.py").is_file()
    assert (ROOT / "tests" / "smoke.py").is_file()


def test_help_documents_the_developer_tools():
    out = _run("help").stdout
    for text in (
        "DEVELOPER TOOLS COMMANDS",
        "dir-tree",
        "smoke [options]",
        "smoke --save",
    ):
        assert text in out, text


def test_help_documents_every_qa_mode():
    out = _run("help").stdout
    for text in (
        "QUALITY ASSURANCE COMMANDS",
        "qa [quick]",
        "qa static",
        "qa tests",
        "qa layer <name>",
        "qa ci",
        "qa audit",
        "qa coverage",
        "qa lint",
        "qa --version",
    ):
        assert text in out, text


def test_qa_audit_coverage_and_lint_are_accepted_modes_and_stay_out_of_quick():
    body = _function("cmd_qa")
    assert re.search(
        r"quick \| static \| tests \| ci \| layer \| audit \| coverage \| lint \|",
        body,
    )
    assert "| audit | coverage | lint)" in body  # the error message lists them


def test_unknown_qa_mode_exits_2():
    proc = _run("qa", "bogus")
    assert proc.returncode == 2
    assert "Unknown qa mode" in proc.stderr


def test_qa_version_reaches_the_runner():
    proc = _run("qa", "--version")
    assert proc.returncode == 0, proc.stderr
    assert "qa.py" in proc.stdout


def test_runner_exit_code_is_passed_through():
    proc = _run("qa", "layer", "no_such_layer")
    assert proc.returncode == 2, (proc.stdout, proc.stderr)
    assert "unknown layer" in proc.stderr


def test_purge_versions_is_menu_10_and_a_command():
    assert re.search(
        r'^\t\t10\) _menu_run run_utility "tools/purge_missing_versions.py" ;;$',
        _function("cmd_menu"),
        re.M,
    )
    assert re.search(
        r'^\tpurge-versions\) run_utility "tools/purge_missing_versions.py" "\$@" ;;$',
        _function("main"),
        re.M,
    )
    assert (ROOT / "tools" / "purge_missing_versions.py").is_file()
    out = _run("help").stdout
    for text in ("purge-versions", "--report", "--undo <file>.json", "--force"):
        assert text in out, text


def test_wal_cleanup_lives_under_version_manage_with_menu_cli_and_help():
    """5.45.1: the WAL clean-up is `version-manage wal`, reachable from menu 9, with no new menu
    number (the numbering tests above would catch one)."""
    body = _function("cmd_menu")
    assert re.search(
        r'^\t\t9\) _menu_run run_utility "tools/version_manage.py" ;;$', body, re.M
    )
    assert re.search(r"9\) version_manage\.py .*WAL", body)
    assert re.search(
        r'^\tversion-manage\) run_utility "tools/version_manage.py" "\$@" ;;$',
        _function("main"),
        re.M,
    )
    out = _run("help").stdout
    for text in (
        "wal [--checkpoint",
        "--if-larger-mb",
        "--timeout",
        "./manage.sh version-manage wal --checkpoint",
        "VERSION_WAL_SIZE_LIMIT_MB",
    ):
        assert text in out, text
    tool = (ROOT / "tools" / "version_manage.py").read_text(encoding="utf-8")
    assert 'sub.add_parser(\n        "wal"' in tool


def test_compression_is_reachable_from_menu_9_and_the_help_names_both_menus():
    """5.47.7: text only. Menu 9's line mentions the compression tools, the version-manage help
    lists the subcommands and says the version-manage menu has them as option 7, and the config
    help says where the settings are edited (the command line itself is unchanged)."""
    assert re.search(r"9\) version_manage\.py .*compression", _function("cmd_menu"))
    out = _run("help").stdout
    for text in (
        "compress --probe | --status | --sweep | --verify | --decompress",
        "menu option 7",
        "as option 7",
        "Engine settings > 13",
        "VERSION_COMPRESSION_*",
        "compression settings",
    ):
        assert text in out, text
    block = out.split("COMMAND MAP", 1)[1].split("EXAMPLES", 1)[0]
    assert "11  config (Version Engine > Engine settings > 13" in block
