"""
tests/conftest.py - shared pytest fixtures for CloudinatorFTP (CLAUDE.md 5.00).

The one rule: a test must NEVER touch the real db/, cache/, versions/ or storage folders.

Why a scratch copy: paths.py reads storage_config.json and config.py reads server_config.json
from the folder that contains the .py file, and core.py starts the file monitor, the cleanup
threads etc. at import time. So the application is never imported into the pytest process.
Instead the source tree is copied into a temporary folder, fresh config files that point
inside that folder are written, and the app runs there as a SUBPROCESS (dev_server.py) on an
ephemeral port. Tests talk to it over HTTP.

In-process imports from the real tree are limited to side-effect-free leaf modules (today:
paths, which has no project imports and no import-time side effects). The autouse guard
below fails any test run in which another root module was imported from the real tree.
"""

import hashlib
import http.cookiejar
import itertools
import json
import os
import shutil
import socket
import subprocess
import sys
import sysconfig
import time
import types
import urllib.error
import urllib.parse
import urllib.request
import uuid
from contextlib import suppress
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parent.parent

# Root modules that are safe to import in-process from the real tree.
IN_PROCESS_OK = {"paths"}

# Never copied into the scratch tree (any depth): real data, caches, vendored pdf.js/fonts.
COPY_SKIP = {
    ".git",
    ".github",
    ".manage_pids",
    "__pycache__",
    ".pytest_cache",
    ".hypothesis",
    "venv",
    ".venv",
    "node_modules",
    "logs",
    "db",
    "cache",
    "versions",
    "uploads",
    "docs",
    "tests",
    "cmaps",
    "iccs",
    "images",
    "standard_fonts",
    "wasm",
    "build",
}
# Config files that are written fresh in the scratch tree, never copied.
CONFIG_FILES = {"storage_config.json", "server_config.json"}


def _is_inside(child, parent) -> bool:
    c = os.path.normcase(os.path.realpath(str(child)))
    p = os.path.normcase(os.path.realpath(str(parent)))
    return c == p or c.startswith(p.rstrip(os.sep) + os.sep)


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def child_gil_environment() -> dict:
    """The GIL setting a scratch server inherits from the test run (5.42).

    On a free-threaded build (python3.14t) that is running WITHOUT the GIL the server must run the
    same way, as the real launcher does (PYTHON_GIL=0), or a C extension that does not declare
    itself safe would silently switch the GIL back on in the child only. On a standard build
    nothing may be set: PYTHON_GIL=0 there is a startup error ("not supported by this build"). A
    free-threaded build that is running WITH the GIL (PYTHON_GIL=1, or an extension re-enabled it)
    also gets nothing, so the child behaves like its parent in every case.
    """
    if not sysconfig.get_config_var("Py_GIL_DISABLED"):
        return {}
    is_gil_enabled = getattr(sys, "_is_gil_enabled", None)
    if is_gil_enabled is None or is_gil_enabled():
        return {}
    return {"PYTHON_GIL": "0"}


def scratch_config_from_environment() -> dict:
    """Extra server_config.json keys for EVERY scratch server of this run (5.42).

        CLOUDINATOR_SCRATCH_CONFIG='{"UPLOAD_CHUNKS_IN_MEMORY": true}' python -m pytest ...

    is an A/B switch for the performance baselines: the same measurement with one setting changed,
    without editing code or restarting the real server. Unset or empty: nothing is added. Keys a
    fixture passes explicitly still win (see build_scratch). The isolation check of the scratch
    copy still runs, so a path that points outside it is refused.
    """
    raw = os.environ.get("CLOUDINATOR_SCRATCH_CONFIG", "").strip()
    if not raw:
        return {}
    value, error = None, None  # set before the try: see test_browser_smoke.py (CodeQL)
    try:
        value = json.loads(raw)
    except ValueError as exc:
        error = exc
    if error is not None:
        pytest.fail(
            f"CLOUDINATOR_SCRATCH_CONFIG is not valid JSON: {error}", pytrace=False
        )
    if not isinstance(value, dict):
        pytest.fail(
            "CLOUDINATOR_SCRATCH_CONFIG must be a JSON object, e.g. "
            "'{\"UPLOAD_TIMING_ENABLED\": true}'",
            pytrace=False,
        )
    return value


def build_scratch(dest, src_root=REPO_ROOT, port=0, config=None) -> Path:
    """Copy the source tree into `dest` and write config files that point inside it.

    `config` (5.40) is merged over the default server_config.json of the scratch copy, e.g. to
    switch the version engine on for one fixture; the defaults keep every optional service off.
    CLOUDINATOR_SCRATCH_CONFIG (5.42, a JSON object) is merged first, `config` over it.
    """
    dest = Path(dest)
    src_root = Path(src_root)

    def _ignore(_dir, names):
        return [n for n in names if n in COPY_SKIP or n in CONFIG_FILES]

    # Root-level .py files, plus helpers/, routes/, templates/ and a trimmed static/.
    dest.mkdir(parents=True, exist_ok=True)
    for f in src_root.glob("*.py"):
        shutil.copy2(f, dest / f.name)
    for sub in ("helpers", "routes", "templates", "static"):
        if (src_root / sub).is_dir():
            shutil.copytree(src_root / sub, dest / sub, ignore=_ignore)

    data = dest / "data"
    storage = data / "storage"
    storage.mkdir(parents=True, exist_ok=True)
    storage_cfg = {
        "storage_path": str(storage),
        "db_path": str(data / "db"),
        "cache_path": str(data / "cache"),
        "versions_path": str(data / "versions"),
        "hls_cache_path": str(data / "cache" / "hls"),
        "img_cache_path": str(data / "cache" / "img"),
    }
    server_cfg = {
        "PORT": int(port),
        "HOST": "127.0.0.1",
        "ENABLE_SEARCH_INDEX": False,
        "ENABLE_FFMPEG": False,
        "ENABLE_LIBVIPS": False,
        "WEBDAV_ENABLED": False,
        "WEBDAV_HTTPS_ENABLED": False,
        "SFTP_ENABLED": False,
        "FTP_ENABLED": False,
        "SMB_ENABLED": False,
        "VERSION_ENGINE_ENABLED": False,
    }
    server_cfg.update(scratch_config_from_environment())
    server_cfg.update(config or {})
    (dest / "storage_config.json").write_text(
        json.dumps(storage_cfg, indent=2), "utf-8"
    )
    (dest / "server_config.json").write_text(json.dumps(server_cfg, indent=2), "utf-8")
    return dest


def resolve_paths(scratch) -> dict:
    """Ask the scratch copy's own paths.py where it would keep its data (read-only call)."""
    code = (
        "import json, os, sys; sys.path.insert(0, os.getcwd()); import paths; "
        "print(json.dumps(paths.get_all_paths()))"
    )
    env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    out = subprocess.run(
        [sys.executable, "-c", code],
        cwd=str(scratch),
        env=env,
        capture_output=True,
        text=True,
        timeout=60,
    )
    if out.returncode != 0:
        raise RuntimeError(f"could not resolve scratch paths: {out.stderr.strip()}")
    return json.loads(out.stdout.strip().splitlines()[-1])


def paths_outside(scratch, repo_root=REPO_ROOT) -> list:
    """Return human-readable violations; an empty list means the scratch tree is isolated."""
    bad = []
    if _is_inside(scratch, repo_root) or _is_inside(repo_root, scratch):
        bad.append(f"scratch folder overlaps the real project: {scratch}")
    resolved = resolve_paths(scratch)
    for key in (
        "db_dir",
        "cache_dir",
        "hls_cache_dir",
        "img_cache_dir",
        "versions_dir",
    ):
        if not _is_inside(resolved[key], scratch):
            bad.append(f"{key} resolves outside the scratch folder: {resolved[key]}")
    try:
        cfg = json.loads((Path(scratch) / "storage_config.json").read_text("utf-8"))
    except (OSError, ValueError) as e:
        return bad + [f"scratch storage_config.json unreadable: {e}"]
    if not _is_inside(cfg.get("storage_path", ""), scratch):
        bad.append(
            f"storage_path is outside the scratch folder: {cfg.get('storage_path')}"
        )
    return bad


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def _hash_real_configs() -> dict:
    out = {}
    for name in sorted(CONFIG_FILES):
        p = REPO_ROOT / name
        out[name] = hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
    return out


# --------------------------------------------------------------------------------------
# Guard: nothing but the leaf modules may be imported in-process from the real tree.
# --------------------------------------------------------------------------------------
def _forbidden_loaded() -> list:
    root_mods = {p.stem for p in REPO_ROOT.glob("*.py")} - IN_PROCESS_OK
    bad = []
    for name in sorted(root_mods):
        mod = sys.modules.get(name)
        f = getattr(mod, "__file__", None)
        if mod is not None and f and _is_inside(f, REPO_ROOT):
            bad.append(name)
    return bad


def pytest_collection_finish(session):
    bad = _forbidden_loaded()
    if bad:
        raise pytest.UsageError(
            "tests imported application modules from the real project in-process: "
            + ", ".join(bad)
            + ". Use the scratch_server fixture (subprocess) instead; see tests/conftest.py."
        )


def _name_the_running_test(item, phase):
    sys.stderr.write(f"[{phase}] {item.nodeid}\n")


@pytest.hookimpl(tryfirst=True)
def pytest_runtest_setup(item):
    """5.47.6: name the running test and its phase in the captured stderr.

    pytest-timeout's `thread` method (the one used on Windows) prints every thread's stack and
    kills the process with `os._exit(1)`: no summary and NO test name, and when the stuck call is
    inside a Playwright greenlet the stack of the main thread shows no pytest frame either. The
    owner's `qa quick` of 5.47.5 died that way at test 1656 of 1661 without saying which one.
    pytest-timeout prints the captured stderr, so each phase (pytest resets its capture between
    setup, call and teardown) writes one line first; on a pass it is captured and never shown.
    """
    _name_the_running_test(item, "setup")


@pytest.hookimpl(tryfirst=True)
def pytest_runtest_call(item):
    _name_the_running_test(item, "call")


@pytest.hookimpl(tryfirst=True)
def pytest_runtest_teardown(item):
    _name_the_running_test(item, "teardown")


@pytest.fixture(autouse=True)
def _no_real_app_modules():
    yield
    bad = _forbidden_loaded()
    assert not bad, (
        "a test imported application modules from the real project in-process: "
        + ", ".join(bad)
    )


# --------------------------------------------------------------------------------------
# Fixtures
# --------------------------------------------------------------------------------------
@pytest.fixture(scope="session")
def scratch_tools():
    """The scratch-copy helpers, for tests of the harness itself."""
    return types.SimpleNamespace(
        build=build_scratch,
        resolve_paths=resolve_paths,
        paths_outside=paths_outside,
        free_port=free_port,
        is_inside=_is_inside,
        real_config_hashes=_hash_real_configs,
        HttpClient=HttpClient,
        run_in_scratch=run_in_scratch,
        test_users=TEST_USERS,
        repo_root=REPO_ROOT,
        start_server=start_scratch_server,
        stop_server=stop_scratch_server,
        seed_users=seed_scratch_users,
    )


# --------------------------------------------------------------------------------------
# Test users, scratch-database helper and a cookie-aware HTTP client
# --------------------------------------------------------------------------------------
# Synthetic accounts, created in the SCRATCH database before the server starts. (A fresh
# database also seeds the built-in admin / guest default users; tests never rely on those.)
TEST_USERS = {
    "qa_writer": ("QaWriter-Pass-1!", "readwrite"),
    "qa_reader": ("QaReader-Pass-1!", "readonly"),
}

_SCRATCH_PRELUDE = (
    "import os, sys\n"
    "sys.path.insert(0, os.getcwd())\n"
    "from paths import ensure_dirs\n"
    "ensure_dirs()\n"
    "from database import db\n"
)


def run_in_scratch(root, code, *args) -> str:
    """Run Python inside the scratch copy (cwd = scratch, so paths.py / database.py are the
    copy's own) with `db` (database.db) in scope. Returns stdout; raises on a non-zero exit.
    """
    env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    env.update(
        {
            "PYTHONUTF8": "1",
            "PYTHONIOENCODING": "utf-8",
            "CLOUDINATOR_FTP_ROOT": str(Path(root) / "data" / "storage"),
        }
    )
    out = subprocess.run(
        [sys.executable, "-c", _SCRATCH_PRELUDE + code, *args],
        cwd=str(root),
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=120,
    )
    if out.returncode != 0:
        raise RuntimeError(f"scratch snippet failed:\n{out.stderr.strip()}")
    return out.stdout


_SEED_CODE = (
    "import json\n"
    "for name, (pw, role) in json.loads(sys.argv[1]).items():\n"
    "    assert db.add_user(name, pw, role), name\n"
)

# Every client gets its own fake client IP, sent as CF-Connecting-IP (the header the app
# trusts, see get_client_ip() in core.py), so each test has its own login rate-limit bucket.
_ip_counter = itertools.count(1)


def _next_ip() -> str:
    n = next(_ip_counter)
    return f"10.77.{n // 250}.{n % 250 + 1}"


def _multipart(fields, files):
    """Encode a multipart/form-data body. files = {name: (filename, bytes)}."""
    boundary = "qa-" + uuid.uuid4().hex
    parts = []
    for name, value in fields.items():
        parts.append(
            f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode()
        )
    for name, (filename, content) in files.items():
        head = (
            f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"; '
            f'filename="{filename}"\r\nContent-Type: application/octet-stream\r\n\r\n'
        )
        parts.append(head.encode() + content + b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode())
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"


class Reply:
    """One HTTP answer: status, headers (case-insensitive), body and every Set-Cookie line."""

    def __init__(self, status, headers, body):
        self.status = status
        self.headers = headers
        self.body = body
        self.set_cookies = headers.get_all("Set-Cookie") or []

    @property
    def text(self) -> str:
        return self.body.decode("utf-8", errors="replace")

    def json(self):
        return json.loads(self.text)

    def header(self, name, default=""):
        return self.headers.get(name, default)


JSON_HEADERS = {"Accept": "application/json"}


class HttpClient:
    """A browser-like client: keeps cookies, never follows redirects, always sends a fixed
    fake client IP. Standard library only."""

    def __init__(self, base_url, ip=None):
        self.base_url = base_url
        self.ip = ip or _next_ip()
        self.jar = http.cookiejar.CookieJar()
        self._opener = urllib.request.build_opener(
            _NoRedirect, urllib.request.HTTPCookieProcessor(self.jar)
        )

    def request(
        self, method, path, fields=None, json_body=None, headers=None, files=None
    ) -> Reply:
        hdrs = {"CF-Connecting-IP": self.ip}
        hdrs.update(headers or {})
        hdrs = {k: v for k, v in hdrs.items() if v is not None}
        data = None
        if files is not None:
            data, content_type = _multipart(fields or {}, files)
            hdrs.setdefault("Content-Type", content_type)
        elif fields is not None:
            data = urllib.parse.urlencode(fields).encode("utf-8")
            hdrs.setdefault("Content-Type", "application/x-www-form-urlencoded")
        elif json_body is not None:
            data = json.dumps(json_body).encode("utf-8")
            hdrs.setdefault("Content-Type", "application/json")
        req = urllib.request.Request(
            self.base_url + path, data=data, headers=hdrs, method=method
        )
        try:
            with self._opener.open(req, timeout=30) as r:
                return Reply(r.status, r.headers, r.read())
        except urllib.error.HTTPError as e:
            return Reply(e.code, e.headers, e.read())

    def get(self, path, headers=None) -> Reply:
        return self.request("GET", path, headers=headers)

    def post_form(self, path, fields, headers=None) -> Reply:
        return self.request("POST", path, fields=fields, headers=headers)

    def csrf_token(self) -> str:
        return self.get("/csrf-token").json()["csrf_token"]

    def login(self, username, password, csrf_token=None) -> Reply:
        token = self.csrf_token() if csrf_token is None else csrf_token
        return self.post_form(
            "/login",
            {"username": username, "password": password, "csrf_token": token},
        )

    def api(self, method, path, fields=None, json_body=None, files=None) -> Reply:
        """A state-changing or JSON call the way the front end makes it: CSRF header from the
        current session plus an Accept: application/json header."""
        headers = dict(JSON_HEADERS)
        if method not in ("GET", "HEAD"):
            headers["X-CSRFToken"] = self.csrf_token()
        return self.request(
            method,
            path,
            fields=fields,
            json_body=json_body,
            headers=headers,
            files=files,
        )

    def cookie_header(self) -> str:
        return "; ".join(f"{c.name}={c.value}" for c in self.jar)


class ScratchServer:
    def __init__(self, root, port, proc, log_path, real_hashes):
        self.root = Path(root)
        self.port = port
        self.proc = proc
        self.log_path = Path(log_path)
        self.base_url = f"http://127.0.0.1:{port}"
        self.real_config_hashes = real_hashes
        self._opener = urllib.request.build_opener(_NoRedirect)
        self.users = dict(TEST_USERS)
        self.storage = self.root / "data" / "storage"
        self.stop_file = self.root / ".manage_pids" / "dev.stop"
        self.log_handle = None  # set by start_scratch_server

    def client(self, ip=None) -> HttpClient:
        """A new anonymous browser-like client with its own fake IP (own rate-limit bucket)."""
        return HttpClient(self.base_url, ip)

    def login_as(self, username) -> HttpClient:
        """A new client already logged in as one of TEST_USERS."""
        client = self.client()
        reply = client.login(username, self.users[username][0])
        assert reply.status == 302, f"login as {username} failed: {reply.status}"
        return client

    def db(self, code, *args) -> str:
        """Run Python against the SCRATCH database (`db` is database.db); returns stdout."""
        return run_in_scratch(self.root, code, *args)

    def make_user(self, role="readwrite"):
        """Create a throw-away account in the scratch database; returns (name, password)."""
        name, password = f"tmp_{uuid.uuid4().hex[:10]}", f"Tmp-{uuid.uuid4().hex[:12]}!"
        self.db(
            "assert db.add_user(sys.argv[1], sys.argv[2], sys.argv[3])",
            name,
            password,
            role,
        )
        return name, password

    def get(self, path, headers=None):
        """GET without following redirects. Returns (status, headers, body_bytes)."""
        req = urllib.request.Request(self.base_url + path, headers=headers or {})
        try:
            with self._opener.open(req, timeout=15) as r:
                return r.status, dict(r.headers), r.read()
        except urllib.error.HTTPError as e:
            return e.code, dict(e.headers), e.read()

    def log_tail(self, n=40) -> str:
        try:
            lines = self.log_path.read_text("utf-8", errors="replace").splitlines()
        except OSError:
            return "(no log)"
        return "\n".join(lines[-n:])


def seed_scratch_users(root) -> None:
    """Create TEST_USERS in the scratch database (before the server starts)."""
    run_in_scratch(root, _SEED_CODE, json.dumps(TEST_USERS))


def stop_scratch_server(server) -> None:
    """Stop a server started by start_scratch_server the way manage.sh does (the stop file that
    dev_server.py watches), then terminate / kill it if it does not exit. Safe to call twice.
    """
    proc = server.proc
    if proc.poll() is None:
        with suppress(OSError):  # best-effort stop request
            server.stop_file.write_text("stop", "utf-8")
        try:
            proc.wait(timeout=20)
        except subprocess.TimeoutExpired:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
    if server.log_handle is not None:
        server.log_handle.close()
        server.log_handle = None


def start_scratch_server(root, port, real_hashes=None) -> "ScratchServer":
    """Start dev_server.py inside the scratch copy `root` on `port` and wait until it answers.

    Returns a ScratchServer; the caller stops it with stop_scratch_server. The log file is opened
    for appending, so a restarted server keeps the log of its first run. Fails the test (after
    stopping the process) when the server exits early or does not answer within 90 s.
    """
    root = Path(root)
    (root / ".manage_pids").mkdir(exist_ok=True)
    log_path = root / "scratch_server.log"
    env = {k: v for k, v in os.environ.items() if k not in ("PYTHONPATH",)}
    env.update(
        {
            "PYTHONUTF8": "1",
            "PYTHONIOENCODING": "utf-8",
            # The server's stdout goes to a FILE (block-buffered), so a test that looks for a log
            # line would wait for the buffer to fill. dev_server.py sets this itself, but only
            # after its imports, which is too late for the lines printed during startup (5.41).
            "PYTHONUNBUFFERED": "1",
            "CLOUDINATOR_BG": "1",  # no reloader (see dev_server.py)
            "CLOUDINATOR_FTP_ROOT": str(root / "data" / "storage"),
        }
    )
    env.update(child_gil_environment())
    env.pop("CLOUDINATOR_PUBLIC_DOMAIN", None)

    log = open(log_path, "ab")
    proc = subprocess.Popen(
        [sys.executable, "dev_server.py"],
        cwd=str(root),
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=log,
        stderr=subprocess.STDOUT,
    )
    server = ScratchServer(
        root, port, proc, log_path, real_hashes or _hash_real_configs()
    )
    server.log_handle = log
    deadline = time.monotonic() + 90
    while True:
        if proc.poll() is not None:
            code = proc.returncode
            stop_scratch_server(server)
            pytest.fail(
                f"scratch server exited with code {code} during startup:\n"
                + server.log_tail()
            )
        try:
            server.get("/login")
            return server  # any HTTP answer means the server is up
        except (urllib.error.URLError, OSError):
            if time.monotonic() > deadline:
                tail = server.log_tail()
                stop_scratch_server(server)
                pytest.fail("scratch server did not answer in 90 s:\n" + tail)
            time.sleep(0.5)


def _build_isolated_scratch(tmp_path_factory, name, config=None):
    """A scratch copy with the test accounts, checked to lie completely inside its own folder.
    Returns (root, port); refuses (and starts nothing) if the isolation check fails."""
    root = tmp_path_factory.mktemp(name) / "app"
    port = free_port()
    build_scratch(root, port=port, config=config)
    violations = paths_outside(root)
    if violations:  # refuse to start anything; this is the production-data safety net
        pytest.fail(
            "scratch isolation check failed, nothing started:\n" + "\n".join(violations)
        )
    seed_scratch_users(root)
    return root, port


@pytest.fixture(scope="session")
def scratch_server(tmp_path_factory):
    """Start dev_server.py from a scratch copy of the project on an ephemeral port."""
    if not (REPO_ROOT / "dev_server.py").exists():
        pytest.skip("dev_server.py not found next to tests/")
    real_hashes = _hash_real_configs()
    root, port = _build_isolated_scratch(tmp_path_factory, "cloudinator_scratch")
    server = start_scratch_server(root, port, real_hashes)
    try:
        yield server
    finally:
        stop_scratch_server(server)


# 5.40: a second scratch server with the Version Engine ON. The engine is its own worker process
# (version_engine.py --worker, started by dev_server.py), so a capture needs real time: the
# watcher polls every 3 s. Tests that use this fixture wait with a bounded poll (see
# tests/reliability/test_version_engine_live.py); they are opt-in (CLOUDINATOR_SLOW_TESTS=1).
def version_engine_config(storage_dir) -> dict:
    return {
        "VERSION_ENGINE_ENABLED": True,
        "VERSION_TRACK_ALL_FILES": True,
        "VERSION_TRACK_ROOTS": [str(storage_dir)],
        "VERSION_WATCH_ENABLED": True,
        "VERSION_SCAN_ENABLED": True,
        "VERSION_SCAN_INTERVAL": 5,
        "VERSION_RETENTION_ENABLED": False,
    }


@pytest.fixture(scope="session")
def scratch_server_with_versions(tmp_path_factory):
    """Like scratch_server, but with the Version Engine tracking the scratch storage folder."""
    if not (REPO_ROOT / "dev_server.py").exists():
        pytest.skip("dev_server.py not found next to tests/")
    real_hashes = _hash_real_configs()
    name = "cloudinator_scratch_versions"
    root = tmp_path_factory.mktemp(name) / "app"
    port = free_port()
    storage = root / "data" / "storage"
    build_scratch(root, port=port, config=version_engine_config(storage))
    violations = paths_outside(root)
    cfg = json.loads((root / "server_config.json").read_text("utf-8"))
    violations += [
        f"VERSION_TRACK_ROOTS entry outside the scratch folder: {r}"
        for r in cfg["VERSION_TRACK_ROOTS"]
        if not _is_inside(r, root)
    ]
    if violations:
        pytest.fail(
            "scratch isolation check failed, nothing started:\n" + "\n".join(violations)
        )
    seed_scratch_users(root)
    server = start_scratch_server(root, port, real_hashes)
    try:
        yield server
    finally:
        stop_scratch_server(server)
