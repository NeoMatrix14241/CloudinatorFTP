"""
routes/uploads.py - uploads, chunks, assembly and the cleanup schedulers: /upload, /cleanup_chunks,
/cancel_upload, /admin/cleanup_chunks, /admin/chunk_stats, /admin/upload_status,
/api/assembly_status*, /api/protect_assembly and the start_* startup functions
(Phase 8 of the split, CLAUDE.md 4.76).

Moved verbatim from app.py. Nothing here runs at import: the schedulers and the assembly worker
are started by initialize_cleanup(), which stays in app.py. Gets shared objects via
`from core import ...`; imports routes.shares only for _prune_expired_shares.
"""

from core import (
    _trigger_reconcile,
    app,
    assembly_queue,
    chunk_tracker,
    get_protected_files,
    login_required,
)

from quart import jsonify, request, session
from werkzeug.exceptions import ClientDisconnected
import os
import shutil
import json
import hashlib
import asyncio
import threading
import time
import uuid
import queue
from config import (
    ROOT_DIR,
    CHUNK_SIZE,
    ENABLE_CHUNKED_UPLOADS,
    ALLOWED_EXTENSIONS,
    UPLOAD_CHUNKS_IN_MEMORY,
    UPLOAD_TIMING_ENABLED,
)
from database import db
from auth import current_user, get_role
import storage
from helpers.upload_perf import (
    IdleDeferral,
    LagProbeStarter,
    StageTimer,
    UploadTimingLog,
    parse_form_in_memory,
)
from routes.shares import _prune_expired_shares

# ---------------------------------------------------------------------------
# Upload performance (CLAUDE.md 5.41); the helpers live in helpers/upload_perf.py.
#  * /upload reads and writes the piece in a worker thread (_read_and_save_chunk): both are
#    synchronous disk work on up to CHUNK_SIZE bytes and used to run on the event-loop thread.
#  * config.UPLOAD_TIMING_ENABLED (default False) logs the time of each stage of every chunk and
#    starts an event-loop lag probe with the first upload request (no startup hook: smoke check 5).
#  * config.UPLOAD_CHUNKS_IN_MEMORY (default True since 5.43) parses a chunk-sized body in RAM
#    instead of in a temp file in the system temp folder (_upload_form_and_files); with the timing
#    log on, that stage is also split into "body arrived" and "parse".
#  * the reconcile walk that follows an assembly waits while another upload is still sending
#    (_reconcile_after_uploads).
# ---------------------------------------------------------------------------
_IN_MEMORY_BODY_MARGIN = 1024 * 1024  # multipart framing and the small text fields
_CSRF_HEADER_NAMES = ("X-CSRFToken", "X-CSRF-Token")

_upload_timing_log = UploadTimingLog()
_lag_probe = LagProbeStarter()


def _uploads_in_flight():
    """True while an upload still has chunks to send: an assembled upload is already untracked
    (AssemblyQueue.complete_job), and an abandoned one stays tracked until the interrupted-upload
    cleanup, which is why _reconcile_after_uploads has a cap."""
    with chunk_tracker.lock:
        return bool(chunk_tracker.active_uploads)


# The count-correcting walk after the assembly queue drains costs one stat per file. While another
# upload is still sending chunks it competes with the chunk writes for the disk, so it waits (it
# re-checks every 5 s) and runs once the last upload is done, or after 10 minutes at the latest.
_reconcile_after_uploads = IdleDeferral(
    action=_trigger_reconcile,
    busy=_uploads_in_flight,
    interval=5.0,
    max_wait=600.0,
)


def _in_memory_parse_wanted():
    """True when THIS request's body should be parsed in RAM (config.UPLOAD_CHUNKS_IN_MEMORY):
    a multipart body of known size up to one chunk plus framing. Only when the CSRF token came in
    a header: otherwise the CSRF hook has already read the form with Quart's parser and the body
    is gone."""
    if not UPLOAD_CHUNKS_IN_MEMORY:
        return False
    if not any(request.headers.get(name) for name in _CSRF_HEADER_NAMES):
        return False
    length = request.content_length
    return (
        length is not None
        and 0 < length <= CHUNK_SIZE + _IN_MEMORY_BODY_MARGIN
        and (request.mimetype or "").startswith("multipart/form-data")
    )


async def _upload_form_and_files(in_memory=None, timer=None):
    """(form, files) of the current request: Quart's parser (a temp file per file part), or, with
    UPLOAD_CHUNKS_IN_MEMORY and a small enough body, the body read into RAM and parsed without
    one. Both give werkzeug MultiDicts of strings and FileStorage objects. `in_memory` is the
    answer of _in_memory_parse_wanted() when the caller already has it.

    5.43: given a StageTimer, the RAM path tells it how its stage divides: how long the body took
    to ARRIVE (awaiting it) and how long the PARSE took (synchronous, on the event-loop thread).
    Quart's own parser reads and parses the body piece by piece as it arrives, so that path cannot
    be divided and reports nothing."""
    if in_memory is None:
        in_memory = _in_memory_parse_wanted()
    if in_memory:
        started = time.perf_counter()
        body = await request.get_data(cache=False)  # Quart drops its copy at once
        arrived = time.perf_counter() - started
        started = time.perf_counter()
        parsed = parse_form_in_memory(body, request.content_type)
        if timer is not None:
            timer.detail("body arrived", arrived)
            timer.detail("parse", time.perf_counter() - started)
        return parsed
    return await request.form, await request.files


def _read_and_save_chunk(chunk, chunk_key, chunk_num):
    """Runs in a worker thread (asyncio.to_thread): read the uploaded piece and write it under
    .chunks/. Returns (outcome, read_seconds, save_seconds, size); outcome is "saved",
    "too_large" or "failed"."""
    started = time.perf_counter()
    chunk_data = chunk.read()
    read_seconds = time.perf_counter() - started
    size = len(chunk_data)
    if size > CHUNK_SIZE:
        return "too_large", read_seconds, 0.0, size
    started = time.perf_counter()
    saved = storage.save_chunk(chunk_key, chunk_num, chunk_data)
    save_seconds = time.perf_counter() - started
    return ("saved" if saved else "failed"), read_seconds, save_seconds, size


# ---------------------------------------------------------------------------
# Upload ids (CLAUDE.md 5.16). The browser sends an id per file (index.js,
# generateFileId); it is only unique inside ONE page, so two users (or two
# tabs) could send the same id. Everything on the server (chunk folder under
# .chunks/, chunk_tracker, assembly_queue) therefore uses a CHUNK KEY =
# <16 hex of sha256(session_id)>_<client id>; the client id itself is what the
# browser sees in every response and URL. A session can only ever reach the keys
# of its own session id, so one user cannot read, overwrite or cancel another
# user's chunks, and a status lookup of a foreign id is simply "not found".
# ---------------------------------------------------------------------------
MAX_CLIENT_UPLOAD_ID_LEN = 128  # the key adds 17 chars and must stay under 200


def _valid_client_upload_id(file_id):
    """A client upload id: a safe single folder name, at most 128 characters."""
    return (
        isinstance(file_id, str)
        and len(file_id) <= MAX_CLIENT_UPLOAD_ID_LEN
        and storage.is_safe_chunk_id(file_id)
    )


def _key_prefix(session_id):
    return hashlib.sha256(str(session_id).encode("utf-8")).hexdigest()[:16] + "_"


def _chunk_key(session_id, file_id):
    """Server-side id of this session's upload `file_id`; None when either is unusable."""
    if not session_id or not _valid_client_upload_id(file_id):
        return None
    return _key_prefix(session_id) + file_id


def _client_file_id(session_id, key):
    """The id the browser used for chunk key `key` (the key itself if it has no prefix)."""
    prefix = _key_prefix(session_id)
    if isinstance(key, str) and key.startswith(prefix):
        return key[len(prefix) :]
    return key


@app.route("/upload", methods=["POST"])
@login_required
async def upload():
    session_id = session.get("session_id")
    if not session_id:
        session_id = str(uuid.uuid4())
        session["session_id"] = session_id

    # Initialize these variables outside the try block to ensure they're available in the except blocks
    file_id = None
    chunk_key = (
        None  # server-side id (session + client id), set once file_id is validated
    )
    filename = None
    timer = StageTimer(UPLOAD_TIMING_ENABLED)
    if UPLOAD_TIMING_ENABLED:
        _lag_probe.start_once(app)

    try:
        role = get_role(current_user())
        if role != "readwrite":
            return "Permission denied", 403
        timer.mark("role")

        in_memory = _in_memory_parse_wanted()
        form, files = await _upload_form_and_files(in_memory, timer)
        timer.mark("receive+parse (RAM)" if in_memory else "receive+parse")
        file_id = form.get("file_id")
        chunk_num = form.get("chunk_num")
        total_chunks = form.get("total_chunks")
        filename = form.get("filename", "")
        dest_path = form.get("dest_path", "")

        # Validate filename (must not be empty)
        if not filename:
            return "Filename is required", 400

        # Remove all sanitization, only check for empty and slashes
        if "/" in filename or "\\" in filename:
            return "Invalid filename", 400

        # Enforce configured file-type allowlist, if one is set.
        # ALLOWED_EXTENSIONS = None means "allow all" (config.py default).
        if ALLOWED_EXTENSIONS is not None:
            ext = os.path.splitext(filename)[1].lower().lstrip(".")
            if ext not in ALLOWED_EXTENSIONS:
                return (
                    f"File type '.{ext}' not allowed. Allowed types: "
                    f"{', '.join(sorted(ALLOWED_EXTENSIONS))}",
                    400,
                )

        # Security check: ensure destination path is safe
        if dest_path and not storage.is_safe_path(dest_path):
            return "Invalid destination path", 400

        if (
            ENABLE_CHUNKED_UPLOADS
            and chunk_num is not None
            and total_chunks is not None
        ):
            # Chunked upload handling
            try:
                chunk_num = int(chunk_num)
                total_chunks = int(total_chunks)
            except ValueError:
                return "Invalid chunk parameters", 400

            if not file_id:
                return "File ID is required for chunked upload", 400
            if not _valid_client_upload_id(file_id):
                return "Invalid file ID", 400
            if total_chunks < 1 or not 0 <= chunk_num < total_chunks:
                return "Invalid chunk parameters", 400
            chunk_key = _chunk_key(session_id, file_id)

            # Track this upload
            chunk_tracker.track_upload(session_id, chunk_key)

            chunk = files.get("chunk")
            if not chunk:
                return "No chunk data received", 400

            # Read the piece and save it in a worker thread: on the event-loop thread this
            # synchronous disk work stops every other request (and the receiving of other
            # uploads) for as long as the disk takes.
            outcome, read_seconds, save_seconds, chunk_size = await asyncio.to_thread(
                _read_and_save_chunk, chunk, chunk_key, chunk_num
            )
            timer.mark("read+save")
            timer.note("read", read_seconds)
            timer.note("save", save_seconds)
            if outcome == "too_large":
                return f"Chunk too large (max {CHUNK_SIZE} bytes)", 413

            if outcome != "saved":
                # Cleanup on failure
                chunk_tracker.untrack_upload(session_id, chunk_key)
                await asyncio.to_thread(storage.cleanup_chunks, chunk_key)
                return "Failed to save chunk", 500
            _upload_timing_log.report(
                timer, chunk_size, f"chunk {chunk_num + 1}/{total_chunks}"
            )

            print(
                f"📦 Saved chunk {chunk_num + 1}/{total_chunks} for {filename} (ID: {file_id})"
            )

            # Queue the background assembly as soon as EVERY chunk 0..total-1 is on disk,
            # whatever order they arrived in (5.16; before, only the chunk numbered
            # total-1 could start it, so an early last chunk left the upload hanging).
            # One worker call per chunk (5.44): this is up to total_chunks stats, and it runs
            # after EVERY chunk of the upload.
            if await asyncio.to_thread(
                storage.chunks_complete, chunk_key, total_chunks
            ):
                existing_job = assembly_queue.get_job_status(chunk_key)
                if existing_job and existing_job.status in ("pending", "processing"):
                    # A retry of a chunk after the job was queued: never assemble twice.
                    return (
                        jsonify(
                            {
                                "status": "upload_complete",
                                "message": f"Upload complete - processing {filename}...",
                                "file_id": file_id,
                                "assembly_queued": True,
                            }
                        ),
                        200,
                    )
                try:
                    # Save metadata for assembly worker
                    chunk_dir = os.path.join(ROOT_DIR, ".chunks", chunk_key)
                    metadata_file = os.path.join(chunk_dir, ".metadata")
                    metadata = {
                        "filename": filename,
                        "dest_path": dest_path,
                        "total_chunks": total_chunks,
                        "session_id": session_id,
                        "timestamp": time.time(),
                    }
                    with open(metadata_file, "w") as f:
                        json.dump(metadata, f)

                    # Add to background assembly queue
                    assembly_queue.add_job(
                        chunk_key, filename, dest_path, total_chunks, session_id
                    )

                    print(f"🔄 Queued {filename} for background assembly")
                    return (
                        jsonify(
                            {
                                "status": "upload_complete",
                                "message": f"Upload complete - processing {filename}...",
                                "file_id": file_id,
                                "assembly_queued": True,
                            }
                        ),
                        200,
                    )

                except Exception as e:
                    # Failed to queue assembly - cleanup
                    chunk_tracker.untrack_upload(session_id, chunk_key)
                    await asyncio.to_thread(storage.cleanup_chunks, chunk_key)
                    print(f"❌ Failed to queue assembly for {filename}: {e}")
                    return f"Failed to queue file assembly: {str(e)}", 500

            return f"Chunk {chunk_num + 1}/{total_chunks} uploaded successfully", 200

        else:
            # Whole file upload handling
            uploaded_file = files.get("file")
            if not uploaded_file or uploaded_file.filename == "":
                return "No file selected", 400

            # `filename` was already validated as non-empty above, so there is no
            # fallback to uploaded_file.filename. Only check for slashes
            if "/" in filename or "\\" in filename:
                return "Invalid filename", 400

            # Construct target path
            target_dir = os.path.join(ROOT_DIR, dest_path) if dest_path else ROOT_DIR
            target_path = os.path.join(target_dir, filename)

            # Ensure target directory exists
            os.makedirs(target_dir, exist_ok=True)

            # Conflict check: return 409 if file exists and overwrite not explicitly requested
            overwrite = form.get("overwrite", "0")
            if (
                os.path.exists(target_path)
                and os.path.isfile(target_path)
                and overwrite != "1"
            ):
                return "File already exists", 409

            # Save file — retry on Windows file-lock errors (e.g. FastCopy holding a write lock).
            # Without this, save() blocks indefinitely waiting for the lock to release,
            # which stalls the request and freezes the entire upload queue.
            max_attempts = 3
            for attempt in range(max_attempts):
                try:
                    uploaded_file.stream.seek(0)
                    await uploaded_file.save(target_path)
                    return "File uploaded successfully", 200
                except PermissionError as e:
                    if attempt < max_attempts - 1:
                        await asyncio.sleep(0.5)
                    else:
                        print(
                            f"❌ File locked after {max_attempts} attempts: {filename} — {e}"
                        )
                        return f"File is locked by another process: {str(e)}", 423
                except Exception as e:
                    print(f"❌ Failed to save whole file {filename}: {e}")
                    return f"Failed to save file: {str(e)}", 500

            # Not reached in practice (the last attempt always returns above); kept so
            # every code path of this route returns a response explicitly.
            return "Failed to save file", 500

    except ClientDisconnected:
        print(
            f"👋 Client disconnected during upload of {filename or 'unknown file'} (ID: {file_id})"
        )
        # Untrack immediately (fast), but run the actual disk cleanup in the background
        # so this handler returns without blocking a Waitress thread on safe_rmtree.
        if chunk_key:
            chunk_tracker.untrack_upload(session_id, chunk_key)

            def _bg_disconnect_cleanup(fid):
                try:
                    storage.cleanup_chunks(fid)
                    print(f"🧹 Background disconnect cleanup done: {fid}")
                except Exception as ex:
                    print(f"⚠️ Background disconnect cleanup error for {fid}: {ex}")

            threading.Thread(
                target=_bg_disconnect_cleanup,
                args=(chunk_key,),
                daemon=True,
                name="upload-disconnect-cleanup",
            ).start()
        return "", 499

    except Exception as e:
        print(f"❌ Upload error: {e}")
        # If there was an error and we were tracking this upload, clean it up
        if chunk_key:
            chunk_tracker.untrack_upload(session_id, chunk_key)
            try:
                await asyncio.to_thread(storage.cleanup_chunks, chunk_key)
            except Exception as cleanup_error:
                # Never let a failing cleanup replace the error text the browser shows.
                print(
                    f"⚠️ Chunk cleanup after the upload error failed: {cleanup_error}"
                )
        return f"Upload error: {str(e)}", 500


def _remove_chunk_folder_sync(chunk_key, file_id):
    """Worker-thread body of the /cleanup_chunks route (5.44). True = the folder existed and
    was removed, False = nothing to clean; an OSError from the delete is raised to the route
    (which answers 500 as before). NOT storage.cleanup_chunks on purpose: the route has its
    own messages and does not honour the `.assembling` marker."""
    chunks_dir = os.path.join(ROOT_DIR, ".chunks", chunk_key)
    removed = False
    if os.path.exists(chunks_dir):
        shutil.rmtree(chunks_dir)
        print(f"🧹 Manual cleanup completed for: {file_id}")

        # Try to remove parent chunks directory if empty
        parent_chunks_dir = os.path.join(ROOT_DIR, ".chunks")
        if os.path.exists(parent_chunks_dir) and not os.listdir(parent_chunks_dir):
            os.rmdir(parent_chunks_dir)
            print("🧹 Removed empty chunks directory")
        removed = True
    return removed


@app.route("/cleanup_chunks", methods=["POST"])
@login_required
async def cleanup_chunks():
    """Clean up unfinished chunk files"""
    session_id = session.get("session_id")

    try:
        role = get_role(current_user())
        if role != "readwrite":
            return jsonify({"error": "Permission denied"}), 403

        data = await request.get_json()
        if not data or "file_id" not in data:
            return jsonify({"error": "File ID is required"}), 400

        file_id = data["file_id"]
        if not _valid_client_upload_id(file_id):
            return jsonify({"error": "Invalid file ID"}), 400

        # A session only reaches its own chunk folders; no session id = nothing of its own
        chunk_key = _chunk_key(session_id, file_id)
        if chunk_key is None:
            return jsonify({"success": True, "message": "No chunks to cleanup"}), 200

        # Untrack and cleanup
        chunk_tracker.untrack_upload(session_id, chunk_key)

        # Clean up chunks directory for this upload (rmtree of up to ~190 files of 10 MB:
        # in a worker thread since 5.44)
        try:
            removed = await asyncio.to_thread(
                _remove_chunk_folder_sync, chunk_key, file_id
            )
        except Exception as e:
            print(f"❌ Failed to cleanup chunks for {file_id}: {e}")
            return jsonify({"error": f"Failed to cleanup chunks: {str(e)}"}), 500
        if removed:
            return (
                jsonify(
                    {"success": True, "message": f"Cleaned up chunks for {file_id}"}
                ),
                200,
            )
        return jsonify({"success": True, "message": "No chunks to cleanup"}), 200

    except Exception as e:
        print(f"❌ Cleanup error: {e}")
        return jsonify({"error": f"Cleanup error: {str(e)}"}), 500


@app.route("/cancel_upload", methods=["POST"])
@login_required
async def cancel_upload():
    """Cancel an ongoing upload and clean up its chunks"""
    session_id = session.get("session_id")

    try:
        role = get_role(current_user())
        if role != "readwrite":
            return jsonify({"error": "Permission denied"}), 403

        data = await request.get_json()
        if not data or "file_id" not in data:
            return jsonify({"error": "File ID is required"}), 400

        file_id = data["file_id"]
        if not _valid_client_upload_id(file_id):
            return jsonify({"error": "Invalid file ID"}), 400
        filename = data.get("filename", "Unknown file")

        print(f"🚫 Cancelling upload: {file_id} ({filename})")

        # A session only reaches its own chunk folders (see _chunk_key)
        chunk_key = _chunk_key(session_id, file_id)

        # Untrack the upload
        if chunk_key:
            chunk_tracker.untrack_upload(session_id, chunk_key)

        # Clean up chunks directory for this upload
        chunks_dir = os.path.join(ROOT_DIR, ".chunks", chunk_key) if chunk_key else None
        if chunks_dir and os.path.exists(chunks_dir):
            try:
                # Run deletion in a daemon thread so this endpoint returns immediately
                # and does NOT block a Waitress thread (safe_rmtree can stall on Windows
                # file locks, which previously exhausted the thread pool when multiple
                # cancellations arrived at the same time).
                def _bg_cleanup(cdir, fid):
                    try:
                        storage.safe_rmtree(cdir)
                        print(f"🧹 Background cancelled-upload cleanup done: {fid}")
                        parent = os.path.join(ROOT_DIR, ".chunks")
                        if os.path.exists(parent):
                            try:
                                if not os.listdir(parent):
                                    os.rmdir(parent)
                            except OSError:
                                # The .chunks folder is busy or already gone; it is removed on a later cleanup.
                                pass
                    except Exception as ex:
                        print(f"⚠️ Background cleanup error for {fid}: {ex}")

                threading.Thread(
                    target=_bg_cleanup,
                    args=(chunks_dir, chunk_key),
                    daemon=True,
                    name="upload-cancel-cleanup",
                ).start()
                print(f"🧹 Queued background cleanup for cancelled upload: {file_id}")

                return (
                    jsonify(
                        {
                            "success": True,
                            "message": f"Upload cancelled and cleanup queued for {filename}",
                            "file_id": file_id,
                        }
                    ),
                    200,
                )
            except Exception as e:
                print(f"❌ Failed to queue cleanup for cancelled upload {file_id}: {e}")
                return (
                    jsonify({"error": f"Failed to cleanup cancelled upload: {str(e)}"}),
                    500,
                )
        else:
            # Upload was cancelled before any chunks were created
            return (
                jsonify(
                    {
                        "success": True,
                        "message": f"Upload cancelled for {filename}",
                        "file_id": file_id,
                    }
                ),
                200,
            )

    except Exception as e:
        print(f"❌ Cancel upload error: {e}")
        return jsonify({"error": f"Cancel upload error: {str(e)}"}), 500


def _admin_cleanup_sync():
    """Worker-thread body of /admin/cleanup_chunks (5.44), same steps in the same order as
    the handler had them inline. Returns (stats_before, stats_after, manual_success)."""
    # Get stats before cleanup
    stats_before = chunk_tracker.get_stats()

    # Cleanup orphaned chunks
    chunk_tracker.cleanup_orphaned_chunks()

    # Cleanup interrupted uploads
    chunk_tracker.cleanup_interrupted_uploads()

    # Get active assembly jobs to protect them from cleanup
    active_assembly_jobs = get_protected_files()

    if active_assembly_jobs:
        print(
            f"🔐 Manual cleanup protecting {len(active_assembly_jobs)} files currently being assembled"
        )

    # Cleanup old chunks (aggressive - 30 minutes)
    storage.cleanup_old_chunks(max_age_hours=0.5, protected_files=active_assembly_jobs)

    # Get stats after cleanup
    stats_after = chunk_tracker.get_stats()

    # Run enhanced manual cleanup
    manual_success = storage.manual_chunks_cleanup()
    return stats_before, stats_after, manual_success


@app.route("/admin/cleanup_chunks", methods=["POST"])
@login_required
async def admin_cleanup_chunks():
    """Admin endpoint to trigger comprehensive chunk cleanup"""
    try:
        role = get_role(current_user())
        if role != "readwrite":
            return jsonify({"error": "Permission denied"}), 403

        print("🧹 Starting comprehensive chunk cleanup...")

        # The whole sequence runs in ONE worker thread (5.44), in the original order.
        stats_before, stats_after, manual_success = await asyncio.to_thread(
            _admin_cleanup_sync
        )

        print("🧹 Comprehensive cleanup completed")
        print(
            f"   Sessions: {stats_before['active_sessions']} -> {stats_after['active_sessions']}"
        )
        print(
            f"   Uploads: {stats_before['active_uploads']} -> {stats_after['active_uploads']}"
        )

        return (
            jsonify(
                {
                    "success": True,
                    "message": (
                        "Comprehensive cleanup completed successfully"
                        if manual_success
                        else "Cleanup completed with some warnings"
                    ),
                    "stats_before": stats_before,
                    "stats_after": stats_after,
                    "manual_cleanup_success": manual_success,
                }
            ),
            200,
        )

    except Exception as e:
        print(f"❌ Error in comprehensive cleanup: {e}")
        # Try emergency cleanup as fallback
        try:
            await asyncio.to_thread(storage.emergency_cleanup_all)
            return (
                jsonify(
                    {
                        "success": True,
                        "message": f"Standard cleanup failed, emergency cleanup performed: {str(e)}",
                        "emergency_cleanup": True,
                    }
                ),
                200,
            )
        except Exception as emergency_error:
            return (
                jsonify(
                    {
                        "error": f"All cleanup methods failed: {str(e)} | Emergency: {str(emergency_error)}"
                    }
                ),
                500,
            )


def _list_chunk_dirs_sync():
    """Worker-thread body of chunk_stats (5.44): names of the folders under .chunks."""
    chunks_dir = os.path.join(ROOT_DIR, ".chunks")
    filesystem_chunks = []
    if os.path.exists(chunks_dir):
        try:
            filesystem_chunks = [
                d
                for d in os.listdir(chunks_dir)
                if os.path.isdir(os.path.join(chunks_dir, d))
            ]
        except OSError:
            # Chunks folder missing or unreadable; the filesystem chunk count simply stays empty.
            pass
    return filesystem_chunks


@app.route("/admin/chunk_stats", methods=["GET"])
@login_required
async def chunk_stats():
    """Get chunk tracking statistics"""
    try:
        role = get_role(current_user())
        if role != "readwrite":
            return jsonify({"error": "Permission denied"}), 403

        stats = chunk_tracker.get_stats()

        # Add filesystem stats (a listdir plus one isdir per entry: worker thread, 5.44)
        filesystem_chunks = await asyncio.to_thread(_list_chunk_dirs_sync)

        stats["filesystem_chunks"] = len(filesystem_chunks)
        stats["chunk_directories"] = filesystem_chunks

        return jsonify(stats), 200

    except Exception as e:
        print(f"❌ Error getting chunk stats: {e}")
        return jsonify({"error": f"Stats error: {str(e)}"}), 500


@app.route("/admin/upload_status", methods=["GET"])
@login_required
async def upload_status():
    """Get current upload status for UI updates"""
    try:
        role = get_role(current_user())

        # Allow readonly users to check auth status, but return limited info
        if role == "readonly":
            return jsonify(
                {
                    "authenticated": True,
                    "role": "readonly",
                    "has_active_uploads": False,
                    "session_has_active": False,
                    "total_active_sessions": 0,
                    "can_upload": False,
                }
            )

        if role != "readwrite":
            return jsonify({"error": "Permission denied"}), 403

        session_id = session.get("session_id")
        stats = chunk_tracker.get_stats()

        # Check if current session has active uploads
        session_has_active = False
        if session_id and session_id in chunk_tracker.active_uploads:
            session_has_active = len(chunk_tracker.active_uploads[session_id]) > 0

        return (
            jsonify(
                {
                    "has_active_uploads": stats["active_uploads"] > 0,
                    "session_has_active": session_has_active,
                    "total_active_sessions": stats["active_sessions"],
                    "total_active_uploads": stats["active_uploads"],
                }
            ),
            200,
        )

    except Exception as e:
        print(f"❌ Error getting upload status: {e}")
        return jsonify({"error": f"Status error: {str(e)}"}), 500


@app.route("/api/assembly_status", methods=["GET"])
@login_required
async def get_assembly_status():
    """Get all assembly jobs for current session"""
    session_id = session.get("session_id")
    if not session_id:
        return jsonify({"jobs": []}), 200

    jobs = assembly_queue.get_jobs_for_session(session_id)
    job_data = []

    for job in jobs:
        job_data.append(
            {
                "file_id": _client_file_id(session_id, job.file_id),
                "filename": job.filename,
                "status": job.status,
                "created_at": job.created_at,
                "error_message": job.error_message,
            }
        )

    return jsonify({"jobs": job_data}), 200


@app.route("/api/protect_assembly/<file_id>", methods=["POST"])
@login_required
async def protect_assembly_job(file_id):
    """Mark an assembly job as protected from cleanup"""
    session_id = session.get("session_id")
    if not session_id:
        return jsonify({"error": "No session ID"}), 400

    # Check if this job belongs to the current session
    chunk_key = _chunk_key(session_id, file_id)
    job = assembly_queue.get_job_status(chunk_key) if chunk_key else None
    if job and job.session_id == session_id:
        # Re-track this upload to prevent cleanup
        chunk_tracker.track_upload(session_id, chunk_key)
        print(f"🔐 Protected assembly job {file_id} from cleanup")
        return jsonify({"status": "protected"}), 200

    return jsonify({"error": "Job not found or access denied"}), 404


@app.route("/api/assembly_status/<file_id>", methods=["GET"])
@login_required
async def get_single_assembly_status(file_id):
    """Get status of a specific assembly job"""
    session_id = session.get("session_id")
    chunk_key = _chunk_key(session_id, file_id)
    job = assembly_queue.get_job_status(chunk_key) if chunk_key else None

    # Another session's job has another chunk key, so it is "not found" here
    if not job or job.session_id != session_id:
        return jsonify({"error": "Job not found"}), 404

    return (
        jsonify(
            {
                "file_id": file_id,
                "filename": job.filename,
                "status": job.status,
                "created_at": job.created_at,
                "error_message": job.error_message,
            }
        ),
        200,
    )


# Enhanced cleanup scheduler functions
def start_enhanced_cleanup_scheduler():
    """Start enhanced background thread for chunk cleanup"""

    def cleanup_worker():
        while True:
            try:
                # More frequent cleanup - every 15 minutes for stale chunks
                time.sleep(900)  # 15 minutes
                print("🧹 Running enhanced chunk cleanup...")

                # Get active assembly jobs to protect them from cleanup
                active_assembly_jobs = get_protected_files()

                if active_assembly_jobs:
                    print(
                        f"🔐 Protecting {len(active_assembly_jobs)} files from periodic cleanup"
                    )

                storage.cleanup_old_chunks(
                    max_age_hours=1, protected_files=active_assembly_jobs
                )  # Clean 1+ hour old chunks

                # Every 4th run (1 hour), do the full 24-hour cleanup
                cleanup_counter = getattr(cleanup_worker, "counter", 0) + 1
                cleanup_worker.counter = cleanup_counter

                if cleanup_counter % 4 == 0:  # Every hour
                    print("🧹 Running full chunk cleanup...")
                    storage.cleanup_old_chunks(
                        max_age_hours=24, protected_files=active_assembly_jobs
                    )

            except Exception as e:
                print(f"❌ Error in enhanced cleanup worker: {e}")

    cleanup_thread = threading.Thread(
        target=cleanup_worker, daemon=True, name="chunk-cleanup-scheduler"
    )
    cleanup_thread.start()
    print("🧹 Started enhanced chunk cleanup scheduler (every 15 minutes)")


def start_orphan_cleanup_scheduler():
    """Start a background thread to cleanup orphaned chunks and detect interruptions"""

    def orphan_cleanup_worker():
        while True:
            try:
                time.sleep(300)  # Every 5 minutes
                chunk_tracker.cleanup_orphaned_chunks()
                chunk_tracker.cleanup_interrupted_uploads()
            except Exception as e:
                print(f"❌ Error in orphan cleanup worker: {e}")

    cleanup_thread = threading.Thread(
        target=orphan_cleanup_worker, daemon=True, name="orphan-cleanup-scheduler"
    )
    cleanup_thread.start()
    print("🗑️ Started enhanced orphaned chunk cleanup scheduler (every 5 minutes)")


def start_expired_share_cleanup_scheduler():
    """Start a background thread that periodically revokes expired shares.

    _get_live_share() and _prune_expired_shares() already revoke an expired
    share lazily the moment any visitor route or admin fetch touches it,
    but a share nobody ever revisits after it expires would otherwise sit
    in the DB — and in the Manage Shared → Active Shares list / revoke-all
    count — until someone happens to look. This sweep is what makes expiry
    removal actually "live" for an admin who just has the tab open and
    idle: it runs frequently and (via _prune_expired_shares) broadcasts an
    active_shares_changed SSE event to every connected admin the moment it
    revokes something, rather than depending on a client-side setTimeout
    that browsers can throttle/suspend in a backgrounded tab, or on the
    admin manually triggering a refetch (switching tabs, etc).
    """

    def expired_share_cleanup_worker():
        while True:
            try:
                _prune_expired_shares(db.list_active_shares())
            except Exception as e:
                print(f"❌ Error in expired share cleanup worker: {e}")
            time.sleep(15)  # frequent enough to feel live, cheap enough to not matter

    cleanup_thread = threading.Thread(
        target=expired_share_cleanup_worker, daemon=True, name="share-expiry-cleanup"
    )
    cleanup_thread.start()
    print("🔗 Started expired share cleanup scheduler (every 15 seconds)")


def assembly_worker():
    """Background worker that processes assembly jobs"""
    print("🔄 Assembly worker started")

    while True:
        try:
            # Get next job from queue (blocks until available)
            job = assembly_queue.job_queue.get(timeout=10)

            print(f"🔨 Processing assembly job: {job.filename} (ID: {job.file_id})")

            # Update job status to processing
            with assembly_queue.lock:
                if job.file_id in assembly_queue.active_jobs:
                    assembly_queue.active_jobs[job.file_id].status = "processing"

            try:
                # Perform the actual assembly
                success = storage.assemble_chunks(
                    job.file_id, job.filename, job.dest_path, job.total_chunks
                )

                if success:
                    assembly_queue.complete_job(job.file_id, success=True)
                    print(f"✅ Successfully assembled: {job.filename}")
                else:
                    assembly_queue.complete_job(
                        job.file_id,
                        success=False,
                        error_message="Assembly failed - see server logs",
                    )
                    print(f"❌ Assembly failed: {job.filename}")

            except Exception as e:
                error_msg = str(e)
                assembly_queue.complete_job(
                    job.file_id, success=False, error_message=error_msg
                )
                print(f"❌ Assembly error for {job.filename}: {error_msg}")

            # Mark queue task as done
            assembly_queue.job_queue.task_done()

            # When the assembly queue drains to zero, trigger an immediate reconcile
            # so the file count corrects itself right away. Use _trigger_reconcile (not
            # reconcile_async) so the SSE force-push fires even if watchdog already
            # updated the counters and _reconcile sees no drift. 5.41: while ANOTHER upload
            # is still sending chunks the walk waits for it (_reconcile_after_uploads).
            if assembly_queue.job_queue.empty() and not assembly_queue.active_jobs:
                _reconcile_after_uploads.request()

        except queue.Empty:
            # Timeout - cleanup old jobs periodically
            assembly_queue.cleanup_old_jobs()
            continue
        except Exception as e:
            print(f"❌ Assembly worker error: {e}")
            time.sleep(1)


def start_assembly_worker():
    """Start the background assembly worker"""
    worker_thread = threading.Thread(
        target=assembly_worker, daemon=True, name="assembly-worker"
    )
    worker_thread.start()
    print("🚀 Started background assembly worker")


def _read_upload_metadata(chunk_dir):
    """The `.metadata` of an upload folder as (filename, dest_path, total_chunks), or None.

    `.metadata` is written by /upload only when EVERY chunk has arrived (5.16), so its presence
    is what says "this upload was complete". None when the file is missing, unreadable or does
    not hold a usable filename and chunk count."""
    metadata_file = os.path.join(chunk_dir, ".metadata")
    if not os.path.isfile(metadata_file):
        return None
    try:
        with open(metadata_file, "r") as f:
            metadata = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(metadata, dict):
        return None
    filename = metadata.get("filename")
    dest_path = metadata.get("dest_path", "")
    total_chunks = metadata.get("total_chunks")
    if not isinstance(filename, str) or not filename.strip():
        return None
    if not isinstance(dest_path, str):
        return None
    if not isinstance(total_chunks, int) or isinstance(total_chunks, bool):
        return None
    if total_chunks < 1:
        return None
    return filename, dest_path, total_chunks


def detect_ready_assemblies():
    """On startup, re-queue uploads that were COMPLETE when the server stopped.

    Only a folder whose `.metadata` says how many chunks the upload has AND that really holds
    exactly that many is assembled. Before 5.17 a folder without metadata was assembled from
    whatever sequential chunks it held and published as `recovered_file_<id>`, so an upload
    interrupted halfway (browser closed, server restarted) could appear as a truncated file.
    Such folders are now left alone; the age-based orphan cleanup removes them."""
    try:
        chunks_dir = os.path.join(ROOT_DIR, ".chunks")
        if not os.path.exists(chunks_dir):
            return

        recovered_count = 0

        for file_id in os.listdir(chunks_dir):
            chunk_dir = os.path.join(chunks_dir, file_id)
            if not os.path.isdir(chunk_dir):
                continue

            try:
                # Skip if assembly is currently in progress
                protection_file = os.path.join(chunk_dir, ".assembling")
                if os.path.exists(protection_file):
                    print(f"🛡️ Skipping {file_id} - assembly protection active")
                    continue

                info = _read_upload_metadata(chunk_dir)
                if info is None:
                    print(
                        f"⏭️ Skipping {file_id}: no usable .metadata, the upload never "
                        "completed (the orphan cleanup removes it)"
                    )
                    continue
                filename, dest_path, expected_chunks = info
                if dest_path and not storage.is_safe_path(dest_path):
                    print(f"⚠️ Skipping {file_id}: unsafe destination in .metadata")
                    continue
                print(
                    f"📋 Found metadata for {file_id}: {filename}, expected {expected_chunks} chunks"
                )

                # Exactly the announced number of chunks must be on disk
                try:
                    chunk_info = storage.verify_chunks_complete(
                        file_id, expected_chunks
                    )
                    total_chunks = chunk_info["total_chunks"]

                    print(
                        f"🔄 Found complete upload ready for assembly: {filename} ({total_chunks} chunks)"
                    )
                    assembly_queue.add_job(file_id, filename, dest_path, total_chunks)
                    recovered_count += 1

                except Exception as verify_error:
                    print(f"⚠️ Chunk verification failed for {file_id}: {verify_error}")
                    continue

            except Exception as e:
                print(f"⚠️ Error checking chunks for {file_id}: {e}")
                continue

        if recovered_count > 0:
            print(
                f"🔄 Recovered {recovered_count} complete upload(s) for background assembly"
            )
        else:
            print("🔍 No complete uploads found waiting for assembly")

    except Exception as e:
        print(f"⚠️ Error detecting ready assemblies: {e}")
