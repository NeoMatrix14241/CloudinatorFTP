# CloudinatorFTP Configuration Reference

This document explains the main runtime settings defined in [../config.py](../config.py) and how they influence the application.

The file acts as the central configuration hub for:

- HTTP server behavior
- upload and session limits
- media conversion settings
- protocol listeners (WebDAV, SFTP, FTP, SMB)
- filesystem storage locations
- Version Engine behavior
- platform-aware storage defaults

_Last checked against `config.py` on 2026-11-04 (version 5.43)._

It is also closely tied to [../server_config.json](../server_config.json), which stores a persisted subset of these values when the app saves the server configuration.

> ⚡ Quick fixes for common admin problems
>
> - If settings reset after restart, run `save_server_config()` and confirm the JSON file is being updated.
> - If the app will not bind ports, check for conflicts on `5000`, `8080`, `8443`, `2121`, `2222`, or `445`.
> - If media preview fails, confirm `ENABLE_FFMPEG` and `ENABLE_LIBVIPS` are enabled and the tools are installed.
> - If storage paths fail, make sure the directory exists and is writable by the service account.
> - If SMB does not work, run `python smb_setup.py` once on the host machine.

> ✅ Before you edit production settings
>
> - Back up [../server_config.json](../server_config.json) and your database/data directories first.
> - Keep sensitive paths outside the server root whenever possible.
> - Change only one setting at a time when diagnosing problems.
> - Restart the app after making configuration changes and confirm behavior before continuing.

---

## Table of Contents

1. [Overview](#1-overview)
2. [Core server settings](#2-core-server-settings)
3. [HLS / media streaming settings](#3-hls--media-streaming-settings)
4. [Image conversion settings](#4-image-conversion-settings)
5. [Configuration via the admin console](#5-configuration-via-the-admin-console)
6. [Protocol server configuration](#6-protocol-server-configuration)
7. [Storage directory settings](#7-storage-directory-settings)
8. [Version Engine configuration](#8-version-engine-configuration)
9. [Persistence model: server_config.json](#9-persistence-model-server_configjson)
10. [Platform detection and storage defaults](#10-platform-detection-and-storage-defaults)
11. [Configuration workflow](#11-configuration-workflow)
12. [Recommended configuration checklist](#12-recommended-configuration-checklist)
13. [Practical examples](#13-practical-examples)
14. [Troubleshooting](#14-troubleshooting)
15. [Summary](#15-summary)

---

## 1. Overview

`config.py` defines global constants that are imported and used throughout the project. It also contains helper functions for:

- detecting the current platform
- choosing a default storage directory
- saving and loading configuration from `server_config.json`
- configuring storage directories for DB/cache/version data
- CLI-based configuration prompts for the admin console

The project uses a mix of:

- hardcoded defaults in the module itself
- one environment override, `CLOUDINATOR_FTP_ROOT`, which only affects the files root (`ROOT_DIR`)
- persisted values from `server_config.json`
- path helper functions in [../paths.py](../paths.py)

`load_server_config()` runs automatically at the bottom of `config.py` every time the module is imported, and `save_server_config()` writes the current values back out.

> ⚠️ **Precedence.** The values written in `config.py` are only fallback defaults. Any key present in `server_config.json` overrides the in-code constant on every import. For example, setting `FTP_ENABLED = False` in `config.py` has no effect while `server_config.json` still contains `"FTP_ENABLED": true`. Change settings through the admin menu (`python config.py`), or edit or delete the key in `server_config.json`, then restart.

`server_config.json` lives in the same directory as `config.py` (anchored via `_HERE` / `_SERVER_CONFIG_FILE`), not in the process working directory.

---

## 2. Core server settings

These are the foundational runtime settings for the main web application.

| Setting | Default | Purpose |
|---|---:|---|
| `PORT` | `5000` | Main Flask/Quart web server port |
| `CHUNK_SIZE` | `10 * 1024 * 1024` | Upload chunk size for large transfers |
| `ENABLE_CHUNKED_UPLOADS` | `True` | Enables resumable chunked file uploads |
| `HOST` | `"0.0.0.0"` | Bind address for the main app |
| `MAX_CONTENT_LENGTH` | `16 * 1024 * 1024 * 1024` | Maximum accepted upload size (16 GB) |
| `ALLOWED_EXTENSIONS` | `None` | Restricts upload types when set to a list/set of lowercase extensions |
| `PERMANENT_SESSION_LIFETIME` | `31536000` | Session lifetime in seconds (365 days) |

### Notes

- `ALLOWED_EXTENSIONS` is intentionally set to `None` by default, which means all file types are permitted.
- To restrict uploads, assign a lowercase set/list such as `{"jpg", "jpeg", "png", "pdf"}` without leading dots.
- `PERMANENT_SESSION_LIFETIME` is tied into the Flask session configuration in the app and is no longer just a dormant value.

### Upload and download performance (5.41 to 5.43)

Four settings control how the request body of an upload chunk is received and how a file is sent. All four are saved in `server_config.json`, loaded at start-up, shown in **View Current Settings**, and validated when loaded (a hand-edited wrong type falls back to the default). **A running server must be restarted** for a change to take effect.

| Setting | Default | Allowed | Menu | Purpose |
|---|---:|---|---|---|
| `UPLOAD_CHUNKS_IN_MEMORY` | `True` (since 5.43; `False` before) | `True` / `False` | Server Settings > 14 > 1 | Parse a chunk-sized upload body in RAM instead of in a temp file in the system temp folder (one 10 MB write and one read less per chunk) |
| `UPLOAD_TIMING_ENABLED` | `False` | `True` / `False` | Server Settings > 14 > 2 | Log the time of every upload stage per chunk and how late the event loop wakes up; off costs nothing |
| `DOWNLOAD_BUFFER_SIZE` | `1048576` (1 MiB) | `8192` to `16777216` bytes | Server Settings > 14 > 3 | Bytes read per step when a file is sent (`/download`, `/view`); Quart's own default is 8 KiB |
| `BODY_TIMEOUT` | `600` | `0` or more seconds; `0` = no limit | none: edit `server_config.json` | Seconds Quart gives ONE request body to arrive and be parsed (Quart's own default is 60) |

Notes:

- **A saved value wins over the new default.** `UPLOAD_CHUNKS_IN_MEMORY` became `True` in 5.43, but a `server_config.json` that already holds `"UPLOAD_CHUNKS_IN_MEMORY": false` (every file saved by 5.41 or 5.42 does) keeps `false` until you switch it in the menu (Server Settings > 14 > 1, then Save & Exit) or edit the file.
- **RAM cost.** `UPLOAD_CHUNKS_IN_MEMORY` is used only when the request carries a CSRF header (`X-CSRFToken` or `X-CSRF-Token`) and a known `Content-Length` of at most `CHUNK_SIZE` plus 1 MiB; any other upload uses Quart's own parser, as before. Each chunk being received at that moment is held in RAM (about 10 MB with the default `CHUNK_SIZE`). The RAM parse runs on the event-loop thread; the timing log's `parse` figure (below) shows how long that takes.
- **`DOWNLOAD_BUFFER_SIZE` costs RAM per download in flight** (1 MiB each by default). The menu offers 64 KB, 256 KB, 1 MB, 4 MB or a custom size from 8 KB to 16384 KB.
- **Reading the timing log** (`UPLOAD_TIMING_ENABLED`): one line per chunk, `upload chunk 2/3: role .. | receive+parse (RAM) .. | read+save .. (in the worker thread: read .., save ..) (body arrived .., parse ..) | total .., N MB, X MB/s`. `body arrived` is how long the body took to reach the server (the client's speed and the network), `parse` is the CPU time of the RAM parse. The split exists only for a RAM-parsed chunk: Quart's own parser reads and parses while the body arrives, so a plain `receive+parse` stage cannot be divided.
- On the owner's Windows PC (standard Python build, hard disk, scratch server) the RAM parse took one client from 9.9 to 15.7 MB/s and four clients from 14.2 to 16.7 MB/s in total; the root cause of the remaining upload speed is not proven. See CLAUDE.md part 93.

---

## 3. HLS / media streaming settings

These settings affect browser playback behavior for video files.

| Setting | Default | Purpose |
|---|---:|---|
| `HLS_MIN_SIZE` | `50 * 1024 * 1024` | Files below this size are served raw for web-native formats |
| `HLS_FORCE_FORMATS` | `{"mkv", "avi", "wmv", "flv", "mpg", "mpeg", "m2ts", "mts", "3gp", "ogv"}` | Formats that always use HLS regardless of file size |
| `ENABLE_FFMPEG` | `True` | Enables HLS/transcoding backend when available |

### Behavior

- Small web-native videos can be streamed directly without transcoding.
- Large or unsupported formats are routed toward HLS streaming.
- If `ENABLE_FFMPEG` is disabled, the app falls back to raw playback only.

---

## 4. Image conversion settings

These settings control image optimization and preview generation.

| Setting | Default | Purpose |
|---|---:|---|
| `ENABLE_LIBVIPS` | `True` | Enables image conversion and WebP optimization |
| `IMG_COMPRESS_MIN_SIZE` | `1 * 1024 * 1024` | Images above this size are compressed to WebP |
| `IMG_WEBP_QUALITY` | `50` | Quality setting for lossy WebP conversion |
| `ENABLE_SEARCH_INDEX` | `True` | Uses SQLite search index when available; otherwise falls back to `os.walk` |

### Notes

- Native image formats smaller than `IMG_COMPRESS_MIN_SIZE` are served raw.
- Larger images may be converted to WebP to reduce bandwidth.
- When `ENABLE_LIBVIPS` is false, raw serving is used and unsupported formats may show a fallback notice instead of processed output.

---

## 5. Configuration via the admin console

The project includes a built-in configuration workflow in `config.py` for administrators who want to change runtime values without editing Python files directly. This follows the same pattern as the user guide’s operational sections: a quick access path, a guided menu, and a save step before the new values take effect.

### Accessing the configuration helpers

From a Python session, you can call the configuration menu directly:

```python
from config import main_configuration_menu
main_configuration_menu()
```

You can also start the same menu from a shell with `python config.py`.

The module also exposes individual helper functions for targeted changes, including:

- `configure_storage_path()` (submenu for all five directories)
- `configure_files_path()`, `configure_db_path()`, `configure_cache_path()`, `configure_hls_cache_path()`, `configure_img_cache_path()`
- `configure_versions_path()`
- `configure_version_engine_settings()` and `configure_version_tracking()`
- `configure_hls_settings()` and `configure_image_settings()`
- `configure_protocol_settings()`
- `configure_server_settings()`
- `view_current_settings()`

### What the menu covers

The main menu is organized into a few practical categories:

| Menu section | Purpose |
|---|---|
| Storage Path Configuration | Adjust file storage, database, cache, HLS cache, and image cache paths |
| Server Settings Configuration | Change ports, session timeout, upload settings, host binding and upload/download performance |
| Version History / Version Engine | Version storage path, engine settings, and tracking scope (details below) |
| View Current Settings | Review the active runtime values |

### Menu reference (as implemented)

**Server Settings** (`configure_server_settings()`):

| Option | Setting |
|---|---|
| 1 | Port |
| 2 | Chunk size |
| 3 | Chunked uploads on/off |
| 4 | Max file size |
| 5 | Session timeout (shown in minutes) |
| 6 | Host binding |
| 7 | Generate a new session secret |
| 8 | HLS settings (minimum size, force-HLS formats) |
| 9 | Image settings (compress threshold, WebP quality) |
| 11 | ffmpeg toggle |
| 12 | libvips toggle |
| 13 | Protocol servers (WebDAV / SFTP / FTP / SMB) |
| 14 | Upload / Download Performance (5.43): 1 = parse chunks in RAM on/off, 2 = upload timing log on/off, 3 = download read size (presets or custom KB) |
| 10 | Save & Exit (writes `server_config.json`) |
| 0 | Exit without saving |

The numbering is out of order in the code (Save & Exit is 10 but is listed last). Values change in memory as you go and are only written to disk when you choose a Save & Exit option.

**Version Engine** (`_version_engine_menu()`): 1 = version storage path, 2 = engine settings, 3 = tracking scope.

- *Engine settings* can toggle the master switch, watcher, scanner, retention, garbage collection, restore-overwrite and symlink following, and can set the small-file threshold (MB), chunk size (MB) and worker count. **13 = Compression (zstd)** (5.47.7) opens the compression sub-menu described under "Compression of the stored objects" below. 13 is listed above Save & Exit, like 14 in the Server Settings menu, so 11 (Save & Exit) and 12 (Exit Without Saving) did not move.
- Not editable from the menu (edit `server_config.json` instead): `VERSION_SCAN_INTERVAL`, `VERSION_MAX_VERSIONS`, `VERSION_GC_GRACE_PERIOD`, `VERSION_MAX_CONCURRENT_SNAPSHOTS`, `VERSION_RETRY_COUNT`, `VERSION_RETRY_DELAY`, `VERSION_SHUTDOWN_TIMEOUT`, `VERSION_CHUNKING_ALGORITHM`, `VERSION_DB_FILENAME`, and the five `VERSION_PURGE_MISSING_*` settings (5.45). The menu shows some of these but does not change them. (The seven `VERSION_COMPRESSION_*` settings were in this list until 5.47.7; they are now editable, see below.)
- *Tracking scope* (`configure_version_tracking()`): tracked files, tracked directories, tracking roots, a track-all-under-roots toggle, excluded directories and excluded patterns.

### Typical admin workflow

1. Start the Python configuration flow.
2. Pick the section that needs adjustment.
3. Choose a suggested location or custom path when prompted.
4. Confirm the final choice before saving.
5. Save the config and restart the app if the setting is runtime-critical.

### Example: changing the storage root

```python
from config import configure_storage_path
configure_storage_path()
```

This opens the storage submenu and lets the administrator select one of the preset folders or enter a custom directory for the main files root.

### Example: changing the version engine settings

```python
from config import configure_version_engine_settings
configure_version_engine_settings()
```

This editor-friendly flow allows the admin to change:

- engine enable/disable state
- small-file threshold
- chunk size
- worker count
- watcher and scanner behavior
- retention and garbage collection on/off (limits such as `VERSION_MAX_VERSIONS` and `VERSION_GC_GRACE_PERIOD` are display-only in this menu)
- restore-overwrite and symlink toggles

### Save behavior

The configuration menus change values in memory as you go and only write them to disk when you choose a Save & Exit option. That option calls the same persistence functions used elsewhere in the project, saving a subset of current values to [../server_config.json](../server_config.json) so the settings survive restarts.

One exception since 5.47.7: the compression sub-menu (Version Engine > Engine settings > 13) does NOT use that whole-file save. `save_server_config()` rebuilds the file from the values in memory, which drops a key `config.py` does not know, turns a value the loader refused into its default, adds every missing key as an explicit default and refreshes `configured_at`. The compression menu instead calls `save_server_config_keys()`: it reads the file as it is on disk, changes only the keys that were edited and keeps every other key, its value and its position (an absent key stays absent, `configured_at` included). A file that is not valid JSON is never overwritten; the new text is checked in a temporary file and put in place with `os.replace`.

> ⚠️ After changing storage paths or sensitive runtime values, restart the app so the updated configuration is reapplied consistently.

---

## 6. Protocol server configuration

CloudinatorFTP supports multiple network protocols. These settings are explicitly documented as being loaded from and saved to `server_config.json`.

### WebDAV

| Setting | Default | Purpose |
|---|---:|---|
| `WEBDAV_ENABLED` | `False` | Plain-HTTP WebDAV listener (off by default; only used when HTTPS is disabled, or as the fallback if the HTTPS certificate can't be prepared) |
| `WEBDAV_PORT` | `8080` | Plain HTTP WebDAV port |
| `WEBDAV_HTTPS_ENABLED` | `True` | Prefer HTTPS WebDAV listener |
| `WEBDAV_HTTPS_PORT` | `8443` | HTTPS WebDAV port |

### Important WebDAV note

The config comments explicitly state:

- When `WEBDAV_HTTPS_ENABLED` is on and the certificate loads, HTTPS runs exclusively. The plain `:8080` listener never opens alongside it, whatever `WEBDAV_ENABLED` says.
- `WEBDAV_ENABLED` only takes effect when HTTPS is disabled, or as an automatic fallback if the HTTPS certificate can't be prepared (for example the `cryptography` package is missing).
- The certificate is auto-generated in `db/webdav.crt` on first run, and FTPS reuses the same certificate.

### SFTP

| Setting | Default | Purpose |
|---|---:|---|
| `SFTP_ENABLED` | `True` | Enables SFTP access |
| `SFTP_PORT` | `2222` | SFTP port |

### FTP / FTPS

| Setting | Default | Purpose |
|---|---:|---|
| `FTP_ENABLED` | `True` | Enables FTP | 
| `FTP_PORT` | `2121` | FTP control port |
| `FTP_TLS_ENABLED` | `True` | Enables FTPS (`AUTH TLS`); falls back to plain FTP if pyOpenSSL isn't installed |
| `FTP_TLS_REQUIRE_DATA` | `True` | Requires TLS on the data channel; `False` allows a plaintext data channel for legacy clients (the control channel stays TLS whenever FTPS and pyOpenSSL are both available) |

### SMB

| Setting | Default | Purpose |
|---|---:|---|
| `SMB_ENABLED` | `False` | SMB share listener is off by default |
| `SMB_PORT` | `445` | Standard SMB port |
| `SMB_FALLBACK_PORT` | `8445` | Fallback port if 445 cannot be bound |
| `SMB_SHARE_NAME` | `"SharedFolder"` | Share name exposed to clients |

### Notes

- SMB is intentionally off by default even when the library is installed.
- The config comments say the machine requires one-time setup before the service is practically useful.
- The admin can run `python smb_setup.py` to enable it properly.

---

## 7. Storage directory settings

`config.py` manages several storage directories that are created and resolved via path helpers from [../paths.py](../paths.py).

### Main storage categories

| Variable | Source | Purpose |
|---|---|---|
| `ROOT_DIR` | `setup_storage_directory()` | main uploaded-file storage root |
| `DB_DIR` | `get_db_dir(create=False)` | database and sensitive secret files |
| `CACHE_DIR` | `get_cache_dir(create=False)` | metadata and index caches |
| `HLS_CACHE_DIR` | `get_hls_cache_dir(create=False)` | HLS segment cache |
| `IMG_CACHE_DIR` | `get_img_cache_dir(create=False)` | generated image preview cache |
| `VERSION_STORAGE_DIR` | `get_versions_dir(create=False)` | version-history object store |

### Path behavior

The project looks for a custom root path in this order:

1. `CLOUDINATOR_FTP_ROOT` environment variable
2. `storage_config.json` saved values via `paths._load()`
3. platform-aware auto-detection via `get_accessible_storage_path()`

The default location depends on platform:

- Termux: the first writable of `/storage/emulated/0/Download/CloudinatorFTP`, `/storage/emulated/0/Documents/CloudinatorFTP`, `/storage/emulated/0/CloudinatorFTP`; otherwise `~/uploads`
- Linux: `$HOME/CloudinatorFTP`
- Windows: Documents/CloudinatorFTP
- macOS: `$HOME/CloudinatorFTP`
- Unknown platform: `./uploads` under the current working directory

If the chosen directory can't be created or written to, `setup_storage_directory()` falls back to `./uploads` under the current working directory.

### Security recommendations

The config comments explicitly warn that `DB_DIR` should be moved outside the server root when possible because it may contain:

- SQLite user database
- `secret.key`
- `session.secret`

This is important for preventing a misconfigured web server from exposing private session or encryption data.

---

## 8. Version Engine configuration

The Version Engine is a separate subsystem for tracking historical file versions.

### Master switch and storage

| Setting | Default | Purpose |
|---|---:|---|
| `VERSION_ENGINE_ENABLED` | `True` | Enables the Version Engine child process |
| `VERSION_STORAGE_DIR` | derived from path helpers | Version object and chunk storage (not saved in `server_config.json`; comes from `versions_path` in `storage_config.json`) |
| `VERSION_DB_FILENAME` | `"version_engine.sqlite3"` | SQLite database for version metadata |

### Chunking and retention

| Setting | Default | Purpose |
|---|---:|---|
| `VERSION_SMALL_FILE_THRESHOLD` | `4 * 1024 * 1024` | Below this: full-object storage |
| `VERSION_CHUNK_SIZE` | `8 * 1024 * 1024` | Version chunk size |
| `VERSION_CHUNKING_ALGORITHM` | `"fixed"` | Chunking strategy |
| `VERSION_RETENTION_ENABLED` | `True` | Enables retention policy |
| `VERSION_MAX_VERSIONS` | `50` | Max versions per file |
| `VERSION_GC_ENABLED` | `True` | Enables garbage collection |
| `VERSION_GC_GRACE_PERIOD` | `24 * 60 * 60` | Time before unreferenced objects are deleted |

### Workers and concurrency

| Setting | Default | Purpose |
|---|---:|---|
| `VERSION_WORKER_COUNT` | `1` | Snapshot worker count; kept low because Termux devices are resource-constrained |
| `VERSION_MAX_CONCURRENT_SNAPSHOTS` | `2` | Upper limit on snapshots running at the same time |

### Watcher and scanner

| Setting | Default | Purpose |
|---|---:|---|
| `VERSION_WATCH_ENABLED` | `True` | Enables filesystem watch-based updates |
| `VERSION_SCAN_ENABLED` | `True` | Enables periodic scan-based reconciliation |
| `VERSION_SCAN_INTERVAL` | `300` | Reconciliation interval in seconds |

### Tracking scope

| Setting | Default | Purpose |
|---|---:|---|
| `VERSION_TRACK_FILES` | `[]` | Explicit list of files to track |
| `VERSION_TRACK_DIRECTORIES` | `[]` | Explicit list of directories to track |
| `VERSION_TRACK_ROOTS` | `[]` | Root paths for recursive tracking |
| `VERSION_TRACK_ALL_FILES` | `False` | Recursively track all files under configured roots |
| `VERSION_EXCLUDE_DIRECTORIES` | `[]` | Directories to exclude |
| `VERSION_EXCLUDE_PATTERNS` | `["*.tmp", "*.part", "~$*"]` | Filename patterns to ignore |

### Reliability and restore behavior

| Setting | Default | Purpose |
|---|---:|---|
| `VERSION_RETRY_COUNT` | `3` | Retries for failed operations |
| `VERSION_RETRY_DELAY` | `2` | Delay between retry attempts |
| `VERSION_COMPRESSION_ENABLED` | `False` | Starts the object compressor; editable in the menu (Engine settings > 13), see "Compression of the stored objects" below |
| `VERSION_FOLLOW_SYMLINKS` | `False` | Whether symlinks are followed during version capture |
| `VERSION_ALLOW_RESTORE_OVERWRITE` | `False` | Allows overwriting files during restore |
| `VERSION_SHUTDOWN_TIMEOUT` | `30` | Grace period before process force-kill |

### Background purge of deleted files' versions (5.45)

The engine never ages out the versions of a file that no longer exists (retention only runs when the same file gets a new snapshot), so the version store only grows. With `VERSION_PURGE_MISSING_ENABLED` on (the default), the Version Engine does what `./manage.sh purge-versions` does by hand, slowly and by itself, in its own `ve-purge` thread (inside the engine process, started and stopped with the engine; nothing runs in the web server, no asyncio, no thread pool). It soft-deletes the versions of files that are gone (status `deleted`, undoable) and the engine's garbage collector frees the chunks after `VERSION_GC_GRACE_PERIOD`. All five settings are read from `server_config.json`, are **not** editable from the `config.py` menu, and need a **restart of the Version Engine** (restart the server) to take effect.

| Setting | Default | Purpose |
|---|---:|---|
| `VERSION_PURGE_MISSING_ENABLED` | `True` | Master switch, ON by default. Off: no thread is started and nothing is ever purged. A missing key keeps the default; a real JSON `true` / `false` is taken as written; any other value (`"false"`, `0`, a typo) counts as OFF |
| `VERSION_PURGE_MISSING_MIN_AGE_DAYS` | `30` | Only files whose NEWEST version is at least this old are looked at (0 = no margin; 0 to 36500) |
| `VERSION_PURGE_MISSING_INTERVAL` | `3600` | Seconds between two passes (60 to 2592000). After a slow pass the engine waits about three times as long as the pass took if that is more |
| `VERSION_PURGE_MISSING_MAX_FILES_PER_PASS` | `5000` | Files whose existence is checked per pass (1 to 100000). The next pass resumes where this one ended; a sweep of the whole table takes `files / this` passes |
| `VERSION_PURGE_MISSING_BATCH_PAUSE` | `0.05` | Seconds paused after every write batch of 500 versions, and the least pause between two slices of 200 existence checks (0 to 5). The pause after a slice is three times the slice's own duration if that is longer, so the disk is busy at most a quarter of the time |

Safety rules (not settings): nothing runs while ANY tracked folder, drive or share is missing, empty or unreadable (a missing file outside every tracked folder counts as gone only while its parent folder exists); the tracked folders are probed again right before the first write and every candidate is checked once more (a file that is back is dropped); an undo record `purge_undo_auto_<time>.json` is written to the version storage folder before any row changes and kept until the GC grace period plus one day (`./manage.sh purge-versions --undo <file>` reads it); the GC and the purge's write phase never overlap; every pass logs what it did (files looked at, gone, left alone, soft-deleted versions and bytes, undo file, duration).

### Compression of the stored objects (5.46 reads, 5.47 writes)

**Editing them (5.47.7).** `./manage.sh config` > Version Engine > Engine settings > **13. Compression (zstd)** lists the seven settings below. For each it shows the current value, the default, the allowed range (the loader's own bounds: both read one table, `VERSION_COMPRESSION_SETTINGS` / `VERSION_COMPRESSION_BOUNDS` in `config.py`) and where the value comes from (`in server_config.json`, `not in server_config.json: default applies`, or a warning when the file holds something the loader ignores, such as the string `"true"`). Entries 1 and 6 toggle a switch; 2 to 5 and 7 ask for a whole number and refuse anything outside the range (nothing changes on a refusal). Changes are held until **8. Save & Back**, which writes ONLY the changed keys with `save_server_config_keys()`: every other key of `server_config.json` stays as it is, the two switches are written as real JSON `true` / `false`, the numbers as JSON numbers, and a key you did not touch (for example an absent `VERSION_COMPRESSION_DELTA_ENABLED`, which means OFF) stays absent. **9. Back Without Saving** (or Ctrl-C / Ctrl-D) writes nothing. A running Version Engine reads these settings when it starts, so a change needs a **restart of the Version Engine** (`./manage.sh restart`). The menu only accepts whole numbers (the loader also takes decimals from a hand-edited file); editing the file by hand still works as before. `./manage.sh config` > 4 (view current settings) shows a one-line summary.

The Version Engine's store (`objects/ab/<sha>`) can be shrunk with zstd without changing anything the user sees. An object's identity stays the SHA-256 of its RAW bytes; compression is only a storage encoding, kept in a NEW file `objects/ab/<sha>.zst` next to the raw one (never in place). The compressor is the engine's own `ve-compress` thread (inside the engine process like `ve-purge`; nothing runs in the web server, no asyncio, no thread pool): it reads a raw object, compresses it, decodes the result back and compares size and SHA-256, publishes the `.zst` atomically, and only minutes later, after verifying the `.zst` once more, removes the raw file. The web side only ever DEcompresses, one block at a time, while a version is restored or downloaded. **Reading always works on whatever is on disk, whatever `VERSION_COMPRESSION_ENABLED` says**: switching the setting off or on can never strand data. Five settings, read from `server_config.json`, **not** editable from the `config.py` menu, taking effect after a **restart of the Version Engine**:

| Setting | Default | Purpose |
|---|---:|---|
| `VERSION_COMPRESSION_ENABLED` | `False` | Starts the `ve-compress` thread (writing). OFF by default; the owner switches it on. A missing key keeps the default; a real JSON `true` / `false` is taken as written; any other value (`"true"`, `1`, a typo) counts as OFF. |
| `VERSION_COMPRESSION_LEVEL` | `22` | zstd level, 1 to 22 (the maximum, the owner's decision; it is used even where it gains nothing over 19). Slower levels only cost background CPU: decoding speed does not depend on the level. A value outside 1 to 22, a string or a typo keeps 22 |
| `VERSION_COMPRESSION_MIN_SAVING_PERCENT` | `5` | The compressed form is kept only if it is at least this much smaller than the raw one (0 to 50); otherwise the object stays raw and is marked `skip` (never retried) |
| `VERSION_COMPRESSION_BUSY_PERCENT` | `25` | Duty cycle of the thread, 5 to 100: after each object it pauses so it is busy at most this share of the time (100 = no pauses) |
| `VERSION_COMPRESSION_INTERVAL` | `600` | Seconds between two looks when nothing is left to compress (60 to 86400) |
| `VERSION_COMPRESSION_DELTA_ENABLED` | `False` | 5.47.1: also store a changed chunk as a DELTA against the same chunk of the file's previous version (see below). Needs `VERSION_COMPRESSION_ENABLED` as well; OFF by default; a real JSON `true` only (anything else counts as OFF); added to `server_config.json` by hand |
| `VERSION_COMPRESSION_DELTA_MIN_GAIN_PERCENT` | `20` | A delta is used only if it is at least this much smaller than the plain compressed chunk (1 to 90); otherwise the chunk is stored on its own. A value outside 1 to 90 keeps 20 |

Fixed values (not settings): objects below 4096 bytes are never compressed; a first attempt at zstd level 3 must save at least 1 % or the object (already-compressed data such as JPG, ZIP, many PDFs) is left raw without paying for the high level; the thread starts 10 minutes after the engine so it never competes with crash recovery, the first scan or the purge; the raw copy is removed only 5 minutes after the `.zst` was committed, and only after the `.zst` decoded and hashed correctly again. An object that fails its own SHA-256 is never touched, is marked `failed` and logged as an ERROR ("possible disk corruption"). Python 3.14 has `compression.zstd`; if the engine finds zstd unusable it logs one warning, does not start the thread and keeps storing raw objects.

By hand (`./manage.sh version-manage compress ...`): `--probe` measures the real store read-only before anything is switched on, `--status` shows the backlog and the result, `--sweep` removes verified raw copies now, `--verify` re-reads and hash-checks every compressed object, and `--decompress` converts everything back to raw files (switch compression off first). An object's `compress_state` is `pending` (not looked at yet), `done` (compressed, raw copy still on disk), `swept` (compressed, raw copy gone: final), `skip` (stays raw on purpose: too small, already-compressed data or no real saving; never retried) or `failed` (it failed its own SHA-256 or the round trip: never touched, logged as an ERROR). Any compressed object can also be checked by hand: `zstd -d < objects/ab/<sha>.zst | sha256sum` prints `<sha>` (a delta needs its base: `zstd -d -D <base raw file> < <sha>.zst | sha256sum`).

**Previous-version delta (5.47.1, `VERSION_COMPRESSION_DELTA_ENABLED`).** A file that is saved again and again changes a few pages per save, so a new version's chunk is nearly identical to the same chunk of the previous version. With the second switch on, the compressor stores such a chunk as a zstd frame that uses the previous chunk as its dictionary (its BASE): a 64-byte edit of a 1 MiB chunk costs a few hundred bytes instead of the whole compressed chunk. The rules that keep it safe: **depth 1** (a base is always a plain object, never a delta, so reading a chunk needs at most two objects and no chain can form; later versions of the same chunk hang on the same base, and a chunk that changed too much simply becomes a new base); the base is the chunk the version REPLACED (the oldest version that uses the chunk is the one that introduced it); the delta is used only if it is at least `VERSION_COMPRESSION_DELTA_MIN_GAIN_PERCENT` smaller than the plain compressed chunk; **a base is never freed while a delta needs it** (the GC counts `objects.base_sha` as a reference, so deleting old versions frees a base only after the deltas on it are gone, and the purge tool does not count such a base as reclaimable); the base is hash-verified every time it is used; a damaged or missing base makes the delta unreadable and is reported (never a wrong byte); the raw copy of a delta is removed only after the delta decoded with its base; objects above 32 MiB are never made deltas. `compress --decompress` turns deltas back into plain raw files. **Rollback:** a release before 5.47.1 cannot read a delta and its GC does not know about bases, so run `compress --decompress` first if the switch was ever on.

### Size limit of the write-ahead log (5.45.1)

SQLite appends every change of `version_engine.sqlite3` to a side file, `version_engine.sqlite3-wal`, and merges it into the main file in a "checkpoint". A checkpoint does **not** shrink that file: it is reused from its start and keeps the size of the biggest burst of writes it ever saw (it reached 2.9 GB next to a 730 MB database after a purge and a GC). One setting, read from `server_config.json`, **not** editable from the `config.py` menu, taking effect after a **restart of the Version Engine**:

| Setting | Default | Purpose |
|---|---:|---|
| `VERSION_WAL_SIZE_LIMIT_MB` | `64` | The limit and the threshold in one. Every engine connection sets `PRAGMA journal_size_limit` to it (after a checkpoint SQLite cuts the file back to this size), and a garbage-collection or purge pass that ends with the `-wal` file **above** it runs `PRAGMA wal_checkpoint(TRUNCATE)`. **Never above 64**: a larger value, a negative number, a string or a typo falls back to 64. `0` switches both off. A value between 0 and 1 is raised to 1 |

The engine's checkpoint waits at most 2 seconds for readers and writers and then gives up until the next pass (nothing is lost, the data is only moved from the log into the main file); it logs what it did, and a busy answer at most every 15 minutes. It takes no lock and runs in the engine's own threads, no asyncio. By hand, and for the file that is already too big: `./manage.sh version-manage wal` shows the sizes, `./manage.sh version-manage wal --checkpoint` runs the checkpoint (safe while the server runs; exit code 1 if the database stayed busy, then repeat it or stop the server first).

### Important note

The comments in the config explicitly state that `VERSION_TRACK_FILES`, `VERSION_TRACK_DIRECTORIES`, and `VERSION_TRACK_ROOTS` all default to empty lists so the system does not accidentally version an entire drive or directory tree.

---

## 9. Persistence model: `server_config.json`

The configuration module contains two key functions:

- `save_server_config()`
- `load_server_config()`

These functions serialize a large subset of the module settings into [../server_config.json](../server_config.json) and reload them on startup.

Saved sections include:

- core server settings
- HLS and image settings
- protocol server settings
- Version Engine values
- metadata such as `configured_at`

Not saved to `server_config.json`:

- `ALLOWED_EXTENSIONS` (a code-only setting)
- `ROOT_DIR`, `DB_DIR`, `CACHE_DIR`, `HLS_CACHE_DIR`, `IMG_CACHE_DIR` and `VERSION_STORAGE_DIR`. Directory locations live in `storage_config.json`, managed by `paths.py`.
- `PRESET_PATHS` and other derived values

An older `server_config.json` that is missing keys falls back to the in-code defaults (`config.get(key, default)`), so no migration is needed.

This makes the app configuration resilient across restarts without hardcoding every setting into the environment.

### Example persisted values

The save function includes entries like:

- `PORT`
- `HOST`
- `CHUNK_SIZE`
- `ENABLE_CHUNKED_UPLOADS`
- `MAX_CONTENT_LENGTH`
- `WEBDAV_ENABLED`
- `SFTP_ENABLED`
- `FTP_ENABLED`
- `SMB_ENABLED`
- `VERSION_ENGINE_ENABLED`
- `VERSION_TRACK_FILES`
- `VERSION_FOLLOW_SYMLINKS`
- `BODY_TIMEOUT`, `UPLOAD_TIMING_ENABLED`, `UPLOAD_CHUNKS_IN_MEMORY`, `DOWNLOAD_BUFFER_SIZE` (see section 2)

---

## 10. Platform detection and storage defaults

The config file includes helper functions such as:

- `detect_platform()`
- `get_windows_documents_path()`
- `get_accessible_storage_path()`
- `setup_storage_directory()`

These are used to choose a default root path and to provide user-friendly messaging about storage location.

### Default platform mapping

- `termux` → first writable of Android `Download`, `Documents`, or the internal-storage root (each with a `CloudinatorFTP` subfolder), else `~/uploads`
- `linux` → `$HOME/CloudinatorFTP`
- `windows` → `Documents/CloudinatorFTP`
- `macos` → `$HOME/CloudinatorFTP`
- `unknown` → `./uploads` under the current working directory

### Preset path helpers

`PRESET_PATHS` defines per-platform presets for quick setup. Each path ends in `CloudinatorFTP` except `termux_home`, which is `~/uploads`.

| Platform | Preset keys |
|---|---|
| termux | `downloads`, `documents`, `internal`, `dcim`, `termux_home` |
| linux | `home`, `desktop`, `documents`, `downloads` |
| windows | `documents`, `desktop`, `downloads`, `userprofile` |
| macos | `documents`, `desktop`, `downloads` |

`set_preset_path(key)` applies one and `list_available_presets()` prints the ones valid for the current platform.

This is used by the config wizard and storage path configuration functions.

---

## 11. Configuration workflow

The file contains interactive helper functions such as:

- `configure_server_settings()`
- `configure_storage_path()`
- `configure_db_path()`
- `configure_cache_path()`
- `configure_versions_path()`
- `configure_version_engine_settings()`
- `configure_hls_settings()`
- `configure_image_settings()`

See section 5 for the full helper list and the menu layout. `python config.py` starts `main_configuration_menu()`.

These are intended for manual CLI configuration and are useful when running the project without editing Python constants directly.

---

## 12. Recommended configuration checklist

For most deployments, these settings are worth reviewing first:

1. `HOST` and `PORT` for network exposure
2. `MAX_CONTENT_LENGTH` for upload limits
3. `WEBDAV_HTTPS_ENABLED` and `WEBDAV_HTTPS_PORT`
4. `SFTP_ENABLED` / `FTP_ENABLED` / `SMB_ENABLED`
5. `DB_DIR` and storage locations for security and performance
6. `VERSION_ENGINE_ENABLED` and version retention thresholds
7. `ENABLE_FFMPEG` and `ENABLE_LIBVIPS` for media optimization

---

## 13. Practical examples

> These snippets edit constants in `config.py`. They only take effect for keys that are **not** already in `server_config.json` (see the precedence note in section 1). Otherwise use the admin menu or edit the JSON.

### Disable a protocol

```python
FTP_ENABLED = False
SFTP_ENABLED = False
WEBDAV_ENABLED = False
```

### Make the app more conservative with uploads

```python
MAX_CONTENT_LENGTH = 4 * 1024 * 1024 * 1024
CHUNK_SIZE = 5 * 1024 * 1024
ENABLE_CHUNKED_UPLOADS = True
```

### Measure where the time of an upload goes

Turn the timing log on (Server Settings > 14 > 2, or `"UPLOAD_TIMING_ENABLED": true` in `server_config.json`), restart, upload a large file, and read the `upload chunk` lines in the server output. Compare `body arrived` with `parse` and `read+save`: the largest figure is where an upload's time goes. Turn the log off again afterwards.

For the test suite the same switch needs no restart of anything: `CLOUDINATOR_SCRATCH_CONFIG='{"UPLOAD_TIMING_ENABLED": true}' CLOUDINATOR_SLOW_TESTS=1 python -m pytest tests/performance/test_baselines.py -q -s` (docs/TESTING_STRATEGY.md section 16).

### Limit uploaded types

```python
ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "pdf", "mp4"}
```

### Move the database outside the app root

```python
from paths import set_db_dir
set_db_dir("/var/lib/cloudinator/db")
```

### Disable version tracking for symlinks and restorations

```python
VERSION_FOLLOW_SYMLINKS = False
VERSION_ALLOW_RESTORE_OVERWRITE = False
```

---

## 14. Troubleshooting

This section covers the most common configuration problems administrators run into when adjusting values in `config.py` or managing the saved settings in [../server_config.json](../server_config.json).

### Problem: settings seem to reset after restart

**Possible cause**
- The values were changed in memory but never saved via `save_server_config()`.
- Or a stale `server_config.json` is overriding the defaults.

**What to check**
- Make sure the active configuration is saved.
- Inspect [../server_config.json](../server_config.json) and confirm the expected keys are present.
- `server_config.json` is always read from the same directory as `config.py`, regardless of the working directory, so make sure you are editing that copy.
- In the admin menu, finish with a Save & Exit option. Exit without saving leaves the change in memory only, so it is lost on restart.

**Fix**
```python
from config import save_server_config
save_server_config()
```

If the file still looks wrong, compare the runtime values in Python with the JSON file and adjust the keys you want to persist.

---

### Problem: port conflicts prevent the app from starting

**Possible cause**
- Another service is already bound to a port used by CloudinatorFTP.
- Common conflicts include `5000`, `8080`, `8443`, `2121`, `2222`, or `445`.

**What to check**
- Review the port values in `config.py`.
- Confirm no other service is using them.
- If using Windows, check the active listener list or firewall rules.

**Fix**
```python
PORT = 5001
WEBDAV_HTTPS_PORT = 9443
SFTP_PORT = 2223
FTP_PORT = 2122
```

Use unique ports that do not conflict with other services on the same machine. If a port is already stored in `server_config.json`, changing the constant alone won't work; use the admin menu (Server Settings → Port or Protocol Servers) or edit the JSON.

---

### Problem: WebDAV HTTPS or FTPS certificate errors

**Possible cause**
- `cryptography` or pyOpenSSL is missing.
- A previous certificate was not generated or cannot be loaded.

**What to check**
- Confirm the HTTPS flags are enabled.
- Read the startup logs for TLS/certificate creation errors.
- Make sure the app has permission to write the secure certificate store or local `db/` directory.

**Fix**
- Reinstall the required package dependencies.
- Re-run the app so the certificate can be generated automatically.
- Check whether the app is falling back to plain HTTP when HTTPS cannot be initialized.

---

### Problem: media preview or transcoding is not working

**Possible cause**
- `ENABLE_FFMPEG` is disabled.
- `ENABLE_LIBVIPS` is disabled.
- The external binaries are not installed on the system.

**What to check**
- Confirm the feature toggles in `config.py`.
- Check whether `ffmpeg` and `libvips` are installed and available on `PATH`.

**Fix**
```python
ENABLE_FFMPEG = True
ENABLE_LIBVIPS = True
```

If the binaries are missing, the app usually falls back to raw playback or raw image serving rather than failing outright, but a real conversion pipeline requires the external tools to be installed.

---

### Problem: database or cache paths are not writable

**Possible cause**
- The configured directory does not exist or lacks write permissions.
- The app was started under a user that cannot access the path.

**What to check**
- Inspect `DB_DIR`, `CACHE_DIR`, `HLS_CACHE_DIR`, and `IMG_CACHE_DIR`.
- Validate permissions on the target directories.
- Confirm the parent folder exists and is writable.

**Fix**
```python
from paths import set_db_dir, set_cache_dir
set_db_dir("/path/to/secure/db")
set_cache_dir("/path/to/cache")
```

For locked-down deployments, use a directory outside the web root and verify the service account has write access.

---

### Problem: Version Engine is not tracking files as expected

**Possible cause**
- `VERSION_ENGINE_ENABLED` is false.
- The tracking lists are empty.
- The configured roots or exclude patterns are too restrictive.

**What to check**
- Confirm `VERSION_ENGINE_ENABLED = True`.
- Inspect `VERSION_TRACK_ROOTS`, `VERSION_TRACK_DIRECTORIES`, and `VERSION_TRACK_FILES`.
- Review `VERSION_EXCLUDE_PATTERNS` and `VERSION_EXCLUDE_DIRECTORIES`.

**Fix**
```python
VERSION_ENGINE_ENABLED = True
VERSION_TRACK_ROOTS = ["/path/to/shared/files"]
VERSION_TRACK_ALL_FILES = True
```

Remember that the lists are intentionally empty by default to avoid accidentally versioning an entire drive.

---

### Problem: SMB does not work even though it is enabled

**Possible cause**
- The one-time machine setup was never completed.
- Port 445 is occupied or the OS-level setup is not valid.

**What to check**
- Confirm `SMB_ENABLED = True`.
- Run the SMB setup script once on the host machine.
- Check whether a fallback port is in use or whether the server is allowed to bind the configured port.

**Fix**
```bash
python smb_setup.py
```

If the platform requires it, run the OS-specific instructions and then re-enable SMB in the configuration.

---

### Problem: uploads are slow

1. Turn on the timing log (see "Measure where the time of an upload goes") and look at one large upload's `upload chunk` lines.
2. A large `body arrived` figure means the bytes reach the server slowly: the client, the network or a tunnel, not the application.
3. A large `parse` or `receive+parse` figure points at the server's own work per chunk. Check that `UPLOAD_CHUNKS_IN_MEMORY` is on (the line then says `(RAM)`; if it never does, the browser's upload request carries no CSRF header and Quart's own parser is used).
4. A large `save` figure points at the disk; the storage folder and the system temp folder on the same hard disk compete with each other.
5. The `[stage]` lines of `tests/performance/test_baselines.py` give the same numbers on a scratch server, so the application can be separated from the network.

### Problem: a setting works in code but not at runtime

**Possible cause**
- The app was not restarted after the change.
- A saved JSON value is overriding the in-code default.
- The setting is only used in one code path and is not wired to the configuration loader.

**What to check**
- Restart the app after editing config values.
- Compare the runtime value against `server_config.json`.
- Confirm the setting is actually imported and used in the code path you expect.

**Best practice**
- Keep configuration changes centralized.
- Save the app config after admin edits.
- Validate the behavior after a restart rather than assuming the value is active immediately.

---

## 15. Summary

`config.py` is the central configuration source for CloudinatorFTP. It defines:

- service ports and access settings
- media conversion behavior
- protocol enablement
- secure/default storage directories
- version history retention and scanning policies
- compatibility with the app’s saved runtime configuration

For production deployments, the safest pattern is to review these settings once, save them to `server_config.json`, and keep sensitive data directories outside the web root. Troubleshooting is usually a matter of confirming the active runtime values, checking filesystem permissions, and ensuring ports and supporting tools are available.