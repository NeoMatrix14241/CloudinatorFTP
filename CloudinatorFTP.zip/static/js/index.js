// ---------------------------------------------------------------------------
// CSRF token injection for every fetch() call in this file.
// Rather than touching all 50+ call sites individually, wrap window.fetch
// once: any same-origin request using a state-changing method (POST, PUT,
// PATCH, DELETE) automatically gets the X-CSRFToken header attached, read
// from the <meta name="csrf-token"> tag Flask renders into the page.
// GET/HEAD requests and cross-origin requests are left untouched.
// ---------------------------------------------------------------------------
(function () {
    const _origFetch = window.fetch.bind(window);
    const STATE_CHANGING = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

    function getCsrfToken() {
        const meta = document.querySelector('meta[name="csrf-token"]');
        return meta ? meta.getAttribute('content') : null;
    }

    function setCsrfToken(token) {
        const meta = document.querySelector('meta[name="csrf-token"]');
        if (meta && token) meta.setAttribute('content', token);
    }

    // The <meta name="csrf-token"> tag is only ever as fresh as the page
    // render that produced it. If session.clear() runs server-side after
    // this page loaded — e.g. logging out and into a different account in
    // another tab, since all tabs share one session cookie — the token
    // baked into this page's HTML no longer matches the session and every
    // state-changing fetch() starts 400ing with "CSRF token missing/
    // incorrect", with no way for this tab to know until it tries.
    // /csrf-token (added alongside this fix) hands out a token for
    // whatever session is CURRENTLY active, so a stale tab can resync
    // itself instead of dead-ending the user's action.
    let _csrfRefreshPromise = null;
    async function refreshCsrfToken() {
        if (!_csrfRefreshPromise) {
            _csrfRefreshPromise = _origFetch('/csrf-token', { credentials: 'same-origin' })
                .then((r) => (r.ok ? r.json() : null))
                .then((data) => {
                    if (data && data.csrf_token) setCsrfToken(data.csrf_token);
                    return data ? data.csrf_token : null;
                })
                .catch(() => null)
                .finally(() => {
                    _csrfRefreshPromise = null;
                });
        }
        return _csrfRefreshPromise;
    }

    function isSameOrigin(url) {
        try {
            return new URL(url, window.location.href).origin === window.location.origin;
        } catch (e) {
            return false;
        }
    }

    async function fetchWithCsrf(input, init) {
        init = init || {};
        const method = (init.method || (input && input.method) || 'GET').toUpperCase();
        const url = typeof input === 'string' ? input : (input && input.url) || '';
        const needsCsrf = STATE_CHANGING.has(method) && isSameOrigin(url);

        if (needsCsrf) {
            const token = getCsrfToken();
            if (token) {
                const headers = new Headers(init.headers || (input && input.headers) || {});
                if (!headers.has('X-CSRFToken')) {
                    headers.set('X-CSRFToken', token);
                }
                init = Object.assign({}, init, { headers });
            }
        }

        const response = await _origFetch(input, init);

        // A 400 here on a state-changing request almost always means this
        // tab's token went stale (see comment above). Refresh once and
        // replay the request transparently — if the retry also fails, the
        // caller sees that response and handles/report it as usual.
        if (needsCsrf && response.status === 400) {
            const cloned = response.clone();
            let looksLikeCsrfFailure = true;
            try {
                const text = await cloned.text();
                looksLikeCsrfFailure = /csrf/i.test(text);
            } catch (e) {
                // Non-text body (e.g. binary) — assume it could still be
                // the CSRF error page and attempt the resync anyway.
            }

            if (looksLikeCsrfFailure) {
                const freshToken = await refreshCsrfToken();
                if (freshToken) {
                    const headers = new Headers(init.headers || {});
                    headers.set('X-CSRFToken', freshToken);
                    init = Object.assign({}, init, { headers });
                    return _origFetch(input, init);
                }
            }
        }

        return response;
    }

    window.fetch = function (input, init) {
        return fetchWithCsrf(input, init);
    };

    // Exposed so non-fetch call sites (e.g. the XMLHttpRequest upload path
    // below) can resync the meta tag through the same mechanism instead of
    // duplicating the refresh logic.
    window._refreshCsrfToken = refreshCsrfToken;
    window._getCsrfToken = getCsrfToken;
})();

// ---------------------------------------------------------------------------
// Delegated action dispatcher — replaces inline onclick/onchange/onkeyup/
// onerror="..." attributes so the Content-Security-Policy no longer needs
// 'unsafe-inline' in script-src. Any element (static or built via
// innerHTML/template literals) can opt in with:
//   data-fn="funcName"            -> called on click
//   data-args='["a","b"]'         -> JSON array of arguments (use dataArgs())
//   data-prevent="1"              -> e.preventDefault() before calling
//   data-stop="1"                 -> e.stopPropagation() before calling
//   data-fn-change="funcName"     -> called on change, with data-args-change
//   data-fn-keyup="funcName"      -> called on keyup with the element's value
//   data-fn-error="funcName"      -> called on error (e.g. broken <img>)
// ---------------------------------------------------------------------------
function escAttr(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
}

// URL-encode a storage path for use in a route like /download/<path>,
// /view/<path>, /office_preview/<path>, /image_preview/<path>. Encodes
// each path segment individually (encodeURIComponent) so filenames
// containing '%', '#', '?', etc. survive round-trip, while '/' segment
// separators are preserved rather than becoming '%2F' (which would 404 —
// the backend expects real slashes between folder/file segments).
// Without this, a filename like "ReadMe%.txt" produces a raw unencoded
// '%' in the href; browsers/Cloudflare treat that as the start of a
// malformed percent-escape and reject the request with 400 before it
// ever reaches the app (confirmed via Cloudflare support + direct testing).
function encodePathForUrl(path) {
    return String(path)
        .split('/')
        .map(encodeURIComponent)
        .join('/');
}

// Build an HTML-attribute-safe, JSON-encoded argument list for data-args=""
function dataArgs(args) {
    return escAttr(JSON.stringify(args));
}

function _invoke(fnName, args, thisArg) {
    const target = window[fnName];
    if (typeof target === 'function') {
        return target.apply(thisArg, args || []);
    }
    console.warn('dispatchAction: no such function on window:', fnName);
}

document.addEventListener('click', function (e) {
    const el = e.target.closest('[data-fn]');
    if (!el) return;
    if (el.dataset.stop === '1') e.stopPropagation();
    if (el.dataset.prevent === '1') e.preventDefault();
    const args = el.dataset.args ? JSON.parse(el.dataset.args) : [];
    _invoke(el.dataset.fn, args, el);
});

document.addEventListener('change', function (e) {
    const el = e.target.closest('[data-fn-change]');
    if (!el) return;
    const args = el.dataset.argsChange ? JSON.parse(el.dataset.argsChange) : [];
    _invoke(el.dataset.fnChange, args, el);
});

document.addEventListener('keyup', function (e) {
    const el = e.target.closest('[data-fn-keyup]');
    if (!el) return;
    _invoke(el.dataset.fnKeyup, [el.value], el);
});

// 'error' events on elements like <img> don't bubble, so this listener
// must use the capture phase to see them via delegation.
document.addEventListener('error', function (e) {
    const el = e.target;
    if (el && el.dataset && el.dataset.fnError) {
        _invoke(el.dataset.fnError, [], el);
    }
}, true);

// Handles a failed load of the image preview in the file viewer (was
// previously an inline onerror="..." attribute on the <img> element).
function _handleImgConvError() {
    const label = document.getElementById('img-conv-label');
    if (label) label.textContent = '';
    this.style.display = 'none';
    const spinner = document.getElementById('img-conv-spinner');
    if (spinner) spinner.innerHTML = '<p class="viewer-error">Could not load image.</p>';
}

// Read Flask configuration from HTML data attributes (avoids VS Code parsing issues)
const configElement = document.getElementById('flask-config');
const CHUNK_SIZE = parseInt(configElement.dataset.chunkSize) || 10485760; // 10MB fallback
const UPLOAD_URL = configElement.dataset.uploadUrl || "/upload";
const LOGOUT_URL = configElement.dataset.logoutUrl || "/logout";
const CURRENT_PATH = configElement.dataset.currentPath || "";
const USER_ROLE = configElement.dataset.userRole || "readonly";

// Browser history management for authentication
document.addEventListener('DOMContentLoaded', function () {
    // Immediate authentication check on page load
    checkAuthenticationOnPageLoad();

    // Clean up browser history to prevent login page from being accessible via back button
    cleanupAuthenticationHistory();
    // Transform any server-rendered rows to use detailed file type & icon mapping
    try { transformInitialRows(); } catch (e) { console.warn('transformInitialRows not available yet', e); }

    // Initialize VT engine from server-rendered JSON (replaces the inline HTML script)
    _initVTFromPageData();

    const createFolderForm = document.getElementById('createFolderForm');
    if (createFolderForm) {
        createFolderForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const folderName = document.getElementById('folderNameInput').value;

            // Use the global currentPath variable
            console.log('Current global path:', currentPath);

            await createFolder(folderName, currentPath);
        });
    }

    // Stop-folder delegation — survives any innerHTML rebuild on folder rows
    const _fqEl = document.getElementById('fileQueue');
    if (_fqEl) {
        _fqEl.addEventListener('click', function (e) {
            const b = e.target.closest('.fg-stop-btn');
            if (b) { e.stopPropagation(); e.preventDefault(); _stopFolderGroup(b.dataset.gid); }
        });
    }

    // Mobile tap-tooltip — shows label on touchstart, hides after 1.2s or on touchend
    initTapTooltips();
});

function initTapTooltips() {
    // Single tooltip element reused for both hover (desktop) and tap (mobile)
    const tip = document.createElement('div');
    tip.id = 'btn-action-tooltip';
    document.body.appendChild(tip);

    let hideTimer = null;

    function showTip(btn) {
        const label = btn.dataset.label;
        if (!label) return;
        clearTimeout(hideTimer);
        tip.textContent = label;
        tip.classList.add('visible');

        const rect = btn.getBoundingClientRect();
        // Measure after setting text so width is accurate
        const tw = tip.offsetWidth;
        const th = tip.offsetHeight;
        let left = rect.left + rect.width / 2 - tw / 2;
        let top = rect.top - th - 7;
        // Clamp inside viewport
        left = Math.max(6, Math.min(left, window.innerWidth - tw - 6));
        if (top < 6) top = rect.bottom + 7; // flip below if no room above
        tip.style.left = left + 'px';
        tip.style.top = top + 'px';
    }

    function hideTip(delay) {
        clearTimeout(hideTimer);
        if (delay) {
            hideTimer = setTimeout(() => tip.classList.remove('visible'), delay);
        } else {
            tip.classList.remove('visible');
        }
    }

    const SEL = '.actions-cell .btn-sm[data-label], #filesTable .actions .btn-sm[data-label]';

    // ── Desktop: mouseenter / mouseleave ─────────────────────────────────────
    document.addEventListener('mouseenter', e => {
        if (!e.target || e.target.nodeType !== 1) return;
        const btn = e.target.closest(SEL);
        if (btn) showTip(btn);
    }, true);

    document.addEventListener('mouseleave', e => {
        if (!e.target || e.target.nodeType !== 1) return;
        if (e.target.closest(SEL)) hideTip(80);
    }, true);

    // ── Mobile: touchstart shows label, hides after 1.3s or on move ──────────
    document.addEventListener('touchstart', e => {
        if (!e.target || e.target.nodeType !== 1) return;
        const btn = e.target.closest(SEL);
        if (btn) {
            showTip(btn);
            hideTip(1300);
        } else {
            hideTip(0);
        }
    }, { passive: true });

    document.addEventListener('touchmove', () => hideTip(0), { passive: true });
}

let _smartColumnizerRO = null; // ResizeObserver reference

function lockTableColumnWidths() {
    // Delegate to smart columnizer — keeps backward-compat for callers
    smartTableColumnizer();
}

/**
 * Width (px) of the Actions column for the current role.
 *
 * Single source of truth: applyWidths() and _getColDefs() below used to each
 * carry their own copy of this number, and the read-only value was too small.
 * With table-layout:fixed the column is exactly this wide, and the <th> clips
 * its own label (overflow:hidden), so the width must cover BOTH
 *   - the icon buttons (28px each + 3px gaps + 6px cell padding per side), and
 *   - the header "<i class=fa-cogs></i> Actions" (about 87px for icon + text
 *     + 13px padding per side = 113px at desktop/tablet sizes, 87px on mobile;
 *     measured in Chromium with the real index.html header markup).
 * Read-write rows show 6 buttons (download, move, copy, rename, share,
 * delete) = 183px of buttons, so 190px works and is left unchanged.
 * Read-only rows show 1 button (download): the buttons need only ~46px, but
 * the header needs about 113px in a simulated test, but a real-browser screenshot showed the final "s" touching the edge at 120px (real icon/font are wider), so 144px (about 25px slack) is used.
 * Before this, read-only used 70px and the header read "Actio".
 */
function _actionsColWidth() {
    const isReadWrite = (typeof USER_ROLE !== 'undefined' && USER_ROLE === 'readwrite');
    return isReadWrite ? 190 : 144;
}

/**
 * Smart real-time column width adjuster.
 * Uses setProperty(...,'important') so inline styles beat any CSS !important rule.
 * Mobile (<600px):  cb | name | size | actions          (type + modified hidden)
 * Tablet (600-899): cb | name | size | type | actions   (modified hidden)
 * Desktop (≥900px): all 6 columns
 */
function smartTableColumnizer() {
    const wrapper = document.getElementById('tableScrollWrapper');
    const table = document.getElementById('filesTable');
    if (!wrapper || !table) return;

    if (_smartColumnizerRO) { _smartColumnizerRO.disconnect(); _smartColumnizerRO = null; }

    function _set(el, prop, val) {
        el.style.setProperty(prop, val, 'important');
    }

    function applyWidths() {
        const W = wrapper.clientWidth || wrapper.offsetWidth;
        if (!W) return;

        const isMobile = W < 600;
        const isTablet = W >= 600 && W < 900;

        // Mobile (<600px):  cb | name | size | actions               (type + modified hidden)
        // Tablet (600-899): cb | name | size | type | actions        (modified hidden, slimmer cols)
        // Desktop (≥900px): all 6 columns
        const cbW = 36;
        const sizeW = isTablet ? 110 : 200;
        const typeW = isTablet ? 110 : 125;
        const modW = 140;
        // Actions column must fit the icon buttons AND the "Actions" header
        // label (the <th> clips its text). See _actionsColWidth().
        const actW = _actionsColWidth();

        const showMod = !isTablet && !isMobile;
        const fixedTotal = cbW + sizeW + typeW + (showMod ? modW : 0) + actW;

        const nameFloor = isMobile ? 250 : isTablet ? 100 : 160;
        const nameW = Math.max(nameFloor, W - fixedTotal - 4);
        const totalW = fixedTotal + nameW;
        _set(table, 'table-layout', 'fixed');
        _set(table, 'width', '100%');
        _set(table, 'min-width', totalW + 'px');

        const colDefs = [cbW, nameW, sizeW, typeW, showMod ? modW : 0, actW];

        function _fixCheckbox(el) {
            if (!el) return;
            _set(el, 'width', '16px');
            _set(el, 'height', '16px');
            _set(el, 'min-width', '16px');
            _set(el, 'min-height', '16px');
            _set(el, 'max-width', '16px');
            _set(el, 'max-height', '16px');
            _set(el, 'display', 'block');
            _set(el, 'margin', '0 auto');
        }

        // ── Apply to <thead th> ───────────────────────────────────────────────────
        table.querySelectorAll('thead th').forEach((th, i) => {
            const w = colDefs[i];
            if (w === 0) { _set(th, 'display', 'none'); return; }
            _set(th, 'display', '');
            _set(th, 'width', w + 'px');
            _set(th, 'max-width', w + 'px');
            _set(th, 'white-space', 'nowrap');
            if (i === 0) {
                _set(th, 'overflow', 'visible');
                _set(th, 'padding', '0');
                _set(th, 'text-align', 'center');
                _set(th, 'vertical-align', 'middle');
                _fixCheckbox(th.querySelector('input[type="checkbox"]'));
            } else {
                _set(th, 'overflow', 'hidden');
                _set(th, 'padding', isMobile ? '14px 6px' : '18px 13px');
            }
        });

        // ── Apply to <tbody td> ───────────────────────────────────────────────────
        _styleRows(table.querySelectorAll('tbody tr'), colDefs, isMobile);
    }

    function _styleRows(rows, colDefs, isMobile) {
        const pad = isMobile ? '6px 8px' : '11px 13px';
        const padTop = isMobile ? '6px' : '11px';
        rows.forEach(row => {
            if (row.classList.contains('empty-folder-row')) return;
            if (row.cells.length && row.cells[0].colSpan > 1) return;

            // Deep-search rows are two-line (name + path) and are centred
            // vertically; folder/file rows are top-aligned. These inline
            // !important styles re-run on every ResizeObserver tick, so without
            // this a sort/reset (which resizes the toolbar) flipped the checkbox
            // and size cells of search rows to the top.
            const isSearchRow = row.classList.contains('search-result-row');
            const vaCell = isSearchRow ? 'middle' : 'top';

            Array.from(row.cells).forEach((td, i) => {
                const w = colDefs[i];
                if (w === 0) { _set(td, 'display', 'none'); return; }

                _set(td, 'display', '');
                _set(td, 'width', w + 'px');
                _set(td, 'max-width', w + 'px');

                if (i === 0) {
                    _set(td, 'overflow', 'visible');
                    _set(td, 'padding', isSearchRow ? '0' : padTop + ' 0 0 0');
                    _set(td, 'text-align', 'center');
                    _set(td, 'vertical-align', vaCell);
                    _set(td, 'line-height', 'normal');
                    const cb = td.querySelector('input[type="checkbox"]');
                    if (cb) {
                        _set(cb, 'width', '16px');
                        _set(cb, 'height', '16px');
                        _set(cb, 'min-width', '16px');
                        _set(cb, 'min-height', '16px');
                        _set(cb, 'max-width', '16px');
                        _set(cb, 'max-height', '16px');
                        _set(cb, 'display', 'block');
                        _set(cb, 'margin', '0 auto');
                    }
                    return;
                }

                _set(td, 'overflow', 'hidden');
                _set(td, 'padding', pad);
                _set(td, 'vertical-align', vaCell);
                _set(td, 'line-height', '1.3');

                if (i === 1) {
                    // Name: word-wrap on all breakpoints
                    _set(td, 'white-space', 'normal');
                    _set(td, 'text-overflow', 'unset');
                    _set(td, 'vertical-align', vaCell);
                    const fn = td.querySelector('.file-name');
                    if (fn) {
                        _set(fn, 'display', 'flex');
                        _set(fn, 'align-items', 'flex-start');
                        _set(fn, 'gap', '6px');
                        _set(fn, 'overflow', 'hidden');
                        _set(fn, 'white-space', 'normal');
                        _set(fn, 'max-width', '100%');
                        // span.search-highlight is excluded on purpose: these are
                        // INLINE !important styles, so display:block here beats every
                        // stylesheet rule and turns the highlight into a full-width bar
                        // (this runs again on every resize / scrollbar change).
                        fn.querySelectorAll('a, span:not(.search-highlight)').forEach(el => {
                            _set(el, 'white-space', 'normal');
                            _set(el, 'word-break', 'break-word');
                            _set(el, 'overflow-wrap', 'anywhere');
                            _set(el, 'overflow', 'hidden');
                            _set(el, 'text-overflow', 'unset');
                            _set(el, 'display', 'block');
                            _set(el, 'max-width', '100%');
                        });
                    }
                } else if (i === 2) {
                    // Size: allow wrapping so "5000 files, 5000 folders\n204 MB" shows fully
                    _set(td, 'white-space', 'normal');
                    _set(td, 'word-break', 'break-word');
                    _set(td, 'text-overflow', 'unset');
                } else if (i === colDefs.length - 1) {
                    // Actions: icon buttons must never be clipped. Use tight
                    // horizontal padding (reclaims space vs. the 13px used by
                    // Type/Modified) and overflow:visible as a safety net —
                    // this is the last column, so nothing else is to its
                    // right for it to overlap.
                    _set(td, 'white-space', 'nowrap');
                    _set(td, 'overflow', 'visible');
                    _set(td, 'padding', (isMobile ? '6px' : '11px') + ' 6px');
                    _set(td, 'vertical-align', 'middle');
                } else {
                    // Type / Modified: single line, ellipsis, centred vertically
                    _set(td, 'white-space', 'nowrap');
                    _set(td, 'text-overflow', 'ellipsis');
                    _set(td, 'vertical-align', 'middle');
                }
            });
        });
    }

    // Expose helpers so applyColumnWidths can style new VT rows consistently
    smartTableColumnizer._styleRows = _styleRows;
    smartTableColumnizer._getColDefs = function () {
        const W = wrapper.clientWidth || wrapper.offsetWidth || 800;
        const isMobile = W < 600;
        const isTablet = W >= 600 && W < 900;
        const cbW = 36, sizeW = isTablet ? 110 : 200, typeW = isTablet ? 110 : 125, modW = 140;
        const actW = _actionsColWidth();
        const showMod = !isTablet && !isMobile;
        const fixedTotal = cbW + sizeW + typeW + (showMod ? modW : 0) + actW;
        const nameFloor = isMobile ? 250 : isTablet ? 100 : 160;
        const nameW = Math.max(nameFloor, W - fixedTotal - 4);
        return { colDefs: [cbW, nameW, sizeW, typeW, showMod ? modW : 0, actW], isMobile };
    };

    applyWidths();

    _smartColumnizerRO = new ResizeObserver(() => applyWidths());
    _smartColumnizerRO.observe(wrapper);
    window.addEventListener('resize', applyWidths, { passive: true });
}

function applyColumnWidths(row) {
    if (!row) return;
    if (smartTableColumnizer._styleRows && smartTableColumnizer._getColDefs) {
        const { colDefs, isMobile } = smartTableColumnizer._getColDefs();
        smartTableColumnizer._styleRows([row], colDefs, isMobile);
    }
}

// Function to protect all modal inputs from event delegation
function protectModalInputs() {
    const modals = document.querySelectorAll('.modal');

    modals.forEach(modal => {
        const inputs = modal.querySelectorAll('input, textarea, select');

        inputs.forEach(input => {
            // Stop propagation for all events that might interfere
            ['click', 'keydown', 'keyup', 'keypress', 'input', 'focus', 'blur'].forEach(eventType => {
                input.addEventListener(eventType, function (e) {
                    e.stopPropagation();
                }, true);
            });
        });
    });
}

// Call this after DOM is loaded or after modals are created
document.addEventListener('DOMContentLoaded', protectModalInputs);

async function checkAuthenticationOnPageLoad() {
    try {
        const response = await fetch('/admin/upload_status', {
            method: 'GET',
            cache: 'no-cache',
            headers: { 'Cache-Control': 'no-cache' }
        });

        if (!response.ok || response.url.includes('/login')) {
            // FIX: Never redirect mid-upload — the page-load check fires on each hard
            // reload, but if somehow called while uploading is in progress, don't kill it.
            if (isUploading) {
                console.warn('🔒 Page-load auth check failed but upload in progress — skipping redirect');
                return;
            }
            console.log('🔒 Not authenticated, redirecting to login...');
            window.location.replace('/login');
            return;
        }

        console.log('✅ Authentication verified');
    } catch (error) {
        if (isUploading) {
            console.warn('🔒 Page-load auth check error during upload — skipping redirect:', error.message);
            return;
        }
        console.log('🔒 Authentication check failed, redirecting to login...');
        window.location.replace('/login');
    }
}

function cleanupAuthenticationHistory() {
    // Check if we came from the login page and clean up history
    const referrer = document.referrer;
    if (referrer && referrer.includes('/login')) {
        // Replace the current history state to remove login page from history
        const currentUrl = window.location.href;
        console.log('🔄 Cleaning up authentication history');

        // Replace current state to ensure login page is not in history
        window.history.replaceState({ authenticated: true }, '', currentUrl);

        // Add a state to prevent accidental back navigation to login
        window.history.pushState({ authenticated: true }, '', currentUrl);

        // Handle popstate events to prevent going back to login
        window.addEventListener('popstate', function (event) {
            if (event.state && event.state.authenticated) {
                // User is authenticated, prevent going back to login
                console.log('🔒 Preventing navigation back to login page');
                window.history.pushState({ authenticated: true }, '', window.location.href);
            }
        });
    }

    // Removed: periodic 1s authentication polling loop.
    // It fired even in background tabs, where browsers throttle/freeze timers
    // and network sockets — causing bursts of false "auth failed" results that
    // forced a hard redirect to /login (the "gray screen") even though the
    // real server-side session was still valid. The server already enforces
    // the actual session lifetime on every real request via @app.before_request,
    // so this client-side watchdog wasn't needed for security — only for a
    // marginally faster redirect on genuine logout, at the cost of false positives.
    //
    // If you want SOME client-side check, re-enable checkAuthenticationStatus()
    // below, but only run it when the tab regains visibility, never on an interval.
    // document.addEventListener('visibilitychange', () => {
    //     if (document.visibilityState === 'visible') checkAuthenticationStatus();
    // });
}

async function checkAuthenticationStatus() {
    // Kept for optional manual/visibility-triggered use (see comment above).
    // No longer runs on an interval, so no failure-counting/backoff is needed.
    if (document.hidden) return; // never evaluate while backgrounded
    try {
        const response = await fetch('/check_session', {
            method: 'GET',
            cache: 'no-cache',
            headers: { 'Cache-Control': 'no-cache' }
        });
        if ((!response.ok || response.url.includes('/login')) && !isUploading) {
            console.log('🔒 Session expired, redirecting to login...');
            window.location.replace('/login');
        }
    } catch (error) {
        // Network hiccup — ignore silently, don't redirect on a single failed ping.
        console.log('🔒 Auth check error (ignored):', error.message);
    }
}

// Device detection for mobile-specific features
const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
const isAndroid = /Android/i.test(navigator.userAgent);
const isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent);

// Global search state tracking
let isSearchResultsDisplayed = false;

// Feature detection for folder upload capabilities
const supportsDragDrop = 'ondrop' in window && 'ondragover' in window;
const supportsWebkitDirectory = 'webkitdirectory' in document.createElement('input');
const supportsWebkitGetAsEntry = 'webkitGetAsEntry' in DataTransferItem.prototype;

console.log(`📱 Device Info: Mobile=${isMobile}, Android=${isAndroid}, iOS=${isIOS}`);
console.log(`🔧 Feature Support: DragDrop=${supportsDragDrop}, WebkitDir=${supportsWebkitDirectory}, WebkitEntry=${supportsWebkitGetAsEntry}`);

// Notification timing configuration (in milliseconds)
// You can easily adjust these values to change how long notifications stay visible:
const NOTIFICATION_TIMERS = {
    SUCCESS: 2000,  // 2 seconds - for positive actions (uploads, deletes, queue operations)
    INFO: 2000,     // 4 seconds - for general information
    ERROR: 4000        // 0 = never auto-hide, stays until manually clicked (for important errors)
};

// Utility function to update notification timers at runtime (for debugging/testing)
function setNotificationTimer(type, milliseconds) {
    if (NOTIFICATION_TIMERS.hasOwnProperty(type.toUpperCase())) {
        NOTIFICATION_TIMERS[type.toUpperCase()] = milliseconds;
        console.log(`📝 Updated ${type.toUpperCase()} notification timer to ${milliseconds}ms`);
    } else {
        console.warn(`❌ Invalid notification type: ${type}. Valid types: SUCCESS, INFO, ERROR`);
    }
}

// Table sorting and searching functionality
let currentSort = { column: null, direction: 'asc' };
let originalRowOrder = []; // Store original order for reset functionality
let searchTimeout = null;
// Deep search (all nested folders) starts at this many characters. Shorter
// queries only filter the current folder. A `*.ext` term always goes deep.
const _DEEP_SEARCH_MIN_CHARS = 3;

// Search functionality

function performLocalSearch(searchTerm) {
    // Hide any deep search results overlay first
    hideDeepSearchResults();

    // Delegate filter to VT engine — works on data array, re-renders visible rows
    VT.applyFilter(searchTerm);

    console.log(`🔍 Local VT filter for "${searchTerm}"`);
}

// ── Deep search: true row windowing (virtual scroll) ─────────────────────────
// Same idea as the VT module above, applied to deep-search results: the FULL
// result list lives in _dsAll (plain data, pages of _DS_LIMIT fetched from the
// server as the user nears the end), but only the rows in the viewport +/-
// _DS_RENDER_BUFFER are ever in the DOM. Two spacer rows stand in for
// everything else. Rules inherited from VT (see CLAUDE.md 4.34) — do not break:
//   * NO style="" attribute in any markup built here (CSP style-src-attr)
//   * spacer height goes on the spacer <td> via style.setProperty(..,'important')
//     (index.css pins every `#filesTable tbody tr` to height:auto !important)
//   * NO JS scrollTop compensation; native scroll anchoring does that job
const _DS_LIMIT = 500;              // rows to fetch from the server per API call
const _DS_RENDER_BUFFER = 7;        // rows kept mounted above/below the viewport
const _DS_DEFAULT_ROW_HEIGHT = 56;  // seed estimate until the first real row is measured
const _DS_PREFETCH_ROWS = 40;       // fetch the next page when the window ends this close to the loaded end
const _DS_RESIZE_DEBOUNCE_MS = 1;

let _dsAll = [];            // every result fetched so far (data only, never DOM)
let _dsTotal = null;        // server total_count (exact), or null if the index couldn't say
let _dsOffset = 0;          // next API offset to request
let _dsHasMore = false;     // server says more rows exist beyond _dsOffset
let _dsFetching = false;    // guard against concurrent fetches
let _dsQuery = '';          // current query (for next-page requests)
let _dsExts = [];           // current ext filter
let _dsSearchTerm = '';     // raw display term for highlight
let _dsGen = 0;             // bumped on every new search / teardown; guards stale async work
let _dsSortClickAt = 0;     // time of the last header click handled (double-dispatch guard)
let _dsSeqNext = 0;         // running index stamped on each result so Reset Sort can restore server order
let _dsSort = { column: null, direction: 'asc' };   // deep-search sort (separate from the folder's currentSort)

let _dsOffsets = null;      // Float64Array, length _dsAll.length+1 — cumulative top px per row
let _dsRowH = _DS_DEFAULT_ROW_HEIGHT;   // running estimate for rows never measured
let _dsHeightCache = new Map();         // result path -> last measured px height
let _dsMounted = new Map();             // _dsAll index -> <tr> currently in the DOM
let _dsWinStart = 0, _dsWinEnd = 0;     // [start, end) indices currently mounted
let _dsTopRow = null, _dsBottomRow = null, _dsTopCell = null, _dsBottomCell = null, _dsLoadRow = null;
let _dsListBase = 0;        // px from the wrapper's scrollable top to the first result row
let _dsScrollHandler = null, _dsScrollRafPending = false;
let _dsResizeHandler = null, _dsResizeTimer = null;

function _dsMakeSpacerRow(id) {
    // Same classes as the VT spacers so index.css zeroes padding/border/font.
    // ds-spacer-row is NOT search-result-row, so selection/delete counters skip it.
    const tr = document.createElement('tr');
    tr.id = id;
    tr.className = 'vt-spacer-row ds-spacer-row';
    tr.setAttribute('aria-hidden', 'true');
    const td = document.createElement('td');
    td.colSpan = 6;
    td.className = 'vt-spacer-cell';
    tr.appendChild(td);
    return tr;
}

function _dsMakeLoadingRow() {
    const tr = document.createElement('tr');
    tr.id = 'dsSearchSentinelRow';
    tr.className = 'vt-loading-row ds-loading-row';
    const td = document.createElement('td');
    td.colSpan = 6;
    td.innerHTML = '<i class="fas fa-circle-notch fa-spin ds-loading-icon"></i>' +
        '<span class="ds-sentinel-label">Loading more results…</span>';
    tr.appendChild(td);
    return tr;
}

function _dsSyncLoadingRow() {
    const tbody = document.querySelector('#filesTable tbody');
    if (!tbody) return;
    if (_dsHasMore) {
        if (!_dsLoadRow) _dsLoadRow = _dsMakeLoadingRow();
        if (_dsLoadRow.parentNode !== tbody) tbody.appendChild(_dsLoadRow);   // always after the bottom spacer
    } else if (_dsLoadRow) {
        _dsLoadRow.remove();
        _dsLoadRow = null;
    }
}

function _dsMeasureListBase(wrapper) {
    if (!wrapper || !_dsTopRow) return 0;
    const spacerTop = _dsTopRow.getBoundingClientRect().top;
    const wrapTop = wrapper.getBoundingClientRect().top;
    return spacerTop - wrapTop + wrapper.scrollTop;
}

// Binary search: greatest index i such that _dsOffsets[i] <= offset.
function _dsFindIndexAtOffset(offset) {
    let lo = 0, hi = _dsAll.length;
    while (lo < hi) {
        const mid = (lo + hi) >> 1;
        if (_dsOffsets[mid] <= offset) lo = mid + 1; else hi = mid;
    }
    return Math.max(0, lo - 1);
}

function _dsRebuildOffsets() {
    const n = _dsAll.length;
    const offsets = new Float64Array(n + 1);
    let acc = 0;
    for (let i = 0; i < n; i++) {
        offsets[i] = acc;
        const cached = _dsHeightCache.get(_dsAll[i].path);
        acc += (cached && cached > 0) ? cached : _dsRowH;
    }
    offsets[n] = acc;
    _dsOffsets = offsets;
}

function _dsPositionSpacers() {
    if (!_dsOffsets || !_dsTopCell || !_dsBottomCell) return;
    const total = _dsAll.length;
    const topH = _dsOffsets[_dsWinStart] || 0;
    const bottomH = Math.max(0, _dsOffsets[total] - _dsOffsets[_dsWinEnd]);
    _dsTopCell.style.setProperty('height', topH + 'px', 'important');
    _dsBottomCell.style.setProperty('height', bottomH + 'px', 'important');
}

function _dsCreateRow(result) {
    const row = createSearchResultRow(result, _dsSearchTerm);
    // A row that scrolled out and back in must still show its selection.
    if (selectedItems.has(result.path)) {
        const cb = row.querySelector('.item-checkbox');
        if (cb) cb.checked = true;
        row.classList.add('selected');
    }
    return row;
}

// Mount exactly [start, end), touching only what changed (same two-phase
// create-then-write approach as VT._mountRange). Returns the newly created rows.
function _dsMountRange(start, end) {
    const tbody = document.querySelector('#filesTable tbody');
    if (!tbody || !_dsTopRow || !_dsBottomRow) return [];

    const created = [];
    const wanted = new Array(Math.max(0, end - start));
    for (let i = start; i < end; i++) {
        let el = _dsMounted.get(i);
        if (!el) {
            el = _dsCreateRow(_dsAll[i]);
            created.push(el);
        }
        wanted[i - start] = el;
    }

    for (const [idx, el] of _dsMounted) {
        if ((idx < start || idx >= end) && el.parentNode) el.remove();
    }

    const keep = new Map();
    let ref = _dsTopRow.nextSibling;
    for (let i = start; i < end; i++) {
        const el = wanted[i - start];
        if (el === ref) ref = ref.nextSibling;   // already in place
        else tbody.insertBefore(el, ref);        // new, or moved
        keep.set(i, el);
    }
    _dsMounted = keep;
    return created;
}

function _dsRenderWindow(force, scrollTopOverride) {
    const wrapper = document.getElementById('tableScrollWrapper');
    if (!wrapper || !_dsOffsets || !_dsAll.length) return;

    const scrollTop = (scrollTopOverride == null) ? wrapper.scrollTop : scrollTopOverride;
    const viewportH = wrapper.clientHeight || 600;
    const rel = scrollTop - _dsListBase;
    const total = _dsAll.length;

    const start = Math.max(0, _dsFindIndexAtOffset(rel) - _DS_RENDER_BUFFER);
    const end = Math.min(total, _dsFindIndexAtOffset(rel + viewportH) + 1 + _DS_RENDER_BUFFER);

    if (force || start !== _dsWinStart || end !== _dsWinEnd) {
        const created = _dsMountRange(start, end);
        _dsWinStart = start; _dsWinEnd = end;
        _dsPositionSpacers();
        if (created.length) _dsScheduleMeasure(created, _dsGen);
    }

    // Near the end of what is loaded? Pull the next page before the user hits the wall.
    if (_dsHasMore && !_dsFetching && _dsWinEnd >= total - _DS_PREFETCH_ROWS) {
        _dsFetchNextPage();
    }
}

// Batched measure of freshly mounted rows (one read pass in the next frame).
// Search-result rows can wrap (long names / long paths), so height is not
// uniform; offsets are only rebuilt when a measurement disagrees with them.
function _dsScheduleMeasure(rows, gen) {
    requestAnimationFrame(() => {
        if (gen !== _dsGen) return;   // search closed / replaced meanwhile
        let changed = false;
        rows.forEach(el => {
            if (!el.isConnected) return;
            const h = el.getBoundingClientRect().height;
            if (!h) return;
            if (_dsRowH === _DS_DEFAULT_ROW_HEIGHT) { _dsRowH = h; changed = true; }   // seed from first real row
            const path = el.dataset.path;
            const prev = _dsHeightCache.get(path);
            const assumed = (prev !== undefined && prev > 0) ? prev : _dsRowH;
            if (prev === undefined || Math.abs(prev - h) > 1) _dsHeightCache.set(path, h);
            if (Math.abs(assumed - h) > 1) changed = true;
        });
        if (!changed) return;
        _dsRebuildOffsets();
        _dsPositionSpacers();
        _dsRenderWindow(false);
    });
}

function _dsAttachScrollHandler() {
    const wrapper = document.getElementById('tableScrollWrapper');
    if (!wrapper) return;
    _dsDetachScrollHandler();
    _dsScrollHandler = () => {
        if (_dsScrollRafPending) return;
        _dsScrollRafPending = true;
        requestAnimationFrame(() => {
            _dsScrollRafPending = false;
            if (isSearchResultsDisplayed) _dsRenderWindow(false);
        });
    };
    wrapper.addEventListener('scroll', _dsScrollHandler, { passive: true });

    // Wrapping (and so row height) depends on width: on resize drop the height
    // cache and keep the row that is at the top of the viewport at the top.
    _dsResizeHandler = () => {
        clearTimeout(_dsResizeTimer);
        _dsResizeTimer = setTimeout(_dsOnResize, _DS_RESIZE_DEBOUNCE_MS);
    };
    window.addEventListener('resize', _dsResizeHandler);
}

function _dsDetachScrollHandler() {
    const wrapper = document.getElementById('tableScrollWrapper');
    if (wrapper && _dsScrollHandler) wrapper.removeEventListener('scroll', _dsScrollHandler);
    _dsScrollHandler = null;
    _dsScrollRafPending = false;
    if (_dsResizeHandler) window.removeEventListener('resize', _dsResizeHandler);
    _dsResizeHandler = null;
    clearTimeout(_dsResizeTimer);
}

function _dsOnResize() {
    if (!isSearchResultsDisplayed || !_dsAll.length || !_dsOffsets) return;
    const wrapper = document.getElementById('tableScrollWrapper');
    if (!wrapper) return;
    const rel = wrapper.scrollTop - _dsListBase;
    const idx = _dsFindIndexAtOffset(rel);
    const intra = rel - _dsOffsets[idx];
    _dsHeightCache.clear();
    _dsRebuildOffsets();
    _dsListBase = _dsMeasureListBase(wrapper);
    const st = Math.max(0, _dsListBase + _dsOffsets[idx] + intra);
    _dsRenderWindow(true, st);
    wrapper.scrollTop = st;
    if (_dsMounted.size) _dsScheduleMeasure(Array.from(_dsMounted.values()), _dsGen);
}

// Build the spacer rows + first window for a fresh result set. The hidden
// folder rows (VT) stay in the tbody untouched; result rows go after them.
function _dsBuildWindow() {
    const tbody = document.querySelector('#filesTable tbody');
    const wrapper = document.getElementById('tableScrollWrapper');
    if (!tbody) return;

    _dsMounted = new Map();
    _dsWinStart = 0; _dsWinEnd = 0;
    _dsHeightCache = new Map();
    _dsRowH = _DS_DEFAULT_ROW_HEIGHT;

    _dsTopRow = _dsMakeSpacerRow('dsTopSpacer');
    _dsBottomRow = _dsMakeSpacerRow('dsBottomSpacer');
    _dsTopCell = _dsTopRow.firstElementChild;
    _dsBottomCell = _dsBottomRow.firstElementChild;
    tbody.appendChild(_dsTopRow);
    tbody.appendChild(_dsBottomRow);
    _dsSyncLoadingRow();

    if (wrapper) wrapper.scrollTop = 0;   // a new search always starts at the top
    _dsRebuildOffsets();
    _dsListBase = _dsMeasureListBase(wrapper);
    _dsRenderWindow(true, 0);
    _dsAttachScrollHandler();
}

function _dsFetchNextPage() {
    if (_dsFetching || !_dsHasMore) return;
    _dsFetching = true;
    const gen = _dsGen;

    let url = `/api/search?q=${encodeURIComponent(_dsQuery)}&offset=${_dsOffset}&limit=${_DS_LIMIT}`;
    if (_dsExts.length) url += `&ext=${encodeURIComponent(_dsExts.join(','))}`;

    fetch(url)
        .then(r => r.json())
        .then(data => {
            if (gen !== _dsGen || !isSearchResultsDisplayed) return;   // search closed or replaced mid-fetch
            const page = data.results || [];
            page.forEach(r => { r._dsSeq = _dsSeqNext++; });
            _dsAll = _dsAll.concat(page);
            _dsOffset += page.length;
            _dsHasMore = !!data.has_more && page.length > 0;   // an empty page ends paging (no infinite loop)
            _dsFetching = false;

            _dsRebuildOffsets();
            _dsSyncLoadingRow();
            _dsRenderWindow(true);
            _dsUpdateCount();
        })
        .catch(err => {
            console.error('❌ Deep search next page error:', err);
            if (gen !== _dsGen) return;
            _dsFetching = false;
            _dsHasMore = false;     // stop retrying on every scroll tick; a new search resets this
            _dsSyncLoadingRow();
        });
}

function _dsUpdateCount() {
    updateVisibleCount(_dsAll.length);
    // Header count badge is set once from total_count on first page — only the
    // delete handlers rewrite it (via _dsRemoveResults).
}

function _dsHeaderCountLabel() {
    if (_dsTotal != null) return _dsTotal.toLocaleString();
    return `${_dsAll.length}${_dsHasMore ? '+' : ''}`;
}

// Drop deleted paths from the result data (rows are no longer 1:1 with the
// DOM, so deleting a <tr> is not enough — the data array is the source of truth).
function _dsRemoveResults(paths) {
    if (!isSearchResultsDisplayed) return;
    const dead = new Set(paths);
    const kept = _dsAll.filter(r => !dead.has(r.path));
    const removed = _dsAll.length - kept.length;
    if (removed > 0) {
        _dsAll = kept;
        if (_dsTotal != null) _dsTotal = Math.max(0, _dsTotal - removed);
        // Indices shifted: unmount everything and re-mount from the data.
        for (const el of _dsMounted.values()) el.remove();
        _dsMounted = new Map();
        _dsWinStart = 0; _dsWinEnd = 0;
        _dsRebuildOffsets();
        _dsPositionSpacers();
        if (_dsAll.length) _dsRenderWindow(true);
        else if (_dsHasMore) _dsFetchNextPage();
    }
    const countEl = document.querySelector('#searchResultsHeader .search-count');
    if (countEl) countEl.textContent = `${_dsHeaderCountLabel()} items found`;
    _dsUpdateCount();
}

// ── Deep-search sorting ──────────────────────────────────────────────────────
// VT.applySort bails out in search mode (the results are not in VT's data
// array), so deep search sorts _dsAll itself. The server returns results in
// pages of _DS_LIMIT in index order, so sorting only the loaded pages would be
// wrong while has_more is true: the remaining pages are fetched first, then
// the whole list is sorted and the window rebuilt. Folders sort first, same as
// the normal table. The folder's own currentSort is NOT touched.
function _dsModifiedKey(v) {
    if (typeof v === 'number') return v;
    if (!v) return 0;
    const t = Date.parse(String(v).replace(' ', 'T'));
    return isNaN(t) ? 0 : t;
}

function _dsCompare(a, b, col, dir) {
    if (a.is_dir && !b.is_dir) return dir === 1 ? -1 : 1;
    if (!a.is_dir && b.is_dir) return dir === 1 ? 1 : -1;
    let cmp = 0;
    if (col === 'name') {
        cmp = String(a.name).localeCompare(String(b.name), undefined, { numeric: true, sensitivity: 'base' });
    } else if (col === 'size') {
        cmp = ((a.size != null) ? a.size : -1) - ((b.size != null) ? b.size : -1);
    } else if (col === 'modified') {
        cmp = _dsModifiedKey(a.modified) - _dsModifiedKey(b.modified);
    } else if (col === 'type') {
        const ta = a.is_dir ? 'Folder' : getFileType(a.name);
        const tb = b.is_dir ? 'Folder' : getFileType(b.name);
        cmp = String(ta).localeCompare(String(tb), undefined, { numeric: true, sensitivity: 'base' });
    }
    return cmp * dir;
}

// Header arrows follow the deep-search sort while results are open, and go
// back to the folder's currentSort when they close or a new search starts.
function _dsRestoreSortHeaders() {
    if (currentSort.column) {
        updateSortHeaders(currentSort.column, currentSort.direction);
    } else {
        document.querySelectorAll('.sortable').forEach(header => {
            header.classList.remove('sort-asc', 'sort-desc');
            const icon = header.querySelector('.sort-icon');
            if (icon) icon.className = 'fas fa-sort sort-icon';
        });
        updateSortInfo(null, null);
    }
}

function _dsLoadAllPages(gen) {
    // Fetch every remaining page (1000 rows each, the server maximum).
    const step = () => {
        if (gen !== _dsGen || !_dsHasMore) return Promise.resolve();
        let url = `/api/search?q=${encodeURIComponent(_dsQuery)}&offset=${_dsOffset}&limit=1000`;
        if (_dsExts.length) url += `&ext=${encodeURIComponent(_dsExts.join(','))}`;
        return fetch(url).then(r => r.json()).then(data => {
            if (gen !== _dsGen) return;
            const page = data.results || [];
            page.forEach(r => { r._dsSeq = _dsSeqNext++; });
            _dsAll = _dsAll.concat(page);
            _dsOffset += page.length;
            _dsHasMore = !!data.has_more && page.length > 0;
            return step();
        });
    };
    return step();
}

function _dsApplySort() {
    const dir = _dsSort.direction === 'asc' ? 1 : -1;
    const col = _dsSort.column;
    if (col) _dsAll.sort((a, b) => _dsCompare(a, b, col, dir));
    else _dsAll.sort((a, b) => (a._dsSeq || 0) - (b._dsSeq || 0));   // Reset Sort: back to server order

    // Indices changed: unmount everything and re-mount from the sorted data.
    for (const el of _dsMounted.values()) el.remove();
    _dsMounted = new Map();
    _dsWinStart = 0; _dsWinEnd = 0;
    _dsRebuildOffsets();
    _dsSyncLoadingRow();
    _dsPositionSpacers();
    const wrapper = document.getElementById('tableScrollWrapper');
    if (wrapper) wrapper.scrollTop = 0;
    _dsRenderWindow(true, 0);
    _dsUpdateCount();
}

function _dsResetSort() {
    _dsSort = { column: null, direction: 'asc' };
    _dsRestoreSortHeaders();
    const resetBtn = document.getElementById('resetSort');
    if (resetBtn && !currentSort.column) resetBtn.style.display = 'none';
    if (_dsFetching) return;
    _dsApplySort();
}

function _dsSortResults(column, forceDirection) {
    if (_dsFetching) return;   // a page or sort-load is already in flight
    // One click must toggle once: if the same header's click reaches us twice
    // (two listeners on the header), the second call would flip it straight back.
    const now = Date.now();
    if (!forceDirection && now - _dsSortClickAt < 250) return;
    _dsSortClickAt = now;
    if (forceDirection) {
        _dsSort = { column, direction: forceDirection };
    } else if (_dsSort.column === column) {
        _dsSort.direction = _dsSort.direction === 'asc' ? 'desc' : 'asc';
    } else {
        _dsSort = { column, direction: 'asc' };
    }
    updateSortHeaders(_dsSort.column, _dsSort.direction);
    const resetBtn = document.getElementById('resetSort');
    if (resetBtn) resetBtn.style.display = 'inline-block';

    if (!_dsHasMore) { _dsApplySort(); return; }

    const gen = _dsGen;
    _dsFetching = true;   // blocks the scroll-prefetch while we load everything
    showSearchLoading(true);   // spinner in the search box while the rest loads
    _dsLoadAllPages(gen)
        .then(() => {
            showSearchLoading(false);
            if (gen !== _dsGen || !isSearchResultsDisplayed) return;
            _dsFetching = false;
            _dsApplySort();
        })
        .catch(err => {
            console.error('❌ Deep search sort load error:', err);
            showSearchLoading(false);
            if (gen !== _dsGen) return;
            _dsFetching = false;
            _dsHasMore = false;
            _dsApplySort();   // sort what did load rather than leave the list unsorted
            showNotification('Sort incomplete', 'Could not load every result; sorted the ones that did load.', 'error');
        });
}

// ── *.ext query parser ────────────────────────────────────────────────────────
// Supports: *.css  |  *.css,js,ts  |  report *.css  |  *.css,js report
function _parseSearchQuery(rawTerm) {
    const extRe = /\*\.([a-zA-Z0-9]+(?:,[a-zA-Z0-9]+)*)/g;
    let exts = [];
    let m;
    while ((m = extRe.exec(rawTerm)) !== null) {
        m[1].split(',').forEach(e => { if (e) exts.push(e.toLowerCase()); });
    }
    const query = rawTerm.replace(/\s*\*\.[a-zA-Z0-9]+(?:,[a-zA-Z0-9]+)*/g, '').trim();
    return { query, exts };
}

// Explicit search trigger (v4.46). Search no longer runs while typing: it runs
// only when the user clicks the Search button (data-fn="runSearch") or presses
// Enter in #tableSearch. 1-2 chars (no *.ext) filter the current folder;
// 3+ chars or an *.ext term run the deep search.
function runSearch() {
    const input = document.getElementById('tableSearch');
    if (!input) return;
    searchTable(input.value);
}

// Immediate (non-debounced) search of `searchTerm`. Kept under its old name.
function searchTable(searchTerm) {
    clearTimeout(searchTimeout);

    // Show/hide clear button
    _syncClearButton(searchTerm);

    const term = (searchTerm || '').trim();
    if (term.length > 0) {
        const { query, exts } = _parseSearchQuery(term);
        if (exts.length || query.length >= _DEEP_SEARCH_MIN_CHARS) {
            performDeepSearch(term);
        } else {
            // 1-2 characters: current-folder filter only. performLocalSearch()
            // also tears down any deep-search list that is still showing.
            performLocalSearch(term);
        }
    } else {
        // Empty query — clear deep search and reset VT view
        hideDeepSearchResults();
        VT.applyFilter('');
    }
}

function _syncClearButton(value) {
    const clearButton = document.getElementById('clearSearch');
    if (clearButton) clearButton.style.display = (value || '').trim() ? 'block' : 'none';
}

// Typing only updates the clear (X) button; Enter starts the search.
document.addEventListener('input', function (e) {
    if (e.target && e.target.id === 'tableSearch') _syncClearButton(e.target.value);
});
document.addEventListener('keydown', function (e) {
    if (e.target && e.target.id === 'tableSearch' && e.key === 'Enter' && !e.isComposing) {
        e.preventDefault();
        runSearch();
    }
});

// Deep search using API to scan nested folders
function performDeepSearch(rawTerm) {
    const { query, exts } = _parseSearchQuery(rawTerm);

    if (!query && !exts.length) {
        hideDeepSearchResults();
        VT.applyFilter('');
        return;
    }

    console.log(`🔍 Starting deep search: query="${query}" exts=${JSON.stringify(exts)}`);
    showSearchLoading(true);

    // Reset state for a fresh search (bump _dsGen so any in-flight page fetch
    // from the previous query is discarded)
    _dsGen++;
    _dsAll = [];
    _dsTotal = null;
    _dsOffset = 0;
    _dsHasMore = false;
    _dsFetching = false;
    _dsSort = { column: null, direction: 'asc' };
    _dsSeqNext = 0;
    _dsRestoreSortHeaders();
    _dsQuery = query;
    _dsExts = exts;
    _dsSearchTerm = query || exts.join(',');

    let url = `/api/search?q=${encodeURIComponent(query)}&offset=0&limit=${_DS_LIMIT}`;
    if (exts.length) url += `&ext=${encodeURIComponent(exts.join(','))}`;

    // Drop this response if the search was closed or replaced while it was in
    // flight (e.g. the user backspaced to a 1-2 char local filter).
    const gen = _dsGen;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (gen !== _dsGen) return;
            console.log(`✅ Deep search results:`, data);
            displayDeepSearchResults(data, _dsSearchTerm, exts);
        })
        .catch(error => {
            if (gen !== _dsGen) return;
            console.error('❌ Deep search error:', error);
            showNotification('Search failed. Please try again.', 'ERROR');
            performLocalSearch(query || rawTerm);
        })
        .finally(() => {
            showSearchLoading(false);
        });
}


// Wraps matches of `term` in <span class="search-highlight"> inside a file-table
// row's name cell. Works on TEXT NODES only, so the row's icon <i>, the folder
// <a> and the preview (eye) button survive - the old version rewrote
// .file-name.innerHTML and destroyed the icon/button on file rows. Idempotent
// (previous highlights are unwrapped first) and regex-safe (term is escaped).
function highlightSearchTerm(row, term) {
    const nameCell = row.querySelector('td:nth-child(2) .file-name');
    if (!nameCell) return;

    // Unwrap any earlier highlight so re-running never nests spans.
    nameCell.querySelectorAll('span.search-highlight').forEach(s => {
        s.replaceWith(document.createTextNode(s.textContent));
    });
    nameCell.normalize();

    // File rows keep the name as a BARE text node directly inside .file-name,
    // which is a flex container. A highlight <span> dropped in there splits the
    // name into separate flex items (gaps around the match, "Q/B" stacked
    // vertically in narrow columns). Wrap the bare name text in one span first
    // so the whole name stays a single flex item and the highlight is inline
    // inside it - exactly how folder rows already work (name lives in an <a>).
    Array.from(nameCell.childNodes).forEach(n => {
        if (n.nodeType === Node.TEXT_NODE && n.nodeValue.trim()) {
            const wrap = document.createElement('span');
            wrap.className = 'fn-text';
            n.parentNode.replaceChild(wrap, n);
            wrap.appendChild(n);
        }
    });

    const needle = String(term == null ? '' : term).trim();
    if (!needle) return;
    const regex = new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');

    const walker = document.createTreeWalker(nameCell, NodeFilter.SHOW_TEXT, {
        acceptNode: n => (n.parentElement && n.parentElement.closest('button'))
            ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT
    });
    const textNodes = [];
    while (walker.nextNode()) textNodes.push(walker.currentNode);

    textNodes.forEach(node => {
        const text = node.nodeValue;
        regex.lastIndex = 0;
        let m, last = 0, frag = null;
        while ((m = regex.exec(text)) !== null) {
            if (m[0].length === 0) { regex.lastIndex++; continue; }
            if (!frag) frag = document.createDocumentFragment();
            if (m.index > last) frag.appendChild(document.createTextNode(text.slice(last, m.index)));
            const span = document.createElement('span');
            span.className = 'search-highlight';
            span.textContent = m[0];
            frag.appendChild(span);
            last = m.index + m[0].length;
        }
        if (frag) {
            if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
            node.parentNode.replaceChild(frag, node);
        }
    });
}


function displayDeepSearchResults(data, searchTerm, exts) {
    if (!data.results || data.results.length === 0) {
        const label = exts && exts.length
            ? `*.${exts.join(', *.')}${searchTerm && searchTerm !== exts.join(',') ? ` containing "${searchTerm}"` : ''}`
            : `"${searchTerm}"`;
        // Nothing deeper in the tree: fall back to filtering the current folder,
        // and only say "no results" if that finds nothing either (it used to
        // toast "No results found" while the local filter was showing a hit).
        performLocalSearch(searchTerm);
        const shown = parseInt((document.getElementById('visibleCount') || {}).textContent, 10) || 0;
        if (shown > 0) {
            showNotification(`No matches in subfolders for ${label} - showing ${shown} in this folder`, 'INFO');
        } else {
            showNotification(`No results found for ${label}`, 'INFO');
        }
        return;
    }

    hideDeepSearchResults();
    hideLocalResults();

    _dsAll = data.results.slice();
    _dsAll.forEach(r => { r._dsSeq = _dsSeqNext++; });
    _dsTotal = (data.total_count != null) ? data.total_count : null;
    _dsHasMore = data.has_more || false;
    _dsOffset = data.results.length;
    _dsSearchTerm = searchTerm;

    isSearchResultsDisplayed = true;
    VT.markSearchResults();

    // Pass exact total_count to header so it shows immediately
    const table = document.getElementById('filesTable');
    const searchHeader = createSearchResultsHeaderDiv(data, exts);
    table.parentNode.insertBefore(searchHeader, table);

    // Windowed render: only the first viewport of rows is created; the rest
    // of _dsAll is mounted on demand as the user scrolls.
    _dsBuildWindow();
    _dsUpdateCount();

    const extLabel = exts && exts.length ? ` [*.${exts.join(', *.')}]` : '';
    const totalLabel = data.total_count != null ? data.total_count.toLocaleString() : data.results.length;
    showNotification(
        `Found ${totalLabel} results${extLabel} (${data.search_time}s)`,
        'SUCCESS'
    );
}

function createSearchResultsHeaderDiv(data, exts) {
    const headerDiv = document.createElement('div');
    headerDiv.className = 'search-results-header-div';
    headerDiv.id = 'searchResultsHeader';

    const extBadge = exts && exts.length
        ? `<span class="search-ext-badge">*.${escapeHtml(exts.join(' *.'))}</span>`
        : '';

    // Show exact total immediately if the index provided it;
    // fall back to page count with '+' if not (e.g. index still building).
    const countLabel = data.total_count != null
        ? data.total_count.toLocaleString()
        : `${data.results.length}${data.has_more ? '+' : ''}`;

    headerDiv.innerHTML = `
        <div class="search-header-content">
            <div class="search-header-main">
                <i class="fas fa-search-plus"></i>
                <span class="search-title">Deep Search Results</span>
                <span class="search-count">${escapeHtml(countLabel)} items found</span>
                ${extBadge}
            </div>
            <div class="search-header-meta">
                <span class="search-time">Search time: ${escapeHtml(data.search_time)}s</span>
                <button data-fn="clearSearch" class="btn-close-search">
                    <i class="fas fa-times"></i> Close Results
                </button>
            </div>
        </div>
    `;

    return headerDiv;
}


function createSearchResultRow(result, searchTerm) {
    const row = document.createElement('tr');
    row.className = 'file-row search-result-row';
    row.dataset.path = result.path;

    const sizeDisplay = result.is_dir ? `<span class="folder-size-text">Folder</span>` : formatFileSize(result.size);

    // Extract folder path (excluding filename)
    const pathParts = result.path.split('/');
    const folderPath = pathParts.slice(0, -1).join('/');
    const displayPath = folderPath || 'Root';

    // Build safer name HTML using escapeHtml and mapping for icon/type
    let nameHtml = '';
    if (result.is_dir) {
        nameHtml = `
        <div class="search-result-name">
            <div class="search-result-icon">
                <i class="fas fa-folder"></i>
            </div>
            <div class="search-result-details">
                <div class="search-result-title">
                    <a href="#" data-fn="navigateToFolder" data-args="${dataArgs([result.path])}" data-prevent="1"
                       class="search-folder-link">
                        ${highlightText(result.name, searchTerm)}
                    </a>
                </div>
                <div class="search-result-path">
                    <i class="fas fa-folder-open"></i>
                    /${escapeHtml(displayPath)}
                </div>
            </div>
        </div>`;
    } else {
        const iconClass = getFileIcon(result.name);
        const typeText = getFileType(result.name);
        nameHtml = `
        <div class="search-result-name">
            <div class="search-result-icon">
                <i class="${iconClass}"></i>
            </div>
            <div class="search-result-details">
                <div class="search-result-title">
                    ${highlightText(result.name, searchTerm)}
                </div>
                <div class="search-result-path">
                    <i class="fas fa-folder-open"></i>
                    /${escapeHtml(displayPath)}
                </div>
            </div>
        </div>`;
        // expose type for the column below
        result._derived_type = typeText;
    }

    const actionsHtml = result.is_dir ?
        `<div class="search-result-actions">
            <button class="btn btn-sm btn-primary" data-fn="navigateToFolder" data-args="${dataArgs([result.path])}" title="Open folder">
                <i class="fas fa-folder-open"></i>
            </button>
            <button class="btn btn-sm btn-success" data-fn="downloadFolderAsZip" data-args="${dataArgs([result.path, result.name])}" title="Download folder as ZIP">
                <i class="fas fa-download"></i>
            </button>
            <button class="btn btn-sm btn-outline" data-fn="openFileLocation" data-args="${dataArgs([folderPath])}" title="Open file location">
                <i class="fas fa-level-up-alt"></i>
            </button>
        </div>` :
        `<div class="search-result-actions">
            <button class="btn btn-sm btn-success" data-fn="showDownloadOptionsModal" data-args="${dataArgs([result.path, result.name])}" title="Download">
                <i class="fas fa-download"></i>
            </button>
            <button class="btn btn-sm btn-outline" data-fn="openFileLocation" data-args="${dataArgs([folderPath])}" title="Open file location">
                <i class="fas fa-folder-open"></i>
            </button>
        </div>`;

    row.innerHTML = `
        <td class="search-checkbox-cell">
            <input type="checkbox" class="file-checkbox item-checkbox" 
                   data-path="${escapeHtml(result.path)}"
                   data-name="${escapeHtml(result.name)}"
                   data-is-dir="${result.is_dir}"
                   data-fn-change="updateSelection">
        </td>
        <td class="search-name-cell">${nameHtml}</td>
        <td class="search-size-cell">${sizeDisplay}</td>
        <td class="search-type-cell">${escapeHtml(result._derived_type || result.type || (result.is_dir ? 'Folder' : getFileType(result.name)))}</td>
        <td class="search-date-cell">${result.modified}</td>
        <td class="search-actions-cell">${actionsHtml}</td>
    `;

    return row;
}

// Takes RAW (unescaped) text and returns safe HTML with matches wrapped in
// <span class="search-highlight">. Escaping is done per piece AFTER matching:
// matching against already-escaped text let a query like "amp", "lt" or "39"
// match inside an entity (&amp; &lt; &#039;) and emit broken markup.
function highlightText(text, searchTerm) {
    const raw = String(text == null ? '' : text);
    const needle = String(searchTerm == null ? '' : searchTerm).trim();
    if (!needle) return escapeHtml(raw);
    // Escape regex metacharacters: a query like "c++" or "(" used to throw here.
    const safeTerm = needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(safeTerm, 'gi');
    let out = '', last = 0, m;
    while ((m = regex.exec(raw)) !== null) {
        if (m[0].length === 0) { regex.lastIndex++; continue; }
        out += escapeHtml(raw.slice(last, m.index))
            + '<span class="search-highlight">' + escapeHtml(m[0]) + '</span>';
        last = m.index + m[0].length;
    }
    return out + escapeHtml(raw.slice(last));
}

function hideLocalResults() {
    const table = document.getElementById('filesTable');
    const tbody = table.querySelector('tbody');
    const rows = tbody.querySelectorAll('tr:not(.search-results-header):not(.search-result-row):not(.ds-spacer-row):not(.ds-loading-row)');

    rows.forEach(row => {
        if (!row.innerHTML.includes('.. (Parent Directory)')) {
            row.style.display = 'none';
        }
    });
}

function hideDeepSearchResults() {
    isSearchResultsDisplayed = false;

    // Tear down the windowed result list. Bumping _dsGen invalidates any
    // in-flight page fetch and any queued measure pass.
    _dsGen++;
    _dsDetachScrollHandler();
    _dsAll = [];
    _dsTotal = null;
    _dsOffset = 0;
    _dsHasMore = false;
    _dsFetching = false;
    if (_dsSort.column) { _dsSort = { column: null, direction: 'asc' }; _dsRestoreSortHeaders(); }
    _dsOffsets = null;
    _dsMounted = new Map();
    _dsWinStart = 0; _dsWinEnd = 0;
    _dsHeightCache = new Map();
    _dsRowH = _DS_DEFAULT_ROW_HEIGHT;
    _dsListBase = 0;

    // Remove result rows, spacers and the loading row
    const searchRows = document.querySelectorAll('.search-results-header, .search-result-row, .ds-spacer-row, .ds-loading-row');
    searchRows.forEach(row => row.remove());
    _dsTopRow = _dsBottomRow = _dsTopCell = _dsBottomCell = _dsLoadRow = null;

    // Remove div-based search header
    const searchHeaderDiv = document.getElementById('searchResultsHeader');
    if (searchHeaderDiv) searchHeaderDiv.remove();

    // Show local results again
    const tbody = document.querySelector('#filesTable tbody');
    if (tbody) tbody.querySelectorAll('tr').forEach(row => { row.style.display = ''; });
}

function showSearchLoading(show) {
    const searchInput = document.getElementById('tableSearch');
    if (show) {
        searchInput.style.background = 'url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICAgIDxjaXJjbGUgY3g9IjEwIiBjeT0iMTAiIHI9IjMiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzMzMzMzMyIgc3Ryb2tlLXdpZHRoPSIyIj4KICAgICAgICA8YW5pbWF0ZSBhdHRyaWJ1dGVOYW1lPSJyIiB2YWx1ZXM9IjM7NjszIiBkdXI9IjFzIiByZXBlYXRDb3VudD0iaW5kZWZpbml0ZSIvPgogICAgPC9jaXJjbGU+Cjwvc3ZnPg==") no-repeat right 10px center';
        searchInput.style.paddingRight = '35px';
    } else {
        searchInput.style.background = '';
        searchInput.style.paddingRight = '';
    }
}

function updateVisibleCount(count) {
    const visibleCountSpan = document.getElementById('visibleCount');
    if (visibleCountSpan) {
        visibleCountSpan.textContent = count;
    }
}


// Open file location function for search results
function openFileLocation(folderPath) {
    console.log(`🔍 === OPEN FILE LOCATION START ===`);
    console.log(`🔍 Input folderPath: "${folderPath}"`);
    console.log(`🔍 folderPath type: ${typeof folderPath}`);
    console.log(`🔍 Current path before: "${currentPath}"`);

    // IMPORTANT: Clear search when opening file location
    console.log(`🧹 Clearing search before navigation...`);
    clearSearch();
    hideDeepSearchResults();

    // Clean and validate the folder path
    let targetPath = '';
    if (!folderPath || folderPath === 'Root' || folderPath === '' || folderPath === '/') {
        console.log(`📁 Navigating to root directory (empty path)`);
        targetPath = '';
    } else {
        // Ensure path doesn't start with / and clean it
        targetPath = String(folderPath).replace(/^\/+/, '').trim();
        console.log(`📁 Cleaned target path: "${targetPath}"`);
    }

    console.log(`� Final target path: "${targetPath}"`);
    console.log(`🔍 Calling navigateToFolder...`);

    // Navigate to the folder containing the file
    console.log("🚀 About to call navigateToFolder...");
    navigateToFolder(targetPath).then(() => {
        console.log("✅ navigateToFolder completed successfully");
    }).catch((error) => {
        console.error("❌ navigateToFolder failed:", error);
    });
}

function clearSearch() {
    const searchInput = document.getElementById('tableSearch');
    const clearButton = document.getElementById('clearSearch');

    searchInput.value = '';
    clearButton.style.display = 'none';

    // Clear both local and deep search results
    hideDeepSearchResults();
    performLocalSearch('');
}

// Column sorting functionality
function sortTable(column, forceDirection) {
    // Deep-search results are not in VT's data array: sort them separately.
    if (isSearchResultsDisplayed) {
        _dsSortResults(column, forceDirection);
        return;
    }

    // Show reset button
    const resetBtn = document.getElementById('resetSort');
    if (resetBtn) resetBtn.style.display = 'inline-block';

    // Delegate to VT engine (works on data array, handles re-render)
    VT.applySort(column, forceDirection);

    console.log(`📊 Sorted by ${column} (${currentSort.direction})`);
}



function parseSize(sizeStr) {
    if (!sizeStr || sizeStr === '--') {
        return 0;
    }

    // Try to extract size value (works for both files and folders)
    const match = sizeStr.match(/([\d.]+)\s*(bytes?|KB|MB|GB|TB)?/i);
    if (!match) return 0;

    const number = parseFloat(match[1]);
    const unit = (match[2] || '').toLowerCase();

    switch (unit) {
        case 'tb': return number * 1024 * 1024 * 1024 * 1024;
        case 'gb': return number * 1024 * 1024 * 1024;
        case 'mb': return number * 1024 * 1024;
        case 'kb': return number * 1024;
        default: return number;
    }
}




function updateSortHeaders(activeColumn, direction) {
    // Reset all headers
    document.querySelectorAll('.sortable').forEach(header => {
        header.classList.remove('sort-asc', 'sort-desc');
        const icon = header.querySelector('.sort-icon');
        if (icon) icon.className = 'fas fa-sort sort-icon';
    });

    // Update active header
    const activeHeader = document.querySelector(`[data-sort="${activeColumn}"]`);
    if (activeHeader) {
        activeHeader.classList.add(`sort-${direction}`);
        const icon = activeHeader.querySelector('.sort-icon');
        if (icon) {
            icon.className = `fas fa-sort-${direction === 'asc' ? 'up' : 'down'} sort-icon`;
        }
    }

    // Update sort info and show/hide reset button
    updateSortInfo(activeColumn, direction);
}

// Store original table order for reset functionality
function storeOriginalTableOrder() {
    const table = document.getElementById('filesTable');
    if (!table) return;

    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));

    // Store clones of all rows in their original order
    originalRowOrder = rows.map(row => row.cloneNode(true));

    console.log('📋 Stored original table order:', originalRowOrder.length, 'rows');
}

// Update sort information display
function updateSortInfo(column, direction) {
    const sortInfo = document.getElementById('currentSortInfo');
    const resetButton = document.getElementById('resetSort');

    if (column && direction) {
        const columnNames = {
            'name': 'Name',
            'size': 'Size',
            'type': 'Type',
            'modified': 'Modified'
        };

        const directionText = direction === 'asc' ? 'ascending' : 'descending';
        const columnText = columnNames[column] || column;

        if (sortInfo) {
            sortInfo.textContent = `• Sorted by ${columnText} (${directionText})`;
        }

        if (resetButton) {
            resetButton.style.display = 'inline-flex';
        }
    } else {
        if (sortInfo) {
            sortInfo.textContent = '';
        }

        if (resetButton) {
            resetButton.style.display = 'none';
        }
    }
}

// Reset sorting to default state, wired from the resetSort button's onclick in index.html
function resetSorting() {
    console.log('🔄 Resetting table sorting to default');

    // Deep search open: reset only ITS sort (back to the server's order) and keep
    // the results on screen; the folder's own sort and the search box are untouched.
    if (isSearchResultsDisplayed) {
        _dsResetSort();
        return;
    }

    // Clear deep search results first
    hideDeepSearchResults();

    // Clear search input and hide clear button
    const searchInput = document.getElementById('tableSearch');
    const clearButton = document.getElementById('clearSearch');
    if (searchInput) searchInput.value = '';
    if (clearButton) clearButton.style.display = 'none';

    // Reset sort state
    currentSort = { column: null, direction: 'asc' };

    // Reset all header styles
    document.querySelectorAll('.sortable').forEach(header => {
        header.classList.remove('sort-asc', 'sort-desc');
        const icon = header.querySelector('.sort-icon');
        if (icon) icon.className = 'fas fa-sort sort-icon';
    });

    // Update sort info display
    updateSortInfo(null, null);

    // Always fetch fresh data — never restore stale DOM clones.
    // Clones captured at render time show deleted files if any refresh
    // was blocked between the delete and this reset call.
    refreshFileTable();

    console.log('✅ Table sorting reset — fetching fresh data from server');
}

// Reinitialize table controls after content update
function reinitializeTableControls(itemCount) {
    // Update visible count
    const visibleCountSpan = document.getElementById('visibleCount');
    if (visibleCountSpan) {
        visibleCountSpan.textContent = itemCount;
    }

    // NOTE: do NOT call VT.applyFilter here either — VT._renderAll already
    // applies the current _filter before rendering rows. Calling applyFilter
    // here would re-trigger _renderAll (another infinite loop).

    // NOTE: do NOT call sortTable here — VT already sorts on the data array
    // before rendering. Calling sortTable here would cause an infinite loop:
    // _renderAll → reinitializeTableControls → sortTable → VT.applySort → _renderAll

    // Initialize sort event listeners for any new headers
    document.querySelectorAll('.sortable').forEach(header => {
        // Remove existing event listeners by cloning
        const newHeader = header.cloneNode(true);
        header.parentNode.replaceChild(newHeader, header);

        // Add new event listener
        newHeader.addEventListener('click', function () {
            const column = this.dataset.sort;
            if (column) {
                sortTable(column);
            }
        });
    });

    // Re-apply table-layout:fixed after cloneNode replaces <th> elements
    lockTableColumnWidths();
}

// Upload queue management
let uploadQueue = [];
// Folder groups — keyed by groupId, one entry per folder upload
const folderGroups = new Map();
// O(1) duplicate check — replaces O(n) uploadQueue.find()
const _seenFileKeys = new Set();
let isUploading = false;
let _mutationInFlight = false; // blocks SSE refresh during delete/move
let _deletingPaths = new Set(); // paths currently being deleted — for real-time size feedback
let _lastFreeSpace = null;      // last known free_space from SSE for delta calculation
let _lastTableRefresh = 0;
let currentUploadIndex = 0;
let currentUploadingFile = null;
let cancelledUploads = new Set(); // Track cancelled upload IDs
let uploadStartTime = 0;
// BUG FIX: Throttle timestamp for mid-upload table refreshes (Bug 2)
let _lastMidUploadTableRefresh = 0;
let totalBytesToUpload = 0;
let totalBytesUploaded = 0;
let lazyBytesUploaded = 0; // bytes from completed lazy folder files

// --- Upload freeze/resume protection ---
// Tracks the last time any file completed uploading. Used by the stall detector
// to decide if the upload loop froze when the tab was backgrounded.
let _lastUploadActivity = 0;
// Cooldown tracker: prevents _resumeStalledUploads from spawning duplicate loops
// when the user switches tabs multiple times in quick succession.
let _lastResumeTime = 0;
// Interval handle for session keepalive pings (sent every 60s during uploads)
let _sessionKeepAliveInterval = null;

// Parallel upload configuration
const PARALLEL_UPLOAD_CONFIG = {
    maxConcurrentUploads: 10,  // Number of files to upload simultaneously
    enableParallelUploads: true,  // Can be toggled by user
    activeUploads: new Set(),  // Track currently uploading file IDs
    completedUploads: new Set(), // Track completed upload IDs for progress
};

// Utility function to update parallel upload settings
function setParallelUploadConfig(maxConcurrent, enabled = true) {
    PARALLEL_UPLOAD_CONFIG.maxConcurrentUploads = Math.max(1, Math.min(10, maxConcurrent)); // Limit 1-10
    PARALLEL_UPLOAD_CONFIG.enableParallelUploads = enabled;
    console.log(`⚡ Parallel uploads: ${enabled ? 'Enabled' : 'Disabled'}, Max concurrent: ${PARALLEL_UPLOAD_CONFIG.maxConcurrentUploads}`);
}

// Current path tracking for AJAX navigation
let currentPath = CURRENT_PATH;

// AJAX Folder Navigation
async function navigateToFolder(newPath) {
    try {
        console.log(`� === NAVIGATION START ===`);
        console.log(`📁 Current path: "${currentPath}"`);
        console.log(`📁 Target path: "${newPath}"`);
        console.log(`📁 Path type: ${typeof newPath}`);

        showUploadStatus('📁 Loading folder...', 'info');

        // Clean and validate the path
        const cleanPath = newPath ? String(newPath).trim() : '';
        console.log(`🧹 Cleaned path: "${cleanPath}"`);

        // Update URL without page refresh
        const url = cleanPath ? `/${cleanPath}` : '/';
        console.log(`🔗 Updating URL to: "${url}"`);
        window.history.pushState({ path: cleanPath }, '', url);

        // Fetch folder contents via API
        const apiUrl = cleanPath ? `/api/files/${encodeURIComponent(cleanPath)}` : '/api/files/';
        console.log(`📡 API URL: "${apiUrl}"`);
        console.log(`🔗 Fetching from: ${apiUrl}`);

        console.log("🚀 Starting fetch request...");
        // cache:'no-store' — never serve this call from the HTTP cache (a cached
        // 301 -> /login would replay as "Session expired" even while logged in).
        const response = await fetch(apiUrl, {
            cache: 'no-store',
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        });
        console.log(`📡 Response status: ${response.status} ${response.statusText}`);
        console.log(`📡 Response headers:`, response.headers);
        console.log("📡 Response object:", response);

        if (!response.ok) {
            // 401 means session expired — show message, redirect only if not uploading
            if (response.status === 401) {
                showUploadStatus('⚠️ Session expired — please log in again', 'error');
                if (!isUploading) {
                    setTimeout(() => { window.location.href = '/login'; }, 1500);
                }
                return;
            }
            throw new Error(`Failed to load folder: ${response.status} ${response.statusText}`);
        }

        // Guard: if the server returned HTML instead of JSON (e.g. session redirect),
        // handle gracefully without a JSON parse explosion.
        const contentType = response.headers.get('content-type') || '';
        if (!contentType.includes('application/json')) {
            showUploadStatus('⚠️ Session expired — please log in again', 'error');
            if (!isUploading) {
                setTimeout(() => { window.location.href = '/login'; }, 1500);
            }
            return;
        }

        console.log("🔄 Parsing response as JSON...");
        const data = await response.json();
        console.log(`📊 Raw API response:`, data);
        console.log(`📊 Response keys:`, Object.keys(data));
        console.log(`📊 data.success:`, data.success);
        console.log(`📊 data.files:`, data.files);
        console.log(`📊 data.error:`, data.error);

        if (!data.success) {
            console.error(`❌ API returned error:`, data.error);
            throw new Error(data.error || 'Failed to load folder contents');
        }

        // Handle different data formats from API
        let files = [];
        if (data.files && Array.isArray(data.files)) {
            files = data.files;
            console.log(`✅ Using data.files array`);
        } else if (data.items && Array.isArray(data.items)) {
            files = data.items;
            console.log(`✅ Using data.items array`);
        } else {
            console.warn(`⚠️ Unexpected data format:`, data);
            console.warn(`⚠️ data.files:`, data.files);
            console.warn(`⚠️ data.items:`, data.items);
            files = [];
        }

        console.log(`📁 Processed files array:`, files);
        console.log(`📁 Found ${files.length} items in folder`);

        // Update current path
        const oldPath = currentPath;
        currentPath = cleanPath;
        console.log(`📝 Updated currentPath: "${oldPath}" → "${currentPath}"`);

        // Update hidden path input
        const pathInput = document.querySelector('input[name="path"]');
        if (pathInput) {
            pathInput.value = currentPath;
            console.log(`📝 Updated hidden path input to: "${currentPath}"`);
        }

        // Update page content
        console.log(`🔄 Updating file table with ${files.length} items...`);
        console.log(`🔄 Files array:`, files);
        console.log(`🔄 Before update - table body innerHTML length:`, document.querySelector('#filesTable tbody')?.innerHTML?.length || 'not found');
        updateFileTable(files, cleanPath);
        console.log(`🔄 After update - table body innerHTML length:`, document.querySelector('#filesTable tbody')?.innerHTML?.length || 'not found');
        console.log(`🍞 Updating breadcrumb...`);
        updateBreadcrumb(cleanPath);

        // Scroll table rows to top, then bring table into view on the page
        requestAnimationFrame(() => {
            const wrapper = document.getElementById('tableScrollWrapper');
            if (wrapper) wrapper.scrollTop = 0;
            const fileTable = document.querySelector('.file-table');
            if (fileTable) fileTable.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });

        // Clear selection when navigating
        clearSelection();

        // Also clear any search filters when navigating
        const searchInput = document.getElementById('tableSearch');
        if (searchInput && searchInput.value) {
            console.log(`🧹 Clearing search filter during navigation...`);
            clearSearch();
        }

        console.log(`✅ === NAVIGATION SUCCESS ===`);
        showUploadStatus(`📁 Loaded folder: ${cleanPath || 'Root'}`, 'success');

    } catch (error) {
        console.error('❌ Navigation error:', error.message);
        showUploadStatus(`❌ Failed to load folder: ${error.message}`, 'error');

        // Only fallback-reload if not uploading — a reload kills the active upload
        if (!isUploading) {
            setTimeout(() => {
                window.location.href = newPath ? `/${newPath}` : '/';
            }, 2000);
        }
    }
}

// Handle browser back/forward buttons
window.addEventListener('popstate', function (event) {
    const path = event.state?.path || '';
    console.log('🔄 POPSTATE EVENT FIRED - Browser back/forward navigation to:', path);
    navigateToFolder(path);
});

function _initVTFromPageData() {
    const tbody = document.querySelector('#filesTable tbody');
    if (!tbody) return;

    // Remove the initial loading spinner row if present
    const loader = document.getElementById('vtInitialLoader');
    if (loader) loader.remove();

    const dataEl = document.getElementById('initialFilesData');
    let files = [];
    if (dataEl) {
        try {
            files = JSON.parse(dataEl.textContent || '[]');
        } catch (e) {
            console.warn('⚠️ _initVTFromPageData: JSON parse failed, starting empty', e);
        }
    }

    // Always init VT — even for empty folders it must set _curPath so the
    // sticky parent row and sort/filter work correctly on first load.
    tbody.innerHTML = '';
    VT.init(files, CURRENT_PATH);
}

/** Parse "1.5 MB" / "230 KB" / "4.2 GB" → approximate bytes for sort */
function _parseDisplaySize(str) {
    if (!str || str === '--') return 0;
    const m = str.match(/([\d.]+)\s*(bytes?|KB|MB|GB|TB)?/i);
    if (!m) return 0;
    const n = parseFloat(m[1]);
    switch ((m[2] || '').toLowerCase()) {
        case 'tb': return n * 1e12;
        case 'gb': return n * 1e9;
        case 'mb': return n * 1e6;
        case 'kb': return n * 1024;
        default: return n;
    }
}

/** Parse displayed date string → Unix timestamp (approximate, for sort only) */
function _parseDisplayDate(str) {
    if (!str || str === '--') return 0;
    try { return Math.floor(new Date(str.replace(/\n/g, ' ')).getTime() / 1000) || 0; }
    catch (e) { return 0; }
}

const VT = (() => {
    // ── row-windowing tunables ──────────────────────────────────
    // Formula: RENDER_BUFFER = 1; DEFAULT_ROW_HEIGHT = 8
    // RESIZE_DEBOUNCE_MS = 150 by default
    const RENDER_BUFFER = 18;        // rows to keep mounted above/below the viewport
    const DEFAULT_ROW_HEIGHT = 144;   // seed estimate; replaced by a real measurement ASAP
    const RESIZE_DEBOUNCE_MS = 150;

    let _allFiles = []; // raw server data for current folder
    let _curPath = '';
    let _filter = ''; // active search term
    let _sortCol = null;
    let _sortDir = 'asc';
    let _searchResultsMode = false; // true when deep-search is active

    // display cache + windowing state (state lives here, never in the DOM)
    let _display = [];               // cached _getDisplayFiles() result for the current render
    let _offsets = null;             // Float64Array, length display.length+1 — cumulative top px per row
    let _rowHeight = DEFAULT_ROW_HEIGHT;   // running estimate for rows never measured
    let _heightCache = new Map();    // item-path -> last measured px height (survives sort/filter/refresh)
    let _winStart = 0, _winEnd = 0;  // [start, end) display-indices currently mounted
    let _mounted = new Map();        // display-index -> <tr> currently in the DOM
    let _renderGen = 0;              // bumped on every full rebuild; guards stale async work

    let _topSpacer = null, _bottomSpacer = null;
    // The spacer HEIGHT lives on these <td>s, never on the <tr>s: index.css's
    // "AUTHORITATIVE TABLE ROW OVERRIDES" pins every `#filesTable tbody tr` to
    // `height:auto !important`, and !important beats every non-important way
    // of setting a row height (inline style, CSSOM style, an inserted rule).
    // A cell's height is not covered by that rule. Written via the CSSOM
    // (`style.setProperty`), which CSP style-src-attr does not govern.
    let _topCell = null, _bottomCell = null;
    // px from the top of the wrapper's scrollable content to the first list
    // row (sticky thead + sticky ".." row sit above it). _offsets is relative
    // to the list, wrapper.scrollTop is relative to the whole content.
    let _listBase = 0;
    let _scrollHandler = null, _resizeHandler = null;
    let _scrollRafPending = false, _resizeTimer = null;

    const _dirInfoCache = new Map();
    // ── public API ────────────────────────────────────────────
    function init(files, path) {
        _allFiles = Array.isArray(files) ? files : [];
        _curPath = path ? path.replace(/\\/g, '/').replace(/\/$/, '') : '';
        _filter = '';
        _searchResultsMode = false;
        // preserve existing sort state
        _sortCol = currentSort.column;
        _sortDir = currentSort.direction;
        // Re-apply cached folder sizes so they survive a refresh rebuild.
        _allFiles.forEach(f => {
            if (!f.is_dir) return;
            const fullPath = _curPath ? `${_curPath}/${f.name}` : f.name;
            const cached = _dirInfoCache.get(fullPath);
            if (cached) f.size = cached.total_size;
        });
        _renderAll();
    }

    function applySort(col, forceDir) {
        if (_searchResultsMode) return;
        if (forceDir) {
            currentSort.column = col;
            currentSort.direction = forceDir;
        } else if (currentSort.column === col) {
            currentSort.direction = currentSort.direction === 'asc' ? 'desc' : 'asc';
        } else {
            currentSort.column = col;
            currentSort.direction = 'asc';
        }
        _sortCol = currentSort.column;
        _sortDir = currentSort.direction;
        updateSortHeaders(_sortCol, _sortDir);
        _renderAll();
    }

    function applyFilter(term) {
        _filter = (term || '').toLowerCase().trim();
        _searchResultsMode = false;
        _renderAll();
        const clearBtn = document.getElementById('clearSearch');
        if (clearBtn) clearBtn.style.display = _filter ? 'block' : 'none';
    }

    function markSearchResults() {
        _searchResultsMode = true;
        _teardownScrollHandler();
    }

    // Scroll the windowed table so `path` (a full item path, same shape as
    // createFileTableRow's data-path) is brought into view. Used after
    // operations like rename/upload where the item may be off-screen.
    // Returns false if the item isn't in the current display list (e.g. it
    // was filtered out, or we're in deep-search mode).
    function scrollToItem(path) {
        if (_searchResultsMode || !_display.length || !_offsets) return false;
        const idx = _display.findIndex(item => {
            const p = _curPath ? `${_curPath}/${item.name}` : item.name;
            return p === path;
        });
        if (idx === -1) return false;
        const wrapper = document.getElementById('tableScrollWrapper');
        if (!wrapper) return false;
        const target = Math.max(0, _listBase + _offsets[idx] - Math.floor((wrapper.clientHeight || 0) / 3));
        _renderWindow(true, target);   // mount + size spacers first, so the height exists...
        wrapper.scrollTop = target;    // ...before we scroll into it
        return true;
    }

    function getAll() { return _allFiles; }
    function getPath() { return _curPath; }

    function patchFolderSize(folderFullPath, totalSize) {
        const existing = _dirInfoCache.get(folderFullPath) || {};
        _dirInfoCache.set(folderFullPath, { ...existing, total_size: totalSize });
        const folderName = folderFullPath.split('/').pop();
        const entry = _allFiles.find(f => f.is_dir && f.name === folderName);
        if (entry) entry.size = totalSize;
    }

    function cacheDirInfo(fullPath, data) {
        _dirInfoCache.set(fullPath, { file_count: data.file_count, dir_count: data.dir_count, total_size: data.total_size || 0 });
        const folderName = fullPath.split('/').pop();
        const entry = _allFiles.find(f => f.is_dir && f.name === folderName);
        if (entry) entry.size = data.total_size || 0;
    }

    function getCachedDirInfo(fullPath) {
        return _dirInfoCache.get(fullPath) || null;
    }

    function invalidateDirCache(fullPath) {
        _dirInfoCache.delete(fullPath);
    }

    function clearDirCache() {
        _dirInfoCache.clear();
    }

    // 4.66: drop every cached folder record EXCEPT the given paths (the ones on
    // screen, which are re-read in place), so folders that scroll in later are
    // fetched fresh while the visible size cells never go blank.
    function pruneDirCache(keepPaths) {
        for (const k of Array.from(_dirInfoCache.keys())) {
            if (!keepPaths.has(k)) _dirInfoCache.delete(k);
        }
    }

    // ── internals ─────────────────────────────────────────────
    function _getDisplayFiles() {
        let list = _allFiles;

        // 1. filter
        if (_filter) {
            list = list.filter(item =>
                item.name.toLowerCase().includes(_filter) ||
                (item.is_dir ? 'folder' : _getTypeName(item.name)).toLowerCase().includes(_filter)
            );
        }

        // 2. sort
        if (_sortCol) {
            const dir = _sortDir === 'asc' ? 1 : -1;
            list = [...list].sort((a, b) => {
                // folders always first (Windows Explorer rule)
                if (a.is_dir && !b.is_dir) return dir === 1 ? -1 : 1;
                if (!a.is_dir && b.is_dir) return dir === 1 ? 1 : -1;

                let cmp = 0;
                if (_sortCol === 'name') {
                    cmp = a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
                } else if (_sortCol === 'size') {
                    const sa = (a.size != null) ? a.size : -1;
                    const sb = (b.size != null) ? b.size : -1;
                    cmp = sa - sb;
                } else if (_sortCol === 'modified') {
                    cmp = (a.modified || 0) - (b.modified || 0);
                } else if (_sortCol === 'type') {
                    const ta = a.is_dir ? 'Folder' : _getTypeName(a.name);
                    const tb = b.is_dir ? 'Folder' : _getTypeName(b.name);
                    cmp = ta.localeCompare(tb, undefined, { numeric: true, sensitivity: 'base' });
                }
                return cmp * dir;
            });
        }

        return list;
    }

    function _getTypeName(filename) {
        try { return getFileType(filename); } catch (e) { return 'File'; }
    }

    function _getTbody() { return document.querySelector('#filesTable tbody'); }

    function _itemPath(item) {
        return _curPath ? `${_curPath}/${item.name}` : item.name;
    }

    // Spacer row. Deliberately NO style="..." attribute: a static inline style
    // in innerHTML markup is dropped by CSP style-src-attr unless its exact
    // SHA-256 is allow-listed in app.py (the old `padding:0;border:0;
    // line-height:0;` here was not, which left each spacer cell with default
    // padding). The zeroing now lives in index.css (.vt-spacer-cell).
    function _makeSpacerRow(id) {
        const tr = document.createElement('tr');
        tr.id = id;
        tr.className = 'vt-spacer-row';
        tr.setAttribute('aria-hidden', 'true');
        const td = document.createElement('td');
        td.colSpan = 6;
        td.className = 'vt-spacer-cell';
        tr.appendChild(td);
        return tr;
    }

    // Where the list starts inside the wrapper's scrollable content. Read in
    // one layout state (rect first, scrollTop last) so it is consistent even
    // if that layout pass clamps scrollTop.
    function _measureListBase(wrapper) {
        if (!wrapper || !_topSpacer) return 0;
        const spacerTop = _topSpacer.getBoundingClientRect().top;
        const wrapTop = wrapper.getBoundingClientRect().top;
        return spacerTop - wrapTop + wrapper.scrollTop;
    }

    function _renderAll() {
        const tbody = _getTbody();
        if (!tbody) return;
        // Capture scroll position BEFORE clearing rows. tbody.innerHTML = ''
        // below collapses the table's height to ~0, which collapses the
        // wrapper's scrollHeight too — the browser clamps wrapper.scrollTop
        // to 0 synchronously as a side effect of that, regardless of what
        // this function does afterward. That's the real "rubber band"
        // scroll-to-top bug: every _renderAll() (refreshFileTable/SSE/
        // polling updates included, not just real navigation) was silently
        // losing the scroll position this way, even though the code never
        // explicitly sets scrollTop itself. Restored below, once the
        // spacers give the wrapper its real height back.
        const wrapper = document.getElementById('tableScrollWrapper');
        const _preservedScrollTop = wrapper ? wrapper.scrollTop : 0;
        _renderGen++;
        _teardownScrollHandler();
        _mounted = new Map();
        _winStart = 0; _winEnd = 0;
        tbody.innerHTML = '';

        // parent-directory row (sticky; lives outside the windowed range)
        if (_curPath) {
            const parentPath = _curPath.split('/').slice(0, -1).join('/');
            const pRow = document.createElement('tr');
            pRow.className = 'parent-dir-sticky';
            pRow.innerHTML = `
                <td></td>
                <td><div class="file-name">
                    <i class="fas fa-level-up-alt file-icon folder-icon"></i>
                    <a href="#" data-fn="navigateToFolder" data-args="${dataArgs([parentPath])}" data-prevent="1" class="folder-link">
                        .. (Parent Directory)
                    </a>
                </div></td>
                <td class="size-cell"><span style="color:white;font-size:13px;"></span></td>
                <td class="type-cell"><span class="file-type"></span></td>
                <td class="date-cell"><span style="color:white;font-size:13px;"></span></td>
                <td></td>`;
            tbody.appendChild(pRow);
            _updateTheadHeightVar();
        }

        _display = _getDisplayFiles();

        if (_display.length === 0) {
            tbody.appendChild(createEmptyFolderRow());
            _offsets = null;
            updateVisibleCount(0);
            reinitializeTableControls(0);
            storeOriginalTableOrder();
            return;
        }

        _topSpacer = _makeSpacerRow('vtTopSpacer');
        _bottomSpacer = _makeSpacerRow('vtBottomSpacer');
        _topCell = _topSpacer.firstElementChild;
        _bottomCell = _bottomSpacer.firstElementChild;
        tbody.appendChild(_topSpacer);
        tbody.appendChild(_bottomSpacer);

        _rebuildOffsets();
        _listBase = _measureListBase(wrapper);

        // Mount the window for where the user WAS (not for the clamped
        // scrollTop the innerHTML clear left behind), which also sizes the
        // spacers — and only THEN restore scrollTop. Restoring before the
        // spacers have their height (as 4.32 did) is clamped straight back.
        // Callers that want the top of the list (navigateToFolder) set
        // scrollTop = 0 themselves afterwards, which simply overrides this.
        _renderWindow(true, _preservedScrollTop);
        if (wrapper && _preservedScrollTop > 0) {
            wrapper.scrollTop = _preservedScrollTop;
        }

        updateVisibleCount(_display.length);
        reinitializeTableControls(_display.length);
        storeOriginalTableOrder();

        _attachScrollHandler();
    }

    // Binary search: greatest index i such that _offsets[i] <= offset.
    function _findIndexAtOffset(offset) {
        let lo = 0, hi = _display.length;
        while (lo < hi) {
            const mid = (lo + hi) >> 1;
            if (_offsets[mid] <= offset) lo = mid + 1; else hi = mid;
        }
        return Math.max(0, lo - 1);
    }

    function _rebuildOffsets() {
        const n = _display.length;
        const offsets = new Float64Array(n + 1);
        let acc = 0;
        for (let i = 0; i < n; i++) {
            offsets[i] = acc;
            const cached = _heightCache.get(_itemPath(_display[i]));
            acc += (cached && cached > 0) ? cached : _rowHeight;
        }
        offsets[n] = acc;
        _offsets = offsets;
    }

    function _positionSpacers() {
        if (!_offsets || !_topCell || !_bottomCell) return;
        const total = _display.length;
        const topH = _offsets[_winStart] || 0;
        const bottomH = Math.max(0, _offsets[total] - _offsets[_winEnd]);
        _topCell.style.setProperty('height', topH + 'px', 'important');
        _bottomCell.style.setProperty('height', bottomH + 'px', 'important');
    }

    // Mount exactly [start, end), touching only what changed. Two phases so
    // layout is never forced against a half-edited table:
    //   1. create the missing rows — createFileTableRow() reads layout
    //      (applyColumnWidths -> wrapper.clientWidth); the DOM is untouched
    //      here, so that read is against a complete table.
    //   2. write only — drop off-window rows, then walk the wanted range in
    //      order and insert only nodes that are not already in place. A one-row
    //      scroll step is one insert + one remove, not a re-insert of the whole
    //      window (the old fragment approach detached every mounted row on
    //      every step, so any layout read mid-way saw a collapsed table).
    // Returns the newly created rows so callers can scope highlighting /
    // dir-info loading / measurement to just those.
    function _mountRange(start, end) {
        const tbody = _getTbody();
        if (!tbody || !_topSpacer || !_bottomSpacer) return [];

        const created = [];
        const wanted = new Array(end - start);
        for (let i = start; i < end; i++) {
            let el = _mounted.get(i);
            if (!el) {
                el = createFileTableRow(_display[i], _curPath);
                created.push(el);
            }
            wanted[i - start] = el;
        }

        for (const [idx, el] of _mounted) {
            if ((idx < start || idx >= end) && el.parentNode) el.remove();
        }

        const keep = new Map();
        let ref = _topSpacer.nextSibling;
        for (let i = start; i < end; i++) {
            const el = wanted[i - start];
            if (el === ref) ref = ref.nextSibling;   // already in place
            else tbody.insertBefore(el, ref);        // new, or moved
            keep.set(i, el);
        }
        _mounted = keep;
        return created;
    }

    // No manual scroll compensation on purpose. Rows are only estimated until
    // first laid out (long filenames wrap, so heights are not uniform), and a
    // size change above the viewport would shift what is on screen. The
    // browser's native scroll anchoring (`overflow-anchor:auto` on the wrapper,
    // see index.css) corrects that on the compositor side without cancelling an
    // in-flight wheel/touch smooth-scroll. An earlier version compensated with
    // `wrapper.scrollTop += delta`; measured in real Chromium, those writes
    // collided with the smooth-scroll animation and produced visible
    // reversals (a lost 14px, or a whole 120px wheel step). Don't reintroduce.

    // `scrollTopOverride`: compute the window for a scroll position that is
    // not (yet) the wrapper's real one — used by _renderAll / scrollToItem /
    // resize, where the real scrollTop is about to be set after the spacers
    // are sized.
    function _renderWindow(force, scrollTopOverride) {
        const wrapper = document.getElementById('tableScrollWrapper');
        if (!wrapper || !_offsets || !_display.length) return;

        const scrollTop = (scrollTopOverride == null) ? wrapper.scrollTop : scrollTopOverride;
        const viewportH = wrapper.clientHeight || 600;
        const rel = scrollTop - _listBase;
        const total = _display.length;

        const start = Math.max(0, _findIndexAtOffset(rel) - RENDER_BUFFER);
        const end = Math.min(total, _findIndexAtOffset(rel + viewportH) + 1 + RENDER_BUFFER);

        if (!force && start === _winStart && end === _winEnd) return;

        const gen = _renderGen;
        let newRows = [];
        const apply = () => {
            newRows = _mountRange(start, end);
            _winStart = start; _winEnd = end;
            _positionSpacers();
        };
        apply();

        if (_filter && newRows.length) _highlightVisible(_filter, newRows);
        if (newRows.length) loadDirInfoCells(newRows);
        if (newRows.length) _scheduleMeasure(newRows, gen);
    }

    // Measures freshly-mounted rows in the next animation frame (a single
    // batched read, after all writes for this pass are done — no
    // read/write layout thrash) and folds anything that differs from the
    // estimate into the per-path height cache. Filenames can wrap onto
    // multiple lines (see index.css .name-cell white-space:normal rules for
    // both desktop and mobile), so row height is NOT assumed uniform —
    // this cache is the fallback for that variance. Offsets are only rebuilt
    // (O(n)) when a measurement actually disagrees with what the offsets
    // currently assume, so a folder of same-height rows costs one measurement
    // pass, ever.
    function _scheduleMeasure(rows, gen) {
        requestAnimationFrame(() => {
            if (gen !== _renderGen) return; // a full re-render already replaced _display/_offsets
            let changed = false;
            rows.forEach(el => {
                if (!el.isConnected) return;
                const h = el.getBoundingClientRect().height;
                if (!h) return;
                if (_rowHeight === DEFAULT_ROW_HEIGHT) { _rowHeight = h; changed = true; } // seed from the very first real row
                const path = el.dataset.path;
                const prev = _heightCache.get(path);
                const assumed = (prev !== undefined && prev > 0) ? prev : _rowHeight;
                if (prev === undefined || Math.abs(prev - h) > 1) _heightCache.set(path, h);
                if (Math.abs(assumed - h) > 1) changed = true;
            });
            if (!changed) return;
            const wrapper = document.getElementById('tableScrollWrapper');
            if (!wrapper) return;
            _rebuildOffsets();
            _positionSpacers();
            _renderWindow(false);
        });
    }

    // A mounted row's content changed size after it was measured (e.g. a
    // folder's size cell going from a one-line spinner to "N files, N
    // folders<br>size"). Fold the new height into the cache.
    function rowResized(tr) {
        if (tr && tr.isConnected) _scheduleMeasure([tr], _renderGen);
    }

    function _remeasureMounted() {
        if (_mounted.size) _scheduleMeasure(Array.from(_mounted.values()), _renderGen);
    }

    function _attachScrollHandler() {
        const wrapper = document.getElementById('tableScrollWrapper');
        if (!wrapper) return;

        _scrollHandler = () => {
            if (_scrollRafPending) return;
            _scrollRafPending = true;
            requestAnimationFrame(() => {
                _scrollRafPending = false;
                _renderWindow(false);
            });
        };
        wrapper.addEventListener('scroll', _scrollHandler, { passive: true });

        // One global resize listener for VT's lifetime; column width and
        // text wrapping both depend on viewport width, so a resize can
        // change every row's real height — re-measure rather than trust
        // the cache. Debounced (not rAF-throttled) since layout on resize
        // is heavier than a scroll tick.
        if (!_resizeHandler) {
            _resizeHandler = () => {
                clearTimeout(_resizeTimer);
                _resizeTimer = setTimeout(_onResize, RESIZE_DEBOUNCE_MS);
            };
            window.addEventListener('resize', _resizeHandler);
        }
    }

    // Column widths changed, so every wrap point (and row height) moved.
    // Remember WHICH row is at the top of the viewport and how far into it,
    // not a pixel offset — after the cache is dropped the pixel offsets are
    // estimates again, and reusing the old scrollTop against them would land
    // on a different part of the list.
    function _onResize() {
        _updateTheadHeightVar();
        if (!_display.length || !_offsets) return;
        const wrapper = document.getElementById('tableScrollWrapper');
        if (!wrapper) return;
        const rel = wrapper.scrollTop - _listBase;
        const idx = _findIndexAtOffset(rel);
        const intra = rel - _offsets[idx];
        _heightCache.clear();          // _rowHeight (first measured row) stays as the estimate
        _rebuildOffsets();
        _listBase = _measureListBase(wrapper);   // thead height can change with width
        const st = Math.max(0, _listBase + _offsets[idx] + intra);
        _renderWindow(true, st);
        wrapper.scrollTop = st;
        _remeasureMounted();
    }

    function _teardownScrollHandler() {
        const wrapper = document.getElementById('tableScrollWrapper');
        if (wrapper && _scrollHandler) wrapper.removeEventListener('scroll', _scrollHandler);
        _scrollHandler = null;
        // _resizeHandler is intentionally left attached — it's a no-op
        // when _display is empty and is reused across every re-render.
    }

    function _highlightVisible(term, rows) {
        const targets = rows || Array.from(_mounted.values());
        targets.forEach(row => highlightSearchTerm(row, term));
    }

    function _updateTheadHeightVar() {
        // Measures real thead height → writes CSS var so the sticky
        // parent row top offset is always pixel-perfect.
        requestAnimationFrame(() => {
            const thead = document.querySelector('#filesTable thead');
            const wrapper = document.getElementById('tableScrollWrapper');
            if (thead && wrapper) {
                wrapper.style.setProperty('--table-thead-h', thead.offsetHeight + 'px');
            }
        });
    }

    return {
        init, applySort, applyFilter, getAll, getPath, markSearchResults, scrollToItem, rowResized,
        patchFolderSize, cacheDirInfo, getCachedDirInfo, invalidateDirCache, clearDirCache, pruneDirCache
    };
})();

function updateFileTable(files, path) {
    console.log(`🔄 updateFileTable: ${files ? files.length : 0} items at "${path}"`);

    const tbody = document.querySelector('#filesTable tbody');
    if (!tbody) { console.error('❌ File table body not found'); return; }

    // Clear deep search results from overlay
    hideDeepSearchResults();

    // Hand off to virtual table engine
    VT.init(files || [], path);

    console.log(`📋 updateFileTable complete (VT engine)`);
}

// Create empty folder message row
function createEmptyFolderRow() {
    const row = document.createElement('tr');
    row.className = 'empty-folder-row';
    row.innerHTML = `
        <td colspan="6" class="empty-folder-cell">
            <div class="empty-folder-content">
                <i class="fas fa-folder-open empty-folder-icon"></i>
                <div class="empty-folder-title">This folder is empty</div>
                <div class="empty-folder-subtitle">No files or folders to display</div>
            </div>
        </td>
    `;
    return row;
}

// Create a file table row element
function createFileTableRow(item, currentPath) {
    const row = document.createElement('tr');

    const itemPath = currentPath ? `${currentPath}/${item.name}` : item.name;

    // Add the file-row class that matches the original template
    row.className = 'file-row';
    row.setAttribute('data-path', itemPath);

    // Use escaped names and mapped icons/types
    const safeName = escapeHtml(item.name);
    const itemIcon = item.is_dir ? 'fas fa-folder' : getFileIcon(item.name);
    const itemTypeText = item.is_dir ? 'Folder' : getFileType(item.name);
    // 4.66: a re-render must not blank the folder size cell. When the folder's
    // counts are already cached, put them in the new cell straight away.
    const _cachedDir = item.is_dir ? VT.getCachedDirInfo(itemPath) : null;
    const _cachedDirOk = !!(_cachedDir && _cachedDir.file_count != null && _cachedDir.dir_count != null);

    row.innerHTML = `
        <td>
            <input type="checkbox" class="file-checkbox item-checkbox" 
                   data-path="${escapeHtml(itemPath)}" 
                   data-name="${escapeHtml(item.name)}"
                   data-is-dir="${item.is_dir ? 'true' : 'false'}"
                   data-fn-change="updateSelection" ${selectedItems.has(itemPath) ? 'checked' : ''}>
        </td>
        <td class="name-cell">
            <div class="file-name">
                ${item.is_dir ?
            `<i class="fas fa-folder file-icon folder-icon"></i>
                     <a href="#" data-fn="navigateToFolder" data-args="${dataArgs([itemPath])}" data-prevent="1"
                        data-folder-path="${escapeHtml(itemPath)}" class="folder-link">
                         ${safeName}
                     </a>` :
            `<i class="${itemIcon} file-icon file-icon-default"></i>
                     ${safeName}${getViewerType(item.name) ? ` <button type="button" class="btn-eye-view" data-fn="openFileViewer" data-args="${dataArgs([itemPath, item.name])}" data-stop="1" title="Preview"><i class="fas fa-eye"></i></button>` : ''}`
        }
            </div>
        </td>
        <td class="size-cell">
            ${item.is_dir ?
            `<span class="dir-info-cell" data-dir-path="${escapeHtml(itemPath)}"${_cachedDirOk ? ` data-sig="${_dirInfoSig(_cachedDir)}"` : ''} style="color: white; font-size: 13px;">${_cachedDirOk ? _dirInfoHtml(_cachedDir) : `
                    <i class="fas fa-spinner fa-spin" style="opacity: 0.4; font-size: 11px;"></i>
                `}</span>` :
            `<span class="file-size" style="color: white; font-weight: 500;">${formatFileSize(item.size)}</span>`
        }
        </td>
        <td class="type-cell">
            ${`<span class="file-type"><i class="${item.is_dir ? 'fas fa-folder folder-icon file-icon' : itemIcon}"></i> ${escapeHtml(itemTypeText)}</span>`}
        </td>
        <td class="date-cell">
            ${item.modified ?
            `<span class="file-date" style="color: white; font-size: 12px; white-space: nowrap;">${(() => { const d = new Date(item.modified * 1000); return d.toLocaleDateString('en-US') + ' ' + d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }); })()}</span>` :
            '<span style="color: white; font-size: 12px;">--</span>'
        }
        </td>
        <td class="actions-cell">
            <div class="actions" style="display:flex;flex-wrap:nowrap;gap:3px;align-items:center;">
                ${!item.is_dir ?
            `<button type="button" class="btn btn-outline btn-sm download-btn" 
                             data-item-path="${escapeHtml(itemPath)}"
                             data-label="Download"
                             data-fn="showDownloadOptionsModal" data-args="${dataArgs([itemPath, item.name])}"
                             title="Download">
                         <i class="fas fa-download"></i>
                     </button>` :
            `<button type="button" class="btn btn-outline btn-sm download-btn" 
                             data-item-path="${escapeHtml(itemPath)}"
                             data-label="Download ZIP"
                             data-fn="downloadFolderAsZip" data-args="${dataArgs([itemPath, item.name])}"
                             title="Download folder as ZIP">
                         <i class="fas fa-download"></i>
                     </button>`
        }
                
                ${USER_ROLE === 'readwrite' ? `
                <button type="button" class="btn btn-warning btn-sm move-btn" 
                        data-item-name="${safeName}"
                        data-item-path="${escapeHtml(itemPath)}"
                        data-label="Move"
                        data-fn="showSingleMoveModal" data-args="${dataArgs([itemPath, item.name])}"
                        title="Move">
                    <i class="fas fa-cut"></i>
                </button>
                
                <button type="button" class="btn btn-success btn-sm copy-btn" 
                        data-item-name="${safeName}"
                        data-item-path="${escapeHtml(itemPath)}"
                        data-label="Copy"
                        data-fn="showSingleCopyModal" data-args="${dataArgs([itemPath, item.name])}"
                        title="Copy">
                    <i class="fas fa-copy"></i>
                </button>
                
                <button type="button" class="btn btn-primary btn-sm rename-btn" 
                        data-item-name="${safeName}"
                        data-item-path="${escapeHtml(itemPath)}"
                        data-label="Rename"
                        data-fn="showSingleRenameModal" data-args="${dataArgs([itemPath, item.name])}"
                        title="Rename">
                    <i class="fas fa-edit"></i>
                </button>

                <button type="button" class="btn btn-outline btn-sm share-btn" 
                        data-item-name="${safeName}"
                        data-item-path="${escapeHtml(itemPath)}"
                        data-label="Share"
                        data-fn="showSingleShareModal" data-args="${dataArgs([itemPath, item.name, !!item.is_dir])}"
                        title="Share">
                    <i class="fas fa-share-nodes"></i>
                </button>
                
                <button type="button" class="btn btn-danger btn-sm delete-btn" 
                        data-item-name="${safeName}"
                        data-item-path="${escapeHtml(itemPath)}"
                        data-label="Delete"
                        data-fn="showSingleDeleteModal" data-args="${dataArgs([itemPath, item.name])}"
                        title="Delete">
                    <i class="fas fa-trash"></i>
                </button>
                ` : ''}
            </div>
        </td>
    `;

    applyColumnWidths(row);

    if (!item.is_dir) {
        const iconEl = row.querySelector('.file-icon-default');
        if (iconEl) iconEl.style.color = getFileColor(item.name);
    }

    return row;
}

// 4.66: one place that formats a folder's "N files, M folders / size" cell, and
// a signature of its content so a refresh can tell "nothing changed" and leave
// the DOM alone.
function _dirInfoFmtSize(bytes) {
    if (!bytes || bytes <= 0) return null;
    if (bytes >= 1024 * 1024 * 1024) return (bytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
    if (bytes >= 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    if (bytes >= 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return bytes + ' bytes';
}
function _dirInfoHtml(d) {
    let html = d.file_count + ' files, ' + d.dir_count + ' folders';
    const s = _dirInfoFmtSize(d.total_size);
    if (s) html += '<br><small style="color:white;">' + s + '</small>';
    return html;
}
function _dirInfoSig(d) {
    return d.file_count + '|' + d.dir_count + '|' + (d.total_size || 0);
}

// Lazy-load folder size and item count for dir-info-cell spans.
// `rows`, when given, scopes this to just the rows VT rendered in the most
// recent pass — with row windowing, most of the folder is never in the DOM,
// so a document-wide querySelectorAll would silently do nothing for
// off-screen rows anyway (and would still cost a full-DOM scan every batch).
// Omitting `rows` falls back to the old whole-document scan, kept for any
// future non-VT caller.
function loadDirInfoCells(rows) {
    const cells = rows
        ? rows.flatMap(row => Array.from(row.querySelectorAll('.dir-info-cell')))
        : Array.from(document.querySelectorAll('.dir-info-cell'));
    if (!cells.length) return;

    cells.forEach(function (cell) {
        if (cell.dataset.loaded === 'true') return;
        cell.dataset.loaded = 'true';

        const dirPath = cell.dataset.dirPath;

        const cached = VT.getCachedDirInfo(dirPath);
        // (patchFolderSize() can cache a size alone, without counts: not usable here)
        if (cached !== null && cached.file_count != null && cached.dir_count != null) {
            const sig = _dirInfoSig(cached);
            if (cell.dataset.sig !== sig) {
                cell.innerHTML = _dirInfoHtml(cached);
                cell.dataset.sig = sig;
            }
            return;
        }

        fetch('/api/dir_info/' + dirPath)
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.error) { if (cell.isConnected) cell.textContent = '--'; return; }
                // Always cache, even if the row has since scrolled out of
                // the rendered window — the next time this folder is
                // rendered (re-scroll, re-sort) it's an instant cache hit.
                VT.cacheDirInfo(dirPath, data);
                // But don't write into a cell whose row is no longer in the
                // DOM — it was recycled/removed when the row scrolled out,
                // and writing to it would be a wasted, stale DOM mutation.
                if (!cell.isConnected) return;
                cell.innerHTML = _dirInfoHtml(data);
                cell.dataset.sig = _dirInfoSig(data);
                // The cell just grew (spinner -> two lines); tell VT so its
                // cached row height / offsets are corrected.
                VT.rowResized(cell.closest('tr'));
            })
            .catch(function () { if (cell.isConnected) cell.textContent = '--'; });
    });
}

// Update breadcrumb navigation
function updateBreadcrumb(path) {
    console.log(`🍞 Updating breadcrumb for path: "${path}"`);

    const breadcrumbContainer = document.querySelector('.breadcrumb');
    if (!breadcrumbContainer) {
        console.error('❌ Breadcrumb container not found!');
        return;
    }

    // Find or create the flex container (first div child with flex styling)
    let flexContainer = breadcrumbContainer.querySelector('div[style*="display: flex"]');

    if (!flexContainer) {
        console.log('📦 Creating new flex container...');
        flexContainer = document.createElement('div');
        flexContainer.style.cssText = 'display: flex; align-items: center; justify-content: space-between;';

        // Insert before controls div if it exists
        const controlsDiv = breadcrumbContainer.querySelector('.controls');
        if (controlsDiv) {
            breadcrumbContainer.insertBefore(flexContainer, controlsDiv);
        } else {
            breadcrumbContainer.insertBefore(flexContainer, breadcrumbContainer.firstChild);
        }
    }

    // Build the flex container content
    const displayPath = path ? `/Root/${path}` : '/Root/';
    let flexHTML = `<h3><i class="fas fa-folder-open"></i> ${displayPath}</h3>`;

    // Add navigation buttons if not at root
    if (path && path !== '') {
        flexHTML += '<div class="btn-group" style="display: flex; gap: 5px;">';

        // Root button
        flexHTML += `
            <a href="#" data-fn="navigateToFolder" data-args="${dataArgs([''])}" data-prevent="1"
               class="btn btn-outline btn-sm"
               style="color: white; border-color: rgba(255,255,255,0.4);" 
               title="Go to root folder">
                <i class="fas fa-home"></i> Root
            </a>`;

        // Calculate parent path for Up button
        let parentPath = '';
        if (path.includes('/')) {
            const pathParts = path.split('/');
            pathParts.pop();
            parentPath = pathParts.join('/');
        }

        // Up button
        flexHTML += `
            <a href="#" data-fn="navigateToFolder" data-args="${dataArgs([parentPath])}" data-prevent="1"
               class="btn btn-outline btn-sm"
               style="color: white; border-color: rgba(255,255,255,0.4);"
               title="Go up one level to: ${escapeHtml(parentPath) || 'Root'}">
                <i class="fas fa-level-up-alt"></i> Up
            </a>`;

        flexHTML += '</div>';
    }

    // Update the flex container
    flexContainer.innerHTML = flexHTML;
    console.log(`✅ Updated breadcrumb to: "${displayPath}"`);

    // Update hidden path input if it exists
    const pathInput = breadcrumbContainer.querySelector('input[name="path"]');
    if (pathInput) {
        pathInput.value = path || '';
        console.log(`📝 Updated hidden path input to: "${path || ''}"`);
    }
}

// Selection management
let selectedItems = new Set();
let _lastRenderedPath = undefined;
let currentModalAction = '';

// Storage stats loading with enhanced error handling
async function loadStorageStats() {
    try {
        console.log('� Loading storage stats...');

        // Single-phase approach with longer timeout for reliability
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 20000); // 20 second timeout

        let response;
        try {
            // Try the normal authenticated endpoint first
            response = await fetch('/api/storage_stats', {
                signal: controller.signal,
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'Cache-Control': 'no-cache'
                }
            });
        } catch (authError) {
            console.log('Auth endpoint failed, trying debug endpoint:', authError);
            // If auth fails, try debug endpoint
            response = await fetch('/api/storage_stats_debug', {
                signal: controller.signal,
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                    'Cache-Control': 'no-cache'
                }
            });
        }

        clearTimeout(timeoutId);

        console.log('Storage stats response status:', response.status);

        if (response.ok) {
            const data = await response.json();
            console.log('✅ Storage stats loaded successfully:', data);

            // Handle both normal and debug response formats
            const stats = data.stats || data;
            updateStorageDisplay(stats);
        } else {
            console.warn('Failed to load storage stats, status:', response.status);
            const errorText = await response.text();
            console.warn('Error response:', errorText);
            showStorageError('Server Error');
        }
    } catch (error) {
        console.error('Error loading storage stats:', error);
        if (error.name === 'AbortError') {
            console.error('Storage stats request timed out');
            showStorageError('Timeout - Try refreshing');
        } else if (error.name === 'TypeError' && error.message.includes('fetch')) {
            console.error('Network error - server might be unreachable');
            showStorageError('Network Error');
        } else {
            showStorageError('Error');
        }
    }
}

function showStorageError(errorType) {
    const elements = ['totalSpace', 'freeSpace', 'usedSpace', 'fileCount', 'dirCount'];
    elements.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = errorType;
            element.style.color = '#ff6b6b';
        }
    });

    // Hide progress bar on error
    const progressBar = document.querySelector('.progress-bar');
    if (progressBar) {
        progressBar.style.display = 'none';
    }

    // Show retry button on error
    const retryButton = document.getElementById('retryStorageStats');
    if (retryButton) {
        retryButton.style.display = 'inline-block';
    }
}

// Retry function for storage stats
async function retryStorageStats() {
    console.log('Retrying storage stats...');

    // Hide retry button during retry
    const retryButton = document.getElementById('retryStorageStats');
    if (retryButton) {
        retryButton.style.display = 'none';
    }

    // Reset loading state
    const elements = ['totalSpace', 'freeSpace', 'usedSpace', 'fileCount'];
    elements.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = 'Loading...';
            element.style.color = 'white';
        }
    });

    // Try to reinitialize
    await initializeStorageStats();
}

function updateStorageDisplay(stats) {
    console.log('📊 updateStorageDisplay called with:', stats);

    // Update text displays with null checks
    const totalSpaceEl = document.getElementById('totalSpace');
    const freeSpaceEl = document.getElementById('freeSpace');
    const usedSpaceEl = document.getElementById('usedSpace');
    const fileCountEl = document.getElementById('fileCount');

    console.log('📊 Found elements:', {
        totalSpaceEl: !!totalSpaceEl,
        freeSpaceEl: !!freeSpaceEl,
        usedSpaceEl: !!usedSpaceEl,
        fileCountEl: !!fileCountEl
    });

    // Update disk space (always numeric)
    if (totalSpaceEl && typeof stats.total_space === 'number') {
        if (totalSpaceEl) {
            totalSpaceEl.textContent = formatFileSize(stats.total_space || 0);
            totalSpaceEl.style.color = 'white';
        }
        console.log('✅ Updated totalSpace:', formatFileSize(stats.total_space));
    } else {
        console.log('❌ Failed to update totalSpace:', { totalSpaceEl: !!totalSpaceEl, total_space: stats.total_space, type: typeof stats.total_space });
    }
    if (freeSpaceEl && typeof stats.free_space === 'number') {
        if (freeSpaceEl) {
            freeSpaceEl.textContent = formatFileSize(stats.free_space || 0);
            freeSpaceEl.style.color = 'white';
        }
        console.log('✅ Updated freeSpace:', formatFileSize(stats.free_space));
    }
    if (usedSpaceEl && typeof stats.used_space === 'number') {
        if (usedSpaceEl) {
            usedSpaceEl.textContent = formatFileSize(stats.used_space || 0);
            usedSpaceEl.style.color = 'white';
        }
        console.log('✅ Updated usedSpace:', formatFileSize(stats.used_space));
    }

    // Handle file counts (should be numbers)
    if (fileCountEl) {
        const fileText = `${stats.file_count || 0} files, ${stats.dir_count || 0} folders`;
        if (fileCountEl) {
            fileCountEl.textContent = fileText;
            fileCountEl.style.color = 'white';
        }
        console.log('✅ Updated fileCount:', fileText);
    }

    // Calculate and display usage percentage (only if we have numeric values)
    if (typeof stats.total_space === 'number' && typeof stats.used_space === 'number') {
        const usagePercent = stats.total_space > 0 ? (stats.used_space / stats.total_space) * 100 : 0;
        const usagePercentRounded = Math.round(usagePercent * 10) / 10; // Round to 1 decimal

        const usagePercentageEl = document.getElementById('usagePercentage');
        const diskUsageFillEl = document.getElementById('diskUsageFill');

        if (usagePercentageEl) usagePercentageEl.textContent = `${usagePercentRounded}%`;
        if (diskUsageFillEl) {
            diskUsageFillEl.style.width = `${usagePercent}%`;

            // Change color based on usage
            if (usagePercent < 70) {
                diskUsageFillEl.style.background = 'linear-gradient(90deg, #27ae60, #2ecc71)';
            } else if (usagePercent < 90) {
                diskUsageFillEl.style.background = 'linear-gradient(90deg, #f39c12, #e67e22)';
            } else {
                diskUsageFillEl.style.background = 'linear-gradient(90deg, #e74c3c, #c0392b)';
            }

            // Show progress bar on successful load
            const progressBar = document.querySelector('.progress-bar');
            if (progressBar) {
                progressBar.style.display = 'block';
            }
        }

        // Add content size info to the title
        if (stats.content_size !== stats.used_space) {
            const contentSizeText = `Content: ${formatFileSize(stats.content_size)}`;
            const usedSpaceEl = document.getElementById('usedSpace');
            if (usedSpaceEl && usedSpaceEl.parentElement) {
                usedSpaceEl.parentElement.title = contentSizeText;
            }
        }
    }

    // Hide retry button on successful load
    const retryButton = document.getElementById('retryStorageStats');
    if (retryButton) {
        retryButton.style.display = 'none';
    }
}

// Track if user is actively downloading to avoid false beforeunload warnings
let activeDownloads = new Set();

window.addEventListener('beforeunload', function (e) {
    // Only show warning if uploads are in progress AND user is actually navigating away
    // Don't interfere with downloads
    if ((isUploading || uploadQueue.some(item => item.status === 'pending')) && activeDownloads.size === 0) {
        // Try immediate cleanup for chunks
        cleanupUnfinishedChunks().catch(console.error);

        // Show warning message
        const message = 'Upload in progress. Leaving will cancel uploads and cleanup temporary files.';
        e.preventDefault();
        e.returnValue = message;
        return message;
    }
});

// Page visibility handling
document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'hidden') {
        // Only cleanup if NOT uploading — never interrupt active uploads
        if (!isUploading && uploadQueue.some(item => item.status === 'pending' || item.status === 'error')) {
            console.log('🧹 Page hidden - cleaning up abandoned uploads');
            cleanupUnfinishedChunks().catch(console.error);
        }
    } else if (document.visibilityState === 'visible') {
        console.log('👀 Page visible again');
        if (!isUploading) {
            updateManualCleanupButton();
        }
    }
});

// Better connection handling.
// isOnline/connectionLostTime track outage duration for the restored-after-Ns
// message below. (Previously lived in a second, dead updateConnectionStatus()
// function of the same name as the SSE-status one further down — that name
// collision meant this outage-duration behavior silently never ran. Merged
// here into the listeners that actually fire, instead of registering a
// second competing "connection restored" toast.)
let isOnline = navigator.onLine;
let connectionLostTime = null;

// 5.43 seventh delivery: the browser's 'offline' event is only a HINT. Chromium /
// Edge raise it on a tab that sits idle (adapter power saving, Wi-Fi or VPN
// re-evaluation, sleep and wake) while the network works. So the event no longer
// shows the toast by itself: after a short grace period the page asks the server
// (_serverReachable) and only a failed answer counts as lost. A 'online' event in
// the grace period cancels it; "restored" is shown only if "lost" was shown.
const OFFLINE_CONFIRM_DELAY_MS = 2500;
const OFFLINE_PROBE_TIMEOUT_MS = 5000;
let _offlineConfirmTimer = null;
let _offlineToastShown = false;

// Any HTTP answer (even a redirect or 401) proves the network and the server are
// reachable; only a rejected fetch (network error) or the timeout means "no".
// redirect: 'manual' + body cancel: see CODING_GUIDELINES.md 14.2 (fetch rules).
async function _serverReachable() {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), OFFLINE_PROBE_TIMEOUT_MS);
    try {
        const response = await fetch('/api/speedtest/ping', {
            method: 'GET',
            cache: 'no-store',
            redirect: 'manual',
            signal: ctl.signal
        });
        try { response.body?.cancel(); } catch (e) { }
        return true;
    } catch (e) {
        return false;
    } finally {
        clearTimeout(timer);
    }
}

window.addEventListener('online', function () {
    if (_offlineConfirmTimer) {
        clearTimeout(_offlineConfirmTimer);
        _offlineConfirmTimer = null;
    }
    isOnline = true;
    if (!_offlineToastShown) {
        // The "lost" toast never appeared, so there is nothing to restore.
        console.log('🌐 Browser reports online again (no outage was shown)');
        connectionLostTime = null;
        return;
    }
    _offlineToastShown = false;
    console.log('🌐 Connection restored');
    let restoredMsg = '🌐 Connection restored';
    if (connectionLostTime) {
        const outageTime = Math.round((Date.now() - connectionLostTime) / 1000);
        restoredMsg += ` after ${outageTime}s outage`;
        connectionLostTime = null;
    }
    const failedItems = uploadQueue.filter(item => item.status === 'error');
    if (failedItems.length > 0) {
        restoredMsg += `. ${failedItems.length} failed upload(s) can be retried.`;
    }
    showUploadStatus(restoredMsg, 'success');
});

window.addEventListener('offline', function () {
    console.log('📡 Browser reported offline - verifying with the server before telling the user');
    if (_offlineConfirmTimer) return;   // one check at a time
    _offlineConfirmTimer = setTimeout(async () => {
        _offlineConfirmTimer = null;
        if (await _serverReachable()) {
            console.log('📡 False alarm: the server answered, connection is fine');
            isOnline = true;
            connectionLostTime = null;
            return;
        }
        if (_offlineToastShown) return;
        console.log('📡 Connection lost');
        isOnline = false;
        connectionLostTime = Date.now();
        _offlineToastShown = true;
        showUploadStatus('📡 Connection lost. Uploads will fail until connection is restored.', 'error');
    }, OFFLINE_CONFIRM_DELAY_MS);
});

// File input handling
document.getElementById('fileInput')?.addEventListener('change', function (e) {
    const files = Array.from(e.target.files);
    if (files.length > 0) {
        addFilesToQueue(files);
        // Reset input for future selections
        e.target.value = '';
    }
});

function addFilesToQueue(files) {
    // Separate folder uploads (have relativePath / webkitRelativePath) from plain files
    const folderFiles = [];
    const plainFiles = [];
    files.forEach(file => {
        const fp = file.relativePath || file.webkitRelativePath || '';
        if (fp.includes('/')) folderFiles.push(file);
        else plainFiles.push(file);
    });

    // Plain files — one queue row each, O(1) duplicate check
    let added = 0;
    plainFiles.forEach(file => {
        const key = `${currentPath}::${file.name}::${file.size}`;
        if (_seenFileKeys.has(key)) { showUploadStatus(`⚠️ "${file.name}" already in queue`, 'info'); return; }
        _seenFileKeys.add(key);
        uploadQueue.push({
            id: generateFileId(file), file,
            name: file.name, displayName: file.name,
            destinationPath: currentPath,
            size: file.size, status: 'pending',
            progress: 0, error: null, uploadedBytes: 0,
            createdTime: Date.now(),
            _seenKey: key  // stored so we can remove it from _seenFileKeys on cleanup
        });
        added++;
    });
    if (added > 0) {
        updateQueueDisplay();
        showUploadStatus(`➕ Added ${added} file(s) to queue`, 'success');
        _spawnFileWorkersIfNeeded();
    }

    // Folder files (webkitdirectory fallback) — group by root folder, show 1 row per folder
    if (folderFiles.length > 0) {
        _addFolderFilesToQueue(folderFiles);
    }
}

/**
 * Formats a backend-relative path the same way the breadcrumb does, so a
 * destination shown anywhere in the upload queue reads identically to how
 * the person would navigate to it — "" -> "/Root/", "Documents" -> "/Root/Documents".
 */
function _formatDisplayPath(path) {
    // Result is only ever placed into HTML text / attribute values, so it is escaped here.
    return escapeHtml(path ? `/Root/${path}` : '/Root/');
}

/**
 * True if a folder with this name is already actively queued/uploading to
 * this exact destination. Deliberately ignores groups that have already
 * finished — done or errored — so those never block a fresh drop of the
 * same name, and ignores groups headed to a DIFFERENT destination, so
 * dropping "folder1" at two different locations is never conflated into
 * one. Previously this only compared rootName, so re-dropping a same-named
 * folder anywhere silently no-op'd against whatever group (active or long
 * since finished/errored) happened to share that name, regardless of where
 * either one was actually headed.
 */
function _isFolderAlreadyQueued(rootName, destPath) {
    const dest = destPath || '';
    for (const g of folderGroups.values()) {
        if (g.rootName === rootName
            && (g.basePath || '') === dest
            && g.status !== 'done' && g.status !== 'error') {
            return true;
        }
    }
    return false;
}

/**
 * Called from drag-drop path — groups files by root folder, registers lazily.
 * Does NOT push into uploadQueue upfront (avoids memory spike).
 * Files are iterated one-at-a-time when upload actually starts.
 */
function _addFolderFilesToQueue(files) {
    // Group by root folder name to detect which distinct folders were dropped
    const byRoot = new Map();
    for (let i = 0; i < files.length; i++) {
        const fp = (files[i].relativePath || files[i].webkitRelativePath || '').replace(/^\//, '');
        const root = fp.split('/')[0] || 'Upload';
        if (!byRoot.has(root)) byRoot.set(root, []);
        byRoot.get(root).push(files[i]);
    }

    byRoot.forEach((groupFiles, rootName) => {
        if (_isFolderAlreadyQueued(rootName, currentPath)) {
            showUploadStatus(`📁 "${rootName}" is already uploading to this location`, 'info');
            return;
        }
        const groupId = `fg_${Date.now()}_${Math.random().toString(36).slice(2)}`;
        const group = {
            id: groupId, rootName,
            basePath: currentPath || '',
            pendingFiles: groupFiles,
            totalCount: groupFiles.length,
            scanned: groupFiles.length,
            completed: 0, errors: 0, assembling: 0,
            totalSize: 0,
            status: 'pending',
            scanComplete: true,
            cancelled: false,
            createdTime: Date.now()
        };
        folderGroups.set(groupId, group);
        updateQueueDisplay();
        showUploadStatus(`✅ "${rootName}" ready — ${groupFiles.length.toLocaleString()} files (computing size…)`, 'success');
        // Non-blocking background size scan
        _scanSizeChunked(group, groupFiles);
        _spawnFolderWorkersIfNeeded();
    });
}

/**
 * Registers a webkitdirectory FileList lazily.
 * Count is instant (fileList.length). Size computed in background without blocking.
 */
function _registerFolderGroup(fileArray, mobilePrefix) {
    if (!fileArray || fileArray.length === 0) return;

    const rootName = mobilePrefix
        || (fileArray[0].webkitRelativePath || '').split('/')[0]
        || 'Upload';

    if (_isFolderAlreadyQueued(rootName, currentPath)) {
        showUploadStatus(`📁 "${rootName}" is already uploading to this location`, 'info');
        return;
    }

    const groupId = `fg_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const group = {
        id: groupId,
        rootName,
        basePath: currentPath || '',  // frozen at queue time — never changes when user browses
        pendingFiles: fileArray, // Stable Array snapshot — never invalidated by input reset
        mobilePrefix,
        totalCount: fileArray.length,
        scanned: fileArray.length,
        completed: 0, errors: 0, assembling: 0,
        totalSize: 0,    // Filled progressively by _scanSizeChunked in background
        status: 'pending',
        scanComplete: true,  // webkitdirectory already enumerated everything before change fired
        cancelled: false,
        createdTime: Date.now()
    };
    folderGroups.set(groupId, group);
    updateQueueDisplay();
    showUploadStatus(`✅ "${rootName}" queued — ${fileArray.length.toLocaleString()} files (computing size…)`, 'success');
    _scanSizeChunked(group, fileArray); // Non-blocking background size scan
    _spawnFolderWorkersIfNeeded();
}

async function _scanSizeChunked(group, source, chunkSize = 1000) {
    const total = source.length;
    let i = 0;
    while (i < total && !group.cancelled) {
        const effectiveChunk = document.hidden ? 5000 : chunkSize;
        const end = Math.min(i + effectiveChunk, total);
        for (; i < end; i++) {
            group.totalSize += (source[i].size || 0);
        }
        updateQueueDisplay(); // Paint size update after each chunk
        await new Promise(r => setTimeout(r, 0)); // Yield to browser
    }
    updateQueueDisplay(); // Final update
}

async function _uploadFolderGroupLazy(group, startFrom = 0) {
    if (group._running) {
        console.warn(`⚠️ Group "${group.rootName}" loop already running — skipping duplicate start`);
        return;
    }
    group._running = true;
    group.status = 'uploading';
    _updateGroupRowInPlace(group);

    const total = group.totalCount || group.scanned;
    const usePendingFiles = !!group.pendingFiles;
    const source = usePendingFiles ? group.pendingFiles : (group.pendingEntries || []);

    console.log(`📁 Starting folder upload: "${group.rootName}" — ${total.toLocaleString()} files`);

    function _resolveItem(i) {
        if (!usePendingFiles) {
            const entry = source[i];
            if (!entry) return null;
            // pendingEntries have dest baked in at scan time using the original rootName.
            // If a rename override was applied after scanning, rewrite dest now.
            if (group.rootNameOverride && group._origRootName) {
                const origName = group._origRootName;
                const oldPrefix = group.basePath ? `${group.basePath}/${origName}` : origName;
                const newPrefix = group.basePath ? `${group.basePath}/${group.rootNameOverride}` : group.rootNameOverride;
                let newDest = entry.dest;
                if (newDest === oldPrefix) {
                    newDest = newPrefix;
                } else if (newDest.startsWith(oldPrefix + '/')) {
                    newDest = newPrefix + newDest.slice(oldPrefix.length);
                }
                const newDisplay = entry.displayName.startsWith(origName)
                    ? group.rootNameOverride + entry.displayName.slice(origName.length)
                    : entry.displayName;
                return { ...entry, dest: newDest, displayName: newDisplay };
            }
            return entry;
        }
        const file = source[i];
        if (!file) return null; // freed slot
        const fp = group.mobilePrefix
            ? `${group.mobilePrefix}/${file.name}`
            : (file.webkitRelativePath || file.relativePath || '').replace(/^\//, '');
        const parts = fp.split('/'); parts.pop();
        let relDir = parts.join('/');
        if (group.rootNameOverride && relDir) {
            const relParts = relDir.split('/');
            relParts[0] = group.rootNameOverride;
            relDir = relParts.join('/');
        } else if (group.rootNameOverride && !relDir) {
            relDir = group.rootNameOverride;
        }
        const base = group.basePath || '';
        const dest = base ? (relDir ? `${base}/${relDir}` : base) : relDir;
        const displayName = relDir ? `${relDir}/${file.name}` : file.name;
        return { file, dest, displayName };
    }

    const uiEvery = 1;
    // Log progress every 1000 files
    const logEvery = 1000;

    try {
        for (let i = startFrom; ; i++) {
            if (group.cancelled || !isUploading) break;

            while (i >= source.length) {
                if (group.scanComplete || group.cancelled || !isUploading) break;
                await new Promise(r => setTimeout(r, 50)); // yield ~50 ms then re-check
            }
            if (i >= source.length) break; // scanner finished and all entries consumed

            group._currentIndex = i;

            const _resolved = _resolveItem(i);
            if (!_resolved) continue; // freed slot from previous run
            const { file, dest, displayName } = _resolved;

            const ac = new AbortController();
            if (!group._activeControllers) group._activeControllers = new Set();
            group._activeControllers.add(ac);

            const queueItem = {
                id: generateFileId(file), file,
                name: file.name, displayName,
                destinationPath: dest,
                size: file.size, status: 'pending',
                progress: 0, error: null, uploadedBytes: 0,
                createdTime: Date.now(),
                _groupId: group.id,
                _abortSignal: ac.signal
            };

            uploadQueue.push(queueItem);
            updateItemStatus(queueItem.id, 'uploading');

            try {
                await uploadSingleFile(queueItem);
                // uploadSingleFile() resolves as soon as the last chunk is SENT,
                // not once the backend has finished reassembling it — for large
                // files it flips the item to 'assembling' and starts polling
                // /api/assembly_status in the background before returning here.
                // Overwriting that back to 'completed' unconditionally (as this
                // used to do) is what caused a folder to show "Done" while its
                // last big file was still being rebuilt server-side. Only mark
                // it completed here if it ISN'T mid-assembly; if it is, leave it
                // alone — startAssemblyPolling() will call updateItemStatus()
                // itself once the backend confirms the file is actually ready.
                if (!group.cancelled && queueItem.status !== 'assembling') {
                    updateItemStatus(queueItem.id, 'completed');
                    lazyBytesUploaded += file.size;
                    _recordSpeedSample(totalBytesUploaded);
                    _lastUploadActivity = Date.now();
                }
            } catch (err) {
                const userCancelled = group.cancelled
                    || err.message === 'Upload cancelled by user';
                const unexpectedAbort = !userCancelled && err.name === 'AbortError';

                const isNetworkError = unexpectedAbort || (!userCancelled && (
                    err.message.includes('Failed to fetch') ||
                    err.message.includes('NetworkError') ||
                    err.message.includes('net::ERR_') ||
                    err.name === 'TypeError'
                ));

                if (userCancelled) {
                    group.cancelled = true;
                    updateItemStatus(queueItem.id, 'cancelled', 'Stopped');
                } else if (isNetworkError && isUploading) {
                    updateItemStatus(queueItem.id, 'pending', 'Waiting to retry…');
                    if (document.hidden) {
                        await new Promise(resolve => {
                            const handler = () => { document.removeEventListener('visibilitychange', handler); resolve(); };
                            document.addEventListener('visibilitychange', handler);
                        });
                    }
                    await new Promise(r => setTimeout(r, 1500));
                    const retryIdx = uploadQueue.findIndex(q => q.id === queueItem.id);
                    if (retryIdx !== -1) uploadQueue.splice(retryIdx, 1);
                    i--;
                    continue;
                } else {
                    updateItemStatus(queueItem.id, 'error', err.message);
                }
            } finally {
                if (group._activeControllers) group._activeControllers.delete(ac);
            }

            // Items still 'assembling' MUST stay in uploadQueue — updateItemStatus()
            // looks the item up by id when the assembly poller later reports
            // 'completed'/'error', and needs to find it to update group counters
            // and remove it. updateItemStatus() itself splices it out once it
            // actually leaves the 'assembling' state (see the group-sync block).
            if (queueItem.status !== 'assembling') {
                const idx = uploadQueue.findIndex(q => q.id === queueItem.id);
                if (idx !== -1) uploadQueue.splice(idx, 1);
            }

            if (usePendingFiles && source[i]) {
                source[i] = null;
            }

            const done = group.completed + group.errors;

            // Folder-level progress log every 1000 files
            if (done > 0 && done % logEvery === 0) {
                const pct = Math.round((done / total) * 100);
                console.log(`📁 "${group.rootName}": ${done.toLocaleString()} / ${total.toLocaleString()} files (${pct}%) — ${group.errors} errors`);
            }

            if (done % uiEvery === 0 || done === total) {
                _updateGroupRowInPlace(group);
                updateOverallProgress();
            }
        }
    } finally {
        group._running = false;
        group._currentIndex = null;
    }

    const finalStatus = group.cancelled ? 'cancelled' : (group.errors > 0 ? 'done with errors' : 'done');
    console.log(`📁 "${group.rootName}" finished sending: ${group.completed.toLocaleString()} uploaded, ${group.errors} errors, ${group.assembling} still processing — ${finalStatus}`);

    group.pendingFiles = null;
    group.pendingEntries = null;
    // _maybeFinalizeGroup only actually sets group.status + runs cleanup if
    // nothing is still being reassembled server-side (group.assembling === 0).
    // If files are still assembling, this is a no-op here — the group-sync
    // block in updateItemStatus() calls it again itself each time an assembly
    // job resolves, and finalizes the group once the last one is done.
    _maybeFinalizeGroup(group);
    _updateGroupRowInPlace(group);
    updateOverallProgress();
}

/**
 * Decide whether a folder group has nothing left in flight — every file has
 * either completed, errored, or (if the group was cancelled) been abandoned —
 * AND no file is still being reassembled server-side. If so, sets the group's
 * final status and runs its one-time cleanup. Safe to call repeatedly and
 * from multiple places (the upload loop's own exit, and updateItemStatus()
 * whenever an async assembly job resolves) — it only acts once per group.
 */
function _maybeFinalizeGroup(group) {
    if (group.status === 'done' || group.status === 'error') { _finalizeGroupCleanup(group); return; }
    const groupTotal = group.totalCount || group.scanned;
    const allAttempted = groupTotal > 0 && (group.completed + group.errors >= groupTotal);
    if (!(allAttempted || group.cancelled)) return; // still files left to upload
    if (group.assembling > 0) return; // still waiting on a backend rebuild
    group.status = group.cancelled ? 'error' : (group.errors > 0 ? 'error' : 'done');
    _finalizeGroupCleanup(group);
}

/** One-time cleanup once a group's final status is set — safe to call more than once. */
function _finalizeGroupCleanup(group) {
    if (group._finalized) return;
    group._finalized = true;
    if (group._activeControllers) group._activeControllers.clear();
    group._activeControllers = null;

    // Each folder removes itself 2s after finishing — independent of other folders.
    if (group.status === 'done') {
        _freeSeen(group); // Release dedup keys immediately so the same folder can be re-queued after deletion
        setTimeout(() => {
            if (folderGroups.has(group.id)) {
                folderGroups.delete(group.id);
                updateQueueDisplay();
            }
        }, 2000);
    }
}

function _freeSeen(group) {
    if (group._ownedKeys) {
        group._ownedKeys.forEach(key => _seenFileKeys.delete(key));
        group._ownedKeys.clear();
    }
}

/** Remove a pending folder group from queue */
function _cancelFolderGroup(groupId) {
    const group = folderGroups.get(groupId);
    if (!group) return;
    group.cancelled = true;
    _freeSeen(group);
    uploadQueue = uploadQueue.filter(item => item._groupId !== groupId);
    folderGroups.delete(groupId);
    updateQueueDisplay();
    showUploadStatus('🗑️ Folder removed from queue', 'info');
}

/** Stop an in-progress folder upload — aborts current fetch + sets cancelled flag */
function _stopFolderGroup(groupId) {
    const group = folderGroups.get(groupId);
    if (!group) return;

    group.cancelled = true;

    if (group._activeControllers && group._activeControllers.size > 0) {
        group._activeControllers.forEach(ac => { try { ac.abort(); } catch (e) { } });
        group._activeControllers.clear();
    }
    // Legacy fallback for any older reference
    if (group._activeController) {
        try { group._activeController.abort(); } catch (e) { }
        group._activeController = null;
    }

    // Mark any items in the queue so chunked loops exit at next check.
    // Items already 'assembling' are left alone: their bytes are already
    // fully on the server and the backend is already reassembling them —
    // abort() has no effect on work that already finished sending, and
    // stomping the status to 'cancelled' here (bypassing updateItemStatus)
    // would desync group.assembling forever, since nothing would ever see
    // it "leave" the assembling state. It'll resolve normally via
    // startAssemblyPolling() like any other assembling file.
    uploadQueue.filter(item => item._groupId === groupId && item.status !== 'assembling').forEach(item => {
        cancelledUploads.add(item.id);
        item.status = 'cancelled';
    });

    group.pendingFiles = null;
    group.pendingEntries = null;
    showUploadStatus(`⛔ Stopping "${group.rootName}" — ${group.completed} files uploaded`, 'info');
    _updateGroupRowInPlace(group);
}


function addToUploadQueue(itemData) {
    // Add a single item to the upload queue (for assembly recovery)
    const queueItem = {
        id: itemData.id,
        file: null, // No file object for recovered items
        name: itemData.name,
        displayName: itemData.name,
        destinationPath: '',
        size: itemData.size || 0,
        status: itemData.status || 'pending',
        progress: itemData.progress || 0,
        error: itemData.error || null,
        uploadedBytes: itemData.size || 0,
        createdTime: Date.now(),
        message: itemData.message || null
    };

    uploadQueue.push(queueItem);
    updateQueueDisplay();
    console.log('📝 Added recovered item to queue:', itemData.name);
}

let _fileIdCounter = 0;

// Upload id: fid_<counter>_<file size>_<16 random hex>. The counter restarts at 1 on every page
// load, so on its own two tabs (or two users) uploading files of the same size would send the
// same id; the random part makes it unique. The server adds the session on top (routes/uploads.py,
// _chunk_key). Only letters, digits and underscores, at most 128 characters (server limit).
function _randomHex(byteCount) {
    const bytes = new Uint8Array(byteCount);
    try {
        // getRandomValues also works on plain-http LAN pages (randomUUID needs a secure context)
        crypto.getRandomValues(bytes);
    } catch (e) {
        for (let i = 0; i < byteCount; i++) bytes[i] = Math.floor(Math.random() * 256);
    }
    return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
}

function generateFileId(file) {
    return `fid_${++_fileIdCounter}_${file.size}_${_randomHex(8)}`;
}

function removeFromQueue(fileId) {
    const index = uploadQueue.findIndex(item => item.id === fileId);
    if (index > -1) {
        const item = uploadQueue[index];
        if (item.status === 'uploading') {
            showUploadStatus('❌ Cannot remove file currently being uploaded', 'error');
            return;
        }
        if (item.status === 'assembling') {
            // Bytes are already fully on the server and being reassembled —
            // removing the row here would just orphan it: the backend keeps
            // working regardless, but nothing would be left to receive the
            // eventual completed/error result from startAssemblyPolling().
            showUploadStatus('❌ Cannot remove file currently being processed on the server', 'error');
            return;
        }
        // This function only ever removed from uploadQueue and never touched
        // folderGroups — fine for ungrouped items, but a grouped item reaching
        // here (it shouldn't; updateItemStatus() splices those out itself)
        // would desync the group's completed/errors counters silently. Warn
        // instead of failing quietly.
        if (item._groupId) {
            console.warn(`⚠️ removeFromQueue() called on grouped item ${fileId} (group ${item._groupId}) — this shouldn't normally happen`);
        }

        uploadQueue.splice(index, 1);

        // Try to cleanup chunks for this item
        if (item.status === 'pending' || item.status === 'error' || item.status === 'cancelled') {
            cleanupSingleFile(fileId).catch(console.error);
        }

        updateQueueDisplay();
        showUploadStatus(`🗑️ Removed "${item.name}" from queue`, 'success');
    }
}

async function cancelUpload(fileId) {
    console.log(`🚫 Cancelling upload for file: ${fileId}`);

    // Immediately mark as cancelled to stop ongoing processes
    cancelledUploads.add(fileId);

    const index = uploadQueue.findIndex(item => item.id === fileId);
    if (index === -1) {
        console.error(`❌ File ${fileId} not found in queue`);
        return;
    }

    const item = uploadQueue[index];
    if (item.status !== 'uploading') {
        console.error(`❌ File ${fileId} is not currently uploading (status: ${item.status})`);
        return;
    }

    try {
        showUploadStatus(`🚫 Cancelling upload of "${item.name}"...`, 'info');

        // Mark as cancelled immediately
        item.status = 'cancelled';
        item.error = 'Upload cancelled by user';
        updateQueueDisplay();

        // Call the cancel endpoint to clean up server-side chunks
        const response = await fetch('/cancel_upload', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                file_id: fileId,
                filename: item.name
            })
        });

        const result = await response.json();

        if (result.success) {
            console.log(`✅ Successfully cancelled upload: ${result.message}`);
            showUploadStatus(`🚫 Cancelled: ${item.name}`, 'warning');

            // Update global state
            if (currentUploadingFile === fileId) {
                currentUploadingFile = null;
                isUploading = false;
            }

            // Refresh file table after cancel
            setTimeout(() => {
                refreshFileTable();
            }, 500);

            // Continue with next file if we were batch uploading
            if (uploadQueue.some(item => item.status === 'pending') && !isUploading) {
                setTimeout(() => {
                    startBatchUpload();
                }, 500);
            }
        } else {
            console.error(`❌ Failed to cancel upload: ${result.error}`);
            showUploadStatus(`❌ Failed to cancel upload: ${result.error}`, 'error');

            // Revert status for retry
            item.status = 'error';
            item.error = 'Cancel failed: ' + result.error;
            cancelledUploads.delete(fileId); // Remove from cancelled set
            updateQueueDisplay();
        }

    } catch (error) {
        console.error('❌ Cancel upload error:', error);
        showUploadStatus(`❌ Cancel upload error: ${error.message}`, 'error');

        // Revert status for retry
        item.status = 'error';
        item.error = 'Cancel error: ' + error.message;
        cancelledUploads.delete(fileId); // Remove from cancelled set
        updateQueueDisplay();
    }
}

function clearAllQueue() {
    if (isUploading) {
        showUploadStatus('❌ Cannot clear queue while uploading', 'error');
        return;
    }
    const itemsToCleanup = uploadQueue.filter(item => item.status === 'pending' || item.status === 'error');
    uploadQueue = [];
    folderGroups.clear();
    _seenFileKeys.clear();
    updateQueueDisplay();
    if (itemsToCleanup.length > 0) cleanupUnfinishedChunks(itemsToCleanup).catch(console.error);
    showUploadStatus('🧹 Upload queue cleared', 'success');
}

function clearCompletedItems() {
    const before = uploadQueue.length;
    // Release dedup keys of completed/error items so they can be re-queued
    uploadQueue.forEach(item => {
        if (item.status !== 'pending' && item.status !== 'uploading' && item.status !== 'assembling') {
            if (item._seenKey) _seenFileKeys.delete(item._seenKey);
        }
    });
    uploadQueue = uploadQueue.filter(item =>
        item.status === 'pending' || item.status === 'uploading' || item.status === 'assembling'
    );
    const filesCleared = before - uploadQueue.length;

    let groupsCleared = 0;
    folderGroups.forEach((group, id) => {
        // Never delete a group while one of its files is still being
        // reassembled server-side — doing so orphans that queue item: it
        // stays counted in the header totals (uploadQueue.length / size)
        // but never renders again, since its folder row is gone and it's
        // filtered out of the plain file list for still having a _groupId.
        // That's the "queue container stays, list goes empty" bug.
        if (group.assembling > 0) return;
        if (group.status === 'done' || group.status === 'error' || group.status === 'cancelled' || group.cancelled) {
            _freeSeen(group); // Release dedup keys so same folder can be re-queued
            folderGroups.delete(id);
            groupsCleared++;
        }
    });

    const total = filesCleared + groupsCleared;
    if (total === 0) { showUploadStatus('ℹ️ No completed items to clear', 'info'); return; }
    updateQueueDisplay();
    showUploadStatus(`🧹 Cleared ${total} item${total > 1 ? 's' : ''}`, 'success');
}

// Enhanced cleanup function with retry logic
async function cleanupUnfinishedChunks(specificItems = null) {
    const itemsToClean = specificItems || uploadQueue.filter(item =>
        item.status === 'pending' || item.status === 'error'
    );

    if (itemsToClean.length === 0) return;

    console.log(`🧹 Cleaning up ${itemsToClean.length} unfinished uploads...`);

    const cleanupPromises = itemsToClean.map(item => cleanupSingleFile(item.id, item.name));

    try {
        await Promise.allSettled(cleanupPromises);
        console.log('✅ Bulk cleanup completed');
    } catch (error) {
        console.error('❌ Error in bulk cleanup:', error);
    }
}

async function cleanupSingleFile(fileId, fileName = 'unknown') {
    const maxRetries = 3;
    let retries = 0;

    while (retries < maxRetries) {
        try {
            const response = await fetch('/cleanup_chunks', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ file_id: fileId })
            });

            if (response.ok) {
                console.log(`🧹 Cleaned up chunks for: ${fileName} (${fileId})`);
                return;
            } else {
                const errorData = await response.json();
                throw new Error(`HTTP ${response.status}: ${errorData.error || 'Unknown error'}`);
            }
        } catch (error) {
            retries++;
            console.warn(`🔄 Cleanup retry ${retries}/${maxRetries} for ${fileId}:`, error.message);

            if (retries < maxRetries) {
                // Wait before retrying (exponential backoff)
                await new Promise(resolve => setTimeout(resolve, Math.pow(2, retries) * 1000));
            } else {
                console.error(`❌ Failed to cleanup chunks for ${fileId} after ${maxRetries} attempts:`, error.message);
                throw error;
            }
        }
    }
}

function updateQueueDisplay() {
    const queueContainer = document.getElementById('uploadQueue');
    const queueElement = document.getElementById('fileQueue');
    const statsElement = document.getElementById('queueStats');
    const uploadBtn = document.getElementById('startUploadBtn');
    const countElement = document.getElementById('uploadCount');

    if (!queueContainer) return;

    const hasItems = uploadQueue.length > 0 || folderGroups.size > 0;
    if (!hasItems) {
        queueContainer.classList.remove('show');
        if (uploadBtn) uploadBtn.disabled = true;
        return; // progress bar driven by setUploadingState() only
    }

    queueContainer.classList.add('show');

    const totalSize = uploadQueue.reduce((sum, item) => sum + (item.size || 0), 0);
    const pendingCount = uploadQueue.filter(item => item.status === 'pending').length;
    const scanning = [...folderGroups.values()].some(g => g.status === 'scanning');

    // Count files + size from ALL lazy folder groups (not yet in uploadQueue)
    let lazyFileCount = 0, lazySize = 0, hasPendingLazyGroups = false;
    folderGroups.forEach(g => {
        if (!g.cancelled) {
            lazyFileCount += (g.totalCount || g.scanned || 0);
            lazySize += (g.totalSize || 0);
            if (g.status === 'pending' && (g.pendingFiles || g.pendingEntries)) {
                hasPendingLazyGroups = true;
            }
        }
    });
    const totalFileCount = uploadQueue.length + lazyFileCount;
    const grandTotalSize = totalSize + lazySize;
    const sizeStr = scanning ? 'scanning…' : formatFileSize(grandTotalSize);

    let statsText = `(${totalFileCount.toLocaleString()} files, ${sizeStr})`;
    if (folderGroups.size > 0)
        statsText = `(${totalFileCount.toLocaleString()} files from ${folderGroups.size} folder${folderGroups.size > 1 ? 's' : ''}, ${sizeStr})`;
    if (scanning) statsText += ' — scanning…';

    if (statsElement) statsElement.textContent = statsText;
    if (countElement) countElement.textContent = pendingCount + lazyFileCount;
    if (uploadBtn) uploadBtn.disabled = (pendingCount === 0 && !hasPendingLazyGroups && !scanning) || isUploading;

    // Progress bar driven by setUploadingState() — not here

    if (queueElement) {
        queueElement.innerHTML = '';
        // One row per folder group
        folderGroups.forEach(group => queueElement.appendChild(_createFolderGroupRow(group)));
        // Individual rows for non-folder files, PLUS any orphaned item whose
        // folder group no longer exists (shouldn't happen — see the
        // assembling>0 guards on every folderGroups.delete() call — but if
        // it ever does, falling back to a normal row here means the item
        // stays visible and removable instead of silently vanishing while
        // still counted in the header stats).
        uploadQueue.filter(item => !item._groupId || !folderGroups.has(item._groupId))
            .forEach(item => queueElement.appendChild(createQueueItemElement(item)));
    }
}

function _folderRowContent(group) {
    const total = group.totalCount || group.scanned;
    const pct = total > 0 ? Math.round((group.completed / total) * 100) : 0;
    const sizeStr = group.status === 'scanning'
        ? 'computing'
        : (group.totalSize > 0 ? formatFileSize(group.totalSize) : '0 bytes');
    const icons = {
        scanning: 'fas fa-circle-notch fa-spin', pending: 'fas fa-clock',
        uploading: 'fas fa-spinner fa-spin', done: 'fas fa-check-circle',
        error: 'fas fa-exclamation-circle'
    };
    const labels = {
        scanning: `Scanning ${group.scanned.toLocaleString()} files`,
        pending: `Queued — ${total.toLocaleString()} files`,
        uploading: `${group.completed.toLocaleString()} / ${total.toLocaleString()} (${pct}%)`,
        done: `Done — ${total.toLocaleString()} files`,
        error: `${group.errors} failed of ${total.toLocaleString()}`
    };
    // All files have been sent but the server is still rebuilding one or more
    // of them from chunks — without this, the row just sits at N-1/N with a
    // plain spinner and looks stuck, instead of showing the same "Processing"
    // gear a single chunked file gets outside of a folder.
    if (group.status === 'uploading' && group.assembling > 0) {
        icons.uploading = 'fas fa-cog fa-spin';
        labels.uploading = group.assembling === 1
            ? `${group.completed.toLocaleString()} / ${total.toLocaleString()} — processing 1 file…`
            : `${group.completed.toLocaleString()} / ${total.toLocaleString()} — processing ${group.assembling.toLocaleString()} files…`;
    }
    const sc = group.status === 'done' ? 'completed' : group.status;
    return { total, pct, sizeStr, icons, labels, sc };
}

function _createFolderGroupRow(group) {
    const { total, pct, sizeStr, icons, labels, sc } = _folderRowContent(group);
    const div = document.createElement('div');
    div.className = `queue-item ${sc}`;
    div.dataset.groupId = group.id;
    div.innerHTML = `
        <div class="file-info">
            <i class="fas fa-folder" style="color:#f39c12;font-size:20px;margin-right:8px;flex-shrink:0;"></i>
            <div class="file-info-details">
                <div class="file-info-name" title="${escapeHtml(group.rootName)}">📁 ${escapeHtml(group.rootName)}</div>
                <div class="file-info-dest" title="Uploading to: ${_formatDisplayPath(group.basePath)}">
                    <i class="fas fa-folder"></i> ${_formatDisplayPath(group.basePath)}
                </div>
                <div class="file-info-meta">
                    <span class="fg-count"><i class="fas fa-file"></i> ${total.toLocaleString()} files</span>
                    <span class="fg-size"><i class="fas fa-weight-hanging"></i> ${sizeStr}</span>
                </div>
            </div>
        </div>
        <div class="file-status">
            ${group.status === 'uploading'
            ? `<div class="progress-bar-small"><div class="progress-fill-small fg-bar"></div></div>`
            : ''}
            ${group.status === 'scanning'
            ? `<div class="progress-bar-small"><div class="progress-fill-small" style="width:100%;background:#f39c12;animation:pulse 1s infinite;"></div></div>`
            : ''}
            <span class="status-text status-${sc} fg-status">
                <i class="${icons[group.status] || 'fas fa-folder'}"></i> ${labels[group.status] || group.status}
            </span>
            ${(group.status === 'pending' || group.status === 'scanning') ? `
                <button class="remove-btn" data-fn="_cancelFolderGroup" data-args="${dataArgs([group.id])}" title="Remove folder">
                    <i class="fas fa-times"></i>
                </button>` : ''}
            ${group.status === 'uploading' ? `
                <button class="remove-btn cancel-btn fg-stop-btn" data-gid="${group.id}" title="Stop upload">
                    <i class="fas fa-ban"></i>
                </button>` : ''}
        </div>`;

    if (group.status === 'uploading') {
        const barEl = div.querySelector('.fg-bar');
        if (barEl) barEl.style.width = pct + '%';
    }

    return div;
}

/** Update an existing folder row in-place — never replaces the element, so the Stop button stays clickable */
function _updateGroupRowInPlace(group) {
    const el = document.querySelector(`[data-group-id="${group.id}"]`);
    if (!el) { updateQueueDisplay(); return; }

    const { total, pct, sizeStr, icons, labels, sc } = _folderRowContent(group);
    el.className = `queue-item ${sc}`;

    const cntEl = el.querySelector('.fg-count');
    if (cntEl) cntEl.innerHTML = `<i class="fas fa-file"></i> ${total.toLocaleString()} files`;

    const szEl = el.querySelector('.fg-size');
    if (szEl) szEl.innerHTML = `<i class="fas fa-weight-hanging"></i> ${sizeStr}`;

    const stEl = el.querySelector('.fg-status');
    if (stEl) {
        stEl.className = `status-text status-${sc} fg-status`;
        stEl.innerHTML = `<i class="${icons[group.status] || 'fas fa-folder'}"></i> ${labels[group.status] || group.status}`;
    }

    const barEl = el.querySelector('.fg-bar');
    if (barEl) barEl.style.width = pct + '%';

    // Add progress bar when transitioning to uploading
    if (group.status === 'uploading' && !barEl) {
        const fs = el.querySelector('.file-status');
        if (fs) {
            const wrap = document.createElement('div');
            wrap.className = 'progress-bar-small';
            const fill = document.createElement('div');
            fill.className = 'progress-fill-small fg-bar';
            fill.style.width = pct + '%';
            wrap.appendChild(fill);
            fs.insertBefore(wrap, fs.firstChild);
        }
    }

    const existingStopBtn = el.querySelector('.fg-stop-btn');
    const existingRemoveBtn = el.querySelector('.remove-btn:not(.fg-stop-btn)');

    const needsStopBtn = group.status === 'uploading';
    const needsRemoveBtn = group.status === 'pending' || group.status === 'scanning';

    if (needsStopBtn && !existingStopBtn) {
        // Transition into uploading — create stop button once
        existingRemoveBtn && existingRemoveBtn.remove();
        const _fs = el.querySelector('.file-status');
        if (_fs) {
            const btn = document.createElement('button');
            btn.className = 'remove-btn cancel-btn fg-stop-btn';
            btn.dataset.gid = group.id;
            btn.title = 'Stop upload';
            btn.innerHTML = '<i class="fas fa-ban"></i>';
            _fs.appendChild(btn);
        }
    } else if (!needsStopBtn && existingStopBtn) {
        // Transition out of uploading — remove stop button
        existingStopBtn.remove();
    }

    if (needsRemoveBtn && !existingRemoveBtn) {
        // Transition into pending/scanning — create remove button once
        const _fs = el.querySelector('.file-status');
        if (_fs) {
            const btn = document.createElement('button');
            btn.className = 'remove-btn';
            btn.title = 'Remove folder';
            btn.onclick = () => _cancelFolderGroup(group.id);
            btn.innerHTML = '<i class="fas fa-times"></i>';
            _fs.appendChild(btn);
        }
    } else if (!needsRemoveBtn && existingRemoveBtn) {
        existingRemoveBtn.remove();
    }
}


function createQueueItemElement(item) {
    const div = document.createElement('div');
    div.className = `queue-item ${item.status}`;
    div.dataset.fileId = item.id;

    const statusIcons = {
        pending: 'fas fa-clock',
        uploading: 'fas fa-spinner fa-spin',
        assembling: 'fas fa-cog fa-spin',
        completed: 'fas fa-check-circle',
        error: 'fas fa-exclamation-circle',
        cancelled: 'fas fa-ban'
    };

    const statusLabels = {
        pending: 'Queued',
        uploading: 'Uploading',
        assembling: 'Processing',
        completed: 'Completed',
        error: 'Failed',
        cancelled: 'Cancelled'
    };

    const statusIcon = statusIcons[item.status] || 'fas fa-question-circle';
    const statusLabel = statusLabels[item.status] || item.status.charAt(0).toUpperCase() + item.status.slice(1);

    // Calculate age for display
    const ageInSeconds = Math.floor((Date.now() - (item.createdTime || Date.now())) / 1000);
    const ageDisplay = ageInSeconds < 60 ? `${ageInSeconds}s` :
        ageInSeconds < 3600 ? `${Math.floor(ageInSeconds / 60)}m` :
            `${Math.floor(ageInSeconds / 3600)}h`;

    div.innerHTML = `
                <div class="file-info">
                    <i class="${getFileIcon(item.name)} queue-item-icon"></i>
                    <div class="file-info-details">
                        <div class="file-info-name" title="${escapeHtml(item.displayName || item.name)}">
                            ${escapeHtml(item.displayName || item.name)}
                        </div>
                        <div class="file-info-dest" title="Uploading to: ${_formatDisplayPath(item.destinationPath)}">
                            <i class="fas fa-folder"></i><span class="file-info-dest-text">${_formatDisplayPath(item.destinationPath)}</span>
                        </div>
                        <div class="file-info-meta">
                            <span><i class="fas fa-weight-hanging"></i> ${formatFileSize(item.size)}</span>
                            <span><i class="fas fa-clock"></i> ${ageDisplay}</span>
                            ${item.status === 'uploading' ? `<span><i class="fas fa-percentage"></i> ${item.progress}%</span>` : ''}
                            ${item.status === 'assembling' ? `<span><i class="fas fa-cog"></i> Processing</span>` : ''}
                            ${item.error ? `<span><i class="fas fa-exclamation"></i> ${escapeHtml(item.error)}</span>` : ''}
                        </div>
                    </div>
                </div>
                <div class="file-status">
                    ${item.status === 'uploading' || item.status === 'assembling' ? `
                        <div class="progress-bar-small">
                            <div class="progress-fill-small queue-item-bar"></div>
                        </div>
                    ` : ''}
                    <span class="status-text status-${item.status}">
                        <i class="${statusIcon}"></i> ${statusLabel}
                    </span>
                    ${item.status === 'pending' || item.status === 'error' || item.status === 'cancelled' ? `
                        <button class="remove-btn" data-fn="removeFromQueue" data-args="${dataArgs([item.id])}" title="Remove from queue">
                            <i class="fas fa-times"></i>
                        </button>
                    ` : ''}
                    ${item.status === 'uploading' ? `
                        <button class="remove-btn cancel-btn" data-fn="cancelUpload" data-args="${dataArgs([item.id])}" title="Cancel upload">
                            <i class="fas fa-ban"></i>
                        </button>
                    ` : ''}
                </div>
            `;

    const queueIconEl = div.querySelector('.queue-item-icon');
    if (queueIconEl) queueIconEl.style.color = getFileColor(item.name);
    const queueBarEl = div.querySelector('.queue-item-bar');
    if (queueBarEl) queueBarEl.style.width = item.progress + '%';

    return div;
}

function updateProgressSummary() {
    const totalSizeElement = document.getElementById('totalSize');
    const uploadedSizeElement = document.getElementById('uploadedSize');
    const uploadSpeedElement = document.getElementById('uploadSpeed');
    const etaElement = document.getElementById('eta');
    const elapsedElement = document.getElementById('elapsedTime');
    const overallPercentageElement = document.getElementById('overallPercentage');
    const overallProgressFill = document.getElementById('overallProgressFill');

    if (isUploading) {
        // FIX: files that belong to a folder group (item._groupId) are already
        // counted inside that group's totalSize, since group.totalSize is never
        // decremented as its files complete. Including them again here double-
        // counts every in-flight file, and because the line below only ever
        // ratchets the total UP (never back down), each double-count becomes a
        // permanent inflation — over a folder with 100+ large files this is what
        // makes "Total" appear to keep climbing/multiplying during the upload.
        const nonGroupQueueBytes = uploadQueue
            .filter(i => !i._groupId)
            .reduce((s, i) => s + (i.size || 0), 0);
        const groupBytes = [...folderGroups.values()]
            .filter(g => g.status === 'scanning' || g.status === 'pending' || g.status === 'uploading')
            .reduce((s, g) => s + (g.totalSize || 0), 0);
        const live = nonGroupQueueBytes + groupBytes;
        // Ratchet is intentionally kept: once a group finishes it's excluded from
        // groupBytes above, and we don't want totalBytesToUpload to shrink below
        // bytes already uploaded — it should only grow as scanning discovers more.
        if (live > totalBytesToUpload) totalBytesToUpload = live;
    }
    if (totalBytesToUpload === 0) return;

    const uploadSpeed = _rollingSpeed();
    const remainingBytes = Math.max(0, totalBytesToUpload - totalBytesUploaded);
    const eta = uploadSpeed > 0 ? remainingBytes / uploadSpeed : 0;
    const overallProgress = Math.min(100, (totalBytesUploaded / totalBytesToUpload) * 100);

    if (totalSizeElement) totalSizeElement.textContent = formatFileSize(totalBytesToUpload);
    if (uploadedSizeElement) uploadedSizeElement.textContent = formatFileSize(totalBytesUploaded);
    if (uploadSpeedElement) uploadSpeedElement.textContent = formatFileSize(uploadSpeed) + '/s';
    if (etaElement) etaElement.textContent = formatTime(eta);
    if (elapsedElement) elapsedElement.textContent = uploadStartTime ? formatTime((Date.now() - uploadStartTime) / 1000) : '0:00';
    if (overallPercentageElement) overallPercentageElement.textContent = Math.round(overallProgress) + '%';
    if (overallProgressFill) overallProgressFill.style.width = overallProgress + '%';
}

function formatTime(seconds) {
    if (!seconds || seconds === Infinity) return '--:--';

    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    if (hours > 0) {
        return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    } else {
        return `${minutes}:${secs.toString().padStart(2, '0')}`;
    }
}

function getFileIcon(filename) {
    const ext = String(filename).split('.').pop().toLowerCase();
    return EXTENSION_MAP[ext]?.icon || 'fas fa-file';
}

function getFileColor(filename) {
    const ext = String(filename).split('.').pop().toLowerCase();
    return EXTENSION_MAP[ext]?.color || '#ffffff';
}

// Centralized extension -> {type, icon, color} mapping (partial but extensive)
const EXTENSION_MAP = (function () {
    // Helper to build entries quickly
    const e = (exts, type, icon, color) => exts.forEach(x => map[x] = { type, icon, color });
    const map = Object.create(null);

    // Documents
    e(['txt', 'rtf', 'doc', 'docx', 'odt', 'pdf', 'tex', 'log', 'csv', 'tsv', 'md', 'xml', 'json', 'ini', 'cfg', 'yaml', 'yml', 'nfo', 'readme', 'wps', 'dot', 'dotx'], 'Document', 'fas fa-file-alt', '#34495e');

    // Data
    e(['xls', 'xlsx', 'ods', 'db', 'mdb', 'accdb', 'sqlite', 'sqlite3', 'sql', 'sav', 'dat', 'dbf', 'parquet', 'arff', 'rdata', 'dta', 'pivot'], 'Data', 'fas fa-file-excel', '#27ae60');

    // Presentations
    e(['ppt', 'pptx', 'odp', 'key', 'pub', 'msg', 'eml', 'oft', 'note'], 'Presentation', 'fas fa-file-powerpoint', '#e67e22');

    // Images
    e(['jpg', 'jpeg', 'png', 'gif', 'bmp', 'tif', 'tiff', 'ico', 'svg', 'webp', 'heic', 'heif', 'psd', 'psb', 'ai', 'eps', 'ind', 'indd', 'idml', 'xcf', 'cpt', 'exr', 'hdr', 'raw', 'nef', 'cr2', 'arw', 'dng', 'sketch', 'fig', 'xd'], 'Image', 'fas fa-file-image', '#9b59b6');

    // Video
    e(['mp4', 'avi', 'mov', 'wmv', 'mkv', 'flv', 'webm', 'mpeg', 'mpg', 'm4v', '3gp', 'mxf', 'f4v', 'vob', 'swf', 'blend', 'aep', 'prproj', 'drp', 'veg'], 'Video', 'fas fa-file-video', '#e74c3c');

    // Audio
    e(['mp3', 'wav', 'ogg', 'flac', 'wma', 'aac', 'm4a', 'mid', 'midi', 'aiff', 'aif', 'oma', 'pcm', 'stem'], 'Audio', 'fas fa-file-audio', '#f39c12');

    // 3D / CAD
    e(['dwg', 'dxf', 'dwf', 'dwt', 'dgn', 'rvt', 'rfa', 'rte', 'ifc', 'step', 'stp', 'stl', 'iges', 'igs', 'sldprt', 'sldasm', 'ipt', 'iam', 'f3d', 'fbx', 'obj', '3ds', 'max', 'skp', 'plt', 'cam', 'cnc', 'nc', 'scad'], '3D / CAD', 'fas fa-cube', '#16a085');

    // Code
    e(['py', 'ipynb', 'js', 'jsx', 'ts', 'tsx', 'html', 'htm', 'css', 'java', 'class', 'jar', 'c', 'cpp', 'h', 'hpp', 'cs', 'vb', 'php', 'asp', 'aspx', 'jsp', 'go', 'rb', 'pl', 'sh', 'bat', 'cmd', 'ps1', 'lua', 'sql', 'yaml', 'yml', 'toml', 'r', 'm', 'scala', 'kt', 'swift', 'rs', 'jsonl', 'env', 'config', 'jsonc'], 'Code', 'fas fa-code', '#2ecc71');

    // Archives
    e(['zip', 'rar', '7z', 'tar', 'gz', 'gzip', 'bz2', 'tgz', 'iso', 'img', 'cab', 'arj', 'lzh', 'pkg'], 'Archive', 'fas fa-file-archive', '#95a5a6');

    // Binaries
    e(['exe', 'msi', 'bat', 'cmd', 'ps1', 'vbs', 'dll', 'sys', 'drv', 'ocx', 'reg', 'inf', 'scr', 'com', 'cpl'], 'Binaries', 'fas fa-cogs', '#7f8c8d');

    // Web
    e(['map', 'sitemap', 'url', 'lnk', 'cache', 'cookie'], 'Web', 'fas fa-globe', '#3498db');

    // Security / Certs
    e(['cer', 'crt', 'pem', 'pfx', 'p12', 'key', 'csr', 'enc', 'sig', 'asc'], 'Cert/Key', 'fas fa-shield-alt', '#c0392b');

    // Project / Config
    e(['project', 'workspace', 'sln', 'solution', 'config', 'settings', 'prefs', 'manifest', 'lock', 'jsonc'], 'Config', 'fas fa-folder-tree', '#34495e');

    // Backups / Logs / Misc
    e(['tmp', 'bak', 'old', 'log', 'err', 'torrent', 'dmp', 'cache', 'backup', 'copy'], 'Misc Files', 'fas fa-file', '#95a5a6');

    // Specialized enterprise
    e(['pst', 'ost', 'ics', 'vcf', 'contact', 'form', 'template', 'report', 'policy', 'license', 'audit', 'script', 'blueprint', 'model', 'sim'], 'Specialized', 'fas fa-file-alt', '#9b59b6');

    // Default PDF mapping (also included above) ensure 'pdf' explicit
    map['pdf'] = { type: 'Document', icon: 'fas fa-file-pdf', color: '#e74c3c' };

    return map;
})();

// ── File Viewer ───────────────────────────────────────────────────────────────
// Extensions that can be previewed inline in the browser.
const VIEWABLE_EXTENSIONS = {
    image: new Set(['jpg', 'jpeg', 'jfif', 'png', 'gif', 'webp', 'svg', 'avif', 'tif', 'tiff', 'bmp', 'dib', 'psd', 'psb', 'heic', 'heif', 'raw', 'cr2', 'cr3', 'nef', 'nrw', 'arw', 'srf', 'sr2', 'dng', 'orf', 'rw2', 'raf', '3fr', 'mef', 'mos', 'erf', 'kdc', 'dcr', 'mrw', 'x3f', 'exr', 'hdr', 'rgbe', 'tga', 'pcx', 'icb', 'vda', 'vst', 'wmf', 'emf', 'jxl', 'jp2', 'jpx', 'j2k', 'jpf', 'ico']),
    // All video formats supported by ffmpeg HLS transcoding
    video: new Set([
        'mp4', 'webm', 'ogv', 'mov', 'm4v',
        'mkv', 'avi', 'wmv', 'flv', 'mpg', 'mpeg',
        'm2ts', 'mts', 'ts', '3gp',
    ]),
    audio: new Set(['mp3', 'wav', 'ogg', 'oga', 'aac', 'flac', 'm4a', 'opus']),
    pdf: new Set(['pdf']), // PDFs + Office docs (viewed via embedded Google Docs Viewer)
    text: new Set([
        'txt', 'md', 'json', 'jsonc', 'jsonl', 'xml', 'tsv', 'log', 'ini', 'cfg',
        'yaml', 'yml', 'toml', 'env', 'sh', 'bash', 'bat', 'cmd', 'ps1', 'reg', 'md', 'ahk',
        'py', 'js', 'jsx', 'ts', 'tsx', 'html', 'htm', 'css', 'java', 'c', 'cpp', 'h', 'hpp',
        'cs', 'go', 'rb', 'pl', 'lua', 'rs', 'kt', 'swift', 'php', 'sql', 'r', 'scala', 'crt', 'key',
        'vb', 'asm', 's', 'makefile', 'dockerfile', 'gitignore', 'editorconfig', 'htaccess'
    ]),
    office: new Set(['docx', 'doc', 'xlsx', 'xls', 'csv', 'pptx', 'ppt']),
    archive: new Set(['zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz', 'tgz', 'tbz2', 'txz']),
};

/**
 * Returns the viewer category for a filename, or null if not viewable.
 * @param {string} filename
 * @returns {'image'|'video'|'audio'|'pdf'|'text'|null}
 */
function getViewerType(filename) {
    if (!filename) return null;
    const ext = String(filename).split('.').pop().toLowerCase();
    for (const [category, exts] of Object.entries(VIEWABLE_EXTENSIONS)) {
        if (exts.has(ext)) return category;
    }
    return null;
}

/**
 * Resolves once the merged pdf.js viewer (viewer.mjs, loaded as a <script
 * type="module"> in <head>) has finished initializing and is ready to accept
 * `.open({ url })` calls. Module scripts execute asynchronously, so on a
 * cold page load PDFViewerApplication may not be attached to `window` yet by
 * the time a user clicks a PDF — this polls briefly until it is, then defers
 * to pdf.js's own `initializedPromise`.
 */
/**
 * Snapshot of document.title taken right before the merged pdf.js viewer
 * takes over. pdf.js unconditionally overwrites document.title when a PDF
 * opens (expected pdf.js behavior) — but this app also has a live
 * connection-status indicator that continuously rewrites document.title by
 * stripping/re-adding an emoji prefix (see the SSE/polling code further
 * down). If we don't explicitly restore the pre-PDF title on close, that
 * indicator would start prepending emojis onto the PDF's filename instead
 * of the app's real title, permanently, until a full page reload.
 */
let _pdfViewerPrevTitle = null;

function _pdfjsReady() {
    return new Promise((resolve, reject) => {
        const start = Date.now();
        (function poll() {
            const app = window.PDFViewerApplication;
            if (app && app.initializedPromise) {
                app.initializedPromise.then(resolve, reject);
            } else if (Date.now() - start > 15000) {
                reject(new Error('PDF viewer failed to initialize'));
            } else {
                setTimeout(poll, 50);
            }
        })();
    });
}

/** Open the file viewer modal for a given server-relative path. */
function openFileViewer(itemPath, filename) {
    const viewType = getViewerType(filename);
    if (!viewType) return;

    const modal = document.getElementById('fileViewerModal');
    const body = document.getElementById('fileViewerBody');
    const titleEl = document.getElementById('viewerFileName');
    const dlLink = document.getElementById('viewerDownloadLink');

    const viewUrl = `/view/${encodePathForUrl(itemPath)}`;
    const dlUrl = `/download/${encodePathForUrl(itemPath)}`;

    titleEl.textContent = filename;
    dlLink.href = dlUrl;

    // Clear previous content
    body.innerHTML = '';
    body.className = 'modal-body file-viewer-body';
    body.style.display = '';
    // The merged pdf.js viewer overlay is a sibling of `body`, not a child of
    // it, so it survives body.innerHTML resets above. Default it hidden here;
    // the 'pdf' case below is the only one that re-shows it.
    const _pdfRootDefault = document.getElementById('pdfjsViewerRoot');
    if (_pdfRootDefault) _pdfRootDefault.style.display = 'none';

    let inner = '';
    switch (viewType) {
        case 'image':
            body.classList.add('viewer-image');
            // Non-native or large images are converted on the backend.
            // Show a spinner immediately and swap to the real image once
            // the backend signals ready via /image_preview_status/.
            // Native small images resolve instantly (backend serves them
            // directly) so the spinner is barely visible in those cases.
            body.innerHTML = `
                <div class="img-conv-wrap" id="img-conv-wrap" style="display:flex;flex-direction:column;width:100%;height:100%;min-height:420px;background:#111;border-radius:inherit;">
                    <div class="img-zoom-toolbar" id="img-zoom-toolbar" style="display:none;align-items:center;gap:5px;padding:5px 10px;background:rgba(0,0,0,0.65);border-bottom:1px solid rgba(255,255,255,0.1);flex-shrink:0;user-select:none;">
                        <button id="img-zoom-out" title="Zoom Out" style="background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);color:#fff;border-radius:4px;width:28px;height:28px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:13px;"><i class="fas fa-search-minus"></i></button>
                        <span id="img-zoom-level" style="color:rgba(255,255,255,0.75);font-size:12px;min-width:42px;text-align:center;font-variant-numeric:tabular-nums;">100%</span>
                        <button id="img-zoom-in" title="Zoom In" style="background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);color:#fff;border-radius:4px;width:28px;height:28px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:13px;"><i class="fas fa-search-plus"></i></button>
                        <button id="img-zoom-reset" title="Reset to 100%" style="background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);color:#fff;border-radius:4px;padding:0 9px;height:28px;cursor:pointer;font-size:11px;white-space:nowrap;"><i class="fas fa-undo-alt" style="margin-right:4px;"></i>Reset</button>
                        <button id="img-zoom-fit" title="Fit to Window" style="background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);color:#fff;border-radius:4px;padding:0 9px;height:28px;cursor:pointer;font-size:11px;white-space:nowrap;"><i class="fas fa-compress-alt" style="margin-right:4px;"></i>Fit</button>
                        <span style="flex:1;"></span>
                        <span style="color:rgba(255,255,255,0.3);font-size:11px;display:none;" class="img-zoom-hint">Scroll · Drag · Dblclick reset</span>
                        <button id="img-fullscreen" title="Fullscreen" style="background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);color:#fff;border-radius:4px;width:28px;height:28px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:13px;margin-left:4px;"><i class="fas fa-expand"></i></button>
                    </div>
                    <div id="img-zoom-viewport" style="flex:1;overflow:hidden;display:flex;align-items:center;justify-content:center;position:relative;min-height:0;touch-action:none;width:100%;">
                        <div class="img-conv-spinner" id="img-conv-spinner">
                            <div class="img-conv-ring"></div>
                            <div class="img-conv-label" id="img-conv-label">Loading image…</div>
                        </div>
                        <img id="img-conv-result" class="viewer-img"
                             alt="${escapeHtml(filename)}"
                             style="display:none;max-width:100%;max-height:100%;object-fit:contain;transform-origin:center center;"
                             data-fn-error="_handleImgConvError">
                    </div>
                </div>`;
            _imgStartPreview(itemPath, filename);
            break;
        case 'video': {
            body.classList.add('viewer-video');
            const hlsWrapperId = 'hls-wrap-' + Date.now();
            body.innerHTML = `
              <div class="hls-player-outer" id="${hlsWrapperId}" style="display:flex;flex-direction:column;width:100%;height:100%;min-height:420px;">
                <div class="hls-btn-row" id="hls-btn-row">
                  <button class="hls-btn hls-btn-raw" id="hls-btn-raw" title="Play without transcoding">
                    <i class="fas fa-play"></i> Play Raw
                  </button>
                  <button class="hls-btn hls-btn-stream" id="hls-btn-stream" disabled title="Adaptive bitrate stream">
                    <span class="hls-spinner" id="hls-btn-spinner"></span>
                    <span id="hls-btn-label">Preparing stream…</span>
                  </button>
                </div>
                <div class="hls-quality-row" id="hls-quality-row" style="display:none;"></div>
                <div class="hls-progress-wrap" id="hls-progress-wrap" style="display:none">
                  <div class="hls-progress-bar" id="hls-progress-bar" style="width:0%"></div>
                </div>
                <div class="hls-status-msg" id="hls-status-msg"></div>
                <div class="hls-player-area" id="hls-player-area" style="flex:1 1 auto;width:100%;min-height:300px;position:relative;"></div>
              </div>`;
            _hlsStartStream(itemPath, hlsWrapperId);
            break;
        }
        case 'audio':
            body.classList.add('viewer-audio');
            inner = `<div class="viewer-audio-wrap">
                        <i class="fas fa-music viewer-audio-icon"></i>
                        <div class="viewer-audio-name">${escapeHtml(filename)}</div>
                        <audio controls autoplay class="viewer-audio-el">
                            <source src="${viewUrl}">
                            Your browser does not support HTML5 audio.
                        </audio>
                     </div>`;
            break;
        case 'pdf': {
            body.classList.add('viewer-pdf');
            // Use the official pdf.js viewer, merged directly into this page
            // (see #pdfjsViewerRoot in index.html) instead of an iframe —
            // gives the full toolbar, thumbnails, search, print, etc. without
            // ever framing a URL, so CSP's frame-src directive never applies.
            const pdfRoot = document.getElementById('pdfjsViewerRoot');
            body.style.display = 'none';
            pdfRoot.style.display = 'block';
            _pdfViewerPrevTitle = document.title;
            _pdfjsReady()
                .then(() => {
                    const app = window.PDFViewerApplication;
                    // The old iframe-based viewer never touched this page's
                    // tab title at all — iframes have an isolated
                    // document.title, so whatever viewer.html set internally
                    // stayed inside the iframe. Now that pdf.js is merged
                    // into this same document, its setTitle() calls
                    // (triggered on open, and again once the PDF's embedded
                    // metadata loads) directly mutate the real page title.
                    // Disable that entirely to restore the old behavior:
                    // the tab title never changes while viewing a PDF.
                    app.setTitle = () => { };
                    return app.open({ url: viewUrl });
                })
                .catch(err => {
                    console.error('PDF viewer failed to load:', err);
                    pdfRoot.style.display = 'none';
                    body.style.display = '';
                    if (_pdfViewerPrevTitle !== null) {
                        document.title = _pdfViewerPrevTitle;
                        _pdfViewerPrevTitle = null;
                    }
                    body.innerHTML = `<div class="viewer-text-loading"><i class="fas fa-exclamation-triangle"></i> Could not load PDF viewer: ${escapeHtml(err && err.message ? err.message : String(err))}</div>`;
                });
            inner = '';
            break;
        }
        case 'text':
            body.classList.add('viewer-text');
            inner = `<div class="viewer-text-loading"><i class="fas fa-circle-notch fa-spin"></i> Loading…</div>`;
            // Fetch text asynchronously after rendering the modal
            fetch(viewUrl)
                .then(r => {
                    if (!r.ok) throw new Error(`HTTP ${r.status}`);
                    return r.text();
                })
                .then(txt => {
                    body.innerHTML = `<pre class="viewer-pre"><code>${escapeHtml(txt)}</code></pre>`;
                })
                .catch(err => {
                    body.innerHTML = `<p class="viewer-error"><i class="fas fa-exclamation-triangle"></i> Could not load file: ${escapeHtml(err.message)}</p>`;
                });
            break;
        case 'office':
            body.classList.add('viewer-office');
            inner = `<div class="viewer-office-loading"><i class="fas fa-circle-notch fa-spin"></i> Generating preview…</div>`;
            fetch(`/office_preview/${encodePathForUrl(itemPath)}`)
                .then(r => r.json())
                .then(data => {
                    if (data.error) {
                        body.innerHTML = `<p class="viewer-error"><i class="fas fa-exclamation-triangle"></i> ${escapeHtml(data.error)}</p>`;
                        return;
                    }
                    _renderOfficePreview(body, data);
                })
                .catch(err => {
                    body.innerHTML = `<p class="viewer-error"><i class="fas fa-exclamation-triangle"></i> Could not load preview: ${escapeHtml(err.message)}</p>`;
                });
            break;
        case 'archive':
            body.classList.add('viewer-archive');
            inner = `<div class="viewer-archive-loading"><i class="fas fa-circle-notch fa-spin"></i> Reading archive…</div>`;
            _loadArchivePreview(body, itemPath, null);
            break;
    }

    // video, pdf, and image cases set body.innerHTML themselves — skip the overwrite
    if (viewType !== 'video' && viewType !== 'pdf' && viewType !== 'image') body.innerHTML = inner;
    modal.classList.add('show');
}

/**
 * Image preview loader — mirrors the HLS spinner pattern.
 *
 * Flow:
 *  1. Fetch /image_info/<path> to find out if backend processing is needed.
 *  2a. If not needed (small native image) → set img.src directly, hide spinner.
 *  2b. If needed and already cached → set img.src to /image_preview/, hide spinner.
 *  2c. If needed and not yet cached  → show "Converting…" spinner, fire
 *      /image_preview/ request (triggers backend conversion), then poll
 *      /image_preview_status/<key> every 1 s until ready, then reveal image.
 */
async function _imgStartPreview(itemPath, filename) {
    const _NATIVE_IMG = new Set(['jpg', 'jpeg', 'jfif', 'png', 'gif', 'webp', 'svg', 'avif', 'ico']);
    const ext = filename.split('.').pop().toLowerCase();
    const isNative = _NATIVE_IMG.has(ext);
    const previewUrl = `/image_preview/${encodePathForUrl(itemPath)}`;
    const viewUrl = `/view/${encodePathForUrl(itemPath)}`;

    const wrap = document.getElementById('img-conv-wrap');
    const spinner = document.getElementById('img-conv-spinner');
    const label = document.getElementById('img-conv-label');
    const img = document.getElementById('img-conv-result');

    // Guard: modal may have been closed before async resumes
    function _alive() { return document.getElementById('img-conv-wrap') === wrap; }

    function _showImage(url) {
        if (!_alive()) return;
        img.onload = () => {
            spinner.style.display = "none";
            img.style.display = "block";
            img.style.setProperty("opacity", "1", "important");
            _initImageZoom(img, wrap);
        };
        img.src = url;
    }

    function _setLabel(text) {
        if (label && _alive()) label.textContent = text;
    }

    // ── Native formats that must never be re-encoded (animated gif, svg, ico, avif,
    //    jfif): load directly, no backend processing ───────────────────────────────
    const _COMPRESSIBLE_NATIVE = new Set(['jpg', 'jpeg', 'png', 'webp']);
    if (isNative && !_COMPRESSIBLE_NATIVE.has(ext)) {
        _setLabel('Loading image…');
        _showImage(viewUrl);
        return;
    }

    // ── Non-native, or a jpg/png/webp that may be large: ask backend for info first.
    //    Small native files come back needs_processing=false and load raw below; files
    //    above IMG_COMPRESS_MIN_SIZE are compressed to WebP by /image_preview. ───────
    let info;
    try {
        _setLabel(isNative ? 'Loading image…' : 'Checking image…');
        const r = await fetch(`/image_info/${encodePathForUrl(itemPath)}`);
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        info = await r.json();
    } catch (e) {
        _showImage(isNative ? viewUrl : previewUrl);
        return;
    }

    if (!_alive()) return;

    // Small native image: the original is fine, load it directly
    if (isNative && !info.needs_processing) {
        _setLabel('Loading image…');
        _showImage(viewUrl);
        return;
    }

    // Already cached or no processing needed → serve immediately
    if (!info.needs_processing || info.cached) {
        _setLabel(info.needs_processing ? 'Loading converted image…' : 'Loading image…');
        _showImage(previewUrl);
        return;
    }

    // ── Needs conversion — show spinner and poll ───────────────────────────
    if (!info.pyvips_available) {
        if (!info.libvips_enabled && info.is_non_native) {
            // libvips is intentionally disabled — show same "requires processing"
            // placeholder as HLS uses for non-native video with ffmpeg disabled.
            if (spinner && _alive()) {
                spinner.style.display = 'none';
            }
            const wrap2 = document.getElementById('img-conv-wrap');
            if (wrap2 && _alive()) {
                wrap2.innerHTML = `
                  <div style="text-align:center;color:rgba(255,255,255,0.6);padding:40px 32px;">
                    <div style="font-size:36px;margin-bottom:14px;">🖼️</div>
                    <div style="font-size:14px;font-weight:600;margin-bottom:8px;color:rgba(255,255,255,0.85);">Image Requires Processing</div>
                    <div style="font-size:12px;opacity:0.65;line-height:1.6;">
                      This format (${info.ext ? info.ext.toUpperCase() : 'image'}) cannot be displayed without libvips conversion.<br>
                      libvips is currently disabled in server settings.<br>
                      Download the file to view it in a local image viewer.
                    </div>
                  </div>`;
            }
        } else {
            _setLabel('⚠️ pyvips not installed — trying raw…');
            _showImage(viewUrl);
        }
        return;
    }

    _setLabel('Converting image…');

    // Kick off backend conversion by touching /image_preview/ once.
    // Don't await — we discover completion via polling below.
    fetch(previewUrl).catch(() => { });

    // Poll /image_preview_status/<cache_key> every 1 s
    const cacheKey = info.cache_key;
    let elapsed = 0;
    const poll = setInterval(async () => {
        if (!_alive()) { clearInterval(poll); return; }

        elapsed += 1;
        const mins = Math.floor(elapsed / 60);
        const secs = elapsed % 60;
        const timeStr = mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
        _setLabel(`Converting image… ${timeStr}`);

        let st;
        try {
            const r = await fetch(`/image_preview_status/${cacheKey}`);
            st = await r.json();
        } catch { return; }

        if (!_alive()) { clearInterval(poll); return; }

        if (st.status === 'ready') {
            clearInterval(poll);
            const fmt = st.out_fmt === 'jpeg' ? 'JPEG' : st.out_fmt === 'png' ? 'PNG' : 'WebP';
            const sizeMB = st.cached_size ? (st.cached_size / 1048576).toFixed(1) + ' MB' : '';
            const extra = st.oversized ? ` (oversized → ${fmt})` : ` (${fmt})`;
            _setLabel(`Done${extra}${sizeMB ? ' · ' + sizeMB : ''}`);
            _showImage(previewUrl);
        } else if (st.status === 'error') {
            clearInterval(poll);
            _setLabel('');
            if (spinner && _alive()) {
                spinner.innerHTML = `<p class="viewer-error">Conversion failed: ${escapeHtml(st.message || 'unknown error')}</p>`;
            }
        }
    }, 1000);
}

/**
 * Initialise zoom, pan, and fullscreen for the image preview.
 * Called once the <img> has fully loaded.
 */
function _initImageZoom(img, wrap) {
    if (window._imgZoomAbortCtrl) {
        try { window._imgZoomAbortCtrl.abort(); } catch (_) { }
    }
    window._imgZoomAbortCtrl = new AbortController();

    // Remove any scroller left over from a previous preview (e.g. re-opening
    // the viewer or a failed fix attempt that left the DOM in a dirty state).
    const _staleScroller = document.getElementById('_imgz_scroller');
    if (_staleScroller) _staleScroller.remove();
    const sig = { signal: window._imgZoomAbortCtrl.signal };

    const viewport = document.getElementById('img-zoom-viewport');
    const toolbar = document.getElementById('img-zoom-toolbar');
    const zoomInBtn = document.getElementById('img-zoom-in');
    const zoomOutBtn = document.getElementById('img-zoom-out');
    const resetBtn = document.getElementById('img-zoom-reset');
    const fitBtn = document.getElementById('img-zoom-fit');
    const fsBtn = document.getElementById('img-fullscreen');
    const zoomLabel = document.getElementById('img-zoom-level');
    const hint = toolbar ? toolbar.querySelector('.img-zoom-hint') : null;

    if (!viewport || !toolbar) return;
    toolbar.style.display = 'flex';
    if (hint) hint.style.display = viewport.clientWidth >= 600 ? 'inline' : 'none';

    // ── Structure ────────────────────────────────────────────────────────────
    // viewport  (overflow:hidden, position:relative)
    //   └─ scroller (position:absolute;inset:0;overflow:scroll)  ← clientW/H = vw/vh
    //        └─ canvas  (explicit cw×ch, position:relative)      ← scrollW/H = cw/ch
    //             └─ img (position:absolute; left:padL; top:padT; w:iw; h:ih)
    //
    // Zoom  = change img + canvas dimensions
    // Pan   = native scrollLeft/scrollTop on scroller
    // Focal = save image-space fraction under cursor before resize, restore after
    //
    // WHY canvas wrapper:
    //   With position:absolute;inset:0, the scroller fills the viewport (clientW=vw).
    //   For the scroller to scroll, its CONTENT must be wider than vw.
    //   Using an explicit-width canvas child guarantees scrollWidth = cw regardless
    //   of browser trailing-margin behaviour.  Symmetrical margins on img would NOT
    //   work reliably because right/bottom margins are excluded from scrollWidth by
    //   most browsers.
    //
    // WHY no visibility:hidden:
    //   The CSS already handles the fade-in via
    //       #img-conv-result { opacity:0; transition:opacity 0.3s }
    //       #img-conv-result[style*="display:block"] { opacity:1 }
    //   Using visibility:hidden here means the image stays invisible if applyZoom()
    //   ever throws before reaching img.style.visibility='visible'.  Instead we
    //   start the img at 0×0 (no unsized flash) and let CSS opacity handle reveal.

    // Webkit scrollbar hiding for #_imgz_scroller now lives in the main
    // stylesheet (static/css/index.css) instead of being injected here —
    // this element goes into document.head (not a shadow root), so a
    // plain CSS rule works with zero runtime cost and no CSP hash to
    // maintain. Previously this was a `document.createElement('style')`
    // + textContent injection, which style-src-elem 'self' silently
    // blocks without a matching sha256 hash.

    // Build scroller + canvas
    const scroller = document.createElement('div');
    scroller.id = '_imgz_scroller';
    scroller.style.cssText = 'position:absolute;inset:0;overflow:scroll;scrollbar-width:none;-ms-overflow-style:none;';

    const canvas = document.createElement('div');
    canvas.id = '_imgz_canvas';
    canvas.style.cssText = 'position:relative;';   // width/height set in applyZoom

    viewport.style.position = 'relative';
    viewport.style.overflow = 'hidden';
    scroller.appendChild(canvas);
    canvas.appendChild(img);          // img lives inside canvas
    viewport.appendChild(scroller);   // scroller (with canvas+img) added to viewport

    // Set structural styles — no opacity:0 or width:0/height:0 to avoid an
    // invisible intermediate state.  applyZoom() is called immediately below to
    // size the image before the first paint; the rAF/ResizeObserver below correct
    // any layout dimensions that weren't available yet at this point.
    img.style.cssText = 'display:block;max-width:none;max-height:none;border-radius:4px;position:absolute;';
    // Re-assert opacity:1 !important — cssText reset cleared the value set in
    // _showImage, and the stylesheet may have opacity:0 [!important] on this id.
    img.style.setProperty('opacity', '1', 'important');

    const NW = img.naturalWidth || 1;
    const NH = img.naturalHeight || 1;

    let scale = 1;
    const MIN_SCALE = 0.1;
    const MAX_SCALE = Math.max(8, NW / 100);
    const ZOOM_STEP = 1.25;

    function vp() {
        const w = viewport.clientWidth || wrap.clientWidth || window.innerWidth || 1;
        const h = viewport.clientHeight || wrap.clientHeight || Math.round(window.innerHeight * 0.65) || 1;
        return { vw: w, vh: h };
    }

    // Size of the image at scale=1 (fit to viewport, never upscale)
    function fitPx() {
        const { vw, vh } = vp();
        const s = Math.min(vw / NW, vh / NH, 1);
        return { fw: Math.round(NW * s), fh: Math.round(NH * s) };
    }

    // Resize image + canvas + restore scroll position around focal point.
    // focalVx/Vy = viewport pixel coords that should stay fixed (default: center)
    function applyZoom(focalVx, focalVy) {
        const { vw, vh } = vp();
        const { fw, fh } = fitPx();
        const iw = Math.round(fw * scale);
        const ih = Math.round(fh * scale);

        // Canvas = content area seen by the scroller.  Always >= viewport so the
        // scroller has something to "sit on" even when the image is smaller.
        const cw = Math.max(vw, iw);
        const ch = Math.max(vh, ih);

        // Centering offsets (0 when image overflows the viewport)
        const padL = Math.max(0, Math.round((cw - iw) / 2));
        const padT = Math.max(0, Math.round((ch - ih) / 2));

        // Focal point in viewport coords (default = center)
        const fx = focalVx !== undefined ? focalVx : vw / 2;
        const fy = focalVy !== undefined ? focalVy : vh / 2;

        // ── Save image-space fraction under focal point (BEFORE resize) ──────
        // Canvas dimensions before this call (fall back to cw/ch on first render)
        const oldCw = canvas.offsetWidth || cw;
        const oldCh = canvas.offsetHeight || ch;
        const oldIw = img.offsetWidth || iw;
        const oldIh = img.offsetHeight || ih;
        const oldPadL = Math.max(0, Math.round((oldCw - oldIw) / 2));
        const oldPadT = Math.max(0, Math.round((oldCh - oldIh) / 2));
        const imgPxX = scroller.scrollLeft + fx - oldPadL;
        const imgPxY = scroller.scrollTop + fy - oldPadT;
        const fracX = oldIw > 0 ? imgPxX / oldIw : 0.5;
        const fracY = oldIh > 0 ? imgPxY / oldIh : 0.5;

        // ── Resize canvas (sets scrollWidth/Height for the scroller) ─────────
        canvas.style.width = cw + 'px';
        canvas.style.height = ch + 'px';

        // ── Size and position image within canvas ─────────────────────────────
        img.style.width = iw + 'px';
        img.style.height = ih + 'px';
        img.style.left = padL + 'px';
        img.style.top = padT + 'px';

        // ── Restore focal scroll position ─────────────────────────────────────
        // maxScroll = canvas size − scroller viewport size
        const maxSL = Math.max(0, cw - vw);
        const maxST = Math.max(0, ch - vh);
        const targetSL = fracX * iw + padL - fx;
        const targetST = fracY * ih + padT - fy;
        scroller.scrollLeft = Math.max(0, Math.min(maxSL, targetSL));
        scroller.scrollTop = Math.max(0, Math.min(maxST, targetST));

        if (zoomLabel) zoomLabel.textContent = Math.round(scale * 100) + '%';
        const canPan = iw > vw || ih > vh;
        scroller.style.cursor = canPan ? 'grab' : 'default';
    }

    function zoomTo(newScale, viewportX, viewportY) {
        scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, newScale));
        applyZoom(viewportX, viewportY);
    }

    // ── Scroll wheel zoom ────────────────────────────────────────────────────
    scroller.addEventListener('wheel', e => {
        e.preventDefault();
        const r = scroller.getBoundingClientRect();
        zoomTo(scale * (e.deltaY < 0 ? ZOOM_STEP : 1 / ZOOM_STEP),
            e.clientX - r.left, e.clientY - r.top);
    }, { passive: false, ...sig });

    // ── Mouse drag to pan ────────────────────────────────────────────────────
    let dragging = false, dragSX = 0, dragSY = 0, dragSL = 0, dragST = 0;

    scroller.addEventListener('mousedown', e => {
        if (e.button !== 0) return;
        const { vw, vh } = vp();
        const { fw, fh } = fitPx();
        if (fw * scale <= vw && fh * scale <= vh) return; // nothing to pan
        dragging = true;
        dragSX = e.clientX; dragSY = e.clientY;
        dragSL = scroller.scrollLeft; dragST = scroller.scrollTop;
        scroller.style.cursor = 'grabbing';
        e.preventDefault();
    }, sig);

    window.addEventListener('mousemove', e => {
        if (!dragging) return;
        scroller.scrollLeft = dragSL - (e.clientX - dragSX);
        scroller.scrollTop = dragST - (e.clientY - dragSY);
    }, sig);

    window.addEventListener('mouseup', () => {
        if (!dragging) return;
        dragging = false;
        const { vw, vh } = vp();
        const { fw, fh } = fitPx();
        scroller.style.cursor = (fw * scale > vw || fh * scale > vh) ? 'grab' : 'default';
    }, sig);

    // ── Double-click to reset ────────────────────────────────────────────────
    scroller.addEventListener('dblclick', () => {
        scale = 1; applyZoom();
    }, sig);

    // ── Touch: one-finger pan + two-finger pinch ─────────────────────────────
    let lastPinchDist = null;
    let t1x = 0, t1y = 0, t1sl = 0, t1st = 0;

    scroller.addEventListener('touchstart', e => {
        if (e.touches.length === 2) {
            lastPinchDist = Math.hypot(
                e.touches[0].clientX - e.touches[1].clientX,
                e.touches[0].clientY - e.touches[1].clientY);
        } else if (e.touches.length === 1) {
            t1x = e.touches[0].clientX; t1y = e.touches[0].clientY;
            t1sl = scroller.scrollLeft; t1st = scroller.scrollTop;
        }
    }, { passive: true, ...sig });

    scroller.addEventListener('touchmove', e => {
        if (e.touches.length === 2 && lastPinchDist) {
            const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX,
                e.touches[0].clientY - e.touches[1].clientY);
            const r = scroller.getBoundingClientRect();
            const cx = (e.touches[0].clientX + e.touches[1].clientX) / 2 - r.left;
            const cy = (e.touches[0].clientY + e.touches[1].clientY) / 2 - r.top;
            zoomTo(scale * d / lastPinchDist, cx, cy);
            lastPinchDist = d;
            e.preventDefault();
        } else if (e.touches.length === 1) {
            scroller.scrollLeft = t1sl - (e.touches[0].clientX - t1x);
            scroller.scrollTop = t1st - (e.touches[0].clientY - t1y);
            e.preventDefault();
        }
    }, { passive: false, ...sig });

    scroller.addEventListener('touchend', () => { lastPinchDist = null; }, { passive: true, ...sig });

    // ── Toolbar buttons ──────────────────────────────────────────────────────
    if (zoomInBtn) zoomInBtn.addEventListener('click', () => zoomTo(scale * ZOOM_STEP), sig);
    if (zoomOutBtn) zoomOutBtn.addEventListener('click', () => zoomTo(scale / ZOOM_STEP), sig);
    if (resetBtn) resetBtn.addEventListener('click', () => { scale = 1; applyZoom(); }, sig);
    if (fitBtn) fitBtn.addEventListener('click', () => { scale = 1; applyZoom(); }, sig);

    // ── Fullscreen ───────────────────────────────────────────────────────────
    function updateFsIcon() {
        if (!fsBtn) return;
        fsBtn.innerHTML = document.fullscreenElement
            ? '<i class="fas fa-compress"></i>' : '<i class="fas fa-expand"></i>';
        fsBtn.title = document.fullscreenElement ? 'Exit Fullscreen' : 'Fullscreen';
        setTimeout(applyZoom, 150);
    }
    if (fsBtn) {
        fsBtn.addEventListener('click', () => {
            const el = document.getElementById('img-conv-wrap') || wrap;
            if (!el) return;
            if (!document.fullscreenElement) {
                (el.requestFullscreen || el.webkitRequestFullscreen || function () { }).call(el);
            } else {
                (document.exitFullscreen || document.webkitExitFullscreen || function () { }).call(document);
            }
        }, sig);
    }
    document.addEventListener('fullscreenchange', updateFsIcon, sig);
    document.addEventListener('webkitfullscreenchange', updateFsIcon, sig);

    // ── Initial synchronous size — image is already visible (opacity:1 !important
    // set above), so just size it correctly before the first paint.  rAF below
    // re-runs applyZoom if the viewport had stale/zero dimensions at this point.
    applyZoom();

    // If the viewport was still zero-sized at that point (e.g. modal CSS not yet
    // applied), a ResizeObserver fires a corrective applyZoom once it gets size.
    let _hasRealSize = false;
    requestAnimationFrame(() => {
        const { vw, vh } = vp();
        if (vw > 1 && vh > 1) {
            _hasRealSize = true;
            applyZoom();
        }
        // Keep opacity forced on (cssText assignment may have cleared it)
        img.style.setProperty('opacity', '1', 'important');
    });

    // Fallback: if the modal is still laying out when the rAF fires, a
    // ResizeObserver re-runs applyZoom the first time the viewport is non-zero.
    if (typeof ResizeObserver !== 'undefined') {
        const _ro = new ResizeObserver(() => {
            if (_hasRealSize) { _ro.disconnect(); return; }
            const { vw, vh } = vp();
            if (vw > 1 && vh > 1) {
                _hasRealSize = true;
                applyZoom();
                img.style.setProperty('opacity', '1', 'important');
                _ro.disconnect();
            }
        });
        _ro.observe(viewport);
        // Auto-disconnect on close (AbortController signal teardown)
        sig.signal.addEventListener('abort', () => _ro.disconnect());
    }
}

/** Close the file viewer and stop any media playback. */
function closeFileViewer() {
    const modal = document.getElementById('fileViewerModal');
    const body = document.getElementById('fileViewerBody');
    if (!modal) return;
    modal.classList.remove('show');

    // 0. If the merged pdf.js viewer overlay is active, unload its document
    //    and hide it. It's a sibling of `body`, not a child, so it survives
    //    body.innerHTML clears below and must be handled separately.
    const pdfRoot = document.getElementById('pdfjsViewerRoot');
    if (pdfRoot && pdfRoot.style.display !== 'none') {
        pdfRoot.style.display = 'none';
        body.style.display = '';
        try {
            if (window.PDFViewerApplication && typeof window.PDFViewerApplication.close === 'function') {
                window.PDFViewerApplication.close();
            }
        } catch (_) { /* best-effort cleanup */ }
        // pdf.js overwrote document.title when it opened this file; restore
        // whatever was there before (see _pdfViewerPrevTitle definition for why).
        if (_pdfViewerPrevTitle !== null) {
            document.title = _pdfViewerPrevTitle;
            _pdfViewerPrevTitle = null;
        }
    }

    // Clean up image zoom listeners and exit fullscreen if active
    if (window._imgZoomAbortCtrl) {
        try { window._imgZoomAbortCtrl.abort(); } catch (_) { }
        window._imgZoomAbortCtrl = null;
    }
    if (document.fullscreenElement) {
        try { document.exitFullscreen(); } catch (_) { }
    }

    window._hlsPollCancel = true;
    window._vjsCurrentPlayer = null;

    // 1. Stop every media element first — pause + blank src + load resets decoder
    body.querySelectorAll('video, audio').forEach(m => {
        try { m.pause(); } catch (_) { }
        try { m.removeAttribute('src'); } catch (_) { }
        try { while (m.firstChild) m.removeChild(m.firstChild); } catch (_) { }
        try { m.load(); } catch (_) { }
    });

    // 2. Call the Lit web component's own destroy() — this is what actually
    //    releases the internal MediaSource / HLS stream held by the component.
    //    The props dump showed: destroy, destroyCallback on the element prototype.
    body.querySelectorAll('video-player, video-skin').forEach(el => {
        try { if (typeof el.destroy === 'function') el.destroy(); } catch (_) { }
        try { if (typeof el.destroyCallback === 'function') el.destroyCallback(); } catch (_) { }
    });

    // 3. Physically remove video elements from DOM before clearing innerHTML —
    //    this forces the browser to release the MediaSource reference immediately
    body.querySelectorAll('video, audio').forEach(m => {
        try { m.parentNode && m.parentNode.removeChild(m); } catch (_) { }
    });

    // 4. Clear the body
    body.innerHTML = '';
}


function _renderOfficePreview(body, data) {
    body.innerHTML = '';

    // ── DOCX ──────────────────────────────────────────────────────────────────
    if (data.type === 'docx') {
        const wrap = document.createElement('div');
        wrap.className = 'office-docx-body';
        wrap.innerHTML = data.html || '<p style="color:#999">No content found.</p>';
        body.appendChild(wrap);

        // ── XLSX ──────────────────────────────────────────────────────────────────
    } else if (data.type === 'xlsx') {
        const sheets = data.sheets || [];
        if (!sheets.length) {
            body.innerHTML = '<p class="viewer-error">No sheets found.</p>';
            return;
        }

        // Build tab strip
        const tabStrip = document.createElement('div');
        tabStrip.className = 'office-tabs';
        sheets.forEach((s, i) => {
            const btn = document.createElement('button');
            btn.className = 'office-tab' + (i === 0 ? ' active' : '');
            btn.textContent = s.name;
            btn.dataset.idx = i;
            tabStrip.appendChild(btn);
        });

        // Build sheet panels
        const sheetsWrap = document.createElement('div');
        sheetsWrap.className = 'office-sheets';

        sheets.forEach((s, i) => {
            const panel = document.createElement('div');
            panel.className = 'office-sheet-panel' + (i === 0 ? ' active' : '');
            panel.dataset.idx = i;

            const tableWrap = document.createElement('div');
            tableWrap.className = 'office-table-wrap';

            const table = document.createElement('table');
            table.className = 'office-table';

            const rows = s.rows || [];
            if (rows.length) {
                const thead = document.createElement('thead');
                const headerTr = document.createElement('tr');
                (rows[0] || []).forEach(cell => {
                    const th = document.createElement('th');
                    th.innerHTML = cell;
                    headerTr.appendChild(th);
                });
                thead.appendChild(headerTr);
                table.appendChild(thead);

                const tbody = document.createElement('tbody');
                rows.slice(1).forEach(row => {
                    const tr = document.createElement('tr');
                    row.forEach(cell => {
                        const td = document.createElement('td');
                        td.innerHTML = cell;
                        tr.appendChild(td);
                    });
                    tbody.appendChild(tr);
                });
                table.appendChild(tbody);
            }

            tableWrap.appendChild(table);
            panel.appendChild(tableWrap);

            if (s.truncated) {
                const notice = document.createElement('div');
                notice.className = 'office-truncation-notice';
                notice.innerHTML = '<i class="fas fa-info-circle"></i> Preview limited to 500 rows. Download the file to view all data.';
                panel.appendChild(notice);
            }

            sheetsWrap.appendChild(panel);
        });

        // Wire up tab switching
        tabStrip.addEventListener('click', e => {
            const btn = e.target.closest('.office-tab');
            if (!btn) return;
            const idx = btn.dataset.idx;
            tabStrip.querySelectorAll('.office-tab').forEach(b => b.classList.remove('active'));
            sheetsWrap.querySelectorAll('.office-sheet-panel').forEach(p => p.classList.remove('active'));
            btn.classList.add('active');
            sheetsWrap.querySelector(`.office-sheet-panel[data-idx="${idx}"]`).classList.add('active');
        });

        const viewer = document.createElement('div');
        viewer.className = 'office-xlsx-viewer';
        viewer.appendChild(tabStrip);
        viewer.appendChild(sheetsWrap);
        body.appendChild(viewer);

        // ── PPTX ──────────────────────────────────────────────────────────────────
    } else if (data.type === 'pptx') {
        const slides = data.slides || [];
        if (!slides.length) {
            body.innerHTML = '<p class="viewer-error">No slides found.</p>';
            return;
        }

        let currentSlide = 0;

        function buildSlideHtml(idx) {
            const slide = slides[idx];
            const titleShape = slide.shapes.find(s => s.is_title);
            const bodyShapes = slide.shapes.filter(s => !s.is_title);

            let html = '';

            if (titleShape) {
                const titleText = titleShape.paragraphs.map(p => p.text).join(' ');
                html += `<h2 class="pptx-slide-title">${escapeHtml(titleText)}</h2>`;
            }

            if (bodyShapes.length) {
                html += '<div class="pptx-body">';
                bodyShapes.forEach(shape => {
                    shape.paragraphs.forEach(p => {
                        const indentClass = p.level > 0 ? ` pptx-indent-${Math.min(p.level, 8)}` : '';
                        const bullet = p.level === 0 ? '• ' : '◦ ';
                        html += `<p class="pptx-para${indentClass}">${bullet}${escapeHtml(p.text)}</p>`;
                    });
                });
                html += '</div>';
            }

            if (!html) {
                html = '<p class="pptx-empty"><i class="fas fa-image"></i><br>No text content on this slide</p>';
            }

            return html;
        }

        function updateSlide() {
            slidePanel.innerHTML = `<div class="pptx-slide">${buildSlideHtml(currentSlide)}</div>`;
            counter.textContent = `${currentSlide + 1} / ${slides.length}`;
            prevBtn.disabled = currentSlide === 0;
            nextBtn.disabled = currentSlide === slides.length - 1;
        }

        const viewer = document.createElement('div');
        viewer.className = 'office-pptx-viewer';

        const slidePanel = document.createElement('div');
        slidePanel.className = 'pptx-slide-panel';

        const controls = document.createElement('div');
        controls.className = 'pptx-controls';

        const prevBtn = document.createElement('button');
        prevBtn.className = 'btn btn-outline btn-sm pptx-prev';
        prevBtn.innerHTML = '<i class="fas fa-chevron-left"></i> Prev';

        const nextBtn = document.createElement('button');
        nextBtn.className = 'btn btn-outline btn-sm pptx-next';
        nextBtn.innerHTML = 'Next <i class="fas fa-chevron-right"></i>';

        const counter = document.createElement('span');
        counter.className = 'pptx-counter';

        prevBtn.addEventListener('click', () => { if (currentSlide > 0) { currentSlide--; updateSlide(); } });
        nextBtn.addEventListener('click', () => { if (currentSlide < slides.length - 1) { currentSlide++; updateSlide(); } });

        // Keyboard navigation (only when viewer is open)
        const _pptxKeyHandler = (e) => {
            const modal = document.getElementById('fileViewerModal');
            if (!modal || !modal.classList.contains('show')) return;
            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') nextBtn.click();
            if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') prevBtn.click();
        };
        document.addEventListener('keydown', _pptxKeyHandler);
        // Clean up key handler when modal closes
        const _origClose = window._pptxCloseCleanup;
        window._pptxCloseCleanup = () => {
            document.removeEventListener('keydown', _pptxKeyHandler);
            if (_origClose) _origClose();
        };

        controls.append(prevBtn, counter, nextBtn);
        viewer.append(slidePanel, controls);
        body.appendChild(viewer);
        updateSlide();

    } else {
        body.innerHTML = `<p class="viewer-error">Unknown preview type: ${escapeHtml(data.type)}</p>`;
    }
}

// Close viewer on outside-click
document.addEventListener('click', function (e) {
    const modal = document.getElementById('fileViewerModal');
    if (modal && e.target === modal) closeFileViewer();
});

// Close viewer on Escape key (registers alongside other modal listeners)
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
        const modal = document.getElementById('fileViewerModal');
        if (modal && modal.classList.contains('show')) closeFileViewer();
    }
    // Arrow keys: skip ±10s when video viewer is open
    const modal = document.getElementById('fileViewerModal');
    if (modal && modal.classList.contains('show')) {
        if (e.key === 'ArrowRight') { e.preventDefault(); _hlsSkip(10); }
        if (e.key === 'ArrowLeft') { e.preventDefault(); _hlsSkip(-10); }
    }
});

/** Skip the active HLS/raw video by +/- seconds */
function _hlsSkip(seconds) {
    // Try video-player web component first, then plain <video>
    const area = document.getElementById('hls-player-area');
    if (!area) return;
    let vid = area.querySelector('video');
    if (!vid) {
        const vp = area.querySelector('video-player');
        if (vp) vid = vp.querySelector('video') || vp.shadowRoot?.querySelector('video');
    }
    if (vid && isFinite(vid.duration)) {
        vid.currentTime = Math.max(0, Math.min(vid.duration, vid.currentTime + seconds));
    }
}
// ─────────────────────────────────────────────────────────────────────────────


function escapeHtml(unsafe) {
    return String(unsafe).replace(/[&<>"'`]/g, function (c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": "&#39;", "`": "&#96;" }[c];
    });
}

function getFileType(filename) {
    if (!filename) return 'Unknown';
    const name = String(filename);
    // directories are handled separately by callers
    const ext = name.includes('.') ? name.split('.').pop().toLowerCase() : '';
    if (!ext) return 'Unknown';
    return EXTENSION_MAP[ext]?.type || ext.toUpperCase() + ' File';
}

// Transform server-rendered rows (initial page load) to use detailed icons/type text
function transformInitialRows() {
    const tbody = document.querySelector('#filesTable tbody');
    if (!tbody) return;

    const rows = Array.from(tbody.querySelectorAll('tr.file-row'));
    rows.forEach(row => {
        try {
            const nameCell = row.querySelector('td:nth-child(2) .file-name');
            if (!nameCell) return;

            const link = nameCell.querySelector('a.folder-link');
            const isDir = !!link;
            let filename = '';
            if (isDir) {
                filename = link.textContent.trim();
                // ensure link onclick uses safe path
                const dataPath = row.dataset.path || '';
                link.setAttribute('onclick', `navigateToFolder('${escapeHtml(dataPath)}'); return false;`);
            } else {
                // for files, the filename text may follow the icon
                filename = nameCell.textContent.trim();
            }

            // Replace icon and text with mapped icon and escaped name
            const iconEl = nameCell.querySelector('i');
            const iconClass = isDir ? 'fas fa-folder' : getFileIcon(filename);
            if (iconEl) iconEl.className = iconClass + ' file-icon';

            // Replace displayed name safely
            if (isDir) {
                link.textContent = filename; // textContent is safe
            } else {
                // Remove existing text nodes after icon
                const clone = nameCell.cloneNode(true);
                const icons = clone.querySelectorAll('i'); icons.forEach(i => i.remove());
                const rawText = clone.textContent.trim();
                // Built with DOM nodes (no innerHTML) so text taken from the DOM can never be re-parsed as HTML.
                const nameIcon = document.createElement('i');
                nameIcon.className = `${iconClass} file-icon file-icon-default`;
                nameCell.textContent = '';
                nameCell.append(nameIcon, document.createTextNode(` ${rawText}`));
                const renamedIconEl = nameCell.querySelector('.file-icon-default');
                if (renamedIconEl) renamedIconEl.style.color = getFileColor(filename);
            }

            // Update type column
            const typeCell = row.querySelector('td:nth-child(4) .file-type') || row.querySelector('td:nth-child(4)');
            if (typeCell) {
                const typeText = isDir ? 'Folder' : getFileType(filename);
                const typeIcon = document.createElement('i');
                typeIcon.className = isDir ? 'fas fa-folder' : getFileIcon(filename);
                typeCell.textContent = '';
                typeCell.append(typeIcon, document.createTextNode(` ${typeText}`));
            }
        } catch (err) {
            console.warn('transformInitialRows skipped a row due to error', err);
        }
    });
}

// Notification stacking system
let notificationId = 0;
let notificationCount = 0; // Track active notifications
let notificationTimers = new Map(); // Track timers for consistent timing

// Toast text is always inserted as text. The only markup allowed is ONE leading
// Font Awesome icon (`<i class="fas fa-..."></i> text`), which is rebuilt from DOM
// nodes. File names, server messages and exception text can therefore never be
// parsed as HTML.
function _setStatusContent(el, message) {
    const text = String(message ?? '');
    const m = /^<i class="([A-Za-z0-9 _-]+)"><\/i>\s*([\s\S]*)$/.exec(text);
    el.textContent = '';
    if (m) {
        const icon = document.createElement('i');
        icon.className = m[1];
        el.append(icon, document.createTextNode(' ' + m[2]));
    } else {
        el.textContent = text;
    }
}

function showUploadStatus(message, type = 'info') {
    // While uploading, only errors pass through — everything else is silent.
    // This stops per-file toasts from burying the Stop button.
    if (isUploading && type !== 'error') return;

    // Hard cap: never stack more than 3 at once regardless of source.
    if (notificationCount >= 3) return;

    // Create unique notification element
    const notificationId_current = ++notificationId;
    const notification = document.createElement('div');
    notification.className = `upload-status show ${type}`;
    _setStatusContent(notification, message);
    notification.id = `notification-${notificationId_current}`;
    notification.dataset.type = type; // Store type for batch operations

    // Calculate position immediately based on header and notification count
    const headerElement = document.querySelector('.header');
    const headerHeight = headerElement ? headerElement.offsetHeight : 70;
    const notificationHeight = 60; // Estimated notification height
    const gap = 10;
    const startPosition = headerHeight + 20;
    const topPosition = startPosition + (notificationCount * (notificationHeight + gap));

    // Style for stacking - set position immediately
    notification.style.position = 'fixed';
    notification.style.right = '20px';
    notification.style.top = `${topPosition}px`;
    notification.style.zIndex = '10000';
    notification.style.minWidth = '300px';
    notification.style.maxWidth = '500px';
    notification.style.transform = 'translateX(100%)'; // Start off-screen
    notification.style.transition = 'transform 0.3s ease-out';

    // Increment count and add to page
    notificationCount++;
    document.body.appendChild(notification);

    // Trigger slide-in animation immediately
    requestAnimationFrame(() => {
        notification.style.transform = 'translateX(0)';
    });

    // Consistent timing for all notifications using centralized config
    if (type === 'info' || type === 'success') {
        // Use centralized timer configuration
        const hideDelay = type === 'success' ? NOTIFICATION_TIMERS.SUCCESS : NOTIFICATION_TIMERS.INFO;

        const timerId = setTimeout(() => {
            removeNotification(notificationId_current);
        }, hideDelay);

        // Store timer reference
        notificationTimers.set(notificationId_current, timerId);
    }

    // Add click to dismiss
    notification.addEventListener('click', () => {
        removeNotification(notificationId_current);
    });

    notification.style.cursor = 'pointer';
    notification.title = 'Click to dismiss';
}

// Function to clear all notifications of a specific type
function clearNotificationsByType(type) {
    const notifications = document.querySelectorAll(`[id^="notification-"][data-type="${type}"]`);
    notifications.forEach(notif => {
        const id = notif.id.replace('notification-', '');
        removeNotification(parseInt(id));
    });
}

function removeNotification(notificationId) {
    const notification = document.getElementById(`notification-${notificationId}`);
    if (notification) {
        // Clear any existing timer
        if (notificationTimers.has(notificationId)) {
            clearTimeout(notificationTimers.get(notificationId));
            notificationTimers.delete(notificationId);
        }

        // Slide out animation
        notification.style.transform = 'translateX(100%)';
        notification.style.opacity = '0';

        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
                notificationCount--; // Decrease count
                // Reposition remaining notifications immediately
                repositionNotifications();
            }
        }, 300);
    }
}

function repositionNotifications() {
    const existingNotifications = document.querySelectorAll('[id^="notification-"]');
    const headerElement = document.querySelector('.header');
    const headerHeight = headerElement ? headerElement.offsetHeight : 70;
    const notificationHeight = 60; // Estimated height
    const gap = 10;
    const startPosition = headerHeight + 20;

    // Reset count to match actual notifications
    notificationCount = existingNotifications.length;

    existingNotifications.forEach((notif, index) => {
        const topPosition = startPosition + (index * (notificationHeight + gap));
        notif.style.top = `${topPosition}px`;
        notif.style.transition = 'top 0.3s ease-out'; // Smooth repositioning
    });
}

// Function to clear all notifications
function clearNotificationQueue() {
    const existingNotifications = document.querySelectorAll('[id^="notification-"]');
    existingNotifications.forEach(notif => {
        if (notif.parentNode) {
            notif.parentNode.removeChild(notif);
        }
    });

    // Clear all timers
    notificationTimers.forEach(timerId => clearTimeout(timerId));
    notificationTimers.clear();

    notificationCount = 0; // Reset count
}

// Rolling 5-second speed window — accurate for small and large files.
const _speedSamples = [];
function _recordSpeedSample(bytes) {
    const now = Date.now();
    _speedSamples.push({ t: now, b: bytes });
    const cutoff = now - 5000;
    // FIX: must keep at least 2 samples, not 1. With only 1 sample left,
    // _rollingSpeed() can never compute a rate (needs an oldest+newest pair),
    // so it returns 0 forever. That happens any time two progress events are
    // more than 5s apart — e.g. a 10MB chunk taking >5s on a slower upload
    // link — which permanently blanks Speed/ETA even while bytes keep moving.
    // Keeping 2 lets the average gracefully widen instead of going blank.
    while (_speedSamples.length > 2 && _speedSamples[0].t < cutoff) _speedSamples.shift();
}
function _rollingSpeed() {
    if (_speedSamples.length < 2) return 0;
    const oldest = _speedSamples[0];
    const newest = _speedSamples[_speedSamples.length - 1];
    // Use "now" (not newest.t) as the window end. This makes speed/ETA decay
    // honestly in real time when the gap since the last chunk grows, instead
    // of freezing at whatever value was true as of the last progress event.
    const now = Date.now();
    const dt = (now - oldest.t) / 1000;
    return dt > 0 ? (newest.b - oldest.b) / dt : 0;
}

// Refresh the progress panel every second so Speed/ETA visibly tick between
// chunk completions, instead of only updating when a chunk/file finishes.
setInterval(() => {
    if (isUploading) updateProgressSummary();
}, 1000);

// @@chunk-progress-begin
// Upload progress that does not move in whole-chunk steps (5.44.1).
//
// xhr.upload 'progress' counts the bytes the browser has handed to its network stack, NOT the
// bytes the other end has received. Over HTTP/3 (QUIC, which Cloudflare turns on by default) the
// stack accepts a whole 10 MB chunk into its send buffer almost at once, so `loaded` runs to the
// end of the chunk right away and then nothing moves until the server answers: 10, 20, 30 MB.
// The only moment that is CONFIRMED is the server's answer to a chunk. So the number shown for
// the chunk in flight is the smallest of
//   - what the browser claims (`loaded`; it is never behind the truth, only sometimes ahead),
//   - what the recent confirmed chunks say the link really does: rate x time since this chunk
//     started (rate = chunk bytes / full round trip of the previous chunks, all uploads, EMA),
//   - 97% of the chunk: 100% only comes with the server's answer.
// If the browser's events are accurate they are the smallest and are shown as they are; if the
// link stalls the browser's numbers stop and so does the bar after at most 97% of that chunk.
// The value only ever grows: updateItemProgress adds positive deltas to the running total.
const CHUNK_PROGRESS_CAP = 0.97;
const CHUNK_RATE_MIN_BYTES = 1024 * 1024; // smaller requests measure latency, not throughput
let _chunkRateEma = 0; // bytes/s of recent confirmed chunk round trips; 0 = nothing measured yet

function _chunkShownBytes(reported, chunkBytes, elapsedMs, bytesPerSec) {
    const claimed = Math.min(Math.max(reported || 0, 0), chunkBytes);
    const cap = chunkBytes * CHUNK_PROGRESS_CAP;
    if (!(bytesPerSec > 0)) return Math.floor(Math.min(claimed, cap));
    const estimate = bytesPerSec * Math.max(elapsedMs, 0) / 1000;
    return Math.floor(Math.min(claimed, estimate, cap));
}

function _noteChunkRate(chunkBytes, elapsedMs) {
    if (chunkBytes < CHUNK_RATE_MIN_BYTES || !(elapsedMs > 0)) return;
    const rate = chunkBytes / (elapsedMs / 1000);
    _chunkRateEma = _chunkRateEma > 0 ? _chunkRateEma * 0.5 + rate * 0.5 : rate;
}

// One reporter per request (a whole small file or one chunk). baseBytes = bytes of the file that
// are already confirmed before this request; chunkBytes = size of THIS request's payload.
function _makeChunkProgress(item, baseBytes, chunkBytes, fileSize) {
    const startedAt = performance.now();
    let shown = 0;
    const report = loaded => {
        const next = _chunkShownBytes(loaded, chunkBytes, performance.now() - startedAt, _chunkRateEma);
        shown = Math.max(shown, next); // never backwards (see above)
        const cumulative = baseBytes + shown;
        updateItemProgress(item.id, Math.round((cumulative / fileSize) * 100), cumulative);
    };
    // Call when the server has answered this request OK: that is the one confirmed measurement.
    report.done = () => _noteChunkRate(chunkBytes, performance.now() - startedAt);
    return report;
}
// @@chunk-progress-end

const PROGRESS_DOM_THROTTLE_MS = 120;

function updateItemProgress(fileId, progress, uploadedBytes = 0) {
    const item = uploadQueue.find(item => item.id === fileId);
    if (item) {
        // Delta accumulator — O(1), survives auto-clear removing completed items
        const delta = (uploadedBytes || 0) - (item.uploadedBytes || 0);
        if (delta > 0) {
            totalBytesUploaded += delta;
            _recordSpeedSample(totalBytesUploaded);
        }
        item.progress = progress;
        item.uploadedBytes = uploadedBytes;

        // Throttle the DOM writes, not the data. xhr.upload's 'progress' event
        // fires as fast as the network stack hands off bytes — often dozens of
        // times per second per connection. With several parallel uploads that's
        // 100+ DOM writes/sec (per-item bar + full stats panel), which the
        // browser can't always paint cleanly in one frame — that's the brief
        // flicker/tearing across this area. Byte totals/speed samples above
        // still update every tick so numbers stay accurate; only how often we
        // actually touch the DOM is capped. progress===100 always goes through
        // so items never visually get stuck short of "done".
        const now = Date.now();
        if (progress < 100 && item._lastDomUpdate && now - item._lastDomUpdate < PROGRESS_DOM_THROTTLE_MS) {
            return;
        }
        item._lastDomUpdate = now;

        const element = document.querySelector(`[data-file-id="${fileId}"]`);
        if (element) {
            const progressBar = element.querySelector('.progress-fill-small');
            const progressText = element.querySelector('.file-info-meta span:nth-child(3)');
            if (progressBar) progressBar.style.width = progress + '%';
            if (progressText) progressText.innerHTML = `<i class="fas fa-percentage"></i> ${progress}%`;
        }

        updateOverallProgress();
    }
}

function updateOverallProgress() {
    // totalBytesUploaded is a running accumulator — never re-reduce the queue
    updateProgressSummary();
}

function updateItemStatus(fileId, status, error = null) {
    const item = uploadQueue.find(item => item.id === fileId);
    if (!item) { return; }

    const prevStatus = item.status;
    item.status = status;
    item.error = error;
    if (status === 'completed' || status === 'error') item.completedTime = Date.now();

    // Keep folder group progress in sync
    if (item._groupId) {
        const group = folderGroups.get(item._groupId);
        if (group) {
            if (status === 'uploading' && group.status === 'pending') group.status = 'uploading';

            // group.assembling tracks files whose bytes are all sent but whose
            // backend chunk-reassembly hasn't been confirmed yet — see the note
            // in _uploadFolderGroupLazy for why this gap used to be invisible.
            if (status === 'assembling' && prevStatus !== 'assembling') group.assembling++;
            if (prevStatus === 'assembling' && status !== 'assembling') group.assembling = Math.max(0, group.assembling - 1);

            if (status === 'completed' && prevStatus !== 'completed') group.completed++;
            if (status === 'error' && prevStatus !== 'error') group.errors++;

            // An item that just left 'assembling' (resolved by the poller, likely
            // well after _uploadFolderGroupLazy's loop already moved on) is truly
            // done now — the loop intentionally left it in uploadQueue for this
            // moment (see _uploadFolderGroupLazy), so remove it here instead.
            if (prevStatus === 'assembling' && (status === 'completed' || status === 'error' || status === 'cancelled')) {
                const idx = uploadQueue.findIndex(q => q.id === item.id);
                if (idx !== -1) uploadQueue.splice(idx, 1);
                _lastUploadActivity = Date.now(); // reset stall heartbeat after a long backend rebuild
            }

            _maybeFinalizeGroup(group);
        }
        // FIX: Folder group items are transient — pushed, uploaded, then spliced out
        // of uploadQueue once they truly finish. They never appear as individual
        // rows in the UI (updateQueueDisplay filters them out via !item._groupId).
        // Calling updateQueueDisplay() here caused a full innerHTML wipe + DOM rebuild
        // on EVERY file — 2 rebuilds × 10 parallel workers = 20 full DOM destructions
        // per batch. Over 16k files this caused Chrome's DOM GC to crash the renderer.
        // _updateGroupRowInPlace is the cheap, safe-per-file alternative — it's
        // already called every file from the upload loop, and is called here too
        // so an out-of-band assembling→completed transition also updates the row.
        if (group) _updateGroupRowInPlace(group);
        return;
    }

    updateQueueDisplay();
}

// 4.66: is the listing the server just returned the one already on screen?
// Only the fields a row is built from are compared (name, is_dir, modified,
// and size for files; a folder's size comes from /api/dir_info), and the order
// is ignored, so an SSE-triggered refresh that changes nothing visible does
// not rebuild the table at all.
function _sameListing(newFiles, path) {
    try {
        const norm = p => (p || '').replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
        if (norm(VT.getPath()) !== norm(path)) return false;
        const cur = VT.getAll();
        if (!Array.isArray(newFiles) || cur.length !== newFiles.length) return false;
        const byName = new Map(cur.map(f => [f.name, f]));
        for (const b of newFiles) {
            const a = byName.get(b.name);
            if (!a) return false;
            if (!!a.is_dir !== !!b.is_dir || a.modified !== b.modified) return false;
            if (!a.is_dir && a.size !== b.size) return false;
        }
        return true;
    } catch (e) {
        return false;
    }
}

// AJAX function to refresh file table without page reload
// opts.onlyIfChanged (4.66): skip the re-render when the listing is identical.
async function refreshFileTable(opts) {
    const startTime = Date.now();
    console.log('📁 refreshFileTable() started...');

    // Check if search results are currently displayed - don't refresh if they are
    const searchHeader = document.getElementById('searchResultsHeader');
    const searchRows = document.querySelectorAll('.search-result-row');

    if (isSearchResultsDisplayed || searchHeader || searchRows.length > 0) {
        console.log('🔍 Search results currently displayed - skipping refresh to preserve search view');
        return;
    }

    try {
        // Use the current path from navigation state, not the static page load path
        const pathToUse = currentPath || '';
        console.log(`📁 Using current navigation path: "${pathToUse}"`);
        console.log(`📁 Fetching files from: /api/files/${pathToUse}`);
        const response = await fetch(`/api/files/${pathToUse}`);

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const data = await response.json();

        if (!data.success) {
            throw new Error(data.error || 'Failed to load files');
        }

        if (opts && opts.onlyIfChanged && _sameListing(data.files, currentPath || '')) {
            console.log('📁 Listing unchanged - table left as is');
            return;
        }

        // BUG FIX: Route through updateFileTable (VT.init) instead of updateFileTableContent.
        // updateFileTableContent bypassed VT entirely — raw DOM rows, _allFiles never updated.
        // After any SSE/upload/delete refresh, _allFiles stayed stale (root page-load data),
        // so sort headers re-sorted the wrong folder. VT.init reads global currentSort so sort is preserved.
        updateFileTable(data.files, currentPath || '');

        const endTime = Date.now();
        console.log(`✅ refreshFileTable() completed in ${endTime - startTime}ms`);

        console.log('✅ File table refreshed successfully');

    } catch (error) {
        console.error('❌ Failed to refresh file table:', error);

        // FIX: Never reload the page while an upload is in progress.
        // The old code unconditionally called window.location.reload() on any
        // fetch failure. During a long upload (50k files, 1+ hour) the session
        // can expire, making /api/files/ return a redirect to /login. The reload
        // then lands on /login → grey screen and the entire upload is lost.
        if (isUploading) {
            console.warn('⚠️ refreshFileTable failed during upload — skipping reload to protect active upload');
            return;
        }

        // Also guard against auth redirect specifically (session expired mid-session).
        const errMsg = error.message || '';
        if (errMsg.includes('401') || errMsg.includes('403') || errMsg.includes('302')) {
            console.warn('⚠️ refreshFileTable got auth error — skipping reload');
            return;
        }

        showUploadStatus('❌ Failed to refresh file list, reloading page...', 'error');
        setTimeout(() => {
            window.location.reload();
        }, 1000);
    }
}

// Function to update file table content

// Handle delete button clicks
function handleDeleteClick(event) {
    console.log('🗑️ handleDeleteClick function called');
    const itemName = this.getAttribute('data-item-name');
    const itemPath = this.getAttribute('data-item-path');
    console.log('Delete button clicked:', itemName, itemPath);
    showDeleteModal(itemName, () => deleteItem(itemPath, itemName));
}

// Helper function to get file extension

// Helper function to format file size
function formatFileSize(bytes) {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));

    // Ensure we don't exceed the sizes array
    const sizeIndex = Math.min(i, sizes.length - 1);
    const value = bytes / Math.pow(k, sizeIndex);

    // Round to 1 decimal place and ensure it's a valid number
    const formattedValue = Math.round(value * 10) / 10;

    return `${formattedValue} ${sizes[sizeIndex]}`;
}

// Helper function to format timestamp  
function formatTimestamp(timestamp) {
    try {
        const date = new Date(timestamp * 1000);
        const time = date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
        const day = date.toLocaleDateString('en-US');
        return `<span style="color:white;font-size:12px;white-space:nowrap;">${day} ${time}</span>`;
    } catch (e) {
        return '--';
    }
}

// ── Overwrite decision cache ──────────────────────────────────────────────────
// Stores per-folder-upload user decisions so we don't re-prompt for every file.
// 'overwrite' | 'skip' | 'ask' (default)
const _overwriteDecisions = new Map(); // conflict key → 'overwrite' | 'skip' | 'rename' | 'ask'

// Loose (non-folder) files have no _groupId, so they share ONE decision key for the
// whole upload batch. Without it "Overwrite all conflicts" was remembered for nobody
// and only the file shown in the dialog was overwritten.
const _LOOSE_CONFLICT_KEY = '__loose__';

// Per-key tail of the dialog queue. Uploads run in parallel, so several files can get
// their 409 at the same moment; their dialogs are chained one after another so that an
// "all" answer given to the first one is already in _overwriteDecisions when the next
// one looks (and a second modal never stacks on top of the first).
const _conflictPromptTail = new Map(); // conflict key → Promise

// ── Conflict Dialog Helpers ──────────────────────────────────────────────────

/**
 * Creates a themed conflict-dialog overlay that matches the blue app UI.
 * Returns a Promise that resolves with the chosen action string.
 *
 * @param {object} opts
 *   icon      – FontAwesome class string (e.g. 'fa-file')
 *   title     – Dialog heading
 *   body      – HTML string shown in the body area
 *   buttons   – Array of { id, label, style } objects
 */
function _buildConflictDialog(opts) {
    return new Promise(resolve => {
        const overlay = document.createElement('div');
        overlay.style.cssText = [
            'position:fixed', 'inset:0',
            'background:rgba(0,0,0,0.55)',
            'backdrop-filter:blur(4px)',
            '-webkit-backdrop-filter:blur(4px)',
            'z-index:9999',
            'display:flex', 'align-items:center', 'justify-content:center'
        ].join(';');

        const btnHtml = opts.buttons.map(b =>
            `<button data-action="${b.id}">${b.label}</button>`
        ).join('');

        overlay.innerHTML = `
        <div style="
            background:rgba(255,255,255,0.97);
            border-radius:15px;
            width:90%;
            max-width:440px;
            box-shadow:0 25px 50px rgba(0,0,0,0.35);
            overflow:hidden;
            font-family:inherit;
        ">
            <!-- Header matching app nav gradient -->
            <div style="
                background:linear-gradient(135deg,#1e3c72 0%,#2a5298 100%);
                padding:18px 22px;
                display:flex;
                align-items:center;
                gap:12px;
                color:#fff;
            ">
                <i class="fas ${opts.icon}" style="font-size:1.25em;opacity:0.9"></i>
                <span style="font-size:1.05em;font-weight:600;letter-spacing:0.01em">${opts.title}</span>
            </div>
            <!-- Body -->
            <div style="padding:20px 22px;color:#2c3e50;font-size:0.95em;line-height:1.5">
                ${opts.body}
            </div>
            <!-- Buttons -->
            <div style="
                padding:0 22px 20px;
                display:flex;
                flex-direction:column;
                gap:9px;
            ">
                ${btnHtml}
            </div>
        </div>`;

        document.body.appendChild(overlay);

        const SHARED_BTN = [
            'width:100%', 'padding:10px 16px',
            'border:none', 'border-radius:8px',
            'font-size:0.92em', 'font-weight:600',
            'cursor:pointer', 'text-align:left',
            'transition:filter .15s',
            'display:flex', 'align-items:center', 'gap:9px'
        ].join(';');

        overlay.querySelectorAll('[data-action]').forEach(btn => {
            const btnDef = opts.buttons.find(b => b.id === btn.dataset.action);
            btn.style.cssText = (btnDef && btnDef.style ? btnDef.style + ';' : '') + SHARED_BTN;
            btn.addEventListener('mouseenter', () => btn.style.filter = 'brightness(0.9)');
            btn.addEventListener('mouseleave', () => btn.style.filter = '');
            btn.addEventListener('click', () => { overlay.remove(); resolve(btn.dataset.action); });
        });
    });
}

/**
 * Prompt the user when a file already exists on the server.
 * Returns one of: 'overwrite-all' | 'overwrite-one' | 'skip-all' | 'skip-one'
 */
async function _promptOverwrite(filename, destPath) {
    const safeName = escapeHtml(filename);
    return _buildConflictDialog({
        icon: 'fa-file-alt',
        title: 'File Already Exists',
        body: `<div style="margin-bottom:12px">
                   <span style="background:#ebf5fb;border:1px solid #aed6f1;border-radius:6px;
                         padding:5px 10px;font-family:monospace;word-break:break-all;
                         display:inline-block;max-width:100%;color:#1a5276">
                       ${safeName}
                   </span>
               </div>
               <div style="color:#566573;margin-bottom:8px">
                   A file with this name already exists at
                   <strong style="color:#2c3e50">${_formatDisplayPath(destPath)}</strong>.
                   Choose how to handle this and any further conflicts.
               </div>`,
        buttons: [
            {
                id: 'overwrite-all',
                label: '<i class="fas fa-sync-alt"></i> Overwrite all conflicts',
                style: 'background:linear-gradient(135deg,#3498db,#2980b9);color:#fff'
            },
            {
                id: 'overwrite-one',
                label: '<i class="fas fa-file-upload"></i> Overwrite this file only',
                style: 'background:linear-gradient(135deg,#5dade2,#3498db);color:#fff'
            },
            {
                id: 'rename-all',
                label: '<i class="fas fa-copy"></i> Keep both — auto-rename all conflicts',
                style: 'background:linear-gradient(135deg,#27ae60,#229954);color:#fff'
            },
            {
                id: 'rename-one',
                label: '<i class="fas fa-i-cursor"></i> Keep both — rename this file only',
                style: 'background:linear-gradient(135deg,#2ecc71,#27ae60);color:#fff'
            },
            {
                id: 'skip-all',
                label: '<i class="fas fa-forward"></i> Skip all conflicts',
                style: 'background:linear-gradient(135deg,#f39c12,#e67e22);color:#fff'
            },
            {
                id: 'skip-one',
                label: '<i class="fas fa-step-forward"></i> Skip this file only',
                style: 'background:linear-gradient(135deg,#7f8c8d,#636e72);color:#fff'
            }
        ]
    });
}

/**
 * Decide what to do with ONE file that got a 409 (already exists).
 * Returns 'overwrite' | 'rename' | 'skip'.
 * An "all" choice is stored under the file's group (folder upload) or under
 * _LOOSE_CONFLICT_KEY (plain files) so every later conflict of the same batch is
 * answered without a dialog. Concurrent callers are served one at a time.
 */
function _resolveFileConflict(item, filename, destPath) {
    const key = item._groupId || _LOOSE_CONFLICT_KEY;
    const tail = _conflictPromptTail.get(key) || Promise.resolve();
    const result = tail.then(async () => {
        const saved = _overwriteDecisions.get(key);
        if (saved === 'overwrite' || saved === 'skip' || saved === 'rename') return saved;

        const action = await _promptOverwrite(filename, destPath);
        if (action === 'overwrite-all') _overwriteDecisions.set(key, 'overwrite');
        if (action === 'skip-all') _overwriteDecisions.set(key, 'skip');
        if (action === 'rename-all') _overwriteDecisions.set(key, 'rename');
        if (action.startsWith('overwrite')) return 'overwrite';
        if (action.startsWith('rename')) return 'rename';
        return 'skip';
    });
    // Keep the chain alive even if a dialog or upload step throws.
    _conflictPromptTail.set(key, result.catch(() => { }));
    return result;
}

/**
 * Prompt the user when a folder being uploaded already exists on the server.
 * Returns one of: 'merge' | 'rename' | 'skip' | 'cancel'
 */
async function _promptFolderConflict(folderName, destPath) {
    const safeName = escapeHtml(folderName);
    return _buildConflictDialog({
        icon: 'fa-folder-open',
        title: 'Folder Already Exists',
        body: `<div style="margin-bottom:12px">
                   <span style="background:#eaf4fb;border:1px solid #aed6f1;border-radius:6px;
                         padding:5px 10px;font-family:monospace;word-break:break-all;
                         display:inline-block;max-width:100%;color:#1a5276">
                       <i class="fas fa-folder" style="color:#f39c12;margin-right:6px"></i>${safeName}
                   </span>
               </div>
               <div style="color:#566573">
                   A folder named <strong style="color:#2c3e50">${safeName}</strong> already exists
                   at <strong style="color:#2c3e50">${_formatDisplayPath(destPath)}</strong>. What would you like to do?
               </div>`,
        buttons: [
            {
                id: 'merge',
                label: '<i class="fas fa-code-branch"></i> Merge — upload into existing folder',
                style: 'background:linear-gradient(135deg,#3498db,#2980b9);color:#fff'
            },
            {
                id: 'rename',
                label: '<i class="fas fa-copy"></i> Keep both — upload as a new renamed folder',
                style: 'background:linear-gradient(135deg,#27ae60,#229954);color:#fff'
            },
            {
                id: 'skip',
                label: '<i class="fas fa-forward"></i> Skip this folder entirely',
                style: 'background:linear-gradient(135deg,#f39c12,#e67e22);color:#fff'
            },
            {
                id: 'cancel',
                label: '<i class="fas fa-times"></i> Cancel upload',
                style: 'background:linear-gradient(135deg,#e74c3c,#c0392b);color:#fff'
            }
        ]
    });
}

/**
 * Finds the first non-existing name for a file/folder by appending (1), (2), …
 * @param {string} destDir  - destination directory path (empty = root)
 * @param {string} name     - original file or folder name
 * @returns {Promise<string>} - a free name like "photo (2).jpg" or "myfolder (1)"
 */
async function _findFreeName(destDir, name) {
    const dotIdx = name.lastIndexOf('.');
    const ext = dotIdx > 0 ? name.slice(dotIdx) : '';
    const base = dotIdx > 0 ? name.slice(0, dotIdx) : name;
    for (let i = 1; i <= 999; i++) {
        const candidate = `${base} (${i})${ext}`;
        const checkPath = destDir ? `${destDir}/${candidate}` : candidate;
        try {
            const resp = await fetch(`/api/exists?path=${encodeURIComponent(checkPath)}`);
            if (resp.ok) {
                const data = await resp.json();
                if (!data.exists) return candidate;
            } else {
                return candidate; // server error — use this name and let upload handle it
            }
        } catch (e) {
            return candidate; // network error — proceed optimistically
        }
    }
    return `${base} (${Date.now()})${ext}`; // last-resort fallback
}

/**
 * @param {string[]} paths       - source paths being moved/copied
 * @param {string}   destination - destination directory path
 * @param {string}   action      - 'move' or 'copy'
 */
async function _promptMoveOrCopyConflicts(paths, destination, action) {
    // Step 1: ask the server which items already exist at the destination
    let conflicts = [];
    try {
        const resp = await fetch('/api/check_conflicts', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ paths, destination })
        });
        if (resp.ok) {
            const data = await resp.json();
            conflicts = data.conflicts || [];
        }
    } catch (e) {
        console.warn('⚠️ Conflict check failed, proceeding without it:', e.message);
        return {};  // empty map → backend default behaviour
    }

    if (conflicts.length === 0) return {};  // no conflicts, proceed normally

    // Step 2: build list HTML
    const listHtml = conflicts.map(c =>
        `<li style="padding:3px 0;display:flex;align-items:center;gap:7px">
            <i class="fas ${c.is_dir ? 'fa-folder conflict-icon-dir' : 'fa-file-alt conflict-icon-file'}"></i>
            <span style="font-family:monospace;word-break:break-all">${escapeHtml(c.name)}</span>
         </li>`
    ).join('');

    const destDisplay = destination || 'Root';
    const verbNoun = action === 'move' ? 'Moving' : 'Copying';

    const choice = await _buildConflictDialog({
        icon: action === 'move' ? 'fa-arrows-alt' : 'fa-copy',
        title: `${conflicts.length} Conflict${conflicts.length > 1 ? 's' : ''} at Destination`,
        body: `<div style="margin-bottom:10px;color:#566573">
                   ${verbNoun} to <strong style="color:#2c3e50">${escapeHtml(destDisplay)}</strong> —
                   the following item${conflicts.length > 1 ? 's' : ''} already exist there:
               </div>
               <ul style="margin:0 0 12px 0;padding:0 0 0 4px;list-style:none;
                           max-height:150px;overflow-y:auto;
                           background:#f8fafc;border:1px solid #d5e8f5;border-radius:6px;padding:8px 12px">
                   ${listHtml}
               </ul>
               <div style="color:#7f8c8d;font-size:0.88em">Choose how to handle all conflicts at once.</div>`,
        buttons: [
            {
                id: 'overwrite',
                label: `<i class="fas fa-sync-alt"></i> Overwrite existing items`,
                style: 'background:linear-gradient(135deg,#3498db,#2980b9);color:#fff'
            },
            {
                id: 'rename',
                label: `<i class="fas fa-copy"></i> Keep both — auto-rename conflicting items`,
                style: 'background:linear-gradient(135deg,#27ae60,#229954);color:#fff'
            },
            {
                id: 'skip',
                label: `<i class="fas fa-forward"></i> Skip conflicting items`,
                style: 'background:linear-gradient(135deg,#f39c12,#e67e22);color:#fff'
            },
            {
                id: 'cancel',
                label: `<i class="fas fa-times"></i> Cancel`,
                style: 'background:linear-gradient(135deg,#e74c3c,#c0392b);color:#fff'
            }
        ]
    });

    if (choice === 'cancel') return null;  // signal: abort entirely

    // Build resolution map: { filename -> choice } for every conflict
    const resolutions = {};
    for (const c of conflicts) {
        resolutions[c.name] = choice;  // same resolution for all
    }
    return resolutions;
}

// ── Live folder worker pool ───────────────────────────────────────────────────
let _activeFolderWorkers = 0;
let _activeFileWorkers = 0;

function _spawnFileWorkersIfNeeded() {
    if (!isUploading || !PARALLEL_UPLOAD_CONFIG.enableParallelUploads) return;
    const max = PARALLEL_UPLOAD_CONFIG.maxConcurrentUploads;
    const pending = uploadQueue.filter(q => q.status === 'pending' && !cancelledUploads.has(q.id)).length;
    const toSpawn = Math.min(pending, max - _activeFileWorkers - PARALLEL_UPLOAD_CONFIG.activeUploads.size);
    for (let i = 0; i < toSpawn; i++) {
        _activeFileWorkers++;
        _runFileWorker().finally(() => { _activeFileWorkers--; });
    }
}

async function _runFileWorker() {
    while (isUploading) {
        const item = uploadQueue.find(q => q.status === 'pending' && !cancelledUploads.has(q.id));
        if (!item) break;
        item.status = 'uploading';
        PARALLEL_UPLOAD_CONFIG.activeUploads.add(item.id);
        try {
            updateItemStatus(item.id, 'uploading');
            await uploadSingleFile(item);
            const currentItem = uploadQueue.find(q => q.id === item.id);
            if (!(currentItem && currentItem.status === 'assembling')) {
                updateItemStatus(item.id, 'completed');
            }
            PARALLEL_UPLOAD_CONFIG.activeUploads.delete(item.id);
            PARALLEL_UPLOAD_CONFIG.completedUploads.add(item.id);
            cancelledUploads.delete(item.id);
        } catch (error) {
            PARALLEL_UPLOAD_CONFIG.activeUploads.delete(item.id);

            // Same network-error detection _uploadFolderGroupLazy already uses,
            // so root-level files get the same resilience folder files do.
            const userCancelled = cancelledUploads.has(item.id)
                || error.message === 'Upload cancelled by user';
            const unexpectedAbort = !userCancelled && error.name === 'AbortError';
            const isNetworkError = unexpectedAbort || (!userCancelled && (
                error.message.includes('Failed to fetch') ||
                error.message.includes('NetworkError') ||
                error.message.includes('net::ERR_') ||
                error.name === 'TypeError'
            ));

            const MAX_FILE_RETRIES = 5;
            item._retryCount = (item._retryCount || 0) + 1;

            if (userCancelled) {
                updateItemStatus(item.id, 'cancelled', 'Stopped');
                cancelledUploads.delete(item.id);
            } else if (isNetworkError && isUploading && item._retryCount <= MAX_FILE_RETRIES) {
                console.warn(`🔄 Network error on "${item.name}" — retry ${item._retryCount}/${MAX_FILE_RETRIES} in 1.5s…`, error.message);
                updateItemStatus(item.id, 'pending', 'Waiting to retry…');
                if (document.hidden) {
                    await new Promise(resolve => {
                        const handler = () => { document.removeEventListener('visibilitychange', handler); resolve(); };
                        document.addEventListener('visibilitychange', handler);
                    });
                }
                await new Promise(r => setTimeout(r, 1500));
                item.status = 'pending'; // re-queue — this or another worker will pick it up
                cancelledUploads.delete(item.id);
                continue;
            } else {
                console.error(`❌ Upload failed: ${item.name}`, error.message);
                updateItemStatus(item.id, 'error', error.message);
                cancelledUploads.delete(item.id);
                showUploadStatus(`❌ Failed: "${item.name}" - ${error.message}`, 'error');
            }
        }
    }
}

function _spawnFolderWorkersIfNeeded() {
    if (!isUploading) return;
    const max = PARALLEL_UPLOAD_CONFIG.enableParallelUploads
        ? PARALLEL_UPLOAD_CONFIG.maxConcurrentUploads : 1;
    // Include 'scanning' groups — upload can begin while the directory tree walk is still running.
    const pending = [...folderGroups.values()].filter(
        g => (g.status === 'pending' || g.status === 'scanning') && !g.cancelled && (g.pendingFiles || g.pendingEntries)
    ).length;
    const toSpawn = Math.min(pending, max - _activeFolderWorkers);
    for (let i = 0; i < toSpawn; i++) {
        _activeFolderWorkers++;
        _runFolderWorker().finally(() => { _activeFolderWorkers--; });
    }
}

async function _runFolderWorker() {
    while (isUploading) {
        // Include 'scanning' groups — workers can start consuming pendingEntries while
        // the directory tree walk is still in progress.
        const group = [...folderGroups.values()].find(
            g => (g.status === 'pending' || g.status === 'scanning') && !g.cancelled && (g.pendingFiles || g.pendingEntries)
        );
        if (!group) break;
        // Claim immediately so no other worker grabs same group
        group.status = 'uploading';
        _overwriteDecisions.set(group.id, 'ask'); // Reset overwrite decision per folder

        try {
            const destPath = group.basePath
                ? `${group.basePath}/${group.rootName}`
                : group.rootName;
            const checkResp = await fetch(`/api/exists?path=${encodeURIComponent(destPath)}`);
            if (checkResp.ok) {
                const checkData = await checkResp.json();
                if (checkData.exists && checkData.is_dir) {
                    _updateGroupRowInPlace(group); // show 'uploading' indicator while dialog shown
                    const choice = await _promptFolderConflict(group.rootName, group.basePath);
                    if (choice === 'cancel') {
                        // Cancel the entire upload session
                        group.cancelled = true;
                        group.status = 'cancelled';
                        group._running = false;
                        _updateGroupRowInPlace(group);
                        showUploadStatus(`⛔ Upload cancelled — "${group.rootName}" already exists`, 'info');
                        setTimeout(() => {
                            if (folderGroups.has(group.id)) {
                                _freeSeen(group);
                                folderGroups.delete(group.id);
                                updateQueueDisplay();
                            }
                        }, 2000);
                        continue;  // move to next group in while loop (will find no pending ones if cancelled)
                    } else if (choice === 'skip') {
                        group.cancelled = true;
                        group.status = 'skipped';
                        group._running = false;
                        _updateGroupRowInPlace(group);
                        showUploadStatus(`⏭️ Skipped "${group.rootName}" — folder already exists`, 'info');
                        // Auto-remove from queue after 2s and free seen-keys so re-drop works
                        setTimeout(() => {
                            if (folderGroups.has(group.id)) {
                                _freeSeen(group);
                                folderGroups.delete(group.id);
                                updateQueueDisplay();
                            }
                        }, 2000);
                        continue;
                    }

                    if (choice === 'rename') {
                        // Find a free folder name, then reroute all files into it
                        const freeFolder = await _findFreeName(group.basePath || '', group.rootName);
                        group._origRootName = group.rootName; // preserve original before mutating
                        group.rootNameOverride = freeFolder;
                        group.rootName = freeFolder; // update display name in queue UI
                        _updateGroupRowInPlace(group);
                        showUploadStatus(`📁 Uploading as "${freeFolder}"…`, 'info');
                    }
                }
            }
        } catch (existErr) {
            // Non-fatal: if the check fails (network issue, old server), proceed normally
            console.warn('⚠️ Folder existence check failed, proceeding:', existErr.message);
        }

        showUploadStatus(`📂 "${group.rootName}" — ${(group.totalCount || group.scanned).toLocaleString()} files…`, 'info');
        await _uploadFolderGroupLazy(group);
        if (group.status === 'uploading') {
            group.status = group.errors > 0 ? 'error' : 'done';
            group._running = false;
            _updateGroupRowInPlace(group);
        }
    }
}

// Wait until workers are idle AND no scanning/pending groups remain
function _waitForFolderWorkers() {
    _spawnFolderWorkersIfNeeded();
    return new Promise(resolve => {
        const check = setInterval(() => {
            if (!isUploading) { clearInterval(check); resolve(); return; }
            // Still active if: workers running OR groups still scanning/pending
            const stillBusy = _activeFolderWorkers > 0
                || [...folderGroups.values()].some(g =>
                    !g.cancelled && (g.status === 'scanning' || g.status === 'pending'));
            if (!stillBusy) { clearInterval(check); resolve(); }
        }, 100);
    });
}
// ─────────────────────────────────────────────────────────────────────────────

// ── Single source of truth for progress bar visibility ───────────────────────
let _progressHideTimer = null;
function setUploadingState(active) {
    isUploading = active;
    if (!active) _lastResumeTime = 0;
    const ps = document.getElementById('uploadProgressSummary');
    if (!ps) return;

    if (active) {
        clearTimeout(_progressHideTimer);
        ps.classList.add('show');
        updateProgressSummary();

        if (!document.getElementById('_stopAllBtn')) {
            const btn = document.createElement('button');
            btn.id = '_stopAllBtn';
            btn.title = 'Stop all uploads';
            btn.innerHTML = '<i class="fas fa-ban"></i> Stop Upload';
            btn.style.cssText = [
                'display:flex', 'align-items:center', 'gap:6px',
                'margin:8px auto 0', 'padding:7px 18px',
                'background:#e74c3c', 'color:#fff', 'border:none',
                'border-radius:6px', 'cursor:pointer', 'font-size:14px',
                'font-weight:600', 'letter-spacing:0.3px',
                'box-shadow:0 2px 6px rgba(0,0,0,0.4)',
                'transition:background 0.15s'
            ].join(';');
            btn.onmouseenter = () => btn.style.background = '#c0392b';
            btn.onmouseleave = () => btn.style.background = '#e74c3c';
            btn.addEventListener('click', () => {
                // Stop every active folder group
                folderGroups.forEach((group, id) => {
                    if (group.status === 'uploading' || group.status === 'pending') {
                        _stopFolderGroup(id);
                    }
                });
                // Also cancel any individual file uploads in progress
                uploadQueue.forEach(item => {
                    if (item.status === 'uploading') cancelUpload(item.id);
                });
            });
            ps.appendChild(btn);
        }
    } else {
        _progressHideTimer = setTimeout(() => {
            if (!isUploading) ps.classList.remove('show');
        }, 2500);
        // Remove the stop button when upload ends
        const btn = document.getElementById('_stopAllBtn');
        if (btn) btn.remove();
    }
}

async function startBatchUpload() {
    console.log('🚀 startBatchUpload called, isUploading:', isUploading);

    if (isUploading) {
        console.log('❌ Already uploading, returning');
        return;
    }

    const pendingFiles = uploadQueue.filter(item => item.status === 'pending');
    // Lazy folder groups: have fileList/pendingFiles/pendingEntries but nothing in uploadQueue yet.
    // Include 'scanning' groups so Upload can start immediately while the tree walk is still running.
    const pendingLazyGroups = [...folderGroups.values()].filter(
        g => (g.status === 'pending' || g.status === 'scanning') && (g.pendingFiles || g.pendingEntries)
    );
    console.log('📋 Pending files:', pendingFiles.length, '| Lazy groups:', pendingLazyGroups.length);

    if (pendingFiles.length === 0 && pendingLazyGroups.length === 0) {
        console.log('❌ No files to upload');
        showUploadStatus('❌ No files to upload', 'error');
        return;
    }

    console.log('✅ Starting upload process...');
    setUploadingState(true);
    _activeFolderWorkers = 0;
    _activeFileWorkers = 0;
    _overwriteDecisions.clear();
    _conflictPromptTail.clear();
    currentUploadIndex = 0;
    uploadStartTime = Date.now();
    _lastUploadActivity = Date.now(); // FIX: seed heartbeat so stall detector doesn't fire immediately

    // Start session keepalive so long uploads don't expire the server session
    _startSessionKeepAlive();

    // FIX: Reset SSE reconnect counters so a prior disconnect doesn't permanently
    // block reconnection during this upload session.
    reconnectAttempts = 0;
    sseFailedPermanently = false;
    // If SSE is dead, revive it now before upload begins
    if (!storageEventSource || storageEventSource.readyState === EventSource.CLOSED) {
        console.log('📡 Reviving SSE connection before upload starts...');
        connectToStorageStream();
    }
    totalBytesToUpload = pendingFiles.reduce((sum, item) => sum + item.size, 0)
        + pendingLazyGroups.reduce((s, g) => s + (g.totalSize || 0), 0);
    totalBytesUploaded = 0;
    _chunkRateEma = 0; // a new run: forget the rate of the previous one (5.44.1)
    _speedSamples.length = 0; // reset rolling speed window
    lazyBytesUploaded = 0;

    // Reset parallel upload tracking
    PARALLEL_UPLOAD_CONFIG.activeUploads.clear();
    PARALLEL_UPLOAD_CONFIG.completedUploads.clear();

    const uploadBtn = document.getElementById('startUploadBtn');
    const clearBtn = document.getElementById('clearAllBtn');

    console.log('🔧 Upload button element:', uploadBtn);

    if (uploadBtn) {
        uploadBtn.disabled = true;
        const mode = PARALLEL_UPLOAD_CONFIG.enableParallelUploads ? 'Parallel' : 'Sequential';
        const concurrent = PARALLEL_UPLOAD_CONFIG.enableParallelUploads ? ` (${PARALLEL_UPLOAD_CONFIG.maxConcurrentUploads} concurrent)` : '';
        uploadBtn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${mode} Upload${concurrent}`;
    }
    if (clearBtn) clearBtn.disabled = true;

    // Hide manual cleanup button during upload
    updateManualCleanupButton();

    try {
        const uploadMode = PARALLEL_UPLOAD_CONFIG.enableParallelUploads ? 'parallel' : 'sequential';
        const concurrentInfo = PARALLEL_UPLOAD_CONFIG.enableParallelUploads ? ` (${PARALLEL_UPLOAD_CONFIG.maxConcurrentUploads} concurrent)` : '';
        showUploadStatus(`🚀 Starting ${uploadMode} upload of ${pendingFiles.length} files${concurrentInfo}...`, 'info');

        // 1. Upload regular queued files
        if (pendingFiles.length > 0) {
            if (PARALLEL_UPLOAD_CONFIG.enableParallelUploads) {
                await startParallelUploads(pendingFiles);
            } else {
                await startSequentialUploads(pendingFiles);
            }
        }

        // 2. Upload lazy folder groups — live worker pool.
        //    Workers grab the next 'pending' or 'scanning' group from folderGroups on each iteration,
        //    so folders added DURING upload are picked up without restarting.
        if (pendingLazyGroups.length > 0 || [...folderGroups.values()].some(g => g.status === 'pending' || g.status === 'scanning')) {
            await _waitForFolderWorkers();
        }

        const completedCount = uploadQueue.filter(item => item.status === 'completed').length
            + [...folderGroups.values()].reduce((s, g) => s + g.completed, 0);
        const errorCount = uploadQueue.filter(item => item.status === 'error').length
            + [...folderGroups.values()].reduce((s, g) => s + g.errors, 0);
        const cancelledCount = uploadQueue.filter(item => item.status === 'cancelled').length;

        // Ensure overall progress is set to 100% after all uploads
        totalBytesUploaded = totalBytesToUpload;
        updateProgressSummary();

        if (errorCount === 0 && cancelledCount === 0) {
            showUploadStatus(
                `🎉 All files uploaded successfully! (${completedCount} files)`,
                'success'
            );

            VT.clearDirCache();

            // Refresh file table via AJAX instead of page reload
            setTimeout(() => {
                refreshFileTable();
            }, 1000);
        } else {
            showUploadStatus(
                `📊 Upload completed: ${completedCount} successful, ${errorCount} failed, ${cancelledCount} cancelled`,
                'info'
            );
        }

        // Auto-clear completed/error/cancelled items after upload batch finishes
        // BUT keep assembling items visible so user can see processing status
        console.log('🧹 Auto-clearing finished items in 3 seconds...');
        setTimeout(() => {
            const itemsToRemove = uploadQueue.filter(item =>
                item.status === 'completed' ||
                item.status === 'error' ||
                item.status === 'cancelled'
                // Note: 'assembling' items are NOT auto-cleared so user can see processing status
            );

            itemsToRemove.forEach(item => {
                removeFromQueue(item.id);
            });

            // Clear completed folder groups too — but never one that's still
            // waiting on a backend reassembly (see the matching guard in
            // clearCompletedItems() for why: deleting the group would orphan
            // that still-assembling item, leaving it invisible forever while
            // still counted in the queue header's totals).
            folderGroups.forEach((group, id) => {
                if (group.assembling > 0) return;
                if (group.status === 'done' || group.status === 'error') folderGroups.delete(id);
            });

            console.log(`🧹 Auto-cleared ${itemsToRemove.length} finished items from queue`);

            updateQueueDisplay(); // Re-render so cleared folder rows actually disappear

            if (uploadQueue.length === 0 && folderGroups.size === 0) {
                showUploadStatus('✨ Upload queue cleared automatically', 'success');
            } else {
                const remainingPending = uploadQueue.filter(item => item.status === 'pending').length;
                console.log(`📋 ${remainingPending} files still pending in queue`);
            }
        }, 3000);

    } catch (error) {
        console.error('❌ Batch upload error:', error);
        showUploadStatus(`❌ Batch upload failed: ${error.message}`, 'error');
    } finally {
        setUploadingState(false);
        PARALLEL_UPLOAD_CONFIG.activeUploads.clear();
        PARALLEL_UPLOAD_CONFIG.completedUploads.clear();

        if (uploadBtn) {
            uploadBtn.disabled = false;
            uploadBtn.innerHTML = '<i class="fas fa-upload"></i> Upload All (<span id="uploadCount">0</span>)';
        }
        if (clearBtn) clearBtn.disabled = false;

        updateManualCleanupButton();
        updateQueueDisplay();
    }
}

function _startSessionKeepAlive() {
    if (_sessionKeepAliveInterval) return;
    // FIX: was setInterval — see startAssemblyPolling for why that stacks
    // overlapping requests during a server slowdown. Only one keepalive at a
    // time, and it never queues the next one until the current one settles.
    const tick = async () => {
        if (!isUploading) {
            _sessionKeepAliveInterval = null;
            return;
        }
        try {
            await fetch('/admin/upload_status', {
                method: 'GET', cache: 'no-cache',
                headers: { 'Cache-Control': 'no-cache' }
            });
        } catch (e) {
            console.warn('⚠️ Session keepalive failed (non-fatal):', e.message);
        }
        _sessionKeepAliveInterval = isUploading ? setTimeout(tick, 30000) : null;
    };
    _sessionKeepAliveInterval = setTimeout(tick, 30000); // Every 30s — browsers throttle background tabs; 30s gives safety margin
}

function _resumeStalledUploads() {
    if (!isUploading) return 0;

    const now = Date.now();
    const msSinceLastResume = now - _lastResumeTime;
    if (msSinceLastResume < 20000) {
        console.log(`⏭️ Resume skipped (cooldown ${Math.round(msSinceLastResume / 1000)}s < 20s)`);
        return 0;
    }
    _lastResumeTime = now;

    const stalledMs = now - (_lastUploadActivity || 0);
    let resumed = 0;
    for (const [, group] of folderGroups) {
        if (group.status !== 'uploading' || group.cancelled || !group.pendingFiles) continue;

        if (group._running) {
            if (stalledMs > 10000) {
                console.warn(`🔄 Force-resetting frozen group "${group.rootName}" (_running=true but stalled ${Math.round(stalledMs / 1000)}s)`);
                group._running = false;
            } else {
                continue;
            }
        }

        // Stagger restarts: launch each group 300ms apart to avoid a thundering
        // herd of simultaneous connections that would exhaust Waitress threads.
        const delay = resumed * 300;
        const capturedGroup = group;
        setTimeout(() => {
            // Re-check: the group might have already restarted naturally
            if (capturedGroup._running || capturedGroup.cancelled || !capturedGroup.pendingFiles) return;
            // Find first non-null slot from _currentIndex (null = already uploaded)
            let resumeFrom = capturedGroup._currentIndex ?? capturedGroup.completed;
            const src = capturedGroup.pendingFiles;
            if (src) {
                while (resumeFrom < src.length && src[resumeFrom] === null) resumeFrom++;
            }
            console.warn(`🔄 Resuming "${capturedGroup.rootName}" from index ${resumeFrom}/${capturedGroup.totalCount} (delay ${delay}ms)`);
            _uploadFolderGroupLazy(capturedGroup, resumeFrom).catch(err => {
                console.error(`❌ Resume failed for "${capturedGroup.rootName}":`, err);
            });
        }, delay);
        resumed++;
    }
    if (resumed > 0) {
        showUploadStatus(`▶️ Resuming ${resumed} upload(s) after tab woke up...`, 'info');
    }
    return resumed;
}

// Page Lifecycle API — fires when a frozen tab is unfrozen
window.addEventListener('resume', () => {
    if (!isUploading) return;
    console.log('▶️ Page resumed from frozen state — checking for stalled uploads');
    // Give the browser 500 ms to settle promise queues before we intervene
    setTimeout(() => {
        const stalledMs = Date.now() - _lastUploadActivity;
        if (stalledMs > 5000) {
            console.warn(`⚠️ Upload stalled for ${Math.round(stalledMs / 1000)}s — attempting resume`);
            _resumeStalledUploads();
        }
    }, 500);
});

// visibilitychange — fires every time the tab becomes visible (including after freeze)
document.addEventListener('visibilitychange', () => {
    if (document.hidden || !isUploading) return;
    const stalledMs = Date.now() - _lastUploadActivity;
    // If no file completed in the last 10 seconds and we're supposed to be uploading,
    // the loop likely froze.
    if (stalledMs > 10000) {
        console.warn(`⚠️ Tab became visible — upload stalled for ${Math.round(stalledMs / 1000)}s`);
        _resumeStalledUploads();
    }
});

// Parallel upload implementation
async function startParallelUploads(pendingFiles) {
    console.log(`⚡ Starting parallel uploads with max concurrency: ${PARALLEL_UPLOAD_CONFIG.maxConcurrentUploads}`);

    // Upload worker — reads live from uploadQueue so files added mid-upload are picked up.
    // Workers exit only when there's nothing left AND no other worker is about to claim something.
    const uploadWorker = async () => {
        while (isUploading) {
            // Grab next unclaimed pending item directly from the live queue
            const item = uploadQueue.find(q => q.status === 'pending' && !cancelledUploads.has(q.id));
            if (!item) break;

            // Claim it immediately to prevent another worker grabbing the same item
            item.status = 'uploading';
            PARALLEL_UPLOAD_CONFIG.activeUploads.add(item.id);

            try {
                updateItemStatus(item.id, 'uploading');
                await uploadSingleFile(item);

                const currentItem = uploadQueue.find(q => q.id === item.id);
                if (!(currentItem && currentItem.status === 'assembling')) {
                    updateItemStatus(item.id, 'completed');
                }

                PARALLEL_UPLOAD_CONFIG.activeUploads.delete(item.id);
                PARALLEL_UPLOAD_CONFIG.completedUploads.add(item.id);
                cancelledUploads.delete(item.id);

            } catch (error) {
                console.error(`❌ Upload failed: ${item.name}`, error.message);
                updateItemStatus(item.id, 'error', error.message);
                PARALLEL_UPLOAD_CONFIG.activeUploads.delete(item.id);
                cancelledUploads.delete(item.id);
                showUploadStatus(`❌ Failed: "${item.name}" - ${error.message}`, 'error');
            }
        }
    };

    const workerCount = Math.min(PARALLEL_UPLOAD_CONFIG.maxConcurrentUploads, pendingFiles.length);
    console.log(`⚡ Starting ${workerCount} upload workers`);

    const workers = [];
    for (let i = 0; i < workerCount; i++) {
        workers.push(uploadWorker());
    }

    await Promise.all(workers);
    console.log(`⚡ All parallel upload workers completed`);
}

// Sequential upload implementation (original behavior)
async function startSequentialUploads(pendingFiles) {
    console.log('📋 Starting sequential uploads (original behavior)');

    for (let i = 0; i < pendingFiles.length; i++) {
        const item = pendingFiles[i];
        currentUploadIndex = i + 1;

        console.log(`📤 Processing file ${i + 1}/${pendingFiles.length}: ${item.name}`);

        // Update status to uploading
        updateItemStatus(item.id, 'uploading');
        currentUploadingFile = item.id;

        try {
            console.log(`📤 Starting upload for: ${item.name}`);
            await uploadSingleFile(item);
            // Same guard as startParallelUploads: uploadSingleFile() resolves once
            // the last chunk is sent, not once the backend confirms reassembly —
            // don't stomp an 'assembling' item back to 'completed' here; the
            // assembly poller it started will mark it completed once ready.
            const currentItem = uploadQueue.find(q => q.id === item.id);
            if (!(currentItem && currentItem.status === 'assembling')) {
                console.log(`✅ Upload completed for: ${item.name}`);
                updateItemStatus(item.id, 'completed');
            } else {
                console.log(`⏳ "${item.name}" sent — backend still processing it`);
            }
            currentUploadingFile = null;
            cancelledUploads.delete(item.id);

        } catch (error) {
            console.error(`❌ Upload failed for ${item.name}:`, error);
            updateItemStatus(item.id, 'error', error.message);
            currentUploadingFile = null;
            cancelledUploads.delete(item.id);

            showUploadStatus(
                `❌ Failed to upload "${item.name}": ${error.message}`,
                'error'
            );

            // Ask user if they want to continue with remaining files
            if (i < pendingFiles.length - 1) {
                const continueUpload = confirm(`Upload failed for "${item.name}". Continue with remaining files?`);
                if (!continueUpload) {
                    console.log('🛑 User chose to stop upload');
                    break;
                }
            }
        }
    }
}

// Real, browser-verified upload progress. fetch() has no upload-progress API —
// with fetch, a chunk (or a whole small file) only reports progress once, when
// the entire request finishes. XMLHttpRequest's xhr.upload 'progress' event
// fires as the browser's network stack actually hands bytes to the wire, so
// this gives true sub-chunk, real-time progress instead of jumps only at
// 10MB/file boundaries — and critically, if sending genuinely stalls, these
// events simply stop firing (nothing is faked/interpolated), so _rollingSpeed's
// time-decay does the honest thing and speed/ETA taper toward 0 on their own.
// FormData is safe to send more than once (unlike a fetch ReadableStream
// body), so on a CSRF-shaped 400 this resyncs the meta tag via
// /csrf-token and replays the exact same upload once with the fresh
// token — same stale-tab scenario as the fetch wrapper above (see its
// comment), just handled here too since uploads go through XHR instead
// of fetch() to get real upload-progress events.
function _sendXhrUploadOnce(url, formData, token, { signal, onProgress } = {}) {
    return new Promise((resolve, reject) => {
        if (signal?.aborted) {
            reject(new DOMException('The user aborted a request.', 'AbortError'));
            return;
        }

        const xhr = new XMLHttpRequest();
        xhr.open('POST', url);
        if (token) xhr.setRequestHeader('X-CSRFToken', token);

        let abortHandler;
        if (signal) {
            abortHandler = () => xhr.abort();
            signal.addEventListener('abort', abortHandler);
        }
        const cleanup = () => { if (signal && abortHandler) signal.removeEventListener('abort', abortHandler); };

        if (onProgress) {
            xhr.upload.addEventListener('progress', e => {
                if (e.lengthComputable) onProgress(e.loaded, e.total);
            });
        }

        xhr.addEventListener('load', () => {
            cleanup();
            resolve({
                status: xhr.status,
                ok: xhr.status >= 200 && xhr.status < 300,
                text: async () => xhr.responseText,
                json: async () => JSON.parse(xhr.responseText),
                body: { cancel: () => { } } // no streaming body with XHR; kept so call sites don't need to change
            });
        });
        xhr.addEventListener('error', () => { cleanup(); reject(new TypeError('Failed to fetch')); });
        xhr.addEventListener('abort', () => { cleanup(); reject(new DOMException('The user aborted a request.', 'AbortError')); });

        xhr.send(formData);
    });
}

async function xhrUpload(url, formData, opts = {}) {
    const token = window._getCsrfToken ? window._getCsrfToken() : document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
    const response = await _sendXhrUploadOnce(url, formData, token, opts);

    if (response.status === 400 && window._refreshCsrfToken) {
        let looksLikeCsrfFailure = true;
        try {
            looksLikeCsrfFailure = /csrf/i.test(await response.text());
        } catch (e) { /* non-text body — assume it could still be the CSRF error page */ }

        if (looksLikeCsrfFailure) {
            const freshToken = await window._refreshCsrfToken();
            if (freshToken) {
                return _sendXhrUploadOnce(url, formData, freshToken, opts);
            }
        }
    }

    return response;
}

async function uploadSingleFile(item) {
    if (cancelledUploads.has(item.id)) {
        throw new Error('Upload cancelled by user');
    }

    const file = item.file;
    const destPath = item.destinationPath !== undefined ? item.destinationPath : (document.getElementById('destPath').value || '');

    // Progress reporters (5.44.1, see _makeChunkProgress): one per request, so the number shown
    // for a request in flight is never ahead of what the link has recently proven it can carry.
    const wholeFileProgress = () => _makeChunkProgress(item, 0, file.size, file.size);

    try {
        if (file.size <= CHUNK_SIZE) {
            const formData = new FormData();
            formData.append('filename', file.name);
            formData.append('dest_path', destPath);
            formData.append('file', file);

            let progress = wholeFileProgress();
            let response = await xhrUpload(UPLOAD_URL, formData, {
                signal: item._abortSignal || null,
                onProgress: progress
            });

            // Handle file-already-exists: ask user what to do
            if (response.status === 409) {
                response.body?.cancel();
                const resolution = await _resolveFileConflict(item, item.displayName || file.name, destPath);
                const shouldSkip = resolution === 'skip';
                const shouldOverwrite = resolution === 'overwrite';
                const shouldRename = resolution === 'rename';

                if (shouldSkip) {
                    updateItemProgress(item.id, 100, file.size);
                    return; // Skip silently
                }

                if (shouldRename) {
                    const freeName = await _findFreeName(destPath, file.name);
                    const renameForm = new FormData();
                    renameForm.append('filename', freeName);
                    renameForm.append('dest_path', destPath);
                    renameForm.append('file', file);
                    progress = wholeFileProgress();
                    response = await xhrUpload(UPLOAD_URL, renameForm, {
                        signal: item._abortSignal || null,
                        onProgress: progress
                    });
                } else if (shouldOverwrite) {
                    const retryForm = new FormData();
                    retryForm.append('filename', file.name);
                    retryForm.append('dest_path', destPath);
                    retryForm.append('file', file);
                    retryForm.append('overwrite', '1');
                    progress = wholeFileProgress();
                    response = await xhrUpload(UPLOAD_URL, retryForm, {
                        signal: item._abortSignal || null,
                        onProgress: progress
                    });
                }
            }

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(errorText);
            }

            progress.done();
            response.body?.cancel();
            updateItemProgress(item.id, 100, file.size);

        } else {
            // Chunked upload
            const totalChunks = Math.ceil(file.size / CHUNK_SIZE);

            for (let i = 0; i < totalChunks; i++) {
                if (cancelledUploads.has(item.id)) {
                    throw new Error('Upload cancelled by user');
                }

                const currentItem = uploadQueue.find(queueItem => queueItem.id === item.id);
                if (!currentItem || currentItem.status === 'cancelled') {
                    throw new Error('Upload cancelled by user');
                }

                const start = i * CHUNK_SIZE;
                const end = Math.min(file.size, start + CHUNK_SIZE);
                const chunk = file.slice(start, end);

                const formData = new FormData();
                formData.append('file_id', item.id);
                formData.append('chunk_num', i);
                formData.append('total_chunks', totalChunks);
                formData.append('filename', file.name);
                formData.append('dest_path', destPath);
                formData.append('chunk', chunk);

                if (cancelledUploads.has(item.id)) {
                    throw new Error('Upload cancelled by user');
                }

                const chunkProgress = _makeChunkProgress(item, start, end - start, file.size);
                const response = await xhrUpload(UPLOAD_URL, formData, {
                    signal: item._abortSignal || null,
                    onProgress: chunkProgress
                });

                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error(`Chunk ${i + 1}/${totalChunks}: ${errorText}`);
                }
                chunkProgress.done();

                if (i === totalChunks - 1) {
                    try {
                        const responseData = await response.json();
                        if (responseData.assembly_queued) {
                            updateItemProgress(item.id, 100, file.size);
                            updateItemStatus(item.id, 'assembling', 'Processing file...');
                            try {
                                await fetch(`/api/protect_assembly/${item.id}`, { method: 'POST' });
                            } catch (protectError) {
                                console.warn(`⚠️ Failed to protect assembly job ${item.id}:`, protectError);
                            }
                            startAssemblyPolling(item.id);
                            updateManualCleanupButton();
                        } else {
                            updateItemProgress(item.id, 100, file.size);
                        }
                    } catch (jsonError) {
                        updateItemProgress(item.id, 100, file.size);
                    }
                } else {
                    // Intermediate chunk — final settle in case the last progress
                    // event didn't land exactly on the chunk boundary.
                    response.body?.cancel();
                    const progress = Math.round(((i + 1) / totalChunks) * 100);
                    updateItemProgress(item.id, progress, end);
                }
            }
        }
    } catch (error) {
        console.error('❌ Upload failed:', item.name, error.message);
        throw error;
    }
}

// Auto-cleanup old items periodically (safety net)
setInterval(() => {
    if (!isUploading) {
        const now = Date.now();
        const itemsToRemove = [];

        uploadQueue.forEach((item, index) => {
            // Remove very old completed items (over 2 minutes) as safety net
            if ((item.status === 'completed' || item.status === 'error') && item.completedTime) {
                if (now - item.completedTime > 120000) { // 2 minutes
                    itemsToRemove.push(index);
                }
            }

            // Remove very old pending items (stale for 5+ minutes)
            if (item.status === 'pending' && item.createdTime) {
                const age = now - item.createdTime;
                if (age > 300000) { // 5 minutes
                    console.log(`🧹 Removing stale pending item: ${item.name} (${Math.round(age / 60000)}min old)`);
                    itemsToRemove.push(index);
                    // Try to cleanup its chunks
                    cleanupSingleFile(item.id, item.name).catch(console.error);
                }
            }
        });

        // Remove items in reverse order to maintain indices
        itemsToRemove.reverse().forEach(index => {
            uploadQueue.splice(index, 1);
        });

        if (itemsToRemove.length > 0) {
            console.log(`🧹 Safety cleanup removed ${itemsToRemove.length} old items`);
            updateQueueDisplay();
        }
    }
}, 60000); // Check every 60 seconds

// Selection Management Functions
function toggleSelectAll() {
    const selectAllCheckbox = document.getElementById('selectAll');
    if (!selectAllCheckbox) return;

    const isNowChecked = selectAllCheckbox.checked;
    selectAllCheckbox.indeterminate = false;

    selectedItems.clear();

    if (isNowChecked) {
        if (isSearchResultsDisplayed) {
            // DEEP SEARCH MODE: select every LOADED search result (_dsAll), not just
            // the rows currently mounted — deep search is windowed now, so the DOM
            // only holds ~a screenful. VT.getAll() is the current-folder list, NOT
            // search results — selecting from it would queue up every file in the
            // folder for deletion.
            _dsAll.forEach(r => { if (r.path) selectedItems.add(r.path); });
        } else {
            // NORMAL MODE: populate from full VT data array (handles virtual scroll).
            // Virtual scroll only renders ~80 rows at a time, so querySelectorAll misses the rest.
            const curPath = VT.getPath();
            VT.getAll().forEach(item => {
                const itemPath = curPath ? `${curPath}/${item.name}` : item.name;
                selectedItems.add(itemPath);
            });
        }
    }

    // Sync the visible DOM checkboxes to match.
    // In deep search mode, only touch search-result checkboxes — hidden regular-table
    // rows also have .item-checkbox and checking them here would corrupt selectedItems.
    if (isSearchResultsDisplayed) {
        document.querySelectorAll('.search-result-row .item-checkbox').forEach(checkbox => {
            checkbox.checked = isNowChecked;
            const row = checkbox.closest('tr');
            if (row) row.classList.toggle('selected', isNowChecked);
        });
    } else {
        document.querySelectorAll('.item-checkbox').forEach(checkbox => {
            checkbox.checked = isNowChecked;
            const row = checkbox.closest('tr');
            if (row) row.classList.toggle('selected', isNowChecked);
        });
    }

    // Update the bulk actions UI
    const selectedCount = document.getElementById('selectedCount');
    const bulkActions = document.getElementById('bulkActions');

    if (selectedCount) selectedCount.textContent = selectedItems.size;

    // Update download button text based on selection
    const downloadButton = document.getElementById('bulkDownloadBtn');
    if (downloadButton) {
        if (selectedItems.size === 1) {
            downloadButton.innerHTML = '<i class="fas fa-download"></i> Download';
            downloadButton.title = 'Download selected file directly';
            downloadButton.classList.remove('zip-mode');
        } else if (selectedItems.size > 1) {
            downloadButton.innerHTML = '<i class="fas fa-file-archive"></i> Download ZIP';
            downloadButton.title = `Download ${selectedItems.size} items as ZIP file`;
            downloadButton.classList.add('zip-mode');
        } else {
            downloadButton.innerHTML = '<i class="fas fa-download"></i> Download';
            downloadButton.title = 'Select items to download';
            downloadButton.classList.remove('zip-mode');
        }
    }

    // Show/hide rename button based on selection count
    const renameButton = document.querySelector('.bulk-buttons button[onclick*="showRenameModal"]');
    if (renameButton) {
        if (selectedItems.size === 1) {
            renameButton.style.display = 'flex';
            renameButton.disabled = false;
        } else {
            renameButton.style.display = 'none';
            renameButton.disabled = true;
        }
    }

    if (bulkActions) {
        if (selectedItems.size > 0) {
            bulkActions.classList.add('show');
        } else {
            bulkActions.classList.remove('show');
        }
    }

    console.log(`✅ ${isNowChecked ? 'Selected' : 'Deselected'} all ${selectedItems.size} items`);
}

function updateSelection() {
    // Called onchange on individual checkboxes — must NOT clear+rebuild selectedItems
    // from DOM, because virtual scroll only has ~80 rows visible at a time. Wiping
    // selectedItems and rebuilding from DOM would erase all off-screen selections.
    // Instead, sync only the checkboxes that are currently in the DOM.
    const itemCheckboxes = document.querySelectorAll('.item-checkbox');
    const selectAllCheckbox = document.getElementById('selectAll');
    const bulkActions = document.getElementById('bulkActions');
    const selectedCount = document.getElementById('selectedCount');

    itemCheckboxes.forEach(checkbox => {
        const row = checkbox.closest('tr');
        // CRITICAL: Skip checkboxes belonging to hidden rows.
        // During deep search, regular file rows are hidden (display:none) but their
        // checkboxes still exist in the DOM.  Picking them up here would pollute
        // selectedItems with paths the user never chose, causing wrong bulk deletes.
        if (row && row.style.display === 'none') return;
        if (checkbox.checked) {
            selectedItems.add(checkbox.dataset.path);
            if (row) row.classList.add('selected');
        } else {
            selectedItems.delete(checkbox.dataset.path);
            if (row) row.classList.remove('selected');
        }
    });

    const checkedCount = selectedItems.size;
    // In deep search mode compare against the loaded search results (_dsAll), not VT folder count.
    // Using VT.getAll().length here would always show the wrong ratio and could allow
    // selectAll to think everything is selected when it isn't.
    const totalCount = isSearchResultsDisplayed
        ? _dsAll.length
        : VT.getAll().length;

    console.log(`📊 Selection update: ${checkedCount}/${totalCount} items selected`);

    if (selectAllCheckbox) {
        if (checkedCount === 0) {
            selectAllCheckbox.checked = false;
            selectAllCheckbox.indeterminate = false;
        } else if (checkedCount >= totalCount) {
            selectAllCheckbox.checked = true;
            selectAllCheckbox.indeterminate = false;
        } else {
            selectAllCheckbox.checked = false;
            selectAllCheckbox.indeterminate = true;
        }
    }

    if (selectedCount) selectedCount.textContent = checkedCount;

    // Update download button text based on selection
    const downloadButton = document.getElementById('bulkDownloadBtn');
    if (downloadButton) {
        if (checkedCount === 1) {
            downloadButton.innerHTML = '<i class="fas fa-download"></i> Download';
            downloadButton.title = 'Download selected file directly';
            downloadButton.classList.remove('zip-mode');
        } else if (checkedCount > 1) {
            downloadButton.innerHTML = '<i class="fas fa-file-archive"></i> Download ZIP';
            downloadButton.title = `Download ${checkedCount} items as ZIP file`;
            downloadButton.classList.add('zip-mode');
        } else {
            downloadButton.innerHTML = '<i class="fas fa-download"></i> Download';
            downloadButton.title = 'Select items to download';
            downloadButton.classList.remove('zip-mode');
        }
    }

    // Show/hide rename button based on selection count
    const renameButton = document.querySelector('.bulk-buttons button[onclick*="showRenameModal"]');
    if (renameButton) {
        if (checkedCount === 1) {
            renameButton.style.display = 'flex';
            renameButton.disabled = false;
        } else {
            renameButton.style.display = 'none';
            renameButton.disabled = true;
        }
    }

    if (bulkActions) {
        if (checkedCount > 0) {
            bulkActions.classList.add('show');
        } else {
            bulkActions.classList.remove('show');
        }
    }
}

function initializeRenameButtonVisibility() {
    // Set initial rename button visibility based on current selection
    const renameButton = document.querySelector('.bulk-buttons button[onclick*="showRenameModal"]');
    if (renameButton) {
        // On page load, no items should be selected, so hide rename button
        renameButton.style.display = 'none';
        renameButton.disabled = true;
        console.log('🔧 Initialized rename button visibility - hidden on page load');
    }
}

function clearSelection() {
    selectedItems.clear();
    document.querySelectorAll('.item-checkbox').forEach(checkbox => {
        checkbox.checked = false;
        checkbox.closest('tr').classList.remove('selected');
    });

    const selectAllCheckbox = document.getElementById('selectAll');
    if (selectAllCheckbox) {
        selectAllCheckbox.checked = false;
        selectAllCheckbox.indeterminate = false;
    }

    // Update the selection UI
    updateSelection();

    console.log('✅ Selection cleared successfully');
}

// Modal Functions
let browserCurrentPath = '';  // Track current path in folder browser

// ── VT-style virtual scroll for the selected-items list in Copy/Move modals ──
// Renders items in batches of VT_LIST_CHUNK (mirrors the main table's CHUNK=80)
// and uses an IntersectionObserver sentinel to load the next batch on scroll.
const VT_LIST_CHUNK = 80;
let _vtListObserver = null;

function _vtListDisconnect() {
    if (_vtListObserver) { _vtListObserver.disconnect(); _vtListObserver = null; }
}

function _vtListRenderChunk(ul, items, rendered) {
    const end = Math.min(rendered + VT_LIST_CHUNK, items.length);
    for (let i = rendered; i < end; i++) {
        const li = document.createElement('li');
        li.textContent = items[i].split('/').pop();
        li.style.cssText = 'padding:2px 4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
        ul.appendChild(li);
    }
    return end;
}

function _populateSelectedItemsVT(ul) {
    if (!ul) return;
    _vtListDisconnect();
    ul.innerHTML = '';

    ul.style.cssText = [
        'max-height:clamp(120px,22vh,280px)',
        'overflow-y:auto',
        'overflow-x:hidden',
        'margin:0',
        'padding:4px 0 4px 18px',
        'list-style:disc',
        'scrollbar-width:thin',
        'font-size:13px',
        'line-height:1.55',
    ].join(';');

    const items = [...selectedItems];
    const total = items.length;

    let badge = ul.previousElementSibling;
    if (!badge || !badge.classList.contains('vt-list-count')) {
        badge = document.createElement('div');
        badge.className = 'vt-list-count';
        badge.style.cssText = 'font-size:11px;opacity:0.65;margin-bottom:3px;';
        ul.parentNode.insertBefore(badge, ul);
    }
    badge.textContent = `${total} item${total !== 1 ? 's' : ''} selected`;

    if (total === 0) return;

    let rendered = _vtListRenderChunk(ul, items, 0);
    if (rendered >= total) return;

    function _attachListSentinel() {
        const old = ul.querySelector('.vt-list-sentinel');
        if (old) old.remove();

        const remaining = total - rendered;
        const sentinel = document.createElement('li');
        sentinel.className = 'vt-list-sentinel';
        sentinel.style.cssText = 'list-style:none;padding:4px 0;font-size:11px;opacity:0.6;text-align:center;';
        sentinel.innerHTML = `<i class="fas fa-circle-notch fa-spin" style="margin-right:5px;"></i>`
            + `Loading ${Math.min(VT_LIST_CHUNK, remaining)} more of ${remaining} remaining…`;
        ul.appendChild(sentinel);

        _vtListObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (!entry.isIntersecting) return;
                _vtListDisconnect();
                sentinel.remove();
                rendered = _vtListRenderChunk(ul, items, rendered);
                if (rendered < total) _attachListSentinel();
            });
        }, { root: ul, threshold: 0.1 });
        _vtListObserver.observe(sentinel);
    }

    _attachListSentinel();
}

function showMoveModal() {
    if (selectedItems.size === 0) return;

    currentModalAction = 'move';
    const modal = document.getElementById('moveModal');
    const modalTitle = document.getElementById('modalTitle');
    const confirmBtn = document.getElementById('confirmAction');
    const selectedItemsList = document.getElementById('selectedItemsList');

    if (modalTitle) modalTitle.textContent = 'Move Items';
    if (confirmBtn) {
        confirmBtn.textContent = 'Move';
        confirmBtn.className = 'btn btn-warning';
    }

    // Populate selected items list with VT-style virtual scroll
    _populateSelectedItemsVT(selectedItemsList);

    // Initialize folder browser
    initializeFolderBrowser();

    if (modal) modal.classList.add('show');
}

function showCopyModal() {
    if (selectedItems.size === 0) return;

    currentModalAction = 'copy';
    const modal = document.getElementById('moveModal');
    const modalTitle = document.getElementById('modalTitle');
    const confirmBtn = document.getElementById('confirmAction');
    const selectedItemsList = document.getElementById('selectedItemsList');

    if (modalTitle) modalTitle.textContent = 'Copy Items';
    if (confirmBtn) {
        confirmBtn.textContent = 'Copy';
        confirmBtn.className = 'btn btn-success';
    }

    // Populate selected items list with VT-style virtual scroll
    _populateSelectedItemsVT(selectedItemsList);

    // Initialize folder browser
    initializeFolderBrowser();

    if (modal) modal.classList.add('show');
}

// Folder Browser Functions
async function initializeFolderBrowser() {
    browserCurrentPath = '';  // Start at root
    await loadFolderContents('');
    updateCurrentPathDisplay();
    updateUpButton();
}

async function loadFolderContents(path) {
    const loading = document.getElementById('browserLoading');
    const folderList = document.getElementById('folderList');
    const emptyState = document.getElementById('emptyFolderState');

    if (loading) loading.style.display = 'block';
    if (folderList) folderList.innerHTML = '';
    if (emptyState) emptyState.style.display = 'none';

    try {
        console.log(`📁 Loading folder contents for path: "${path}"`);

        // Use the existing API endpoint to get folder contents
        const apiUrl = path ? `/api/files/${encodeURIComponent(path)}` : '/api/files/';
        const response = await fetch(apiUrl);

        if (!response.ok) {
            throw new Error(`Failed to load folder: ${response.statusText}`);
        }

        const data = await response.json();

        if (loading) loading.style.display = 'none';

        // Filter to show only directories
        const folders = data.files.filter(item => item.is_dir || item.type === 'dir');

        if (folders.length === 0) {
            if (emptyState) emptyState.style.display = 'block';
        } else {
            displayFolders(folders);
        }

    } catch (error) {
        console.error('❌ Error loading folder contents:', error);
        if (loading) loading.style.display = 'none';
        if (folderList) {
            folderList.innerHTML = `
                <div style="padding: 15px; text-align: center; color: #e74c3c;">
                    <i class="fas fa-exclamation-triangle"></i><br>
                    Error loading folders: ${escapeHtml(error.message)}
                </div>
            `;
        }
    }
}

function displayFolders(folders) {
    const folderList = document.getElementById('folderList');
    if (!folderList) return;

    folderList.innerHTML = '';

    folders.forEach(folder => {
        const folderItem = document.createElement('div');
        folderItem.className = 'folder-item';
        folderItem.style.cssText = `
            display: flex;
            align-items: center;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 6px;
            margin-bottom: 2px;
            transition: background-color 0.2s ease;
            color: #fff;
        `;

        folderItem.innerHTML = `
            <i class="fas fa-folder" style="color: #f39c12; margin-right: 10px; font-size: 14px;"></i>
            <span style="flex: 1;">${escapeHtml(folder.name)}</span>
            <i class="fas fa-chevron-right" style="color: rgba(255,255,255,0.5); font-size: 12px;"></i>
        `;

        // Add hover effect
        folderItem.addEventListener('mouseenter', function () {
            this.style.backgroundColor = 'rgba(255,255,255,0.1)';
        });

        folderItem.addEventListener('mouseleave', function () {
            this.style.backgroundColor = 'transparent';
        });

        // Add click handler to navigate into folder
        folderItem.addEventListener('click', function () {
            const newPath = browserCurrentPath ? `${browserCurrentPath}/${folder.name}` : folder.name;
            navigateFolderBrowser(newPath);
        });

        folderList.appendChild(folderItem);
    });
}

async function navigateFolderBrowser(path) {
    browserCurrentPath = path;
    await loadFolderContents(path);
    updateCurrentPathDisplay();
    updateUpButton();
}

function updateCurrentPathDisplay() {
    const pathDisplay = document.getElementById('currentDestinationPath');
    if (pathDisplay) {
        pathDisplay.textContent = browserCurrentPath || 'Root Directory';
    }
}

function updateUpButton() {
    const upButton = document.getElementById('upButton');
    if (upButton) {
        upButton.disabled = !browserCurrentPath;
    }
}

function goToRoot() {
    navigateFolderBrowser('');
}

function goUpOneLevel() {
    if (!browserCurrentPath) return;

    const pathParts = browserCurrentPath.split('/');
    pathParts.pop();
    const newPath = pathParts.join('/');
    navigateFolderBrowser(newPath);
}

async function createNewFolderInBrowser() {
    const folderName = prompt('Enter new folder name:');
    if (!folderName || !folderName.trim()) return;

    try {
        // Create the folder using the real mkdir endpoint.
        // NOTE: this used to POST to a nonexistent '/create_folder' endpoint
        // with a 'folder_name' field — always 404'd. The real route is
        // '/mkdir' and expects 'foldername' (no underscore) + 'path'.
        const response = await fetch('/mkdir', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `foldername=${encodeURIComponent(folderName.trim())}&path=${encodeURIComponent(browserCurrentPath)}`
        });

        if (!response.ok) {
            throw new Error('Failed to create folder');
        }

        // Refresh the current folder view
        await loadFolderContents(browserCurrentPath);

        showUploadStatus(`✅ Created folder: ${folderName}`, 'success');

    } catch (error) {
        console.error('❌ Error creating folder:', error);
        showUploadStatus(`❌ Failed to create folder: ${error.message}`, 'error');
    }
}

function closeModal() {
    const modal = document.getElementById('moveModal');
    if (modal) modal.classList.remove('show');

    // Tear down the VT list observer so it doesn't fire after the modal closes
    _vtListDisconnect();

    // Reset form
    const destinationPath = document.getElementById('destinationPath');
    if (destinationPath) destinationPath.value = '';
}

function showRenameModal() {
    if (isOperationInProgress) {
        console.log('⏳ Operation in progress, please wait...');
        showNotification('Please Wait', 'An operation is in progress', 'info');
        return;
    }

    if (selectedItems.size === 0) {
        showNotification('No Selection', 'Please select an item to rename', 'error');
        return;
    }

    if (selectedItems.size > 1) {
        showNotification('Multiple Selection', 'Only one item can be renamed at a time. Please select a single item.', 'error');
        return;
    }

    const selectedPath = Array.from(selectedItems)[0];
    const itemName = selectedPath.split('/').pop();

    const modal = document.getElementById('renameModal');
    const newItemNameInput = document.getElementById('newItemName');
    const currentItemNameDiv = document.getElementById('currentItemName');

    if (newItemNameInput) {
        newItemNameInput.value = itemName;

        const stopPropagation = (e) => e.stopPropagation();

        newItemNameInput.removeEventListener('click', stopPropagation);
        newItemNameInput.removeEventListener('keydown', stopPropagation);
        newItemNameInput.removeEventListener('keyup', stopPropagation);
        newItemNameInput.removeEventListener('input', stopPropagation);
        newItemNameInput.removeEventListener('focus', stopPropagation);

        newItemNameInput.addEventListener('click', stopPropagation);
        newItemNameInput.addEventListener('keydown', stopPropagation);
        newItemNameInput.addEventListener('keyup', stopPropagation);
        newItemNameInput.addEventListener('input', stopPropagation);
        newItemNameInput.addEventListener('focus', stopPropagation);

        setTimeout(() => {
            newItemNameInput.focus();
            const lastDotIndex = itemName.lastIndexOf('.');
            if (lastDotIndex > 0) {
                newItemNameInput.setSelectionRange(0, lastDotIndex);
            } else {
                newItemNameInput.select();
            }
        }, 100);
    }

    if (currentItemNameDiv) {
        currentItemNameDiv.innerHTML = `<i class="fas fa-file"></i> ${escapeHtml(itemName)}`;
    }

    if (modal) modal.classList.add('show');
}

function closeRenameModal() {
    const modal = document.getElementById('renameModal');
    if (modal) modal.classList.remove('show');

    // Reset form
    const newItemNameInput = document.getElementById('newItemName');
    if (newItemNameInput) newItemNameInput.value = '';
}

// Add this at the top of your script
let isOperationInProgress = false;

async function confirmRename() {
    const newName = document.getElementById('newItemName').value.trim();
    const selectedPath = Array.from(selectedItems)[0];

    if (!newName) {
        showNotification('Invalid Name', 'Please enter a valid name', 'error');
        return;
    }

    // Get current name from selected path
    const currentName = selectedPath.split('/').pop();

    if (newName === currentName) {
        showNotification('Same Name', 'The new name is the same as the current name', 'info');
        closeRenameModal();
        return;
    }

    if (!isValidFilename(newName)) {
        showNotification('Invalid Name', 'Invalid filename. Avoid special characters like <, >, :, ", |, ?, *, \\', 'error');
        return;
    }

    // Prevent rapid-fire renames
    if (isOperationInProgress) {
        console.log('⏳ Please wait for previous operation to complete');
        return;
    }

    isOperationInProgress = true;

    const renameButton = document.querySelector('#renameModal .btn-primary');
    const cancelButton = document.querySelector('#renameModal .btn-secondary');

    if (renameButton) {
        renameButton.disabled = true;
        renameButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Renaming...';
    }
    if (cancelButton) {
        cancelButton.disabled = true;
    }

    try {
        await performRename(selectedPath, newName);

        // Small delay for visual feedback
        await new Promise(resolve => setTimeout(resolve, 300));

    } finally {
        if (renameButton) {
            renameButton.disabled = false;
            renameButton.innerHTML = 'Rename';
        }
        if (cancelButton) {
            cancelButton.disabled = false;
        }

        isOperationInProgress = false;
        closeRenameModal();
    }
}

function isValidFilename(filename) {
    // Check for invalid filename characters
    return !/[<>:"|?*\\\/]/.test(filename) && filename !== '.' && filename !== '..';
}

async function performRename(oldPath, newName) {
    try {
        const response = await fetch('/rename', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                old_path: oldPath,
                new_name: newName
            })
        });

        const result = await response.json();

        if (response.ok && result.success) {
            showNotification('Success', result.message || 'Item renamed successfully', 'success');

            // Clear selection immediately before navigating — stale selectedItems
            // causes isOperationInProgress check to block the next rename attempt
            selectedItems.clear();
            isOperationInProgress = false;

            // Trigger navigation (file monitor will update later), then
            // scroll the renamed item into view — it may have moved well
            // outside the current scroll window (e.g. a rename that changes
            // sort order under a "sort by name" view).
            const oldDir = oldPath.includes('/') ? oldPath.split('/').slice(0, -1).join('/') : '';
            const renamedPath = oldDir ? `${oldDir}/${newName}` : newName;
            navigateToFolder(currentPath || '').then(() => {
                VT.scrollToItem(renamedPath);
            });

        } else {
            showNotification('Rename Failed', result.error || 'Could not rename item', 'error');
        }
    } catch (error) {
        console.error('Rename error:', error);
        showNotification('Error', 'Failed to rename item: ' + error.message, 'error');
    }
}

// Single-item action functions for individual action buttons
function downloadItem(itemPath) {
    // Track download to prevent beforeunload warning
    const downloadId = Date.now() + Math.random();
    activeDownloads.add(downloadId);

    // Create a temporary link to track when download completes
    const link = document.createElement('a');
    link.href = `/download/${encodePathForUrl(itemPath)}`;
    link.style.display = 'none';
    document.body.appendChild(link);

    // Remove from active downloads after a delay (download should start)
    setTimeout(() => {
        activeDownloads.delete(downloadId);
        if (document.body.contains(link)) {
            document.body.removeChild(link);
        }
    }, 1000);

    // Trigger download
    window.location.href = `/download/${encodePathForUrl(itemPath)}`;
}

function downloadFolderAsZip(folderPath, folderName) {
    console.log(`📁 Downloading folder as ZIP: ${folderName} (${folderPath})`);
    showUploadStatus(`📦 Preparing ZIP download for folder: ${folderName}`, 'info');

    // Track download to prevent beforeunload warning
    const downloadId = Date.now() + Math.random();
    activeDownloads.add(downloadId);

    // Remove from active downloads after a delay (download should start)
    setTimeout(() => {
        activeDownloads.delete(downloadId);
    }, 3000); // Longer delay for ZIP preparation

    // Use the existing bulk download function with single folder path
    performBulkZipDownload([folderPath]);
}

function showSingleMoveModal(itemPath, itemName) {
    // Clear any existing selection and select this item
    clearSelection();
    selectedItems.add(itemPath);

    // Set the checkbox as checked
    const checkbox = document.querySelector(`input[data-path="${itemPath}"]`);
    if (checkbox) {
        checkbox.checked = true;
        checkbox.closest('tr').classList.add('selected');
    }

    // Update the UI and show the modal
    updateSelection();
    showMoveModal();
}

function showSingleCopyModal(itemPath, itemName) {
    // Clear any existing selection and select this item
    clearSelection();
    selectedItems.add(itemPath);

    // Set the checkbox as checked
    const checkbox = document.querySelector(`input[data-path="${itemPath}"]`);
    if (checkbox) {
        checkbox.checked = true;
        checkbox.closest('tr').classList.add('selected');
    }

    // Update the UI and show the modal
    updateSelection();
    showCopyModal();
}

function showSingleRenameModal(itemPath, itemName) {
    // Clear any existing selection and select this item
    clearSelection();
    selectedItems.add(itemPath);

    // Set the checkbox as checked
    const checkbox = document.querySelector(`input[data-path="${itemPath}"]`);
    if (checkbox) {
        checkbox.checked = true;
        checkbox.closest('tr').classList.add('selected');
    }

    // Update the UI and show the modal
    updateSelection();
    showRenameModal();
}

function showSingleDeleteModal(itemPath, itemName) {
    // Show delete confirmation directly for single item
    showDeleteModal(itemName, () => {
        performSingleDelete(itemPath, itemName);
    }, 'individual');
}

async function performSingleDelete(itemPath, itemName) {
    try {
        showUploadStatus('🔄 Deleting item...', 'info');

        const response = await fetch('/bulk_delete', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                paths: [itemPath]
            })
        });

        const result = await response.json();

        if (result.success || result.deleted_count > 0) {
            showUploadStatus(`✅ Successfully deleted "${itemName}"`, 'success');
            // Deleting via the row action button doesn't go through bulkDelete(),
            // so selectedItems/bulkActions were never cleared even when the
            // deleted item was checked — clear it here so the bulk bar hides.
            clearSelection();
            await refreshFileTable();
            // Refresh storage stats after delete (file count and size changed)
            refreshStorageStats('delete operation');
        } else {
            const errorMsg = result.error || (result.errors && result.errors[0]) || 'Unknown error';
            showUploadStatus(`❌ Delete failed: ${errorMsg}`, 'error');
        }
    } catch (error) {
        console.error('Delete error:', error);
        showUploadStatus('❌ Network error during delete', 'error');
    } finally {
        closeDeleteModal();
    }
}

async function confirmMoveOrCopy() {
    // Use browserCurrentPath instead of text input
    const destinationPath = browserCurrentPath || '';
    const selectedPaths = Array.from(selectedItems);

    if (selectedPaths.length === 0) {
        showNotification('No Selection', 'No items selected', 'error');
        return;
    }

    // Moving to the same location is a no-op — block it.
    // Copying to the same location is fine — the conflict dialog will offer rename/overwrite.
    const currentLocation = currentPath || '';
    if (destinationPath === currentLocation && currentModalAction === 'move') {
        showNotification('Same Location', 'Cannot move items to the same location', 'error');
        return;
    }

    // Validate destination path
    if (destinationPath && !isValidPath(destinationPath)) {
        showNotification('Invalid Path', 'Invalid destination path. Use forward slashes and avoid special characters.', 'error');
        return;
    }

    const actionName = currentModalAction === 'move' ? 'Move' : 'Copy';
    const destinationDisplay = destinationPath || 'Root Directory';

    // Confirm the action with professional modal
    const confirmMessage = `${actionName} ${selectedPaths.length} item(s) to "${destinationDisplay}"?`;
    const confirmClass = currentModalAction === 'move' ? 'btn-warning' : 'btn-primary';
    const icon = currentModalAction === 'move' ? 'fa-cut' : 'fa-copy';

    const confirmed = await showConfirmationModal(
        `Confirm ${actionName}`,
        confirmMessage,
        actionName,
        confirmClass,
        icon
    );
    if (!confirmed) return;

    // ── Conflict check ────────────────────────────────────────────────────────
    const conflictResolutions = await _promptMoveOrCopyConflicts(
        selectedPaths, destinationPath, currentModalAction
    );
    if (conflictResolutions === null) return;  // user cancelled at conflict dialog
    // ─────────────────────────────────────────────────────────────────────────

    closeModal();

    if (currentModalAction === 'move') {
        performBulkMove(selectedPaths, destinationPath, conflictResolutions);
    } else if (currentModalAction === 'copy') {
        performBulkCopy(selectedPaths, destinationPath, conflictResolutions);
    }
}

function isValidPath(path) {
    // Basic path validation
    return !/[<>:"|?*\\]/.test(path) && !path.includes('..');
}

// 4.64: bulk move/copy are background jobs on the server (a big one outlives the
// ~100 s a Cloudflare-style proxy waits for a response and used to fail with a
// 524 even though the server finished it). POST answers 202 + job id, then we
// poll /bulk_job/<id>. Resolves to {ok, status, result} - the same shape the old
// synchronous answer had - so the callers below did not have to change.
async function postBulkJob(url, payload, verb) {
    const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });
    let first = {};
    try { first = await resp.json(); } catch (e) { first = {}; }
    if (resp.status !== 202 || !first.job_id) {
        return {
            ok: resp.ok,
            status: resp.status,
            result: (resp.ok || first.error) ? first : { error: `server answered HTTP ${resp.status}` }
        };
    }
    let failures = 0;
    const t0 = Date.now();
    while (true) {
        await new Promise(r => setTimeout(r, 2000));
        let st = {};
        let httpStatus = 0;
        try {
            const r = await fetch('/bulk_job/' + encodeURIComponent(first.job_id), { cache: 'no-store' });
            httpStatus = r.status;
            try { st = await r.json(); } catch (e) { st = {}; }
            if (r.status === 404) {
                throw new Error('the server no longer knows this operation (it may have restarted)');
            }
            if (!r.ok) throw new Error(st.error || `HTTP ${r.status}`);
            failures = 0;
        } catch (e) {
            if (httpStatus === 404 || ++failures >= 5) {
                throw new Error(httpStatus === 404 ? e.message
                    : 'lost contact with the server; the operation may still be running');
            }
            continue;
        }
        if (st.state === 'done') {
            const code = st.status || 500;
            return { ok: code >= 200 && code < 300, status: code, result: st.result || {} };
        }
        const secs = Math.round((Date.now() - t0) / 1000);
        showUploadStatus(
            `<i class="fas fa-circle-notch fa-spin"></i> ${verb} ${st.done || 0}/${st.total || '?'}` +
            (st.current ? `: ${st.current}` : '') + ` (${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, '0')})`,
            'info');
    }
}

async function performBulkMove(paths, destination, conflictResolutions = {}) {
    try {
        const { ok, result } = await postBulkJob('/bulk_move', {
            paths: paths,
            destination: destination,
            current_path: currentPath || '',
            conflict_resolutions: conflictResolutions
        }, 'Moving');

        if (ok) {
            showNotification('Move Successful', `Successfully moved ${result.moved_count} item(s)`, 'success');
            // Clear selection first, then refresh file table
            clearSelection();
            VT.clearDirCache(); // Flush stale folder counts so fresh data is fetched
            await refreshFileTable();
            // Refresh storage stats after move (file locations changed)
            refreshStorageStats('move operation');
        } else {
            showNotification('Move Failed', result.error, 'error');
        }
    } catch (error) {
        showNotification('Move Failed', error.message, 'error');
    }
}

async function performBulkCopy(paths, destination, conflictResolutions = {}) {
    try {
        const { ok, result } = await postBulkJob('/bulk_copy', {
            paths: paths,
            destination: destination,
            current_path: currentPath || '',
            conflict_resolutions: conflictResolutions
        }, 'Copying');

        if (ok) {
            showNotification('Copy Successful', `Successfully copied ${result.copied_count} item(s)`, 'success');
            clearSelection();

            // The server has started a background reconcile walk.
            // Rebuild the file list immediately (new files are visible) but do NOT
            // feed dir-info cells from the stale in-memory _dir_info — the walk
            // hasn't finished yet so sizes would be wrong.
            // Strategy: rebuild table, then invalidate every dir-info cell so they
            // all show a spinner.  They will be re-fetched when the reconcile_complete
            // SSE arrives and triggers another refreshFileTable().
            VT.clearDirCache();
            await refreshFileTable();

            // Mark all freshly-rendered dir-info cells as pending so they show
            // a spinner instead of fetching stale data right now.
            document.querySelectorAll('.dir-info-cell').forEach(cell => {
                cell.dataset.loaded = '';          // reset "loaded" flag
                cell.innerHTML = '<i class="fas fa-circle-notch fa-spin" style="opacity:0.5;font-size:11px;"></i>';
            });

            showUploadStatus('<i class="fas fa-circle-notch fa-spin"></i> Scanning new files…', 'info');
        } else {
            showNotification('Copy Failed', result.error, 'error');
        }
    } catch (error) {
        showNotification('Copy Failed', error.message, 'error');
    }
}

function bulkDelete() {
    const selectedPaths = Array.from(selectedItems);

    if (selectedPaths.length === 0) {
        showNotification('No Selection', 'No items selected', 'error');
        return;
    }

    showDeleteModal('', () => performBulkDelete(selectedPaths), 'bulk');
}

async function performBulkDelete(paths) {
    _mutationInFlight = true;
    paths.forEach(p => {
        _deletingPaths.add(p);
        document.querySelectorAll(`.dir-info-cell[data-dir-path="${p}"]`).forEach(cell => {
            cell.innerHTML = '<i class="fas fa-spinner fa-spin" style="opacity:0.6;font-size:11px;"></i> Deleting…';
            cell.dataset.loaded = '';
        });
    });
    try {
        const response = await fetch('/bulk_delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ paths })
        });
        const result = await response.json();
        if (response.ok) {
            showUploadStatus(`🗑️ Successfully deleted ${result.deleted_count} item(s)`, 'success');
            clearSelection();
            if (isSearchResultsDisplayed) {
                // In deep search mode refreshFileTable() is a no-op (intentionally
                // skipped to preserve the search view).  Search results are windowed,
                // so drop the deleted paths from the result data and re-mount.
                _dsRemoveResults(paths);
            } else {
                await refreshFileTable();
            }
            refreshStorageStats('bulk delete operation');
        } else {
            showUploadStatus(`❌ Bulk delete failed: ${result.error}`, 'error');
        }
    } catch (error) {
        showUploadStatus(`❌ Bulk delete failed: ${error.message}`, 'error');
    } finally {
        paths.forEach(p => _deletingPaths.delete(p));
        VT.clearDirCache();
        setTimeout(() => { _mutationInFlight = false; }, 1500);
    }
}

// Bulk Download Function - handles single files vs multiple files/folders
function bulkDownload() {
    const selectedPaths = Array.from(selectedItems);

    if (selectedPaths.length === 0) {
        showNotification('No Selection', 'No items selected for download', 'error');
        return;
    }

    console.log('📥 Starting bulk download for:', selectedPaths);

    // Check if we have only a single FILE (not folder) for direct download
    if (selectedPaths.length === 1) {
        const singlePath = selectedPaths[0];

        // Check if it's a file or a folder. Reads VT's data array rather than
        // the DOM: with row windowing, the row for `singlePath` frequently
        // isn't rendered at all (scrolled out), so a DOM lookup here would
        // silently and incorrectly treat folders as files. Falls back to a
        // DOM check only for paths VT doesn't know about (e.g. a deep-search
        // result), where the row, if selected, is guaranteed to be rendered.
        const vtCurPath = VT.getPath();
        const vtItem = VT.getAll().find(f => (vtCurPath ? `${vtCurPath}/${f.name}` : f.name) === singlePath);
        const isDirectory = vtItem
            ? !!vtItem.is_dir
            : !!document.querySelector(`tr[data-path="${singlePath}"] .folder-icon, tr[data-path="${singlePath}"] .fa-folder`);

        if (!isDirectory) {
            console.log('📄 Single file selected, doing direct download:', singlePath);
            showUploadStatus('📥 Starting direct download...', 'info');
            downloadItem(singlePath);
            return;
        } else {
            console.log('📁 Single folder selected, creating ZIP stream:', singlePath);
        }
    }

    // For multiple items, single folders, or any combination, do ZIP stream download
    console.log('📦 Multiple items or folder selected, creating ZIP stream');
    showUploadStatus('📦 Preparing ZIP download...', 'info');
    performBulkZipDownload(selectedPaths);
}

// Perform ZIP streaming download for multiple items
async function performBulkZipDownload(paths) {
    try {
        console.log('🔄 Initiating ZIP stream download for paths:', paths);
        showUploadStatus('📦 Preparing ZIP download...', 'info');

        // Track download to prevent beforeunload warning
        const downloadId = Date.now() + Math.random();
        activeDownloads.add(downloadId);

        // Use form submission method for large files - no memory limits
        console.log('📥 Using form submission for large file download (no memory limits)');

        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '/bulk-download';
        form.style.display = 'none';

        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'paths';
        input.value = JSON.stringify(paths);
        form.appendChild(input);

        // This is a real <form>.submit() navigation, NOT fetch/XHR, so the
        // CSRF-injecting fetch() wrapper (top of this file) never touches
        // it — that wrapper only patches window.fetch. Flask-WTF looks for
        // the token in an X-CSRFToken header OR a form field literally
        // named "csrf_token"; a browser form submit can only supply the
        // latter. Fetch a guaranteed-current token right before building
        // the form (not the possibly-stale <meta> tag — see the fetch
        // wrapper's comment on session.clear() invalidating it across
        // tabs) so this keeps working even right after switching accounts.
        const csrfToken = (window._refreshCsrfToken && await window._refreshCsrfToken())
            || (window._getCsrfToken && window._getCsrfToken());
        if (csrfToken) {
            const csrfInput = document.createElement('input');
            csrfInput.type = 'hidden';
            csrfInput.name = 'csrf_token';
            csrfInput.value = csrfToken;
            form.appendChild(csrfInput);
        }

        document.body.appendChild(form);
        form.submit();

        setTimeout(() => {
            if (document.body.contains(form)) {
                document.body.removeChild(form);
            }
            // Remove from active downloads after form submission completes
            activeDownloads.delete(downloadId);
        }, 2000);

        showUploadStatus('✅ Large file ZIP download started', 'success');
        clearSelection();

    } catch (error) {
        console.error('❌ ZIP download error:', error);
        showUploadStatus(`❌ Download failed: ${error.message}`, 'error');
    }
}

// Create Folder Function
async function createFolder(folderName, path) {
    try {
        // Use the global currentPath variable instead of the passed path
        const actualPath = currentPath || path || '';

        console.log('Creating folder with currentPath:', actualPath);

        const formData = new FormData();
        formData.append('foldername', folderName);
        formData.append('path', actualPath);

        const response = await fetch('/mkdir', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (response.ok) {
            showNotification('Folder Created', result.message, 'success');
            document.getElementById('folderNameInput').value = '';
            await refreshFileTable();
            refreshStorageStats('folder creation');
        } else {
            showNotification('Create Folder Failed', result.error, 'error');
        }
    } catch (error) {
        showNotification('Create Folder Failed', error.message, 'error');
    }
}

// Delete Modal Functions
let currentDeleteTarget = null;
let currentDeleteType = 'individual'; // 'individual' or 'bulk'

function showDeleteModal(itemName, deleteCallback, type = 'individual') {
    console.log('showDeleteModal called:', itemName, type);
    currentDeleteTarget = deleteCallback;
    currentDeleteType = type;

    const modal = document.getElementById('deleteModal');
    const message = document.getElementById('deleteMessage');

    if (type === 'bulk') {
        const selectedPaths = Array.from(selectedItems);
        message.textContent = `Are you sure you want to delete ${selectedPaths.length} selected item(s)? This action cannot be undone.`;
    } else {
        message.textContent = `Are you sure you want to delete "${itemName}"? This action cannot be undone.`;
    }

    modal.classList.add('show');
}

function closeDeleteModal() {
    const modal = document.getElementById('deleteModal');
    modal.classList.remove('show');
    currentDeleteTarget = null;
    currentDeleteType = 'individual';
}

function confirmDelete() {
    if (currentDeleteTarget) {
        currentDeleteTarget();
    }
    closeDeleteModal();
}

// Notification Modal Functions
function showNotification(title, message, type = 'info') {
    const modal = document.getElementById('notificationModal');
    const titleElement = document.getElementById('notificationTitle');
    const messageElement = document.getElementById('notificationMessage');

    titleElement.textContent = title;
    messageElement.textContent = message;

    // Add appropriate icon based on type
    const icon = type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️';
    titleElement.textContent = `${icon} ${title}`;

    modal.classList.add('show');
}

function closeNotificationModal() {
    const modal = document.getElementById('notificationModal');
    modal.classList.remove('show');
}

// Individual Delete Function
async function deleteItem(itemPath, itemName) {
    console.log('deleteItem called:', itemPath, itemName);
    _mutationInFlight = true;
    _deletingPaths.add(itemPath);

    // Immediately mark the target cell as deleting so the user gets instant feedback
    document.querySelectorAll(`.dir-info-cell[data-dir-path="${itemPath}"]`).forEach(cell => {
        cell.innerHTML = '<i class="fas fa-spinner fa-spin" style="opacity:0.6;font-size:11px;"></i> Deleting…';
        cell.dataset.loaded = '';
    });

    try {
        const response = await fetch('/delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `target_path=${encodeURIComponent(itemPath)}`
        });
        if (response.ok) {
            showUploadStatus(`🗑️ Successfully deleted "${itemName}"`, 'success');
            clearSelection();
            if (isSearchResultsDisplayed) {
                // In deep search mode refreshFileTable() is a no-op (intentionally
                // skipped to preserve the search view).  Search results are windowed,
                // so drop the deleted path from the result data and re-mount.
                _dsRemoveResults([itemPath]);
            } else {
                await refreshFileTable();
            }
        } else {
            const errorText = await response.text();
            showUploadStatus(`❌ Failed to delete "${itemName}": ${errorText}`, 'error');
        }
    } catch (error) {
        console.error('Delete error:', error);
        showUploadStatus(`❌ Delete failed: ${error.message}`, 'error');
    } finally {
        _deletingPaths.delete(itemPath);
        VT.clearDirCache();
        setTimeout(() => { _mutationInFlight = false; }, 1500);
    }
}

// Add manual cleanup button for debugging/admin use

// Function to update manual cleanup button visibility
async function updateManualCleanupButton() {
    const cleanupBtn = document.getElementById('manualCleanupBtn');
    if (!cleanupBtn) return;

    try {
        // Check both upload status and assembly status
        const [uploadResponse, assemblyResponse] = await Promise.all([
            fetch('/admin/upload_status'),
            fetch('/api/assembly_status')
        ]);

        let hasActiveUploads = false;
        let hasActiveAssembly = false;
        let chunkCount = 0;

        // Check upload status
        if (uploadResponse.ok) {
            const uploadStatus = await uploadResponse.json();
            hasActiveUploads = uploadStatus.has_active_uploads;
            chunkCount = typeof uploadStatus.chunk_count === 'number' ? uploadStatus.chunk_count : 0;
        }

        // Check assembly status
        if (assemblyResponse.ok) {
            const assemblyStatus = await assemblyResponse.json();
            const activeJobs = assemblyStatus.jobs || [];
            hasActiveAssembly = activeJobs.some(job =>
                job.status === 'pending' || job.status === 'processing'
            );

            if (hasActiveAssembly) {
                console.log(`🔐 Cleanup button disabled - ${activeJobs.length} active assembly jobs`);
            }
        }

        // Disable button if there are active uploads OR active assembly jobs
        if (isUploading || hasActiveAssembly) {
            cleanupBtn.style.setProperty('display', 'none', 'important');
            if (isUploading) {
                cleanupBtn.title = 'Manual cleanup disabled during active uploads';
            } else if (hasActiveAssembly) {
                cleanupBtn.title = 'Manual cleanup disabled during file processing/assembly';
            }
        } else {
            cleanupBtn.style.setProperty('display', 'inline-flex', 'important');
            // Update title based on whether chunks exist
            if (hasActiveUploads && chunkCount > 0) {
                cleanupBtn.title = `Clean up ${chunkCount} temporary chunk files (Safe - no active uploads or processing)`;
                cleanupBtn.innerHTML = '<i class="fas fa-broom"></i> Cleanup Chunk (' + chunkCount + ')';
            } else {
                cleanupBtn.title = 'Clean up temporary chunk files (Safe - no active uploads or processing)';
                cleanupBtn.innerHTML = '<i class="fas fa-broom"></i> Cleanup Chunk';
            }
        }
    } catch (error) {
        console.warn('Failed to check upload/assembly status:', error);
        // On error, hide the button to be safe
        cleanupBtn.style.setProperty('display', 'none', 'important');
        cleanupBtn.title = 'Manual cleanup disabled (Status check failed)';
    }
}

// ---------------------------------------------------------------------------
// 4.66: Rebuild Cache button state lives OUTSIDE the button. The rebuild runs on
// the server, so after a page refresh (or any rebuild of the toolbar) the button
// must ask the server and, if a rebuild is still running, come back disabled with
// its timer - not clickable. ONE follower polls the status route (every 3 s);
// the label is repainted every second from a clock, so the timer counts 1,2,3...
// ---------------------------------------------------------------------------
const _REBUILD_IDLE_HTML = '<i class="fas fa-database"></i> Rebuild Cache';
let _rebuildFollow = null;   // { t0, detail } while a rebuild is being followed

function _rebuildBtn() { return document.getElementById('cleanupCacheBtn'); }

function _paintRebuildBtn() {
    const b = _rebuildBtn();
    if (!b) return;
    if (_rebuildFollow) {
        const secs = Math.max(0, Math.floor((Date.now() - _rebuildFollow.t0) / 1000));
        b.disabled = true;
        b.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Rebuilding... ' +
            Math.floor(secs / 60) + ':' + String(secs % 60).padStart(2, '0') +
            (_rebuildFollow.detail ? ' - ' + _rebuildFollow.detail : '');
    } else {
        b.disabled = false;
        b.innerHTML = _REBUILD_IDLE_HTML;
    }
}

// 5.44.1: one short line on what a running rebuild is doing, from the status route:
// "waiting for another walk to finish", "walking: 412,000 files", or the worker's phase.
function _rebuildDetail(st) {
    const w = st.walk || {};
    if (st.phase === 'walking the storage') {
        if (w.phase === 'walking') {
            return 'walking: ' + Number(w.files || 0).toLocaleString() + ' files';
        }
        if (w.waiters > 0) return 'waiting for another walk to finish';
        return 'starting the walk';
    }
    return st.phase || '';
}

async function _readJsonSafe(resp) {
    try { return await resp.json(); } catch (e) { return {}; }
}

// Follow a running rebuild until it ends. t0 = local ms timestamp of its start.
async function _followRebuild(t0) {
    if (_rebuildFollow) return;   // already being followed
    _rebuildFollow = { t0 };
    const ticker = setInterval(_paintRebuildBtn, 1000);
    _paintRebuildBtn();
    try {
        let failures = 0;
        while (true) {
            await new Promise(r => setTimeout(r, 3000));
            let st;
            try {
                const r = await fetch('/admin/rebuild_cache/status', { cache: 'no-store' });
                st = await _readJsonSafe(r);
                if (!r.ok) throw new Error(st.error || `HTTP ${r.status}`);
                failures = 0;
            } catch (e) {
                if (++failures >= 5) {
                    throw new Error('lost contact with the server while waiting; the rebuild may still be running');
                }
                continue;
            }
            if (_rebuildFollow) _rebuildFollow.detail = _rebuildDetail(st);
            _paintRebuildBtn();
            if (st.state === 'done') {
                showUploadStatus('✅ ' + (st.message || 'Cache cleared and rebuilt successfully'), 'success');
                break;
            }
            if (st.state === 'error') {
                throw new Error(st.error || 'Cache rebuild failed');
            }
            if (st.state === 'idle') {
                throw new Error('the server has no rebuild in progress (it may have restarted)');
            }
            if ((Date.now() - _rebuildFollow.t0) > 3600 * 1000) {
                throw new Error('still running after 60 minutes' +
                    (_rebuildFollow.detail ? ' (' + _rebuildFollow.detail + ')' : '') +
                    '; check the server log');
            }
        }
    } catch (error) {
        showUploadStatus(`❌ Cache cleanup failed: ${error.message}`, 'error');
    } finally {
        clearInterval(ticker);
        _rebuildFollow = null;
        _paintRebuildBtn();
    }
}

// Called when the button is (re)created: hold it disabled until the server says
// whether a rebuild is running, then either attach to it or enable the button.
async function _syncRebuildButton() {
    if (_rebuildFollow) { _paintRebuildBtn(); return; }
    const b = _rebuildBtn();
    if (b) b.disabled = true;
    try {
        const r = await fetch('/admin/rebuild_cache/status', { cache: 'no-store' });
        const st = await _readJsonSafe(r);
        if (r.ok && st.state === 'running') {
            _followRebuild(Date.now() - (typeof st.elapsed === 'number' ? st.elapsed * 1000 : 0));
            return;
        }
    } catch (e) { /* fall through: enable the button */ }
    _paintRebuildBtn();
}

// Add manual cleanup button for debugging/admin use
function addManualCleanupButton() {
    const controls = document.querySelector('.controls');
    if (controls && USER_ROLE === 'readwrite') {

        // Group the admin buttons in their own wrapper so they wrap as a
        // single unit (stay in one row together, drop to a new line as a
        // group) instead of each button wrapping independently next to the
        // create-folder form. Fixes misalignment on tablet widths and the
        // "one giant full-width button per row" look on mobile.
        let adminActions = controls.querySelector('.admin-actions');
        if (!adminActions) {
            adminActions = document.createElement('div');
            adminActions.className = 'admin-actions';
            controls.appendChild(adminActions);
        }

        // --- Cleanup Chunk button ---
        const cleanupBtn = document.createElement('button');
        cleanupBtn.id = 'manualCleanupBtn';
        cleanupBtn.className = 'btn btn-warning btn-sm manual-cleanup-btn';
        cleanupBtn.innerHTML = '<i class="fas fa-broom"></i> Cleanup Chunk';
        cleanupBtn.style.display = 'none';
        cleanupBtn.title = 'Checking safety status...';

        cleanupBtn.onclick = async function () {
            try {
                const assemblyResponse = await fetch('/api/assembly_status');
                if (assemblyResponse.ok) {
                    const assemblyStatus = await assemblyResponse.json();
                    const activeJobs = assemblyStatus.jobs || [];
                    const hasActiveAssembly = activeJobs.some(job =>
                        job.status === 'pending' || job.status === 'processing'
                    );
                    if (hasActiveAssembly) {
                        showUploadStatus('❌ Cannot cleanup - files are currently being processed/assembled', 'error');
                        return;
                    }
                }
                cleanupBtn.disabled = true;
                cleanupBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Cleaning...';
                const response = await fetch('/admin/cleanup_chunks', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                const result = await response.json();
                if (response.ok) {
                    showUploadStatus('🧹 Temp chunked files cleanup completed', 'success');
                } else {
                    throw new Error(result.error || 'Cleanup failed');
                }
            } catch (error) {
                showUploadStatus(`❌ Cleanup failed: ${error.message}`, 'error');
            } finally {
                cleanupBtn.disabled = false;
                cleanupBtn.innerHTML = '<i class="fas fa-broom"></i> Cleanup Chunk';
                updateManualCleanupButton();
            }
        };

        adminActions.appendChild(cleanupBtn);

        // --- Rebuild Cache button ---
        const cacheBtn = document.createElement('button');
        cacheBtn.id = 'cleanupCacheBtn';
        cacheBtn.className = 'btn btn-warning btn-sm manual-cleanup-btn';
        cacheBtn.innerHTML = '<i class="fas fa-database"></i> Rebuild Cache';
        cacheBtn.title = 'Delete storage_index.json and file_index.json and rebuild both from scratch (the search index is kept)';

        cacheBtn.onclick = async function () {
            if (!confirm('This will delete the storage index cache and rebuild it from scratch.\nThe server re-scans every file in the background - on a large tree this can take several minutes. You can keep using the page.\n\nContinue?')) {
                return;
            }
            try {
                cacheBtn.disabled = true;
                cacheBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Starting...';
                const startResp = await fetch('/admin/rebuild_cache', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                const startData = await _readJsonSafe(startResp);
                // 202 = started, 409 = one is already running: follow it either way
                if (!startResp.ok && startResp.status !== 409) {
                    throw new Error(startData.error || `server answered HTTP ${startResp.status}`);
                }
                const elapsed = (startResp.status === 409 && typeof startData.elapsed === 'number') ? startData.elapsed : 0;
                await _followRebuild(Date.now() - elapsed * 1000);
            } catch (error) {
                showUploadStatus(`❌ Cache cleanup failed: ${error.message}`, 'error');
                _paintRebuildBtn();
            }
        };

        adminActions.appendChild(cacheBtn);
        _syncRebuildButton();

        // --- Clean Media Preview button ---
        const mediaPreviewBtn = document.createElement('button');
        mediaPreviewBtn.id = 'cleanupMediaPreviewBtn';
        mediaPreviewBtn.className = 'btn btn-warning btn-sm manual-cleanup-btn';
        mediaPreviewBtn.innerHTML = '<i class="fas fa-image"></i> Clear Media Preview';
        mediaPreviewBtn.title = 'Delete the media preview cache';

        mediaPreviewBtn.onclick = async function () {
            if (!confirm(
                'This will delete all HLS transcode and image preview cache files.\n' +
                'Active transcodes and conversions in progress will be preserved.\n\n' +
                'Continue?'
            )) {
                return;
            }
            try {
                mediaPreviewBtn.disabled = true;
                mediaPreviewBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Clearing...';
                const response = await fetch('/admin/clear_media_preview', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                const result = await response.json();
                if (response.ok) {
                    showUploadStatus(`🧹 ${result.message}`, 'success');
                } else {
                    throw new Error(result.error || 'Clear media preview failed');
                }
            } catch (error) {
                showUploadStatus(`❌ Clear media preview failed: ${error.message}`, 'error');
            } finally {
                mediaPreviewBtn.disabled = false;
                mediaPreviewBtn.innerHTML = '<i class="fas fa-image"></i> Clear Media Preview';
            }
        };

        adminActions.appendChild(mediaPreviewBtn);

        // --- Manage Shared button ---
        const manageSharedBtn = document.createElement('button');
        manageSharedBtn.id = 'manageSharedBtn';
        manageSharedBtn.className = 'btn btn-primary btn-sm manual-cleanup-btn';
        manageSharedBtn.innerHTML = '<i class="fas fa-shield-halved"></i> Manage Shared' +
            '<span id="manageSharedBtnBadge" class="notif-badge" style="display:none;">0</span>';
        manageSharedBtn.title = 'View and manage every active share link, approve access requests, or revoke all links';
        manageSharedBtn.onclick = openManageSharedModal;

        adminActions.appendChild(manageSharedBtn);
        _startManageSharedBadgePolling();

    }
}

// ---------------------------------------------------------------------------
// Share links — per-item share/unshare modal (with security: passkey /
// approval / expiry), bulk share/unshare, and the admin "Manage Shared"
// panel (active shares, pending approval requests, revoke-all).
// ---------------------------------------------------------------------------

function _fmtEpoch(sec) {
    if (!sec) return 'Never';
    const d = new Date(sec * 1000);
    const now = Date.now();
    const diff = sec * 1000 - now;
    if (diff <= 0) return 'Expired';
    const days = Math.floor(diff / 86400000);
    if (days >= 1) return `in ${days}d (${d.toLocaleDateString()})`;
    const hours = Math.floor(diff / 3600000);
    if (hours >= 1) return `in ${hours}h`;
    const mins = Math.max(1, Math.floor(diff / 60000));
    return `in ${mins}m`;
}

function _fmtAgo(sec) {
    if (!sec) return '';
    const diff = Date.now() - sec * 1000;
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
}

function _modeBadge(mode) {
    if (mode === 'passkey') return '<span class="mode-badge mode-passkey"><i class="fas fa-key"></i> Passkey</span>';
    if (mode === 'approval') return '<span class="mode-badge mode-approval"><i class="fas fa-user-check"></i> Approval</span>';
    return '<span class="mode-badge mode-public"><i class="fas fa-globe"></i> Public</span>';
}

// --- Security panel (used when creating new shares from the Share modal) ---

function _initShareSecurityPanelEvents() {
    const modeRadios = document.querySelectorAll('input[name="shareSecurityMode"]');
    const passkeySub = document.getElementById('sharePasskeySub');
    modeRadios.forEach(r => r.addEventListener('change', () => {
        if (passkeySub) passkeySub.style.display = (r.checked && r.value === 'passkey') ? 'block' : passkeySub.style.display;
        if (r.checked && r.value !== 'passkey' && passkeySub) passkeySub.style.display = 'none';
    }));
    const expiryPreset = document.getElementById('shareExpiryPreset');
    const expiryCustomSub = document.getElementById('shareExpiryCustomSub');
    if (expiryPreset) {
        expiryPreset.addEventListener('change', () => {
            if (expiryCustomSub) expiryCustomSub.style.display = expiryPreset.value === 'custom' ? 'block' : 'none';
        });
    }
}
document.addEventListener('DOMContentLoaded', _initShareSecurityPanelEvents);

function _computeExpiresAt(presetValue, customValue) {
    if (presetValue === 'never') return null;
    if (presetValue === 'custom') {
        if (!customValue) return null;
        const ms = Date.parse(customValue);
        return isNaN(ms) ? null : Math.floor(ms / 1000);
    }
    const seconds = parseInt(presetValue, 10);
    if (!seconds) return null;
    return Math.floor(Date.now() / 1000) + seconds;
}

function _readShareSecurityPanel() {
    const modeEl = document.querySelector('input[name="shareSecurityMode"]:checked');
    const mode = modeEl ? modeEl.value : 'public';
    const passkeyInput = document.getElementById('sharePasskeyInput');
    const preset = document.getElementById('shareExpiryPreset');
    const customInput = document.getElementById('shareExpiryCustomInput');
    const payload = { security_mode: mode };
    if (mode === 'passkey') {
        const val = passkeyInput ? passkeyInput.value.trim() : '';
        if (val) payload.passkey = val; else payload.generate_passkey = true;
    }
    const expiresAt = _computeExpiresAt(preset ? preset.value : 'never', customInput ? customInput.value : '');
    if (expiresAt) payload.expires_at = expiresAt;
    return payload;
}

// --- Share modal rows ---

function _shareModalRowTemplate(path, name, index) {
    return `
        <div class="share-item-row" data-share-path="${escAttr(path)}" data-row-index="${index}">
            <div class="share-item-row-header">
                <strong class="share-item-name" title="${escAttr(name)}">${escapeHtml(name)}</strong>
                <label class="share-toggle">
                    <input type="checkbox" class="share-toggle-checkbox"
                           data-fn-change="onShareToggleChanged" data-args-change="${dataArgs([path])}">
                    Shared
                </label>
            </div>
            <div class="share-link-row">
                <input type="text" class="form-control share-link-input" readonly>
                <button type="button" class="btn btn-outline btn-sm" data-fn="copyShareLink"
                        data-args="${dataArgs([path])}" title="Copy link"><i class="fas fa-copy"></i></button>
                <button type="button" class="btn btn-danger btn-sm" data-fn="onShareRevokeClicked"
                        data-args="${dataArgs([path])}" title="Revoke this link"><i class="fas fa-ban"></i></button>
            </div>
            <div class="share-security-summary">
                <span class="share-summary-badges"></span>
                <button type="button" class="btn btn-outline btn-xs" data-fn="toggleShareRowEdit"
                        data-args="${dataArgs([path])}"><i class="fas fa-sliders"></i> Edit security</button>
            </div>
            <div class="share-passkey-reveal" style="display:none;"></div>
            <div class="share-row-editor" style="display:none;">
                <div class="share-security-row">
                    <div class="security-mode-options">
                        <label><input type="radio" name="rowMode${index}" value="public"> <i class="fas fa-globe"></i> Public</label>
                        <label><input type="radio" name="rowMode${index}" value="passkey"> <i class="fas fa-key"></i> Passkey</label>
                        <label><input type="radio" name="rowMode${index}" value="approval"> <i class="fas fa-user-check"></i> Approval</label>
                    </div>
                </div>
                <div class="share-security-sub row-passkey-sub" style="display:none;">
                    <input type="text" class="form-control row-passkey-input" placeholder="New passkey — leave blank to keep or auto-generate">
                    <label class="row-generate-label"><input type="checkbox" class="row-generate-passkey"> Generate new random passkey</label>
                </div>
                <div class="share-security-row">
                    <select class="form-control row-expiry-select">
                        <option value="keep">Keep current expiry</option>
                        <option value="never">Never</option>
                        <option value="3600">1 hour</option>
                        <option value="86400">1 day</option>
                        <option value="604800">7 days</option>
                        <option value="2592000">30 days</option>
                        <option value="custom">Custom date…</option>
                    </select>
                </div>
                <div class="share-security-sub row-expiry-custom-sub" style="display:none;">
                    <input type="datetime-local" class="form-control row-expiry-custom-input">
                </div>
                <div class="row-editor-actions">
                    <button type="button" class="btn btn-outline btn-sm" data-fn="toggleShareRowEdit"
                            data-args="${dataArgs([path])}">Cancel</button>
                    <button type="button" class="btn btn-primary btn-sm" data-fn="saveShareRowSettings"
                            data-args="${dataArgs([path])}"><i class="fas fa-check"></i> Save</button>
                </div>
            </div>
            <div class="share-status-loading"><i class="fas fa-spinner fa-spin"></i> Checking current status…</div>
        </div>
    `;
}

function _wireShareRowEditorEvents(row) {
    const modeRadios = row.querySelectorAll('.share-row-editor input[type="radio"]');
    const passkeySub = row.querySelector('.row-passkey-sub');
    modeRadios.forEach(r => r.addEventListener('change', () => {
        if (passkeySub) passkeySub.style.display = r.value === 'passkey' ? 'block' : 'none';
    }));
    const expirySelect = row.querySelector('.row-expiry-select');
    const expiryCustomSub = row.querySelector('.row-expiry-custom-sub');
    if (expirySelect) {
        expirySelect.addEventListener('change', () => {
            if (expiryCustomSub) expiryCustomSub.style.display = expirySelect.value === 'custom' ? 'block' : 'none';
        });
    }
}

async function _renderShareModalRows(items) {
    const container = document.getElementById('shareModalItems');
    if (!container) return;

    const bulkControls = items.length > 1 ? `
        <div class="share-bulk-controls">
            <button type="button" class="btn btn-primary btn-sm" data-fn="bulkShareAll">
                <i class="fas fa-share-nodes"></i> Share All
            </button>
            <button type="button" class="btn btn-outline btn-sm" data-fn="bulkUnshareAll">
                <i class="fas fa-ban"></i> Unshare All
            </button>
        </div>` : '';

    container.innerHTML = bulkControls + items.map((it, i) => _shareModalRowTemplate(it.path, it.name, i)).join('');
    container.querySelectorAll('.share-item-row').forEach(_wireShareRowEditorEvents);

    for (const it of items) {
        try {
            const resp = await fetch(`/api/share/status?path=${encodeURIComponent(it.path)}`);
            const data = await resp.json();
            _applyShareRowState(it.path, resp.ok && data.shared ? data : { shared: false });
        } catch (e) {
            _applyShareRowState(it.path, { shared: false });
        }
    }
}

function _applyShareRowState(path, state) {
    const row = document.querySelector(`.share-item-row[data-share-path="${CSS.escape(path)}"]`);
    if (!row) return;
    const checkbox = row.querySelector('.share-toggle-checkbox');
    const linkRow = row.querySelector('.share-link-row');
    const linkInput = row.querySelector('.share-link-input');
    const loading = row.querySelector('.share-status-loading');
    const summaryEl = row.querySelector('.share-security-summary');
    const badgesEl = row.querySelector('.share-summary-badges');
    if (loading) loading.style.display = 'none';
    if (checkbox) checkbox.checked = !!state.shared;
    if (linkRow) linkRow.style.display = state.shared ? 'flex' : 'none';
    if (linkInput) linkInput.value = state.shared ? (state.share_url || '') : '';
    if (summaryEl) summaryEl.style.display = state.shared ? 'flex' : 'none';

    if (state.shared) {
        row.dataset.securityMode = state.security_mode || 'public';
        row.dataset.hasPasskey = state.has_passkey ? '1' : '';
        row.dataset.expiresAt = state.expires_at || '';
        if (badgesEl) {
            badgesEl.innerHTML = _modeBadge(state.security_mode) +
                ` <span class="expiry-badge"><i class="fas fa-clock"></i> ${escapeHtml(_fmtEpoch(state.expires_at))}</span>`;
        }
        const modeRadio = row.querySelector(`.share-row-editor input[value="${state.security_mode || 'public'}"]`);
        if (modeRadio) modeRadio.checked = true;
        const passkeySub = row.querySelector('.row-passkey-sub');
        if (passkeySub) passkeySub.style.display = state.security_mode === 'passkey' ? 'block' : 'none';
    } else {
        // Unshared (checkbox unticked / revoked) — clear everything the
        // "shared" branch above populates, so a stale passkey-reveal box
        // or an open row editor from the previous share doesn't linger
        // until the modal is closed and reopened.
        delete row.dataset.securityMode;
        delete row.dataset.hasPasskey;
        delete row.dataset.expiresAt;
        if (badgesEl) badgesEl.innerHTML = '';
        const passkeyReveal = row.querySelector('.share-passkey-reveal');
        if (passkeyReveal) {
            passkeyReveal.style.display = 'none';
            passkeyReveal.innerHTML = '';
        }
        const editor = row.querySelector('.share-row-editor');
        if (editor) editor.style.display = 'none';
        const publicRadio = row.querySelector('.share-row-editor input[value="public"]');
        if (publicRadio) publicRadio.checked = true;
        const rowPasskeySub = row.querySelector('.row-passkey-sub');
        if (rowPasskeySub) rowPasskeySub.style.display = 'none';
    }
}

async function showSingleShareModal(itemPath, itemName /*, isDir — server determines this itself */) {
    const modal = document.getElementById('shareModal');
    const title = document.getElementById('shareModalTitle');
    if (title) title.textContent = `Share "${itemName}"`;
    await _renderShareModalRows([{ path: itemPath, name: itemName }]);
    if (modal) modal.classList.add('show');
}

function showBulkShareModal() {
    if (selectedItems.size === 0) {
        showNotification('No Selection', 'No items selected', 'error');
        return;
    }
    const paths = Array.from(selectedItems);
    const title = document.getElementById('shareModalTitle');
    if (title) title.textContent = `Share ${paths.length} Item(s)`;
    _renderShareModalRows(paths.map(p => ({ path: p, name: p.split('/').filter(Boolean).pop() || p })));
    const modal = document.getElementById('shareModal');
    if (modal) modal.classList.add('show');
}

function closeShareModal() {
    const modal = document.getElementById('shareModal');
    if (modal) modal.classList.remove('show');
}

// =============================================================================
// Version History modal — list / restore (to .recovered/, never in-place) /
// download / delete for one file's tracked version history. Backed by
// /api/versions/list, /api/versions/restore, /api/versions/download,
// /api/versions/delete — see app.py + version_history.py.
// =============================================================================

const _VERSION_STATUS_ICON = {
    completed: 'fa-check',
    failed: 'fa-xmark',
    deleted: 'fa-trash',
    pending: 'fa-hourglass-half',
    processing: 'fa-gear',
    verifying: 'fa-magnifying-glass',
};

function _versionStatusBadge(status) {
    const icon = _VERSION_STATUS_ICON[status] || 'fa-circle-question';
    return `<span class="version-status-badge status-${status}"><i class="fas ${icon}"></i> ${status}</span>`;
}

// Restores in flight, keyed "path::versionId". Lives OUTSIDE the DOM/_vhState
// on purpose: _paintVersionHistory() rebuilds the rows' innerHTML, which used
// to throw away a button's `disabled` state mid-restore and let a second click
// start a second rebuild (WinError 32 on the server). The row template reads
// this set, so the loading state survives every repaint and modal reopen.
const _vhRestoring = new Set();
const _vhDownloading = new Set();
const _vhKey = (p, id) => `${p}::${id}`;

function _vhIsRestoring(itemPath, versionId) {
    if (_vhRestoring.has(_vhKey(itemPath, versionId))) return true;
    // Also busy if the SERVER says so (another tab/user, or modal reopened).
    const srv = (_vhState.data && _vhState.data.restoring) || [];
    return _vhState.path === itemPath && srv.includes(versionId);
}

function _versionHistoryRowTemplate(itemPath, itemName, version) {
    const isCompleted = version.status === 'completed';
    const fullDate = version.created_at ? new Date(version.created_at * 1000).toLocaleString() : '—';
    const canWrite = USER_ROLE === 'readwrite';

    const actions = isCompleted ? `
        <div class="version-history-row-actions">
            <button type="button" class="btn btn-outline btn-sm"
                data-fn="downloadVersionAction" data-args="${dataArgs([itemPath, version.version_id])}"
                title="Download this version"${_vhDownloading.has(_vhKey(itemPath, version.version_id)) ? ' disabled' : ''}>
                ${_vhDownloading.has(_vhKey(itemPath, version.version_id))
            ? '<i class="fas fa-spinner fa-spin"></i> Starting…'
            : '<i class="fas fa-download"></i> Download'}
            </button>
            ${canWrite ? `
            <button type="button" class="btn btn-outline btn-sm"
                data-fn="restoreVersionAction" data-args="${dataArgs([itemPath, version.version_id])}"
                title="Reconstruct this version into .recovered/ — never overwrites the live file"
                ${_vhIsRestoring(itemPath, version.version_id) ? 'disabled aria-busy="true"' : ''}>
                ${_vhIsRestoring(itemPath, version.version_id)
                ? '<i class="fas fa-spinner fa-spin"></i> Restoring…'
                : '<i class="fas fa-rotate-left"></i> Restore'}
            </button>
            <button type="button" class="btn btn-danger btn-sm"
                data-fn="showVersionDeleteConfirm" data-args="${dataArgs([version.version_id])}"
                title="Permanently delete this version">
                <i class="fas fa-trash"></i> Delete
            </button>` : ''}
        </div>` : '';

    const errorLine = version.error
        ? `<div class="version-history-error">${escapeHtml(version.error)}</div>` : '';

    const deleteConfirm = canWrite ? `
        <div class="version-history-delete-confirm" id="vh-delete-confirm-${version.version_id}" style="display:none;">
            <p>Type <strong>${escapeHtml(itemName)}</strong> to permanently delete this version. This cannot be
                undone.</p>
            <input type="text" class="form-control" id="vh-delete-input-${version.version_id}" autocomplete="off">
            <div class="version-history-delete-confirm-actions">
                <button type="button" class="btn btn-outline btn-sm"
                    data-fn="cancelVersionDeleteConfirm" data-args="${dataArgs([version.version_id])}">Cancel</button>
                <button type="button" class="btn btn-danger btn-sm"
                    data-fn="confirmDeleteVersionAction"
                    data-args="${dataArgs([itemPath, version.version_id, itemName])}">Confirm Delete</button>
            </div>
        </div>` : '';

    return `
        <div class="version-history-row" data-version-id="${version.version_id}">
            <div class="version-history-row-main">
                ${_versionStatusBadge(version.status)}
                <span class="version-history-date" title="${escapeHtml(fullDate)}">${_fmtAgo(version.created_at)}</span>
                <span class="version-history-size">${formatFileSize(version.size)}</span>
                <span class="version-history-mode">${escapeHtml(version.storage_mode || '')}</span>
            </div>
            ${errorLine}
            ${actions}
            ${deleteConfirm}
        </div>`;
}

// One open Version History modal at a time, so its view state lives here
// rather than being threaded through every data-fn call.
let _vhState = {
    path: null, name: null, data: null,
    showHidden: false,   // reveal failed + deleted rows (hidden by default)
    status: null,        // inline result line: { type: 'success'|'error'|'info', text }
    suppressBanner: false, // a retry just reported "up to date" -> the stale failed row shouldn't nag
    busy: false,         // a retry/clear request is in flight
    clearArmed: false, clearTimer: null,
};

function _vhResetState(itemPath, itemName) {
    clearTimeout(_vhState.clearTimer);
    _vhState = {
        path: itemPath, name: itemName, data: null, showHidden: false, status: null,
        suppressBanner: false, busy: false, clearArmed: false, clearTimer: null
    };
}

function _paintVersionHistory() {
    const container = document.getElementById('versionHistoryList');
    const s = _vhState;
    if (!container || !s.data) return;

    const versions = s.data.versions;
    const retention = s.data.retention;
    const canWrite = USER_ROLE === 'readwrite';
    const isHidden = v => v.status === 'failed' || v.status === 'deleted';
    const failedCount = versions.filter(v => v.status === 'failed').length;
    const hiddenCount = versions.filter(isHidden).length;
    const visible = s.showHidden ? versions : versions.filter(v => !isHidden(v));

    let html = '';

    // "12 of 50 versions kept" — counts completed rows only, same as the
    // engine's retention pass, so failed/deleted rows never use it up.
    if (retention && retention.enabled) {
        const nearLimit = retention.kept >= Math.ceil(retention.max * 0.9);
        const atLimit = retention.kept >= retention.max;
        html += `<div class="version-history-retention${nearLimit ? ' is-near-limit' : ''}">
            <i class="fas fa-layer-group"></i>
            <span>${retention.kept} of ${retention.max} versions kept${atLimit ? ' — saving a new version removes the oldest' : ''}</span>
        </div>`;
    }

    if (s.status) {
        const icon = s.status.type === 'success' ? 'fa-circle-check'
            : s.status.type === 'error' ? 'fa-circle-xmark' : 'fa-circle-info';
        html += `<div class="version-history-status status-${s.status.type}">
            <i class="fas ${icon}"></i><span>${escapeHtml(s.status.text)}</span></div>`;
    }

    // Retry banner: only when the newest attempt overall failed. Retrying always
    // re-captures the live file, so it is one action, not a per-row button.
    const newest = versions[0];
    if (newest && newest.status === 'failed' && canWrite && !s.suppressBanner) {
        html += `<div class="version-history-retry-banner">
            <div class="version-history-retry-banner-text">
                <i class="fas fa-triangle-exclamation"></i>
                <span>The latest snapshot attempt failed${newest.error ? ': ' + escapeHtml(newest.error) : '.'}</span>
            </div>
            <button type="button" class="btn btn-primary btn-sm" ${s.busy ? 'disabled' : ''}
                data-fn="retrySnapshotAction" data-args="${dataArgs([s.path, s.name])}">
                <i class="fas ${s.busy ? 'fa-spinner fa-spin' : 'fa-rotate-right'}"></i> ${s.busy ? 'Retrying…' : 'Retry Now'}
            </button>
        </div>`;
    }

    if (hiddenCount > 0) {
        const clearBtn = (canWrite && failedCount > 0) ? `
            <button type="button" class="btn ${s.clearArmed ? 'btn-danger' : 'btn-outline'} btn-sm" ${s.busy ? 'disabled' : ''}
                data-fn="clearFailedAction"
                title="Permanently remove failed attempts. Nothing restorable is lost — a failed attempt never captured any content.">
                <i class="fas fa-broom"></i>
                ${s.clearArmed ? `Click again to clear ${failedCount}` : `Clear failed attempts (${failedCount})`}
            </button>` : '';
        html += `<div class="version-history-toolbar">
            <button type="button" class="btn btn-outline btn-sm" data-fn="toggleVersionHistoryHidden">
                <i class="fas ${s.showHidden ? 'fa-eye-slash' : 'fa-eye'}"></i>
                ${s.showHidden ? 'Hide failed & deleted' : `Show failed & deleted (${hiddenCount})`}
            </button>
            ${clearBtn}
        </div>`;
    }

    if (visible.length === 0) {
        html += `<p class="version-history-empty">No saved versions to show. ${hiddenCount} failed/deleted attempt${hiddenCount === 1 ? '' : 's'} hidden.</p>`;
    } else {
        html += visible.map(v => _versionHistoryRowTemplate(s.path, s.name, v)).join('');
    }

    container.innerHTML = html;
}

// silent=true re-fetches without blanking the list to a spinner (used after
// retry/clear so the inline result message doesn't flicker away).
// Parse a JSON body but never throw: a 500 from the server is an HTML page,
// and resp.json() throwing used to be reported as "Could not reach the
// server" even though the server had answered.
async function _vhJson(resp) {
    try {
        return await resp.json();
    } catch (e) {
        return { error: `Server error (HTTP ${resp.status}) — see the server log.` };
    }
}

async function _renderVersionHistoryList(itemPath, itemName, silent = false) {
    const container = document.getElementById('versionHistoryList');
    if (!container) return;
    if (!silent) {
        container.innerHTML = '<div class="share-status-loading"><i class="fas fa-spinner fa-spin"></i> Loading version history…</div>';
    }

    try {
        const resp = await fetch(`/api/versions/list?path=${encodeURIComponent(itemPath)}`);
        const data = await _vhJson(resp);
        if (!resp.ok) {
            container.innerHTML = `<p class="version-history-empty">${escapeHtml(data.error || 'Could not load version history.')}</p>`;
            return;
        }
        if (!data.tracked || !data.versions || data.versions.length === 0) {
            _vhState.data = null;
            container.innerHTML = '<p class="version-history-empty">No version history for this file yet.</p>';
            return;
        }
        _vhState.data = data;
        _paintVersionHistory();
    } catch (e) {
        container.innerHTML = '<p class="version-history-empty">Could not load version history — check your connection.</p>';
    }
}

function toggleVersionHistoryHidden() {
    _vhState.showHidden = !_vhState.showHidden;
    _paintVersionHistory();
}

// Retry reports its result INLINE in the Version History modal. It used to pop
// the shared notification modal, which is redundant here (the list right
// underneath already shows the outcome) and used to render behind this modal.
async function retrySnapshotAction(itemPath, itemName) {
    if (_vhState.busy) return;
    _vhState.busy = true;
    _vhState.status = null;
    _paintVersionHistory();

    try {
        const resp = await fetch('/api/versions/retry', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: itemPath }),
        });
        const data = await _vhJson(resp);
        if (!resp.ok || !data.success) {
            _vhState.status = { type: 'error', text: data.message || data.error || 'Could not retry the snapshot.' };
        } else if (data.version) {
            _vhState.status = { type: 'success', text: 'Snapshot captured — a new version was saved.' };
        } else {
            _vhState.status = { type: 'success', text: 'Already up to date — the file’s current content matches the latest saved version.' };
            _vhState.suppressBanner = true;
        }
    } catch (e) {
        _vhState.status = { type: 'error', text: 'Could not reach the server.' };
    } finally {
        _vhState.busy = false;
    }
    await _renderVersionHistoryList(itemPath, itemName, true);
}

// Two-step: the first click arms the button (5 s), the second click clears.
async function clearFailedAction() {
    const s = _vhState;
    if (s.busy) return;
    if (!s.clearArmed) {
        s.clearArmed = true;
        clearTimeout(s.clearTimer);
        s.clearTimer = setTimeout(() => { s.clearArmed = false; _paintVersionHistory(); }, 5000);
        _paintVersionHistory();
        return;
    }
    clearTimeout(s.clearTimer);
    s.clearArmed = false;
    s.busy = true;
    _paintVersionHistory();

    try {
        const resp = await fetch('/api/versions/clear-failed', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: s.path }),
        });
        const data = await _vhJson(resp);
        s.status = (!resp.ok || !data.success)
            ? { type: 'error', text: data.error || 'Could not clear failed attempts.' }
            : { type: 'success', text: data.message };
        if (resp.ok && data.success) s.suppressBanner = false;
    } catch (e) {
        s.status = { type: 'error', text: 'Could not reach the server.' };
    } finally {
        s.busy = false;
    }
    await _renderVersionHistoryList(s.path, s.name, true);
}

// =============================================================================
// Download Options modal — the row's Download button opens this instead of
// downloading directly, so Version History is reachable without a second
// permanent icon in the row's action bar (which was pushing Delete and
// other icons out of view on narrow screens).
// =============================================================================

let _downloadOptionsTarget = null; // { path, name } for whichever row's modal is open

function showDownloadOptionsModal(itemPath, itemName) {
    _downloadOptionsTarget = { path: itemPath, name: itemName };
    const title = document.getElementById('downloadOptionsModalTitle');
    if (title) title.innerHTML = `<i class="fas fa-download"></i> ${escapeHtml(itemName)}`;
    const modal = document.getElementById('downloadOptionsModal');
    if (modal) modal.classList.add('show');
}

function closeDownloadOptionsModal() {
    const modal = document.getElementById('downloadOptionsModal');
    if (modal) modal.classList.remove('show');
    _downloadOptionsTarget = null;
}

// Wired once at load rather than per-render, since the modal itself is a
// single static element in index.html (not re-created per row) — matches
// how the rest of this file's one-off modals (share, move, rename...)
// attach their static-button handlers.
document.addEventListener('DOMContentLoaded', () => {
    const currentBtn = document.getElementById('downloadOptionCurrent');
    const historyBtn = document.getElementById('downloadOptionHistory');

    if (currentBtn) {
        currentBtn.addEventListener('click', () => {
            if (!_downloadOptionsTarget) return;
            const { path } = _downloadOptionsTarget;
            closeDownloadOptionsModal();
            downloadItem(path);
        });
    }

    if (historyBtn) {
        historyBtn.addEventListener('click', () => {
            if (!_downloadOptionsTarget) return;
            const { path, name } = _downloadOptionsTarget;
            closeDownloadOptionsModal();
            showVersionHistoryModal(path, name);
        });
    }
});

function showVersionHistoryModal(itemPath, itemName) {
    const title = document.getElementById('versionHistoryModalTitle');
    if (title) title.innerHTML = `<i class="fas fa-clock-rotate-left"></i> Version History — ${escapeHtml(itemName)}`;
    const modal = document.getElementById('versionHistoryModal');
    if (modal) modal.classList.add('show');
    _vhResetState(itemPath, itemName);
    _renderVersionHistoryList(itemPath, itemName);
}

function closeVersionHistoryModal() {
    const modal = document.getElementById('versionHistoryModal');
    if (modal) modal.classList.remove('show');
}

function _vhRepaintIfOpen(itemPath) {
    // Only repaint if the modal is still showing this same file.
    if (_vhState.path === itemPath && _vhState.data) _paintVersionHistory();
}

function downloadVersionAction(itemPath, versionId) {
    // Plain navigation, same pattern as downloadItem() — the response
    // carries Content-Disposition: attachment, so this doesn't navigate
    // away from the app. The server now streams straight from the version
    // store (no rebuild), so the browser's own download UI takes over almost
    // immediately; the button is only locked for a moment to stop
    // double-click from starting two downloads.
    const key = _vhKey(itemPath, versionId);
    if (_vhDownloading.has(key)) return;
    _vhDownloading.add(key);
    _vhRepaintIfOpen(itemPath);
    window.location.href = `/api/versions/download?path=${encodePathForUrl(itemPath)}&version_id=${versionId}`;
    setTimeout(() => {
        _vhDownloading.delete(key);
        _vhRepaintIfOpen(itemPath);
    }, 3000);
}

// Another request (double-click in another tab, etc.) is already rebuilding
// this version. Wait for the SERVER to report it finished, rather than
// showing an error or letting the button re-enable.
async function _vhWaitForRestoreToFinish(itemPath, versionId, maxSeconds = 600) {
    const deadline = Date.now() + maxSeconds * 1000;
    while (Date.now() < deadline) {
        await new Promise(r => setTimeout(r, 1500));
        try {
            const resp = await fetch(`/api/versions/list?path=${encodeURIComponent(itemPath)}`);
            const data = await _vhJson(resp);
            if (resp.ok) {
                if (_vhState.path === itemPath) _vhState.data = data;
                if (!(data.restoring || []).includes(versionId)) return true;
            }
        } catch (e) { /* transient — keep waiting */ }
    }
    return false;
}

async function restoreVersionAction(itemPath, versionId, _afterWait = false) {
    const key = _vhKey(itemPath, versionId);
    if (_vhRestoring.has(key)) return;          // already processing — ignore extra clicks
    _vhRestoring.add(key);
    _vhRepaintIfOpen(itemPath);                 // shows "Restoring…" and disables the button

    try {
        const resp = await fetch('/api/versions/restore', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: itemPath, version_id: versionId }),
        });
        const data = await _vhJson(resp);

        if (resp.status === 409 && data.in_progress) {
            // Not an error: it's still rebuilding. Keep the loading state,
            // wait for it to finish, then ask again — the server returns the
            // finished file instantly (no second rebuild).
            if (!_afterWait) {
                const finished = await _vhWaitForRestoreToFinish(itemPath, versionId);
                if (finished) {
                    _vhRestoring.delete(key);
                    return restoreVersionAction(itemPath, versionId, true);
                }
            }
            showNotification('Still Restoring', 'This version is still being rebuilt. Please check again in a moment.', 'info');
            return;
        }

        if (!resp.ok || !data.success) {
            showNotification('Restore Failed', data.error || 'Could not restore this version.', 'error');
            return;
        }
        showNotification(
            'Version Restored',
            `Restored into ${data.recovered_path} — the live file was not changed. ` +
            `You can find it in the .recovered folder, or download it now.`,
            'success'
        );
        if (data.download_url) {
            // Give the user an immediate way to grab the recovered copy
            // without having to browse to .recovered/ themselves.
            setTimeout(() => { window.location.href = data.download_url; }, 400);
        }
    } catch (e) {
        showNotification('Restore Failed', 'Could not reach the server.', 'error');
    } finally {
        _vhRestoring.delete(key);
        _vhRepaintIfOpen(itemPath);
    }
}

function showVersionDeleteConfirm(versionId) {
    const el = document.getElementById(`vh-delete-confirm-${versionId}`);
    if (el) {
        el.style.display = 'block';
        const input = document.getElementById(`vh-delete-input-${versionId}`);
        if (input) input.focus();
    }
}

function cancelVersionDeleteConfirm(versionId) {
    const el = document.getElementById(`vh-delete-confirm-${versionId}`);
    if (el) el.style.display = 'none';
}

async function confirmDeleteVersionAction(itemPath, versionId, itemName) {
    const input = document.getElementById(`vh-delete-input-${versionId}`);
    const confirmText = input ? input.value : '';

    try {
        const resp = await fetch('/api/versions/delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path: itemPath, version_id: versionId, confirm_text: confirmText }),
        });
        const data = await _vhJson(resp);
        if (!resp.ok || !data.success) {
            showNotification('Delete Failed', data.error || 'Could not delete this version.', 'error');
            return;
        }
        showNotification('Version Deleted', data.message || 'Version deleted.', 'success');
        _renderVersionHistoryList(itemPath, itemName, true);
    } catch (e) {
        showNotification('Delete Failed', 'Could not reach the server.', 'error');
    }
}

function _showRowPasskeyReveal(row, passkey) {
    const el = row ? row.querySelector('.share-passkey-reveal') : null;
    if (!el) return;
    el.style.display = 'block';
    el.innerHTML = `<i class="fas fa-key"></i> Passkey: <code>${escapeHtml(passkey)}</code>
        <button type="button" class="btn btn-outline btn-xs" data-fn="copyRevealedPasskey"
                data-args="${dataArgs([passkey])}">Copy</button>
        <span class="passkey-reveal-note">Shown once — save it now.</span>`;
}

function copyRevealedPasskey(passkey) {
    const done = () => showUploadStatus('📋 Passkey copied to clipboard', 'success');
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(passkey).then(done).catch(() => {
            showUploadStatus('❌ Could not copy passkey', 'error');
        });
    } else {
        showUploadStatus('❌ Could not copy passkey', 'error');
    }
}

async function onShareToggleChanged(path) {
    const row = document.querySelector(`.share-item-row[data-share-path="${CSS.escape(path)}"]`);
    const checkbox = row ? row.querySelector('.share-toggle-checkbox') : null;
    if (!checkbox) return;
    const wantShared = checkbox.checked;
    checkbox.disabled = true;
    try {
        if (wantShared) {
            const payload = Object.assign({ path }, _readShareSecurityPanel());
            const resp = await fetch('/api/share', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const data = await resp.json();
            if (resp.ok) {
                _applyShareRowState(path, {
                    shared: true, share_url: data.share_url, security_mode: data.security_mode,
                    has_passkey: !!data.passkey, expires_at: data.expires_at
                });
                if (data.passkey) _showRowPasskeyReveal(row, data.passkey);
                showUploadStatus('🔗 Share link created', 'success');
            } else {
                checkbox.checked = false;
                showUploadStatus(`❌ ${data.error || 'Failed to create share link'}`, 'error');
            }
        } else {
            await _revokeShareForPath(path, /*quiet=*/false);
        }
    } catch (error) {
        checkbox.checked = !wantShared;
        showUploadStatus(`❌ Share update failed: ${error.message}`, 'error');
    } finally {
        checkbox.disabled = false;
    }
}

function onShareRevokeClicked(path) {
    _revokeShareForPath(path, false);
}

async function _revokeShareForPath(path, quiet) {
    try {
        const resp = await fetch('/api/unshare', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ path })
        });
        const data = await resp.json();
        if (resp.ok) {
            _applyShareRowState(path, { shared: false });
            if (!quiet) showUploadStatus('🚫 Share link revoked', 'success');
        } else if (!quiet) {
            showUploadStatus(`❌ ${data.error || 'Failed to revoke share'}`, 'error');
        }
    } catch (error) {
        if (!quiet) showUploadStatus(`❌ Revoke failed: ${error.message}`, 'error');
    }
}

function copyShareLink(path) {
    const row = document.querySelector(`.share-item-row[data-share-path="${CSS.escape(path)}"]`);
    const input = row ? row.querySelector('.share-link-input') : null;
    if (!input || !input.value) return;

    const done = () => showUploadStatus('📋 Link copied to clipboard', 'success');
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(input.value).then(done).catch(() => {
            input.select();
            document.execCommand('copy');
            done();
        });
    } else {
        input.select();
        document.execCommand('copy');
        done();
    }
}

function toggleShareRowEdit(path) {
    const row = document.querySelector(`.share-item-row[data-share-path="${CSS.escape(path)}"]`);
    const editor = row ? row.querySelector('.share-row-editor') : null;
    if (!editor) return;
    editor.style.display = editor.style.display === 'none' ? 'block' : 'none';
}

async function saveShareRowSettings(path) {
    const row = document.querySelector(`.share-item-row[data-share-path="${CSS.escape(path)}"]`);
    if (!row) return;
    const modeEl = row.querySelector('.share-row-editor input[type="radio"]:checked');
    const passkeyInput = row.querySelector('.row-passkey-input');
    const generateCb = row.querySelector('.row-generate-passkey');
    const expirySelect = row.querySelector('.row-expiry-select');
    const expiryCustomInput = row.querySelector('.row-expiry-custom-input');

    const payload = { path }; // resolved server-side to a token via a status lookup fallback below
    if (modeEl) payload.security_mode = modeEl.value;
    if (modeEl && modeEl.value === 'passkey') {
        if (generateCb && generateCb.checked) payload.generate_passkey = true;
        else if (passkeyInput && passkeyInput.value.trim()) payload.passkey = passkeyInput.value.trim();
    } else {
        // Switching to approval/public — don't leave the old passkey active.
        payload.clear_passkey = true;
    }

    const expiryVal = expirySelect ? expirySelect.value : 'keep';
    if (expiryVal === 'never') payload.clear_expiry = true;
    else if (expiryVal !== 'keep') {
        const expiresAt = _computeExpiresAt(expiryVal, expiryCustomInput ? expiryCustomInput.value : '');
        if (expiresAt) payload.expires_at = expiresAt;
    }

    try {
        // /api/share/settings addresses shares by token — look it up from status first.
        const statusResp = await fetch(`/api/share/status?path=${encodeURIComponent(path)}`);
        const statusData = await statusResp.json();
        if (!statusResp.ok || !statusData.shared) {
            showUploadStatus('❌ This item is no longer shared', 'error');
            return;
        }
        payload.token = statusData.token;
        delete payload.path;

        const resp = await fetch('/api/share/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await resp.json();
        if (resp.ok) {
            const refreshed = await (await fetch(`/api/share/status?path=${encodeURIComponent(path)}`)).json();
            _applyShareRowState(path, refreshed.shared ? refreshed : { shared: false });
            if (data.passkey) _showRowPasskeyReveal(row, data.passkey);
            toggleShareRowEdit(path);
            showUploadStatus('✅ Share settings updated', 'success');
        } else {
            showUploadStatus(`❌ ${data.error || 'Failed to update settings'}`, 'error');
        }
    } catch (error) {
        showUploadStatus(`❌ Failed to update settings: ${error.message}`, 'error');
    }
}

async function bulkShareAll() {
    const rows = document.querySelectorAll('#shareModalItems .share-item-row');
    const paths = Array.from(rows).map(r => r.dataset.sharePath);
    if (paths.length === 0) return;
    try {
        const payload = Object.assign({ paths, action: 'share' }, _readShareSecurityPanel());
        const resp = await fetch('/api/share/bulk', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await resp.json();
        if (resp.ok) {
            for (const path of paths) {
                const r = data.results[path];
                if (r && r.token) {
                    _applyShareRowState(path, {
                        shared: true, share_url: r.share_url, security_mode: payload.security_mode,
                        has_passkey: payload.security_mode === 'passkey', expires_at: payload.expires_at
                    });
                }
            }
            if (data.results._passkey) {
                showUploadStatus(`🔗 Shared ${paths.length} item(s) — passkey: ${data.results._passkey}`, 'success');
            } else {
                showUploadStatus(`🔗 Shared ${paths.length} item(s)`, 'success');
            }
        } else {
            showUploadStatus(`❌ ${data.error || 'Bulk share failed'}`, 'error');
        }
    } catch (error) {
        showUploadStatus(`❌ Bulk share failed: ${error.message}`, 'error');
    }
}

async function bulkUnshareAll() {
    const rows = document.querySelectorAll('#shareModalItems .share-item-row');
    const paths = Array.from(rows).map(r => r.dataset.sharePath);
    if (paths.length === 0) return;
    try {
        const resp = await fetch('/api/share/bulk', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ paths, action: 'unshare' })
        });
        const data = await resp.json();
        if (resp.ok) {
            paths.forEach(path => _applyShareRowState(path, { shared: false }));
            showUploadStatus(`🚫 Unshared ${paths.length} item(s)`, 'success');
        } else {
            showUploadStatus(`❌ ${data.error || 'Bulk unshare failed'}`, 'error');
        }
    } catch (error) {
        showUploadStatus(`❌ Bulk unshare failed: ${error.message}`, 'error');
    }
}

// ---------------------------------------------------------------------------
// Manage Shared (admin) — Active Shares / Pending Requests / Danger Zone
// ---------------------------------------------------------------------------

function openManageSharedModal() {
    const modal = document.getElementById('manageSharedModal');
    if (modal) modal.classList.add('show');
    switchManageSharedTab('active'); // also refreshes counts now
    _startManageSharedVisibilityRefresh();
}

function closeManageSharedModal() {
    const modal = document.getElementById('manageSharedModal');
    if (modal) modal.classList.remove('show');
    _revokeAllSharesNonce = null;
    _revokeAllSharesCode = null;
    _clearShareExpiryTimers();
    _stopManageSharedVisibilityRefresh();
}

// The per-share setTimeout in _scheduleShareExpiryTimers is a nice
// "instant while the tab is actually active" mechanism, but browsers
// (especially Chrome on Android) can significantly delay or fully
// suspend setTimeout/setInterval callbacks in a tab that isn't the
// current foreground/visible one — screen locked, app-switched away,
// even briefly. When that happens the timer just doesn't fire on
// schedule, and the modal is left showing a share the server has
// already expired/pruned. As a safety net, force a full refresh of
// whichever Manage Shared tab is open every time the tab regains
// visibility while the modal is up — same pattern already used for
// the pending-requests badge fallback.
let _manageSharedVisibilityHandler = null;

function _startManageSharedVisibilityRefresh() {
    if (_manageSharedVisibilityHandler) return; // already running
    _manageSharedVisibilityHandler = () => {
        if (document.visibilityState !== 'visible') return;
        const modal = document.getElementById('manageSharedModal');
        if (!modal || !modal.classList.contains('show')) return;
        const activePanel = document.getElementById('manageSharedPanel-active');
        const reqPanel = document.getElementById('manageSharedPanel-requests');
        if (activePanel && activePanel.style.display !== 'none') loadManageSharedActive();
        else if (reqPanel && reqPanel.style.display !== 'none') loadManageSharedRequests();
        _refreshManageSharedCounts();
    };
    document.addEventListener('visibilitychange', _manageSharedVisibilityHandler);
}

function _stopManageSharedVisibilityRefresh() {
    if (!_manageSharedVisibilityHandler) return;
    document.removeEventListener('visibilitychange', _manageSharedVisibilityHandler);
    _manageSharedVisibilityHandler = null;
}


function switchManageSharedTab(tab) {
    document.querySelectorAll('.manage-shared-tab').forEach(btn => btn.classList.remove('active'));
    const activeBtn = Array.from(document.querySelectorAll('.manage-shared-tab'))
        .find(btn => btn.getAttribute('data-args') === JSON.stringify([tab]));
    if (activeBtn) activeBtn.classList.add('active');

    ['active', 'requests', 'danger'].forEach(t => {
        const panel = document.getElementById(`manageSharedPanel-${t}`);
        if (panel) panel.style.display = t === tab ? 'block' : 'none';
    });

    if (tab === 'active') loadManageSharedActive();
    else if (tab === 'requests') loadManageSharedRequests();
    else if (tab === 'danger') _openDangerZone();

    // Row lists refetch themselves on every tab switch, but the pill counts
    // next to each tab label were only ever refreshed on modal-open or after
    // an explicit revoke/approve/deny action — switching tabs never touched
    // them, so they'd silently go stale (e.g. an expired share vanishing
    // from the Active list on refetch, while its pill count stayed frozen
    // at the old number). Keep them in lockstep with whatever's on screen.
    _refreshManageSharedCounts();
}

// Per-share timers so the Active Shares tab (list + pill counts) updates
// the instant a share crosses its expires_at, instead of waiting for the
// next tab switch/modal reopen. We already know each share's exact expiry
// timestamp from the API response, so rather than polling faster (which
// only shrinks the staleness window, never closes it), we schedule a
// one-shot timeout for exactly when it happens and reconcile with the
// server at that moment. setTimeout has a ~24.8-day max delay, so shares
// expiring further out just aren't scheduled yet — they'll get picked up
// next time the list is fetched and is closer to their expiry.
const _manageShareExpiryTimers = new Map(); // token -> timeoutId
const MAX_TIMEOUT_MS = 2 ** 31 - 1;
// Small cushion so the client timer never fires before the server's own
// clock would agree the share is expired — without this, a browser clock
// running even a second ahead of the server causes the row to vanish from
// the DOM while the server still counts it as active for a moment,
// leaving the tab pill showing a stale (too-high) number.
const EXPIRY_BUFFER_MS = 2000;

function _clearShareExpiryTimers() {
    _manageShareExpiryTimers.forEach(id => clearTimeout(id));
    _manageShareExpiryTimers.clear();
}

function _scheduleShareExpiryTimers(shares) {
    _clearShareExpiryTimers();
    const now = Date.now();
    shares.forEach(share => {
        if (!share.expires_at) return;
        const delay = share.expires_at * 1000 - now + EXPIRY_BUFFER_MS;
        if (delay <= 0 || delay > MAX_TIMEOUT_MS) return; // already past, or too far out to schedule
        const id = setTimeout(() => _onShareExpiredClientSide(share.token), delay);
        _manageShareExpiryTimers.set(share.token, id);
    });
}

function _onShareExpiredClientSide(token) {
    _manageShareExpiryTimers.delete(token);
    // Re-render from the server's own answer rather than mutating the DOM
    // ourselves — that's what keeps the visible list and the tab pill
    // counts guaranteed to agree, since both come from the same fetch.
    const activePanel = document.getElementById('manageSharedPanel-active');
    if (activePanel && activePanel.style.display !== 'none') {
        loadManageSharedActive();
    }
    _refreshManageSharedCounts();
}

async function _refreshManageSharedCounts() {
    try {
        const [activeResp, reqResp] = await Promise.all([
            fetch('/admin/shares'), fetch('/admin/shares/requests')
        ]);
        const activeData = await activeResp.json();
        const reqData = await reqResp.json();
        const activeCountEl = document.getElementById('manageSharedActiveCount');
        const reqCountEl = document.getElementById('manageSharedRequestsCount');
        if (activeCountEl && activeResp.ok) activeCountEl.textContent = activeData.shares.length;
        if (reqCountEl && reqResp.ok) reqCountEl.textContent = reqData.requests.length || '';
        if (reqResp.ok) _setManageSharedBadge(reqData.requests.length);
        if (activeResp.ok) _scheduleShareExpiryTimers(activeData.shares);
    } catch (e) { /* non-fatal */ }
}

function _setManageSharedBadge(count) {
    const badge = document.getElementById('manageSharedBtnBadge');
    if (!badge) return;
    if (count > 0) {
        badge.textContent = count > 99 ? '99+' : String(count);
        badge.style.display = 'inline-flex';
    } else {
        badge.style.display = 'none';
    }
}

async function _pollManageSharedBadge() {
    try {
        const resp = await fetch('/admin/shares/requests');
        if (!resp.ok) return;
        const data = await resp.json();
        _setManageSharedBadge(data.requests.length);
    } catch (e) { /* non-fatal — network hiccup, try again next tick */ }
}

// ---------------------------------------------------------------------------
// Live badge via SSE. The server pushes a fresh pending-request count the
// instant a request is created/approved/denied (see realtime_shares.py /
// /admin/shares/requests/stream) — this is genuinely real-time, not a fast
// poll. EventSource reconnects automatically on transient drops; if the
// browser gives up entirely (or doesn't support EventSource at all), we
// fall back to the old interval-poll-plus-refresh-on-focus behavior so the
// badge still stays roughly current instead of going silent forever.
// ---------------------------------------------------------------------------
let _manageSharedBadgeInterval = null;
let _shareEventsSource = null;

function _startManageSharedBadgePolling() {
    if (_manageSharedBadgeInterval || _shareEventsSource) return; // already running
    _pollManageSharedBadge(); // paint a real value immediately while the stream connects
    _startShareEventsStream();
}

// 4.67: paused while the tab stays hidden (see _pauseLiveStreams); on return the badge
// is polled once and the stream reopened.
let _shareStreamPaused = false;
function _pauseShareEventsStream() {
    if (!_shareEventsSource) return;   // not running (or already in fallback polling)
    try { _shareEventsSource.close(); } catch (e) { }
    _shareEventsSource = null;
    _shareStreamPaused = true;
}
function _resumeShareEventsStream() {
    if (!_shareStreamPaused) return;
    _shareStreamPaused = false;
    _pollManageSharedBadge();          // catch up on anything missed while paused
    _startShareEventsStream();
}

function _startShareEventsStream() {
    if (typeof EventSource === 'undefined') {
        _fallBackToBadgePolling();
        return;
    }
    try {
        _shareEventsSource = new EventSource('/admin/shares/requests/stream');
        _shareEventsSource.onmessage = function (e) {
            let data;
            try { data = JSON.parse(e.data); } catch (err) { return; }

            if (data.type === 'share_requests_update') {
                _setManageSharedBadge(data.pending_count);
                const reqCountEl = document.getElementById('manageSharedRequestsCount');
                if (reqCountEl) reqCountEl.textContent = data.pending_count || '';

                // If the Pending Requests tab is the one currently open, refresh
                // its row list too, so an approve/deny from another session (or
                // a brand-new request) shows up without a manual reopen.
                const reqPanel = document.getElementById('manageSharedPanel-requests');
                if (reqPanel && reqPanel.style.display !== 'none') {
                    loadManageSharedRequests();
                }
            } else if (data.type === 'active_shares_changed') {
                // Server revoked an expired share — from the 15s sweep, or a
                // visitor/admin lazily triggering it. This is the mechanism
                // that makes expiry removal actually live, since it doesn't
                // depend on a client-side setTimeout ever firing (browsers,
                // especially mobile, can throttle/suspend those in a
                // backgrounded tab). Refresh whatever's on screen.
                const modal = document.getElementById('manageSharedModal');
                const modalOpen = modal && modal.classList.contains('show');
                const activePanel = document.getElementById('manageSharedPanel-active');
                if (modalOpen && activePanel && activePanel.style.display !== 'none') {
                    loadManageSharedActive();
                }
                if (modalOpen) _refreshManageSharedCounts();
            }
            // else: 'connected' / 'ping' — nothing to do
        };
        _shareEventsSource.onerror = function () {
            if (_shareEventsSource && _shareEventsSource.readyState === EventSource.CLOSED) {
                _shareEventsSource = null;
                _fallBackToBadgePolling();
            }
            // Otherwise EventSource is auto-reconnecting — nothing to do.
        };
    } catch (e) {
        _fallBackToBadgePolling();
    }
}

function _fallBackToBadgePolling() {
    if (_manageSharedBadgeInterval) return; // already running
    _manageSharedBadgeInterval = setInterval(_pollManageSharedBadge, 30000);
    // Browsers throttle (or fully pause) setInterval timers in background
    // tabs to save resources, so a request submitted while this tab wasn't
    // focused can sit un-polled well past the 30s interval. Force a fresh
    // check the instant the tab regains focus, so switching back always
    // reflects reality immediately instead of waiting on a throttled timer.
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') _pollManageSharedBadge();
    });
}

function _manageSharedRowTemplate(share) {
    const path = share.file_path;
    return `
        <div class="manage-share-row" data-token="${escAttr(share.token)}">
            <div class="manage-share-main">
                <i class="fas ${share.is_dir ? 'fa-folder' : 'fa-file'}"></i>
                <div class="manage-share-info">
                    <strong title="${escAttr(path)}">${escapeHtml(share.item_name)}</strong>
                    <div class="manage-share-meta">
                        ${_modeBadge(share.security_mode)}
                        <span class="expiry-badge"><i class="fas fa-clock"></i> ${escapeHtml(_fmtEpoch(share.expires_at))}</span>
                        <span class="downloads-badge"><i class="fas fa-download"></i> ${share.download_count}</span>
                        <span class="created-badge">by ${escapeHtml(share.created_by || '?')} · ${_fmtAgo(share.created_at)}</span>
                    </div>
                </div>
            </div>
            <div class="manage-share-actions">
                <button type="button" class="btn btn-outline btn-xs" data-fn="copyManageShareLink"
                        data-args="${dataArgs([share.share_url])}" title="Copy link"><i class="fas fa-copy"></i></button>
                <button type="button" class="btn btn-danger btn-xs" data-fn="revokeManageShare"
                        data-args="${dataArgs([path])}" title="Revoke"><i class="fas fa-ban"></i> Revoke</button>
            </div>
        </div>
    `;
}

async function loadManageSharedActive() {
    const container = document.getElementById('manageSharedActiveList');
    if (!container) return;
    container.innerHTML = '<div class="share-status-loading"><i class="fas fa-spinner fa-spin"></i> Loading shares…</div>';
    try {
        const resp = await fetch('/admin/shares');
        const data = await resp.json();
        if (!resp.ok) throw new Error(data.error || 'Failed to load shares');
        if (!data.shares.length) {
            container.innerHTML = '<p class="manage-shared-empty">No active share links.</p>';
            return;
        }
        container.innerHTML = data.shares.map(_manageSharedRowTemplate).join('');
        _scheduleShareExpiryTimers(data.shares);
    } catch (error) {
        container.innerHTML = `<p class="manage-shared-empty">❌ ${escapeHtml(error.message)}</p>`;
    }
}

function copyManageShareLink(url) {
    if (!url) return;
    navigator.clipboard && navigator.clipboard.writeText(url);
    showUploadStatus('📋 Link copied to clipboard', 'success');
}

async function revokeManageShare(path) {
    await _revokeShareForPath(path, false);
    loadManageSharedActive();
    _refreshManageSharedCounts();
}

function _manageRequestRowTemplate(req) {
    return `
        <div class="manage-request-row" data-request-id="${req.id}">
            <div class="manage-share-main">
                <i class="fas fa-user-clock"></i>
                <div class="manage-share-info">
                    <strong>${escapeHtml(req.requester_name)}</strong>
                    <div class="manage-share-meta">
                        <span>wants <strong>${escapeHtml(req.item_name)}</strong></span>
                        <span class="created-badge">${_fmtAgo(req.requested_at)}</span>
                    </div>
                    ${req.requester_note ? `<div class="request-note">"${escapeHtml(req.requester_note)}"</div>` : ''}
                </div>
            </div>
            <div class="manage-share-actions request-actions">
                <label class="max-downloads-label">Downloads:
                    <input type="number" class="form-control max-downloads-input" value="1" min="1">
                </label>
                <button type="button" class="btn btn-primary btn-xs" data-fn="approveShareRequest"
                        data-args="${dataArgs([req.id])}"><i class="fas fa-check"></i> Approve</button>
                <button type="button" class="btn btn-danger btn-xs" data-fn="denyShareRequest"
                        data-args="${dataArgs([req.id])}"><i class="fas fa-xmark"></i> Deny</button>
            </div>
        </div>
    `;
}

async function loadManageSharedRequests() {
    const container = document.getElementById('manageSharedRequestsList');
    if (!container) return;
    container.innerHTML = '<div class="share-status-loading"><i class="fas fa-spinner fa-spin"></i> Loading requests…</div>';
    try {
        const resp = await fetch('/admin/shares/requests');
        const data = await resp.json();
        if (!resp.ok) throw new Error(data.error || 'Failed to load requests');
        if (!data.requests.length) {
            container.innerHTML = '<p class="manage-shared-empty">No pending access requests.</p>';
            return;
        }
        container.innerHTML = data.requests.map(_manageRequestRowTemplate).join('');
    } catch (error) {
        container.innerHTML = `<p class="manage-shared-empty">❌ ${escapeHtml(error.message)}</p>`;
    }
}

async function approveShareRequest(id) {
    const row = document.querySelector(`.manage-request-row[data-request-id="${id}"]`);
    const input = row ? row.querySelector('.max-downloads-input') : null;
    const maxDownloads = input ? Math.max(1, parseInt(input.value, 10) || 1) : 1;
    try {
        const resp = await fetch(`/admin/shares/requests/${id}/approve`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ max_downloads: maxDownloads })
        });
        const data = await resp.json();
        if (resp.ok) {
            showUploadStatus('✅ Access approved', 'success');
            loadManageSharedRequests();
            _refreshManageSharedCounts();
        } else {
            showUploadStatus(`❌ ${data.error || 'Failed to approve'}`, 'error');
        }
    } catch (error) {
        showUploadStatus(`❌ Failed to approve: ${error.message}`, 'error');
    }
}

async function denyShareRequest(id) {
    try {
        const resp = await fetch(`/admin/shares/requests/${id}/deny`, { method: 'POST' });
        const data = await resp.json();
        if (resp.ok) {
            showUploadStatus('🚫 Access denied', 'success');
            loadManageSharedRequests();
            _refreshManageSharedCounts();
        } else {
            showUploadStatus(`❌ ${data.error || 'Failed to deny'}`, 'error');
        }
    } catch (error) {
        showUploadStatus(`❌ Failed to deny: ${error.message}`, 'error');
    }
}

// --- Danger Zone: revoke ALL share links, gated by a freshly-randomized
// 10-digit code that must be typed back exactly. A new code is minted
// server-side every time this tab is opened, so a remembered/scripted code
// never works for a later attempt. ---
let _revokeAllSharesNonce = null;
let _revokeAllSharesCode = null;

async function _openDangerZone() {
    const countEl = document.getElementById('revokeAllSharesCount');
    const codeEl = document.getElementById('revokeAllSharesCode');
    const inputEl = document.getElementById('revokeAllSharesInput');
    const errorEl = document.getElementById('revokeAllSharesError');

    if (inputEl) inputEl.value = '';
    if (errorEl) errorEl.style.display = 'none';
    if (codeEl) codeEl.textContent = '----------';
    _revokeAllSharesNonce = null;
    _revokeAllSharesCode = null;

    try {
        const countResp = await fetch('/admin/shares/count');
        const countData = await countResp.json();
        if (countEl && countResp.ok) {
            countEl.textContent = `This will revoke ${countData.count} currently active share link(s). This cannot be undone.`;
        }
    } catch (e) { /* non-fatal — proceed without the count */ }

    try {
        const resp = await fetch('/admin/revoke_all_shares/code', { method: 'POST' });
        const data = await resp.json();
        if (resp.ok) {
            _revokeAllSharesNonce = data.nonce;
            _revokeAllSharesCode = data.code;
            if (codeEl) codeEl.textContent = data.code;
        } else {
            showUploadStatus(`❌ ${data.error || 'Failed to start confirmation'}`, 'error');
        }
    } catch (error) {
        showUploadStatus(`❌ Failed to start confirmation: ${error.message}`, 'error');
    }
}

async function confirmRevokeAllShares() {
    const inputEl = document.getElementById('revokeAllSharesInput');
    const errorEl = document.getElementById('revokeAllSharesError');
    const btn = document.getElementById('confirmRevokeAllShares');
    const typed = inputEl ? inputEl.value.trim() : '';

    if (errorEl) errorEl.style.display = 'none';
    if (!_revokeAllSharesNonce) {
        if (errorEl) { errorEl.textContent = 'Confirmation expired — switch tabs and back to get a new code.'; errorEl.style.display = 'block'; }
        return;
    }
    if (!typed) {
        if (errorEl) { errorEl.textContent = 'Type the code shown above to confirm.'; errorEl.style.display = 'block'; }
        return;
    }

    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Revoking...'; }
    try {
        const resp = await fetch('/admin/revoke_all_shares', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nonce: _revokeAllSharesNonce, code: typed })
        });
        const data = await resp.json();
        if (resp.ok) {
            showUploadStatus(`🚫 Revoked ${data.revoked_count} share link(s)`, 'success');
            _revokeAllSharesNonce = null;
            _revokeAllSharesCode = null;
            loadManageSharedActive();
            _refreshManageSharedCounts();
            switchManageSharedTab('active');
        } else {
            if (errorEl) { errorEl.textContent = data.error || 'Failed to revoke — request a new code and try again.'; errorEl.style.display = 'block'; }
        }
    } catch (error) {
        if (errorEl) { errorEl.textContent = `Error: ${error.message}`; errorEl.style.display = 'block'; }
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-ban"></i> Revoke All'; }
    }
}

// Speed Test Modal Functions
function openSpeedTestModal() {
    const modal = document.getElementById('speedTestModal');
    const results = document.getElementById('speedTestResults');
    if (results) results.innerHTML = '<p>Testing connection...</p>';
    if (modal) modal.classList.add('show');
    runSpeedTest();
}

function closeSpeedTestModal() {
    const modal = document.getElementById('speedTestModal');
    if (modal) modal.classList.remove('show');
}

// Speed Test Logic
async function runSpeedTest() {
    const results = document.getElementById('speedTestResults');
    const TEST_SIZE = 5 * 1024 * 1024; // 5 MiB
    let latency = null, uploadMbps = null, downloadMbps = null;

    try {
        // 1. Latency test (small ping)
        const t0 = performance.now();
        await fetch('/api/speedtest/ping', { method: 'GET' });
        const t1 = performance.now();
        latency = t1 - t0;

        // 2. Upload test
        const uploadData = new Uint8Array(TEST_SIZE); // 5MiB zeroes
        const uploadForm = new FormData();
        uploadForm.append('data', new Blob([uploadData]), 'speedtest.bin');
        const uploadStart = performance.now();
        await fetch('/api/speedtest/upload', { method: 'POST', body: uploadForm });
        const uploadEnd = performance.now();
        const uploadTime = (uploadEnd - uploadStart) / 1000;
        uploadMbps = (TEST_SIZE / 1024 / 1024) / uploadTime;

        // 3. Download test
        const downloadStart = performance.now();
        const resp = await fetch('/api/speedtest/download', { method: 'GET' });
        await resp.arrayBuffer();
        const downloadEnd = performance.now();
        const downloadTime = (downloadEnd - downloadStart) / 1000;
        downloadMbps = (TEST_SIZE / 1024 / 1024) / downloadTime;

        // Show results
        if (results) {
            results.innerHTML = `
                <div><strong>Latency:</strong> ${latency.toFixed(1)} ms</div>
                <div><strong>Upload Speed:</strong> ${uploadMbps.toFixed(2)} MiB/s</div>
                <div><strong>Download Speed:</strong> ${downloadMbps.toFixed(2)} MiB/s</div>
                <div style="margin-top:10px;font-size:12px;color:#888;">Tested with 5 MiB transfer</div>
            `;
        }
    } catch (e) {
        if (results) results.innerHTML = `<div style="color:red;">Speed test failed: ${escapeHtml(e)}</div>`;
    }
}

document.addEventListener('DOMContentLoaded', function () {
    // Store original table order for reset functionality
    storeOriginalTableOrder();

    // Initialize table sorting functionality
    document.querySelectorAll('.sortable').forEach(header => {
        header.addEventListener('click', function () {
            const column = this.dataset.sort;
            if (column) {
                sortTable(column);
            }
        });
    });

    // Initialize search functionality
    const searchInput = document.getElementById('tableSearch');
    if (searchInput) {
        // Set initial visible count
        const rows = document.querySelectorAll('#filesTable tbody tr');
        const initialCount = Array.from(rows).filter(row =>
            !row.style.background?.includes('rgba(52, 152, 219, 0.1)') &&
            !row.innerHTML.includes('.. (Parent Directory)')
        ).length;

        const visibleCountSpan = document.getElementById('visibleCount');
        if (visibleCountSpan) {
            visibleCountSpan.textContent = initialCount;
        }
    }

    const clearBtn = document.getElementById('clearAllBtn');
    const uploadBtn = document.getElementById('startUploadBtn');
    const fileInput = document.getElementById('fileInput');
    const folderInput = document.getElementById('folderInput');
    const fileInputDisplay = document.querySelector('.file-input-display');
    const speedTestBtn = document.getElementById('speedTestBtn');
    const filesBtn = document.getElementById('filesBtn');
    const foldersBtn = document.getElementById('foldersBtn');

    let currentUploadMode = 'files'; // 'files' or 'folders'

    // Upload mode switcher
    function setUploadMode(mode) {
        currentUploadMode = mode;
        const uploadModeHint = document.getElementById('uploadModeHint');
        const uploadInstructions = document.getElementById('uploadInstructions');

        if (mode === 'files') {
            if (filesBtn) filesBtn.classList.add('active');
            if (foldersBtn) foldersBtn.classList.remove('active');
            if (fileInput) fileInput.style.display = '';
            if (folderInput) folderInput.style.display = 'none';
            updateFileInputDisplay('files');
            if (uploadModeHint) {
                uploadModeHint.textContent = 'Multiple file selection supported';
            }
            if (uploadInstructions) {
                uploadInstructions.style.display = 'none';
            }
        } else {
            if (foldersBtn) foldersBtn.classList.add('active');
            if (filesBtn) filesBtn.classList.remove('active');
            if (fileInput) fileInput.style.display = 'none';
            if (folderInput) folderInput.style.display = '';
            updateFileInputDisplay('folders');
            if (uploadModeHint) {
                if (isAndroid) {
                    uploadModeHint.textContent = '⚠️ Android: One folder at a time (browser limitation)';
                } else if (isMobile) {
                    uploadModeHint.textContent = '📱 Mobile: Limited folder support';
                } else {
                    uploadModeHint.textContent = 'Add multiple folders by clicking repeatedly';
                }
            }
            if (uploadInstructions) {
                uploadInstructions.style.display = 'block';
            }
        }
    }

    function updateFileInputDisplay(mode) {
        const display = document.getElementById('fileInputDisplay');
        if (display) {
            if (mode === 'files') {
                display.innerHTML = `
                    <i class="fas fa-upload" style="font-size: 20px;"></i>
                    <div>
                        <strong>Choose files to upload</strong>
                        <div style="font-size: 12px; opacity: 0.8; margin-top: 5px;">
                            Click here or drag and drop files (multiple files supported)
                        </div>
                    </div>
                `;
            } else {
                if (isAndroid) {
                    display.innerHTML = `
                        <i class="fas fa-folder-open" style="font-size: 20px;"></i>
                        <div>
                            <strong>Choose folders to upload</strong>
                            <div style="font-size: 12px; opacity: 0.8; margin-top: 5px;">
                                <div>📱 Android: Select one folder at a time</div>
                                <div style="margin-top: 2px;">🔄 Click repeatedly to add more folders</div>
                                <div style="margin-top: 2px; color: #f39c12;">⚠️ Drag & drop not supported on Android</div>
                            </div>
                        </div>
                    `;
                } else if (isMobile) {
                    display.innerHTML = `
                        <i class="fas fa-folder-open" style="font-size: 20px;"></i>
                        <div>
                            <strong>Choose folders to upload</strong>
                            <div style="font-size: 12px; opacity: 0.8; margin-top: 5px;">
                                <div>📱 Mobile: Limited folder support</div>
                                <div style="margin-top: 2px;">🔄 Click to select folders one by one</div>
                            </div>
                        </div>
                    `;
                } else {
                    display.innerHTML = `
                        <i class="fas fa-folder-open" style="font-size: 20px;"></i>
                        <div>
                            <strong>Choose folders to upload</strong>
                            <div style="font-size: 12px; opacity: 0.8; margin-top: 5px;">
                                <div>🔄 Click repeatedly to add multiple folders</div>
                                <div style="margin-top: 2px;">🖱️ Or Ctrl+select folders in Explorer, then drag here</div>
                            </div>
                        </div>
                    `;
                }
            }
        }
    }

    // Upload mode button handlers
    if (filesBtn) {
        filesBtn.addEventListener('click', () => setUploadMode('files'));
    }
    if (foldersBtn) {
        foldersBtn.addEventListener('click', () => setUploadMode('folders'));
    }

    // Initialize with files mode only if upload elements exist
    if (filesBtn || foldersBtn) {
        setUploadMode('files');
    }

    // Update mobile-specific instructions after initialization
    function updateMobileInstructions() {
        const uploadInstructions = document.getElementById('uploadInstructions');
        if (uploadInstructions && currentUploadMode === 'folders') {
            if (isAndroid) {
                uploadInstructions.innerHTML = '<small>📱 Android limitation: Select folders one at a time. Drag & drop not supported.</small>';
            } else if (isMobile) {
                uploadInstructions.innerHTML = '<small>📱 Mobile: Limited folder support. Select folders one by one.</small>';
            }
        }
    }

    // Apply mobile instructions on load
    setTimeout(updateMobileInstructions, 100);

    // Add event listeners with null checks
    if (clearBtn) {
        console.log('🔧 Setting up clear button event listener');
        clearBtn.addEventListener('click', clearAllQueue);
    } else {
        console.log('ℹ️ Clear button not found');
    }

    // Add Clear Completed button event listener
    const clearCompletedBtn = document.getElementById('clearCompletedBtn');
    if (clearCompletedBtn) {
        console.log('🔧 Setting up clear completed button event listener');
        clearCompletedBtn.addEventListener('click', function () {
            clearCompletedItems();
        });
    } else {
        console.log('ℹ️ Clear completed button not found');
    }

    if (uploadBtn) {
        console.log('🔧 Setting up upload button event listener');
        uploadBtn.addEventListener('click', startBatchUpload);
    } else {
        console.log('ℹ️ Upload button not found');
    }

    // Setup parallel upload controls
    const enableParallelCheckbox = document.getElementById('enableParallelUploads');
    const maxConcurrentSelect = document.getElementById('maxConcurrentUploads');

    if (enableParallelCheckbox) {
        enableParallelCheckbox.addEventListener('change', function (e) {
            PARALLEL_UPLOAD_CONFIG.enableParallelUploads = e.target.checked;
            console.log(`⚡ Parallel uploads ${e.target.checked ? 'enabled' : 'disabled'}`);

            // Update button text to show current mode
            const uploadBtn = document.getElementById('startUploadBtn');
            if (uploadBtn && !isUploading) {
                const mode = e.target.checked ? 'Parallel' : 'Sequential';
                uploadBtn.title = `${mode} upload mode`;
            }
        });
    }

    if (maxConcurrentSelect) {
        maxConcurrentSelect.addEventListener('change', function (e) {
            const newValue = parseInt(e.target.value);
            PARALLEL_UPLOAD_CONFIG.maxConcurrentUploads = newValue;
            console.log(`⚡ Max concurrent uploads set to: ${newValue}`);
        });
    }

    // Ensure Speed Test button event is attached
    if (speedTestBtn) {
        speedTestBtn.addEventListener('click', openSpeedTestModal);
    }

    // Rename modal Enter key support and Ctrl+A support
    const newItemNameInput = document.getElementById('newItemName');
    if (newItemNameInput) {
        newItemNameInput.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                confirmRename();
            }
        });

        // Add Ctrl+A support for select all
        newItemNameInput.addEventListener('keydown', function (e) {
            if (e.ctrlKey && e.key === 'a') {
                e.preventDefault();
                this.select();
            }
        });
    }

    // Drag and drop functionality (disabled on Android due to poor support)
    if (fileInputDisplay && fileInput && !isAndroid) {
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            fileInputDisplay.addEventListener(eventName, preventDefaults, false);
            document.body.addEventListener(eventName, preventDefaults, false);
        });

        ['dragenter', 'dragover'].forEach(eventName => {
            fileInputDisplay.addEventListener(eventName, highlight, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            fileInputDisplay.addEventListener(eventName, unhighlight, false);
        });

        fileInputDisplay.addEventListener('drop', handleDrop, false);
    } else if (!isAndroid) {
        // fileInputDisplay not found — attach drop to document.body as fallback
        console.warn('⚠️ .file-input-display not found — attaching drag-drop to body as fallback');
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            document.body.addEventListener(eventName, preventDefaults, false);
        });
        document.body.addEventListener('drop', handleDrop, false);
    } else {
        console.log('📱 Android detected: Drag & drop disabled due to limited browser support');
    }

    // Click functionality works on all devices
    if (fileInputDisplay && fileInput) {
        fileInputDisplay.addEventListener('click', function () {
            if (currentUploadMode === 'files') {
                fileInput.click();
            } else {
                // Use showDirectoryPicker (File System Access API) for true lazy scanning.
                // Falls back to webkitdirectory input on mobile / unsupported browsers.
                if (window.showDirectoryPicker && !isMobile) {
                    _pickFolderLazy();
                } else {
                    // webkitdirectory: browser enumerates all files BEFORE firing change event.
                    // Show scanning message immediately so user knows it's working.
                    showUploadStatus('📂 Opening folder — browser is scanning files…', 'info');
                    folderInput.click();
                }
            }
        });

        // Update file input display when files are selected
        fileInput.addEventListener('change', function (e) {
            handleInputChange(e, 'file');
        });

        // webkitdirectory fallback (mobile / browsers without showDirectoryPicker)
        if (folderInput) {
            folderInput.addEventListener('change', function (e) {
                handleInputChange(e, 'folder');
            });
        }
    }

    async function _pickFolderLazy() {
        let dirHandle;
        try {
            dirHandle = await window.showDirectoryPicker({ mode: 'read' });
        } catch (e) {
            if (e.name !== 'AbortError') console.error('showDirectoryPicker error', e);
            return;
        }

        const rootName = dirHandle.name;
        // NOTE: this used to be `folderGroups.has(rootName)`, but folderGroups
        // is keyed by generated groupId, never by rootName — that check could
        // never actually match anything, so duplicate picks were never caught.
        if (_isFolderAlreadyQueued(rootName, currentPath)) {
            showUploadStatus(`📁 "${rootName}" is already uploading to this location`, 'info');
            return;
        }

        const groupId = `fg_${Date.now()}_${Math.random().toString(36).slice(2)}`;
        const group = {
            id: groupId, rootName,
            basePath: currentPath || '',   // frozen at queue time — never changes when user browses
            scanned: 0, completed: 0, errors: 0, assembling: 0,
            totalSize: 0,
            status: 'scanning',
            scanComplete: false,   // set true when tree walk finishes; upload loop uses this, not status
            cancelled: false,
            createdTime: Date.now()
        };
        folderGroups.set(groupId, group);
        updateQueueDisplay();
        showUploadStatus(`📂 Scanning "${rootName}"…`, 'info');

        // Recursively walk directory entries, yielding File objects
        async function* walkDir(handle, relPath) {
            for await (const [name, entry] of handle.entries()) {
                if (group.cancelled) return;
                const entryPath = relPath ? `${relPath}/${name}` : name;
                if (entry.kind === 'file') {
                    const file = await entry.getFile();
                    // Attach relative path so upload logic knows destination
                    Object.defineProperty(file, 'relativePath', { value: `${rootName}/${entryPath}`, writable: false });
                    yield file;
                } else if (entry.kind === 'directory') {
                    yield* walkDir(entry, entryPath);
                }
            }
        }

        group.pendingEntries = [];

        let uiThrottle = 0;
        for await (const file of walkDir(dirHandle, '')) {
            if (group.cancelled) break;
            const parts = (`${rootName}/${file.relativePath.slice(rootName.length + 1)}`).split('/');
            parts.pop();
            const relDir = parts.join('/');
            const base = group.basePath || '';
            const dest = base ? (relDir ? `${base}/${relDir}` : base) : relDir;
            const key = `${dest}::${file.name}::${file.size}`;
            if (!_seenFileKeys.has(key)) {
                _seenFileKeys.add(key);
                if (!group._ownedKeys) group._ownedKeys = new Set();
                group._ownedKeys.add(key);
                group.pendingEntries.push({ file, dest, displayName: relDir ? `${relDir}/${file.name}` : file.name });
                group.scanned++;
                group.totalSize += file.size;
            }
            if (++uiThrottle % 200 === 0) updateQueueDisplay();
            if (group.scanned === 1 || group.scanned % 1000 === 0) {
                _spawnFolderWorkersIfNeeded();
            }
        }

        if (!group.cancelled) {
            group.totalCount = group.scanned;
            group.scanComplete = true;
            if (group.status === 'scanning') group.status = 'pending';
            updateQueueDisplay();
            showUploadStatus(`✅ "${rootName}" ready — ${group.scanned.toLocaleString()} files, ${formatFileSize(group.totalSize)}`, 'success');
            _spawnFolderWorkersIfNeeded();
        }
    }


    function handleInputChange(e, type) {
        const fileList = e.target.files;
        if (!fileList || fileList.length === 0) return;

        if (type === 'folder') {
            const fileArray = Array.from(fileList);
            const count = fileArray.length;
            e.target.value = '';

            let mobilePrefix = null;
            const hasRelativePath = !!(fileArray[0] && fileArray[0].webkitRelativePath);
            if (isMobile && !hasRelativePath) {
                const ts = new Date().toISOString().slice(0, 19).replace(/[:\-T]/g, '_');
                mobilePrefix = `MobileUpload_${ts}`;
                console.log('📱 Mobile fallback prefix:', mobilePrefix);
            }
            _registerFolderGroup(fileArray, mobilePrefix);

            const display = document.querySelector('.file-input-display');
            if (display) {
                display.innerHTML = `
                    <i class="fas fa-plus-circle" style="font-size:20px;color:#27ae60;"></i>
                    <div>
                        <strong>${count.toLocaleString()} files queued</strong>
                        <div style="font-size:12px;opacity:0.8;margin-top:4px;">Computing size… click again to add more folders</div>
                    </div>`;
                display.style.borderColor = '#27ae60';
                display.style.backgroundColor = 'rgba(39,174,96,0.1)';
                setTimeout(() => {
                    updateFileInputDisplay(currentUploadMode);
                    display.style.borderColor = 'rgba(255,255,255,0.4)';
                    display.style.backgroundColor = 'rgba(255,255,255,0.1)';
                }, 4000);
            }
            return;
        }

        // ── REGULAR FILES PATH ───────────────────────────────────────────────
        const files = Array.from(fileList);
        if (files.length > 0) {
            addFilesToQueue(files);

            const display = document.querySelector('.file-input-display');
            if (display) {
                const itemType = files.length === 1 ? 'file' : 'files';
                display.innerHTML = `
                    <i class="fas fa-plus-circle" style="font-size: 20px; color: #27ae60;"></i>
                    <div>
                        <strong>Added ${files.length} ${itemType} to queue</strong>
                        <div style="font-size: 12px; opacity: 0.8; margin-top: 5px;">
                            Click again to add more files
                        </div>
                    </div>
                `;
                display.style.borderColor = '#27ae60';
                display.style.backgroundColor = 'rgba(39, 174, 96, 0.1)';
                setTimeout(() => {
                    updateFileInputDisplay(currentUploadMode);
                    display.style.borderColor = 'rgba(255, 255, 255, 0.4)';
                    display.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                }, 2000);
            }
            e.target.value = '';
        }
    }

    // Add dynamic file type icons for existing files
    document.querySelectorAll('.file-icon-default').forEach(icon => {
        const fileNameElement = icon.parentElement.querySelector('a, span');
        if (fileNameElement) {
            const fileName = fileNameElement.textContent.trim();
            const iconClass = getFileIcon(fileName);
            const color = getFileColor(fileName);

            icon.className = iconClass + ' file-icon';
            icon.style.color = color;
        }
    });

    // Initialize selection handlers
    if (USER_ROLE === 'readwrite') {
        document.querySelectorAll('.item-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', updateSelection);
        });

        // Add delete button event listeners
        document.querySelectorAll('.delete-btn').forEach(button => {
            console.log('🔧 Adding delete event listener to button:', button);
            button.addEventListener('click', handleDeleteClick);
        });

        // Initialize rename button visibility on page load
        setTimeout(() => {
            initializeRenameButtonVisibility();
        }, 100);
    }

    // Add manual cleanup button for debugging
    addManualCleanupButton();

    // Check cleanup button status immediately and again shortly after
    updateManualCleanupButton(); // Immediate check
    setTimeout(() => {
        updateManualCleanupButton(); // Follow-up check to be sure
    }, 100);

    // Check for existing assembly jobs immediately
    checkExistingAssemblies();

    // Initialize real-time monitoring (which handles storage stats internally)
    // Only do this once to prevent duplicate SSE connections
    if (!window.storageMonitoringInitialized) {
        initializeRealTimeMonitoring();
    } else {
        console.log('📡 Real-time monitoring already initialized, skipping duplicate initialization');
    }

    // Show enhanced upload hints
    showUploadStatus(
        '<i class="fas fa-info-circle"></i> Enhanced server-sided cleanup active: chunks auto-cleanup on page refresh, connection loss, and periodically',
        'info'
    );

    // Cleanup any stale items from previous sessions on page load
    setTimeout(() => {
        cleanupUnfinishedChunks().catch(console.error);
    }, 2000);

    // Debug info
    console.log('🚀 Cloudinator Enhanced initialized');
    console.log('📤 Upload URL:', UPLOAD_URL);
    console.log('📦 Chunk size:', CHUNK_SIZE, 'bytes (' + Math.round(CHUNK_SIZE / (1024 * 1024)) + 'MB)');
    console.log('🧹 Enhanced cleanup system active');
});

function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
}

function highlight(e) {
    const fileInputDisplay = document.querySelector('.file-input-display');
    if (fileInputDisplay) {
        fileInputDisplay.style.borderColor = '#2ecc71';
        fileInputDisplay.style.backgroundColor = 'rgba(46, 204, 113, 0.1)';
        fileInputDisplay.style.transform = 'scale(1.02)';
    }
}

function unhighlight(e) {
    const fileInputDisplay = document.querySelector('.file-input-display');
    if (fileInputDisplay) {
        fileInputDisplay.style.borderColor = 'rgba(255, 255, 255, 0.4)';
        fileInputDisplay.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
        fileInputDisplay.style.transform = 'scale(1)';
    }
}

async function handleDrop(e) {
    const dt = e.dataTransfer;

    // Handle both files and directories from drag & drop
    if (dt.items) {
        const plainFiles = [];
        const dirEntries = [];

        for (let i = 0; i < dt.items.length; i++) {
            const item = dt.items[i];
            if (item.kind !== 'file') continue;
            const entry = item.webkitGetAsEntry();
            if (!entry) continue;
            if (entry.isFile) {
                const file = item.getAsFile();
                if (file) plainFiles.push(file);
            } else if (entry.isDirectory) {
                dirEntries.push(entry);
            }
        }

        if (plainFiles.length > 0) addFilesToQueue(plainFiles);

        for (const dirEntry of dirEntries) {
            _registerDirEntryLazy(dirEntry);
        }

    } else {
        const files = Array.from(dt.files);
        if (files.length > 0) addFilesToQueue(files);
    }
}

async function _registerDirEntryLazy(dirEntry) {
    const rootName = dirEntry.name;

    if (_isFolderAlreadyQueued(rootName, currentPath)) {
        showUploadStatus(`📁 "${rootName}" is already uploading to this location`, 'info');
        return;
    }

    const groupId = `fg_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const group = {
        id: groupId, rootName,
        basePath: currentPath || '',
        scanned: 0, completed: 0, errors: 0, assembling: 0,
        totalSize: 0,
        status: 'scanning',
        scanComplete: false,   // set true when tree walk finishes; upload loop uses this, not status
        cancelled: false,
        createdTime: Date.now(),
        pendingEntries: []
    };
    folderGroups.set(groupId, group);
    updateQueueDisplay();
    showUploadStatus(`📂 Scanning "${rootName}"…`, 'info');

    // Walk FileSystemEntry tree using createReader (100 entries per batch — browser limit)
    async function walkEntry(entry, relPath) {
        if (group.cancelled) return;
        if (entry.isFile) {
            await new Promise(resolve => {
                entry.file(file => {
                    const dest = relPath
                        ? (group.basePath ? `${group.basePath}/${relPath}` : relPath)
                        : (group.basePath || '');
                    const displayName = relPath ? `${relPath}/${file.name}` : file.name;
                    const key = `${dest}::${file.name}::${file.size}`;
                    if (!_seenFileKeys.has(key)) {
                        _seenFileKeys.add(key);
                        if (!group._ownedKeys) group._ownedKeys = new Set();
                        group._ownedKeys.add(key);
                        group.pendingEntries.push({ file, dest, displayName });
                        group.scanned++;
                        group.totalSize += file.size;
                    }
                    if (group.scanned % 200 === 0) updateQueueDisplay();
                    if (group.scanned === 100 || group.scanned % 1000 === 0) {
                        _spawnFolderWorkersIfNeeded();
                    }
                    resolve();
                }, resolve);
            });
        } else if (entry.isDirectory) {
            const reader = entry.createReader();
            // createReader only returns up to 100 entries per call — must loop until empty
            await new Promise((resolve, reject) => {
                const subPath = relPath ? `${relPath}/${entry.name}` : entry.name;
                function readBatch() {
                    reader.readEntries(async entries => {
                        if (!entries.length) { resolve(); return; }
                        for (const e of entries) {
                            if (group.cancelled) { resolve(); return; }
                            await walkEntry(e, subPath);
                        }
                        readBatch(); // fetch next batch
                    }, reject);
                }
                readBatch();
            });
        }
    }

    try {
        const reader = dirEntry.createReader();
        await new Promise((resolve, reject) => {
            function readBatch() {
                reader.readEntries(async entries => {
                    if (!entries.length) { resolve(); return; }
                    for (const e of entries) {
                        if (group.cancelled) { resolve(); return; }
                        await walkEntry(e, rootName);
                    }
                    readBatch();
                }, reject);
            }
            readBatch();
        });
    } catch (err) {
        console.error(`❌ Error scanning "${rootName}":`, err);
        showUploadStatus(`❌ Failed to scan "${rootName}"`, 'error');
        folderGroups.delete(groupId);
        updateQueueDisplay();
        return;
    }

    if (!group.cancelled) {
        group.totalCount = group.scanned;
        group.scanComplete = true;
        if (group.status === 'scanning') group.status = 'pending';
        updateQueueDisplay();
        showUploadStatus(`✅ "${rootName}" ready — ${group.scanned.toLocaleString()} files, ${formatFileSize(group.totalSize)}`, 'success');
        _spawnFolderWorkersIfNeeded();
    }
}

// Recursively read directory contents

// Convert FileEntry to File object
function getFileFromEntry(fileEntry) {
    return new Promise((resolve) => {
        fileEntry.file(resolve, () => resolve(null));
    });
}

// Enhanced keyboard shortcuts
document.addEventListener('keydown', function (e) {
    // Ctrl/Cmd + U for upload file/folder selection
    if ((e.ctrlKey || e.metaKey) && e.key === 'u' && !isUploading) {
        e.preventDefault();
        if (typeof currentUploadMode !== 'undefined' && currentUploadMode === 'folders') {
            const folderInput = document.getElementById('folderInput');
            if (folderInput) folderInput.click();
        } else {
            const fileInput = document.getElementById('fileInput');
            if (fileInput) fileInput.click();
        }
    }

    // Shift + Ctrl/Cmd + U for quick "add another folder" (switches to folder mode and opens picker)
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'U' && !isUploading) {
        e.preventDefault();
        // Switch to folder mode if not already
        if (typeof setUploadMode !== 'undefined') {
            setUploadMode('folders');
        }
        // Open folder picker
        setTimeout(() => {
            const folderInput = document.getElementById('folderInput');
            if (folderInput) folderInput.click();
        }, 100);
    }

    // Ctrl/Cmd + Enter to start upload
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && !isUploading) {
        e.preventDefault();
        if (uploadQueue.filter(item => item.status === 'pending').length > 0) {
            startBatchUpload();
        }
    }

    // Escape to clear queue or close modal
    if (e.key === 'Escape') {
        const modal = document.getElementById('moveModal');
        if (modal && modal.classList.contains('show')) {
            closeModal();
        } else if (!isUploading && uploadQueue.length > 0) {
            clearAllQueue();
        }
    }

    // Delete key to remove completed/failed items or bulk delete
    if (e.key === 'Delete' && !isUploading) {
        if (selectedItems.size > 0) {
            bulkDelete();
        } else {
            const completedItems = uploadQueue.filter(item =>
                item.status === 'completed' || item.status === 'error'
            );
            completedItems.forEach(item => removeFromQueue(item.id));
        }
    }

    // Ctrl/Cmd + A to select all files
    if ((e.ctrlKey || e.metaKey) && e.key === 'a' && USER_ROLE === 'readwrite') {
        e.preventDefault();
        const selectAllCheckbox = document.getElementById('selectAll');
        if (selectAllCheckbox) {
            selectAllCheckbox.checked = true;
            toggleSelectAll();
        }
    }

    // Backspace or Alt + Left Arrow to go up one level
    if ((e.key === 'Backspace' || (e.altKey && e.key === 'ArrowLeft')) && window.location.pathname !== '/') {
        // Check if user is typing in an input field
        const activeElement = document.activeElement;
        const isInputField = activeElement && (
            activeElement.tagName === 'INPUT' ||
            activeElement.tagName === 'TEXTAREA' ||
            activeElement.contentEditable === 'true'
        );

        // Only navigate back if NOT typing in an input field
        if (!isInputField) {
            e.preventDefault();
            const currentPath = CURRENT_PATH;
            if (currentPath) {
                const pathParts = currentPath.split('/');
                pathParts.pop();
                const parentPath = pathParts.join('/');
                window.location.href = parentPath ? `/${parentPath}` : '/';
            }
        }
    }

    // F5 or Ctrl/Cmd + R - Enhanced refresh with cleanup warning
    if (e.key === 'F5' || ((e.ctrlKey || e.metaKey) && e.key === 'r')) {
        if (isUploading || uploadQueue.some(item => item.status === 'pending')) {
            e.preventDefault();
            const shouldRefresh = confirm('⚠️ Upload in progress. Refreshing will cancel uploads and cleanup temporary files. Continue?');
            if (shouldRefresh) {
                // Try cleanup before refresh
                cleanupUnfinishedChunks().finally(() => {
                    window.location.reload();
                });
            }
        }
    }
});

// Modal close on outside click
document.addEventListener('click', function (e) {
    const modal = document.getElementById('moveModal');
    if (modal && e.target === modal) {
        closeModal();
    }
});

// Update progress every second during upload
setInterval(() => {
    if (isUploading) {
        updateProgressSummary();
    }
}, 1000);

// Check cleanup button state periodically (skip during upload to avoid interrupting connections)
setInterval(() => {
    if (!isUploading) updateManualCleanupButton();
}, 5000);

// Enhanced connection monitoring
// (isOnline / connectionLostTime tracking + the restored/lost notifications
// now live earlier in the file, merged into the real 'online'/'offline'
// event listeners — see the comment there for why.)

// Monitor connection changes
window.addEventListener('online', updateConnectionStatus);
window.addEventListener('offline', updateConnectionStatus);

// Ping server periodically to detect connection issues.
// FIX: was setInterval — see startAssemblyPolling for why that stacks
// overlapping requests during a server slowdown.
(function scheduleConnectionPing() {
    setTimeout(async () => {
        if (isUploading) {
            try {
                const response = await fetch('/admin/chunk_stats', {
                    method: 'GET',
                    cache: 'no-cache'
                });

                if (!response.ok && isOnline) {
                    console.warn('⚠️ Server connection issues detected');
                    showUploadStatus('⚠️ Server connection unstable', 'error');
                }
            } catch (error) {
                if (isOnline) {
                    console.warn('⚠️ Network connectivity issues:', error);
                }
            }
        }
        scheduleConnectionPing();
    }, 30000); // Check every 30 seconds during upload
})();

// Global error handler for unhandled promise rejections
window.addEventListener('unhandledrejection', function (event) {
    console.error('🚨 Unhandled promise rejection:', event.reason);

    // If it's related to cleanup, try to handle gracefully
    if (event.reason && event.reason.message && event.reason.message.includes('cleanup')) {
        showUploadStatus('⚠️ Cleanup operation failed - some temporary files may remain', 'error');
        event.preventDefault();
    }
});

// Utility functions
function logout() {
    // Cleanup before logout
    cleanupUnfinishedChunks().finally(() => {
        window.location.href = LOGOUT_URL;
    });
}

// Export functions for global access
window.CloudinatorUpload = {
    addFilesToQueue,
    startBatchUpload,
    clearAllQueue,
    clearNotificationQueue,
    clearNotificationsByType,
    cleanupUnfinishedChunks,
    showMoveModal,
    showCopyModal,
    bulkDelete,
    bulkDownload,
    clearSelection,
    closeModal,
    confirmMoveOrCopy,
    toggleSelectAll,
    updateSelection,
    setNotificationTimer,
    setParallelUploadConfig,
    goToRoot,
    goUpOneLevel,
    createNewFolderInBrowser
};

// Confirmation Modal Functions
let pendingConfirmAction = null;

function showConfirmationModal(title, message, confirmText = 'Confirm', confirmClass = 'btn-primary', icon = 'fa-question-circle') {
    return new Promise((resolve) => {
        const modal = document.getElementById('confirmationModal');
        const titleElement = document.getElementById('confirmationTitle');
        const messageElement = document.getElementById('confirmationMessage');
        const confirmBtn = document.getElementById('confirmationConfirmBtn');
        const iconElement = document.getElementById('confirmationIcon');

        titleElement.textContent = title;
        messageElement.textContent = message;
        confirmBtn.textContent = confirmText;
        confirmBtn.className = `btn ${confirmClass}`;
        iconElement.className = `fas ${icon}`;

        pendingConfirmAction = resolve;
        modal.style.display = 'block';
    });
}

function closeConfirmationModal() {
    const modal = document.getElementById('confirmationModal');
    modal.style.display = 'none';

    if (pendingConfirmAction) {
        pendingConfirmAction(false);
        pendingConfirmAction = null;
    }
}

function executeConfirmedAction() {
    const modal = document.getElementById('confirmationModal');
    modal.style.display = 'none';

    if (pendingConfirmAction) {
        pendingConfirmAction(true);
        pendingConfirmAction = null;
    }
}

// Assembly Status Tracking
const assemblyPollers = new Map(); // file_id -> timeout_id

// If a backend assembly job never resolves (worker crashed, job orphaned,
// etc.) there was previously nothing to stop startAssemblyPolling from
// polling every 2s forever — a silent zombie that kept its item (and, for
// a folder file, the whole folder group) permanently stuck in-flight, with
// nothing to hide the queue container and nothing for "Clear Completed" to
// act on. After this long without a real answer from the backend, give up
// and report it as a normal, dismissable error instead.
const ASSEMBLY_POLL_TIMEOUT_MS = 15 * 60 * 1000; // 15 minutes

function startAssemblyPolling(fileId, startedAt = Date.now()) {
    // Clear any existing poller for this file
    if (assemblyPollers.has(fileId)) {
        clearTimeout(assemblyPollers.get(fileId));
    }

    console.log(`🔄 Starting assembly status polling for ${fileId}`);

    // FIX: this used to be setInterval(async () => {...}, 2000). setInterval
    // fires on a fixed clock regardless of whether the previous callback's
    // fetch has resolved — so if /api/assembly_status ever takes longer than
    // 2s to respond (e.g. the server is briefly under load), a second
    // overlapping request for the SAME file fires on top of it, then a third,
    // etc. With up to ~100 of these pollers running at once for a big folder,
    // that pileup snowballs: more stacked requests make the server slower,
    // which makes more requests stack, without bound — which is exactly what
    // ran the Waitress queue up regardless of thread count. A self-
    // rescheduling setTimeout only queues the NEXT poll once the current one
    // has actually finished, so it can never stack and naturally backs off
    // instead of piling on during a slowdown.
    const scheduleNext = () => {
        const timeoutId = setTimeout(pollOnce, 2000);
        assemblyPollers.set(fileId, timeoutId);
    };

    const pollOnce = async () => {
        try {
            const response = await fetch(`/api/assembly_status/${fileId}`);

            if (!response.ok) {
                console.error(`❌ Assembly status check failed for ${fileId}`);
                assemblyPollers.delete(fileId);
                updateItemStatus(fileId, 'error', 'Assembly status check failed');
                return;
            }

            const status = await response.json();
            console.log(`📊 Assembly status for ${fileId}:`, status.status);

            if (status.status === 'completed') {
                console.log(`✅ Assembly completed for ${status.filename}`);
                updateItemStatus(fileId, 'completed', 'File ready!');
                assemblyPollers.delete(fileId);

                // Update cleanup button availability when assembly completes
                updateManualCleanupButton();

                // Auto-clear the completed item after a short delay so the
                // user briefly sees the "completed" state before it disappears.
                setTimeout(() => {
                    // FIX: this used to grab the DOM node directly and call
                    // .remove() on it without touching the uploadQueue array,
                    // then check queueContainer.children.length (queueContainer
                    // is the WHOLE panel — header, buttons, progress summary —
                    // which always has children) to decide whether to hide the
                    // container. That check could never be true, and the
                    // array/DOM state fell out of sync: the row visually
                    // vanished but the item was still sitting in uploadQueue as
                    // 'completed', so the panel just sat there looking empty
                    // until autoCleanupCompletedItems happened to catch up —
                    // the "queue looks clear but the panel won't go away"
                    // symptom. Removing it from the array and letting
                    // updateQueueDisplay() rebuild + decide visibility is the
                    // same path every other completion goes through, so it
                    // can't drift out of sync with what's actually still
                    // in flight (including any folder groups).
                    console.log(`🧹 Auto-clearing completed assembly item: ${fileId}`);
                    const idx = uploadQueue.findIndex(q => q.id === fileId);
                    if (idx !== -1) uploadQueue.splice(idx, 1);
                    updateQueueDisplay();
                }, 3000); // Clear after 3 seconds

                // Also trigger the general auto-cleanup function
                setTimeout(autoCleanupCompletedItems, 5000);

                // Refresh file table to show new file
                setTimeout(() => {
                    refreshFileTable();
                    // Also refresh storage stats after successful upload
                    refreshStorageStats('upload completed');
                }, 1000);

            } else if (status.status === 'error') {
                console.error(`❌ Assembly failed for ${status.filename}: ${status.error_message}`);
                updateItemStatus(fileId, 'error', `Assembly failed: ${status.error_message}`);
                assemblyPollers.delete(fileId);
            } else if (Date.now() - startedAt > ASSEMBLY_POLL_TIMEOUT_MS) {
                console.error(`⏱️ Assembly timed out for ${fileId} after ${Math.round(ASSEMBLY_POLL_TIMEOUT_MS / 60000)} minutes with no resolution`);
                assemblyPollers.delete(fileId);
                updateItemStatus(fileId, 'error', 'Server is taking too long to process this file — please check server status or try again');
            } else {
                // Keep polling if status is 'pending' or 'processing'
                scheduleNext();
            }

        } catch (error) {
            console.error(`❌ Assembly polling error for ${fileId}:`, error);
            assemblyPollers.delete(fileId);
            updateItemStatus(fileId, 'error', 'Connection error during assembly');
        }
    };

    scheduleNext();
}

async function checkExistingAssemblies() {
    // Check for any existing assembly jobs on page load
    try {
        const response = await fetch('/api/assembly_status');

        if (!response.ok) {
            console.log('No existing assembly jobs found');
            return;
        }

        const data = await response.json();
        const jobs = data.jobs || [];

        console.log(`🔄 Found ${jobs.length} existing assembly job(s)`);

        // Process each job
        for (const job of jobs) {
            if (job.status === 'pending' || job.status === 'processing') {
                console.log(`🔄 Resuming assembly tracking for ${job.filename}`);

                // IMMEDIATELY protect this job from cleanup
                try {
                    await fetch(`/api/protect_assembly/${job.file_id}`, { method: 'POST' });
                    console.log(`🔐 Protected assembly job ${job.file_id} from cleanup`);
                } catch (protectError) {
                    console.warn(`⚠️ Failed to protect assembly job ${job.file_id}:`, protectError);
                }

                // Add to upload queue as assembling
                addToUploadQueue({
                    id: job.file_id,
                    name: job.filename,
                    status: 'assembling',
                    progress: 100,
                    message: job.status === 'processing' ? 'Processing file...' : 'Queued for processing...',
                    size: 0 // Unknown size for resumed uploads
                });

                // Start polling for this job — pass the job's real backend age
                // (created_at, seconds since epoch) rather than defaulting to
                // "now": otherwise a job that was already stuck for an hour
                // before this refresh would get a brand new 15-minute grace
                // period every single time the page reloads, and could never
                // actually hit the staleness timeout.
                const jobStartedAt = job.created_at ? job.created_at * 1000 : Date.now();
                startAssemblyPolling(job.file_id, jobStartedAt);

                // Update cleanup button to disable it during assembly
                updateManualCleanupButton();
            }
        }

    } catch (error) {
        console.error('❌ Error checking existing assemblies:', error);
    }
}

// Cleanup polling on page unload
window.addEventListener('beforeunload', () => {
    assemblyPollers.forEach(intervalId => clearInterval(intervalId));
    assemblyPollers.clear();
});

// Log parallel upload configuration on page load
console.log('⚡ Parallel Upload System Initialized');
console.log('📊 Default Configuration:');
console.log(`   • Parallel Uploads: ${PARALLEL_UPLOAD_CONFIG.enableParallelUploads ? 'Enabled' : 'Disabled'}`);
console.log(`   • Max Concurrent: ${PARALLEL_UPLOAD_CONFIG.maxConcurrentUploads}`);
console.log('🔧 Use setParallelUploadConfig(maxConcurrent, enabled) to modify via console');

console.log('✅ Cloudinator Enhanced Upload System Ready');

// Auto-clear completed items from upload queue
function autoCleanupCompletedItems() {


    // Count completed items before clearing
    const completedItems = uploadQueue.filter(item =>
        item.status === 'completed' ||
        item.status === 'assembled' ||
        (item.error && item.error.includes('File ready!'))
    );

    if (completedItems.length === 0) {

        return;
    }

    console.log(`🧹 Found ${completedItems.length} completed items to auto-clear:`,
        completedItems.map(item => `${item.name} (${item.status})`));

    // Remove completed items from queue, and release their dedup keys so the
    // same files can be re-added after the user deletes and re-drops them.
    completedItems.forEach(item => {
        if (item._seenKey) _seenFileKeys.delete(item._seenKey);
    });
    uploadQueue = uploadQueue.filter(item =>
        item.status !== 'completed' &&
        item.status !== 'assembled' &&
        !(item.error && item.error.includes('File ready!'))
    );

    // Update display
    updateQueueDisplay();

    console.log(`🧹 Auto-cleared ${completedItems.length} completed items`);

    // If queue is now empty, hide it
    if (uploadQueue.length === 0) {
        const queueContainer = document.getElementById('uploadQueue');
        if (queueContainer) {
            queueContainer.classList.remove('show');
            console.log('🧹 Upload queue hidden (empty after auto-cleanup)');
        }
    }
}

// Run auto-cleanup every 10 seconds
setInterval(autoCleanupCompletedItems, 10000);

// Also run cleanup when page becomes visible
document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
        setTimeout(autoCleanupCompletedItems, 1000);
    }
});

// Real-time storage monitoring with Server-Sent Events and Polling Fallback
let storageEventSource = null;
let connectionStatus = 'disconnected';
let reconnectAttempts = 0;
const maxReconnectAttempts = 5;
const reconnectDelay = 3000; // 3 seconds
let lastKnownFileCount = null;
let lastKnownDirCount = null;

// Polling fallback variables
let pollingInterval = null;
let pollingEnabled = false;
let lastPollingCheck = 0;
let sseFailedPermanently = false;
// 4.67: the last change batch this tab has seen (number + server epoch) and the last
// total size, so a returning stream or a poll can ask "what changed since?".
let lastChangeSeq = null;
let lastSeqEpoch = null;
let lastKnownTotalSize = null;

// MANUAL TIMING CONTROLS - Edit these for instant loading
const INSTANT_LOAD_SETTINGS = {
    sseTimeout: 1000,        // How long to wait for SSE before fallback (1 second)
    pollingDelay: 50,        // Delay before starting polling (50ms)
    initialDelay: 50,        // Delay before starting any monitoring (50ms)
    pollingIntervalTime: 500, // How often polling checks for changes (0.5 seconds)
    enableInstantMode: true  // Set to false to use original timing
};

function initializeRealTimeMonitoring() {
    console.log('📡 Initializing INSTANT real-time storage monitoring...');

    // Skip duplicate initialization if already done
    if (window.storageMonitoringInitialized) {
        console.log('📡 Real-time monitoring already initialized, skipping...');
        return;
    }
    window.storageMonitoringInitialized = true;

    // Add Page Visibility API handling to prevent issues on tab switching
    document.addEventListener('visibilitychange', function () {
        if (document.hidden) {
            console.log('📱 Tab became hidden - monitoring continues in background');
        } else {
            console.log('📱 Tab became visible - monitoring already active, no re-initialization needed');
            // Don't re-initialize - just log that tab is visible again
            // This prevents the "+1 files" issue when switching tabs
        }
    });

    // Reset fallback state
    sseFailedPermanently = false;
    pollingEnabled = false;

    // Use manual timing controls
    const sseTimeout = INSTANT_LOAD_SETTINGS.enableInstantMode ? INSTANT_LOAD_SETTINGS.sseTimeout : 2000;
    const initialDelay = INSTANT_LOAD_SETTINGS.enableInstantMode ? INSTANT_LOAD_SETTINGS.initialDelay : 100;

    console.log(`📡 Using instant mode: SSE timeout=${sseTimeout}ms, initial delay=${initialDelay}ms`);

    // Try SSE first with minimal delay
    setTimeout(() => {
        console.log('📡 Attempting SSE connection...');
        connectToStorageStream();

        // Fast fallback to polling if SSE fails
        setTimeout(() => {
            if (connectionStatus !== 'connected' && !window.storageStatsInitialized && !sseFailedPermanently) {
                console.log('⚠️ SSE connection timeout, falling back to instant polling...');
                sseFailedPermanently = true;
                setupFallbackPolling();
            }
        }, sseTimeout);

    }, initialDelay);
}

async function initializeStorageStats() {
    // Prevent duplicate calls during page load
    if (window.storageStatsInitialized) {
        console.log('📊 Storage stats already initialized by main handler, skipping fallback...');
        return;
    }

    console.log('📊 Initializing storage stats at startup...');
    try {
        const response = await fetch('/api/storage_stats');
        if (response.ok) {
            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                const data = await response.json();
                if (data.file_count !== undefined && data.dir_count !== undefined) {
                    lastKnownFileCount = data.file_count;
                    lastKnownDirCount = data.dir_count;
                    console.log(`📊 Initial stats: ${data.file_count} files, ${data.dir_count} dirs`);
                    updateStorageDisplay(data);
                }
            } else {
                // Got HTML instead of JSON - likely an error page
                const text = await response.text();
                console.warn(`⚠️ Initial stats API returned HTML instead of JSON (status ${response.status}):`, text.substring(0, 100) + '...');
            }
        } else {
            throw new Error(`API error: ${response.status} ${response.statusText}`);
        }
    } catch (error) {
        console.warn('⚠️ Failed to initialize storage stats:', error);
    }
}

function handleStatsUpdate(data) {
    // Check for changes and refresh if needed
    if (lastKnownFileCount !== null && lastKnownDirCount !== null) {
        if (data.file_count !== lastKnownFileCount || data.dir_count !== lastKnownDirCount) {
            console.log(`🔄 Real-time update detected: ${lastKnownFileCount}→${data.file_count} files, ${lastKnownDirCount}→${data.dir_count} dirs`);
            refreshFileTable();
        }
    }

    // Update stored values and display
    lastKnownFileCount = data.file_count;
    lastKnownDirCount = data.dir_count;
    updateStorageDisplay(data);
}


// Function to manually refresh storage stats when file operations occur
async function refreshStorageStats(reason = 'manual') {
    try {
        console.log(`📊 Refreshing storage stats (reason: ${reason})`);
        const response = await fetch('/api/storage_stats');
        if (response.ok) {
            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                const data = await response.json();
                handleStatsUpdate(data);
                document.title = '🟢 ' + document.title.replace(/^🟢 |^🔴 |^🟠 |^⚡ /, '');
                console.log(`✅ Storage stats updated (${reason})`);
            } else {
                console.warn(`⚠️ API returned HTML instead of JSON (status ${response.status})`);
                document.title = '🟠 ' + document.title.replace(/^🟢 |^🔴 |^🟠 |^⚡ /, '');
            }
        } else {
            throw new Error(`API error: ${response.status} ${response.statusText}`);
        }
    } catch (error) {
        console.error('⚠️ Storage stats refresh failed:', error);
        document.title = '🔴 ' + document.title.replace(/^🟢 |^🔴 |^🟠 |^⚡ /, '');
    }
}


// 4.64: the connection indicator used to APPEND " (SSE)" / " (Polling)" to the
// current title on every (re)connect, so the tab title kept growing. Strip the
// status prefix and any suffix first, then add exactly one.
function _titleBase(title) {
    return String(title).replace(/^(🟢|🔴|🟠|⚡) /, '').replace(/( \((SSE|Polling)\))+$/, '');
}

// 4.66: reconnect bookkeeping. Every error event used to queue its own reconnect
// and the previous EventSource (still CONNECTING, retrying by itself) was left
// open next to the new one: duplicate streams, and late events from the old one
// reading `storageEventSource` after it had been set to null (the console's
// "Cannot read properties of null (reading 'readyState')").
let _sseReconnectTimer = null;
let _sseRetryTimer = null;

function _scheduleSseReconnect(ms) {
    if (_sseReconnectTimer) return;   // one pending reconnect is enough
    _sseReconnectTimer = setTimeout(() => {
        _sseReconnectTimer = null;
        connectToStorageStream();
    }, ms);
}

// Polling is only the fallback: keep trying to get the stream back (a QUIC/HTTP3
// reset after the tab was hidden is usually transient). onopen stops the polling.
function _scheduleSseRetryFromPolling() {
    if (_sseRetryTimer) return;
    _sseRetryTimer = setTimeout(() => {
        _sseRetryTimer = null;
        if (!pollingEnabled) return;                       // SSE is already back
        if (document.hidden) { _scheduleSseRetryFromPolling(); return; }
        console.log('📡 Polling mode - trying to restore the SSE stream');
        reconnectAttempts = 0;
        sseFailedPermanently = false;
        connectToStorageStream();
    }, 30000);
}

function connectToStorageStream() {
    try {
        if (storageEventSource) {
            if (storageEventSource.readyState === EventSource.OPEN) {
                console.log('📡 SSE connection already active, not creating duplicate');
                return;
            }
            // CONNECTING (the browser is retrying on its own) or CLOSED: drop it.
            try { storageEventSource.close(); } catch (e) { }
            storageEventSource = null;
        }

        console.log('📡 Connecting to storage stats stream...');

        // Show connecting state
        document.title = '🟠 ' + document.title.replace(/^🟢 |^🔴 |^🟠 |^⚡ /, '');

        // Create EventSource with credentials to include session cookies.
        // Everything below uses the local `es`, never the shared variable, and
        // ignores events from a stream that has since been replaced.
        // 4.67: a returning tab tells the server the last batch it saw; the server then
        // sends one catch-up message if anything newer exists.
        const seqQuery = (lastChangeSeq !== null && lastSeqEpoch !== null)
            ? `?last_seq=${encodeURIComponent(lastChangeSeq)}&seq_epoch=${encodeURIComponent(lastSeqEpoch)}`
            : '';
        const es = new EventSource('/api/storage_stats_stream' + seqQuery, { withCredentials: true });
        storageEventSource = es;
        const isCurrent = () => es === storageEventSource;

        // POLL the readyState to detect connection success
        const stateCheckInterval = setInterval(() => {
            if (!isCurrent()) { clearInterval(stateCheckInterval); return; }
            if (es.readyState === EventSource.OPEN) {
                document.title = '🟢 ' + document.title.replace(/^🟢 |^🔴 |^🟠 |^⚡ /, '');
                connectionStatus = 'connected';
                window.storageStatsInitialized = true;
                clearInterval(stateCheckInterval);
            } else if (es.readyState === EventSource.CLOSED) {
                clearInterval(stateCheckInterval);
            }
        }, 100); // Check every 100ms

        // IMMEDIATE detection of ANY data
        let dataReceived = false;
        es.addEventListener('message', function (event) {
            if (!isCurrent()) return;
            if (!dataReceived) {
                dataReceived = true;
                // Immediately turn green on first message
                document.title = '🟢 ' + document.title.replace(/^🟢 |^🔴 |^🟠 |^⚡ /, '');
                connectionStatus = 'connected';
                window.storageStatsInitialized = true;
            }
        });

        // A backgrounded/frozen tab getting its HTTP/2 or HTTP/3 stream reset by
        // the browser itself (not the server) is expected: keep it at debug level
        // while hidden; the reconnect/polling logic in onerror recovers from it.
        es.addEventListener('error', function (event) {
            if (!isCurrent()) return;
            const logFn = document.hidden ? console.debug : console.warn;
            logFn('⚠️ SSE error event, readyState:', es.readyState);
        });

        es.onopen = function () {
            if (!isCurrent()) return;
            console.log('✅ SSE connection successful - disabling polling fallback');
            connectionStatus = 'connected';
            reconnectAttempts = 0;

            // Stop polling if it was running
            stopPolling();

            // SSE will provide initial data, no need for separate API call
            window.storageStatsInitialized = true;

            // Add clean connection indicator
            document.title = '🟢 ' + _titleBase(document.title) + ' (SSE)';
        };

        es.onmessage = function (event) {
            if (!isCurrent()) return;

            // If this is the first message and we're still connecting, treat it as successful connection
            if (document.title.startsWith('🟠')) {
                document.title = '🟢 ' + document.title.replace(/^🟢 |^🔴 |^🟠 |^⚡ /, '');
                connectionStatus = 'connected';
                reconnectAttempts = 0;
                updateConnectionStatus();
                window.storageStatsInitialized = true;
            }

            try {
                const data = JSON.parse(event.data);

                handleStorageUpdate(data);
            } catch (error) {
                console.warn('⚠️ Failed to parse SSE data:', error, event.data);
            }
        };

        es.onerror = function (event) {
            if (!isCurrent()) return;   // a replaced stream's late event

            // While hidden this is almost always the browser itself resetting the
            // stream on a backgrounded/frozen tab, not a real failure.
            const logFn = document.hidden ? console.debug : console.warn;
            logFn('❌ Storage stats stream error, readyState:', es.readyState);
            connectionStatus = 'error';

            document.title = '🔴 ' + document.title.replace(/^🟢 |^🔴 |^🟠 |^⚡ /, '');

            // A reconnect is already queued: further error events of the same failing
            // stream must not use up reconnect attempts (or queue more).
            if (_sseReconnectTimer) return;

            if (isUploading) {
                console.log('📤 Upload in progress — reconnecting SSE (no give-up limit)');
                reconnectAttempts = 0; // Never count against upload sessions
                _scheduleSseReconnect(1000); // Reconnect faster during uploads (1s vs 3s)
                return;
            }

            // Normal (non-upload) path: try a few SSE reconnects then fall back to polling
            if (reconnectAttempts < 2) {
                reconnectAttempts++;
                console.log(`🔄 Attempting SSE reconnect (${reconnectAttempts}/2) in ${reconnectDelay}ms...`);
                _scheduleSseReconnect(reconnectDelay);
            } else {
                (document.hidden ? console.debug : console.warn)('💀 SSE reconnection failed, switching to polling fallback...');
                sseFailedPermanently = true;

                try { es.close(); } catch (e) { }
                if (isCurrent()) storageEventSource = null;

                setupFallbackPolling();
                _scheduleSseRetryFromPolling();
            }
        };

    } catch (error) {
        console.error('❌ Error initializing SSE connection:', error);
        sseFailedPermanently = true;
        setupFallbackPolling();
        _scheduleSseRetryFromPolling();
    }
}

// Polling fallback system for when SSE fails
function setupFallbackPolling() {
    if (pollingEnabled) {
        console.log('📊 Polling already enabled, skipping setup');
        return;
    }

    const pollingDelay = INSTANT_LOAD_SETTINGS.enableInstantMode ? INSTANT_LOAD_SETTINGS.pollingDelay : 0;

    console.log(`🔄 Setting up INSTANT polling fallback (delay: ${pollingDelay}ms)...`);

    setTimeout(() => {
        pollingEnabled = true;
        lastPollingCheck = 0; // Start with 0 for instant initial load

        // Update title to show polling mode
        document.title = '🟠 ' + _titleBase(document.title) + ' (Polling)';

        // Start polling with configurable interval
        const pollingIntervalTime = INSTANT_LOAD_SETTINGS.pollingIntervalTime || 2000;
        pollingInterval = setInterval(performPollingCheck, pollingIntervalTime);

        // Perform immediate initial check
        performPollingCheck();
    }, pollingDelay);
}

async function performPollingCheck() {
    try {
        // Include current file/dir counts for accurate change detection
        const currentFiles = lastKnownFileCount || 0;
        const currentDirs = lastKnownDirCount || 0;

        let pollUrl = `/api/storage_stats_poll?last_check=${lastPollingCheck}&last_files=${currentFiles}&last_dirs=${currentDirs}`;
        if (lastChangeSeq !== null && lastSeqEpoch !== null) {
            // 4.67: the server then reports a change only when something changed
            // and says which folders (changed_dirs), like the SSE stream does
            pollUrl += `&last_seq=${encodeURIComponent(lastChangeSeq)}&seq_epoch=${encodeURIComponent(lastSeqEpoch)}&last_size=${lastKnownTotalSize || 0}`;
        }
        const response = await fetch(pollUrl, {
            method: 'GET',
            cache: 'no-cache',
            headers: {
                'Cache-Control': 'no-cache'
            }
        });

        if (!response.ok) {
            throw new Error(`Polling failed: ${response.status}`);
        }

        const data = await response.json();
        console.log('📊 Polling response:', data);

        // Update connection status on successful poll
        if (connectionStatus !== 'connected') {
            connectionStatus = 'connected';
            document.title = '🟢 ' + _titleBase(document.title) + ' (Polling)';
            console.log('🟢 Polling connection established');
        }

        // Update last check timestamp
        lastPollingCheck = data.timestamp;
        _noteChangeSeq(data);   // 4.67: keep the baseline even when nothing changed

        // Handle the data same way as SSE
        if (data.changed || !window.storageStatsInitialized) {
            console.log('🔄 Changes detected via polling, updating display...');

            // Convert polling response to SSE-like format
            const sseData = {
                type: 'storage_stats_update',
                timestamp: data.timestamp,
                initial: !window.storageStatsInitialized,
                data: data.data
            };
            if (data.change_seq !== undefined) {   // 4.67
                sseData.change_seq = data.change_seq;
                sseData.seq_epoch = data.seq_epoch;
            }
            if (Array.isArray(data.changed_dirs)) {
                sseData.changed_dirs = data.changed_dirs;
                sseData.changed_dirs_truncated = !!data.changed_dirs_truncated;
            }

            handleStorageUpdate(sseData);
            window.storageStatsInitialized = true;
        }

    } catch (error) {
        console.error('❌ Polling check failed:', error);
        connectionStatus = 'error';
        document.title = '🔴 ' + _titleBase(document.title) + ' (Polling)';
    }
}

function stopPolling() {
    if (pollingInterval) {
        clearInterval(pollingInterval);
        pollingInterval = null;
        pollingEnabled = false;
        console.log('🛑 Polling stopped');
    }
}

// 4.67: remember the newest change batch this tab has seen.
function _noteChangeSeq(data) {
    if (!data || typeof data.change_seq !== 'number') return;
    lastChangeSeq = data.change_seq;
    if (data.seq_epoch !== undefined && data.seq_epoch !== null) lastSeqEpoch = data.seq_epoch;
}

// 4.67: a tab that stays hidden does not need live streams. Browsers freeze or
// throttle background tabs and HTTP/3 resets the long-lived streams (that is where
// the ERR_QUIC_PROTOCOL_ERROR lines came from), so after a while hidden the storage
// stream, the polling fallback and the shares stream are closed. On return the
// storage stream reconnects with last_seq (the server replays what changed) and the
// shares badge is polled once.
const STREAM_PAUSE_AFTER_HIDDEN_MS = 45000;
let _streamPauseTimer = null;
let _streamsPaused = false;

function _pauseLiveStreams() {
    _streamPauseTimer = null;
    if (!document.hidden) return;
    if (isUploading) {            // never pause while an upload is running
        _streamPauseTimer = setTimeout(_pauseLiveStreams, 30000);
        return;
    }
    _streamsPaused = true;
    console.debug('⏸️ Tab hidden - pausing live streams');
    if (_sseReconnectTimer) { clearTimeout(_sseReconnectTimer); _sseReconnectTimer = null; }
    if (_sseRetryTimer) { clearTimeout(_sseRetryTimer); _sseRetryTimer = null; }
    if (storageEventSource) {
        try { storageEventSource.close(); } catch (e) { }
        storageEventSource = null;
    }
    stopPolling();
    connectionStatus = 'paused';
    if (typeof _pauseShareEventsStream === 'function') _pauseShareEventsStream();
}

function _resumeLiveStreams() {
    if (_streamPauseTimer) { clearTimeout(_streamPauseTimer); _streamPauseTimer = null; }
    if (!_streamsPaused) return;
    _streamsPaused = false;
    console.log('▶️ Tab visible - resuming live streams');
    reconnectAttempts = 0;
    sseFailedPermanently = false;
    connectToStorageStream();      // sends last_seq: the server replays what was missed
    if (typeof _resumeShareEventsStream === 'function') _resumeShareEventsStream();
}

document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        if (!_streamPauseTimer && !_streamsPaused) {
            _streamPauseTimer = setTimeout(_pauseLiveStreams, STREAM_PAUSE_AFTER_HIDDEN_MS);
        }
    } else {
        _resumeLiveStreams();
    }
});

// 4.66: what does a batch of changed folders (changed_dirs = folders whose DIRECT
// entries changed) mean for the folder on screen?
//   listing  - the folder on screen itself, or one of its direct sub-folders (its
//              Date modified may have moved), changed, or the list was truncated:
//              re-read /api/files (the re-render is skipped if nothing visible differs).
//   children - Set of the on-screen folder's sub-folders that contain a changed folder
//              somewhere below. Only THEIR size cell is re-read, in place. null = all.
//   known    - false when the message carries no changed_dirs (polling, rebuild).
// Before 4.66 any changed folder anywhere below the view (the root shows everything)
// wiped the folder cache and rebuilt the table, so a file that kept changing deep in
// one tree (QuickBooks index files) made every size cell flash all the time.
function _classifyChangedDirs(data) {
    const out = { known: false, listing: false, children: new Set() };
    if (!data || !Array.isArray(data.changed_dirs)) return out;
    out.known = true;
    if (data.changed_dirs_truncated) { out.listing = true; out.children = null; return out; }
    const view = (typeof currentPath === 'string' ? currentPath : '').replace(/^\/+|\/+$/g, '');
    for (const d of data.changed_dirs) {
        if (d === view) { out.listing = true; continue; }
        let rest;
        if (view === '') rest = d;
        else if (d.startsWith(view + '/')) rest = d.slice(view.length + 1);
        else continue;
        const first = rest.split('/')[0];
        out.children.add(view ? view + '/' + first : first);
        if (first === rest) out.listing = true;   // a direct sub-folder changed
    }
    return out;
}

// Re-read folder size cells IN PLACE: no spinner, no row rebuild, and the DOM is
// touched only when the numbers really differ. paths = Set of folder paths, or null
// for every folder on screen. Folders not on screen just lose their cached record.
async function _revalidateDirCells(paths) {
    if (isSearchResultsDisplayed) return;
    const cells = new Map();
    document.querySelectorAll('.dir-info-cell').forEach(c => {
        const p = c.dataset.dirPath;
        if (p) cells.set(p, c);
    });
    if (paths === null) {
        VT.pruneDirCache(new Set(cells.keys()));
    } else {
        paths.forEach(p => { if (!cells.has(p)) VT.invalidateDirCache(p); });
    }
    const queue = (paths === null ? Array.from(cells.keys()) : Array.from(paths).filter(p => cells.has(p)));
    const worker = async () => {
        while (queue.length) {
            const p = queue.shift();
            try {
                const r = await fetch('/api/dir_info/' + p, { cache: 'no-store' });
                if (!r.ok) continue;
                const d = await r.json();
                if (!d || d.error) continue;
                VT.cacheDirInfo(p, d);
                const cell = cells.get(p);
                if (!cell || !cell.isConnected) continue;
                const sig = _dirInfoSig(d);
                if (cell.dataset.sig === sig) continue;   // same numbers: leave it alone
                cell.innerHTML = _dirInfoHtml(d);
                cell.dataset.sig = sig;
                cell.dataset.loaded = 'true';
                const tr = cell.closest('tr');
                if (tr) VT.rowResized(tr);
            } catch (e) { /* keep what is shown */ }
        }
    };
    await Promise.all([worker(), worker(), worker(), worker()]);
}

// Apply an SSE-driven update at most once per second. Several messages in that
// second are merged: listing refresh if ANY asked for it, union of folder cells.
let _sseRefreshLast = 0;
let _sseRefreshTimer = null;
let _ssePendingListing = false;
let _ssePendingCells = new Set();   // Set of folder paths, or null = all visible
function _scheduleSseUpdate(listing, cells) {
    if (listing) _ssePendingListing = true;
    if (cells === null) _ssePendingCells = null;
    else if (cells && _ssePendingCells !== null) cells.forEach(c => _ssePendingCells.add(c));
    if (_sseRefreshTimer) return;  // one already queued - it will use the merged request
    const wait = Math.max(0, 1000 - (Date.now() - _sseRefreshLast));
    _sseRefreshTimer = setTimeout(async () => {
        _sseRefreshTimer = null;
        const doListing = _ssePendingListing;
        const cellSet = _ssePendingCells;
        _ssePendingListing = false;
        _ssePendingCells = new Set();
        if (isUploading || _mutationInFlight) return;
        _sseRefreshLast = Date.now();
        try {
            if (doListing) await refreshFileTable({ onlyIfChanged: true });
            if (cellSet === null || cellSet.size > 0) await _revalidateDirCells(cellSet);
        } catch (e) { console.warn('SSE table refresh failed', e); }
    }, wait);
}
function _scheduleSseTableRefresh() { _scheduleSseUpdate(true, new Set()); }

function handleStorageUpdate(data) {
    _noteChangeSeq(data);   // 4.67

    switch (data.type) {
        case 'connected':
            console.log('📡 SSE connection established');
            break;

        case 'storage_stats_update':
            console.log('🔄 Processing storage_stats_update...', data.data,
                data.walk_progress ? '(walk progress)' : '(reconcile complete)');

            // Brief flash to show SSE activity
            document.title = '⚡ ' + document.title.replace(/^🟢 |^🔴 |^🟠 |^⚡ /, '');
            setTimeout(() => {
                document.title = '🟢 ' + document.title.replace(/^🟢 |^🔴 |^🟠 |^⚡ /, '');
            }, 2000);

            if (data.data) {
                // Always update the storage stats panel (header numbers, disk bar).
                updateStorageDisplay(data.data);
                // Seed free_space tracker for deletion delta calculation
                if (data.data.free_space != null) _lastFreeSpace = data.data.free_space;

                // Update our tracked file counts
                if (data.data.file_count !== undefined) {
                    lastKnownFileCount = data.data.file_count;
                }
                if (data.data.dir_count !== undefined) {
                    lastKnownDirCount = data.data.dir_count;
                }
                if (data.data.total_size !== undefined) {
                    lastKnownTotalSize = data.data.total_size;   // 4.67: sent with polls
                }

                // ── Walk-progress event ────────────────────────────────────────────
                // The walk is still in progress; _dir_info is not yet up-to-date.
                // Only update the stats panel — do NOT refresh the file table or
                // dir-info cells, because they'd fetch stale per-folder sizes.
                // Show a lightweight "scanning…" notification so the user can see
                // the count climbing without the table flickering on every tick.
                if (data.walk_progress && !data.initial) {
                    const changes = data.data.changes || {};
                    if (changes.files_changed > 0 || changes.size_changed !== 0) {
                        let msg = '🔍 Scanning: ';
                        if (data.data.file_count) msg += `${data.data.file_count.toLocaleString()} files`;
                        if (data.data.total_size) {
                            const s = data.data.total_size;
                            const sStr = s >= 1e12 ? (s / 1e12).toFixed(2) + ' TB'
                                : s >= 1e9 ? (s / 1e9).toFixed(2) + ' GB'
                                    : s >= 1e6 ? (s / 1e6).toFixed(1) + ' MB'
                                        : s >= 1024 ? (s / 1024).toFixed(1) + ' KB'
                                            : s + ' bytes';
                            msg += ', ' + sStr;
                        }
                        showUploadStatus(`<i class="fas fa-circle-notch fa-spin"></i> ${msg}`, 'info');
                    }
                    break; // Do NOT fall through to file-table refresh logic
                }

                // ── Reconcile-complete (or regular watchdog) event ─────────────────
                // _dir_info is now authoritative — safe to refresh the file table
                // and re-fetch all dir-info cells.

                // Check for file/folder changes and refresh table if needed
                // Skip change notifications for initial data (page load)
                if (data.data.changes && !data.initial) {
                    const changes = data.data.changes;
                    console.log('🔍 Changes detected:', changes);

                    const hasSignificantChanges = (
                        changes.files_changed !== 0 ||
                        changes.dirs_changed !== 0 ||
                        changes.size_changed !== 0
                    );

                    // 4.66: decide WHAT to refresh instead of "everything".
                    //  refreshListing      - re-read /api/files (skipped if identical)
                    //  cellsToRevalidate   - folder size cells re-read in place:
                    //                        a Set of paths, or null = every folder on screen
                    const cd = _classifyChangedDirs(data);
                    const countsMoved = hasSignificantChanges;
                    // content_changed / mtime_changed are only trusted when the message
                    // has no changed_dirs (the polling endpoint sets both on EVERY new
                    // snapshot, which is how polling mode refreshed the table non-stop)
                    const noisy = changes.content_changed === true || changes.mtime_changed === true;
                    const refreshListing = !!(
                        data.reconcile_complete ||      // walk done: counters are authoritative
                        cd.listing ||                   // 4.64: the folder on screen changed (moves/renames/edits)
                        (!cd.known && (countsMoved || noisy))
                    );
                    const cellsToRevalidate = (
                        data.reconcile_complete || cd.children === null || (!cd.known && countsMoved)
                    ) ? null : cd.children;
                    const shouldRefresh = (
                        refreshListing || cellsToRevalidate === null || cellsToRevalidate.size > 0
                    );

                    if (shouldRefresh) {
                        // Only show notification for significant changes
                        if (hasSignificantChanges) {
                            let message = 'Storage updated: ';
                            if (changes.files_changed > 0) message += `+${changes.files_changed} files `;
                            if (changes.files_changed < 0) message += `${changes.files_changed} files `;
                            if (changes.dirs_changed > 0) message += `+${changes.dirs_changed} folders `;
                            if (changes.dirs_changed < 0) message += `${changes.dirs_changed} folders `;
                            if (changes.size_changed !== 0) message += `size changed `;
                            if (changes.files_changed === 0 && changes.dirs_changed === 0 && changes.size_changed === 0) {
                                message += 'files modified/renamed ';
                            }

                            showUploadStatus(`<i class="fas fa-sync-alt"></i> ${message.trim()}`, 'info');
                        } else {
                            // Minor change - refresh table but don't show notification
                            console.log('📊 Minor content change detected - refreshing table silently');
                        }

                        // Refresh file table for any change
                        console.log('🚀 Triggering instant file table refresh via SSE...');

                        if (!isUploading && !_mutationInFlight) {
                            // 4.66: no cache wipe and no spinner: the table is re-read only if
                            // the listing differs, and the affected folder cells are updated
                            // in place only if their numbers differ.
                            _scheduleSseUpdate(refreshListing, cellsToRevalidate);
                        } else if (isUploading && !_mutationInFlight) {
                            const uploadPaths = new Set();
                            folderGroups.forEach(g => {
                                if (g.status !== 'uploading' && g.status !== 'pending') return;
                                const base = g.basePath || '';
                                const name = g.rootNameOverride || g.rootName || '';
                                if (name) uploadPaths.add(base ? `${base}/${name}` : name);
                            });

                            document.querySelectorAll('.dir-info-cell').forEach(cell => {
                                const p = cell.dataset.dirPath;
                                if (!p) return;
                                const relevant = [...uploadPaths].some(up => {
                                    if (!up) return false;
                                    return p === up || up.startsWith(p + '/');
                                });
                                if (!relevant) return;
                                VT.invalidateDirCache(p);
                                cell.dataset.loaded = '';
                                fetch('/api/dir_info/' + p)
                                    .then(r => r.json())
                                    .then(data => {
                                        if (data.error) return;
                                        let html = data.file_count + ' files, ' + data.dir_count + ' folders';
                                        if (data.total_size > 0) {
                                            const s = data.total_size;
                                            const sStr = s >= 1e12 ? (s / 1e12).toFixed(2) + ' TB'
                                                : s >= 1e9 ? (s / 1e9).toFixed(2) + ' GB'
                                                    : s >= 1e6 ? (s / 1e6).toFixed(1) + ' MB'
                                                        : s >= 1024 ? (s / 1024).toFixed(1) + ' KB'
                                                            : s + ' bytes';
                                            html += '<br><small style="color:white;">' + sStr + '</small>';
                                        }
                                        cell.innerHTML = html;
                                        cell.dataset.loaded = 'true';
                                        VT.cacheDirInfo(p, data);
                                    })
                                    .catch(() => { });
                            });

                            const now = Date.now();
                            if (now - _lastMidUploadTableRefresh > 3000) {
                                _lastMidUploadTableRefresh = now;
                                requestAnimationFrame(async () => { await refreshFileTable(); });
                            }
                        } else if (_mutationInFlight) {
                            const freeNow = data.data.free_space;
                            if (freeNow != null && _lastFreeSpace != null && _deletingPaths.size > 0) {
                                const freed = freeNow - _lastFreeSpace;
                                if (freed > 0) {
                                    _deletingPaths.forEach(p => {
                                        document.querySelectorAll(`.dir-info-cell[data-dir-path="${p}"]`).forEach(cell => {
                                            const s = freed;
                                            const sStr = s >= 1e12 ? (s / 1e12).toFixed(2) + ' TB freed'
                                                : s >= 1e9 ? (s / 1e9).toFixed(2) + ' GB freed'
                                                    : s >= 1e6 ? (s / 1e6).toFixed(1) + ' MB freed'
                                                        : s >= 1024 ? (s / 1024).toFixed(1) + ' KB freed'
                                                            : s + ' bytes freed';
                                            cell.innerHTML = `<i class="fas fa-spinner fa-spin" style="opacity:0.6;font-size:11px;"></i> Deleting… <small style="color:white;">${sStr}</small>`;
                                        });
                                    });
                                }
                            }
                            if (freeNow != null) _lastFreeSpace = freeNow;
                            console.log('🗑️ Mutation in flight — showing deletion progress via free_space delta');
                        }

                        // Skip redundant storage stats call since we already have the data
                        console.log('📊 Using real-time storage data (skipping additional API call)');
                    } else {
                        console.log('📊 No significant changes detected, no file table refresh needed');
                    }
                } else if (data.initial) {
                    console.log('📊 Initial storage data received (no change notification shown)');
                } else {
                    console.log('📊 No changes data in SSE update');
                }

                console.log(`📊 Updated file counts: ${lastKnownFileCount} files, ${lastKnownDirCount} dirs`);
            }
            break;

        case 'fs_activity': {
            // 4.64: files changed while a reconcile walk is running (counters are
            // frozen then). Refresh the listing if the folder on screen is affected;
            // folder-size cells are refreshed when the walk completes.
            // 4.67: catch_up = the server telling a returning tab (hidden / dropped
            // stream) what changed meanwhile. Not a walk, so the affected folder
            // cells are re-read too (children null = everything on screen).
            const cd = _classifyChangedDirs(data);
            if (!isUploading && !_mutationInFlight) {
                if (data.catch_up) _scheduleSseUpdate(cd.listing, cd.children);
                else if (cd.listing) _scheduleSseUpdate(true, new Set());
            }
            break;
        }

        case 'ping':
            // Keep-alive ping, just log it

            break;

        default:
            console.log('📡 Unknown SSE message type:', data.type);
    }
}

function updateConnectionStatus() {
    // Update a connection indicator if you have one in the UI
    // This is optional - you could add a small indicator icon
    const indicator = document.getElementById('connectionStatus');
    if (indicator) {
        indicator.className = `connection-status ${connectionStatus}`;
        indicator.title = `Real-time monitoring: ${connectionStatus}`;
    }
}

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (storageEventSource) {
        storageEventSource.close();
        storageEventSource = null;
    }
});

// Reconnect when page becomes visible (in case connection was lost)
document.addEventListener('visibilitychange', () => {
    if (!document.hidden && connectionStatus === 'error' && storageEventSource === null) {
        console.log('📡 Page visible - attempting to reconnect to storage stream');
        reconnectAttempts = 0;
        connectToStorageStream();
    }
});

// ── Archive preview: load & retry ────────────────────────────────────────────

/**
 * Fetch archive listing from the server, handling password prompts & errors.
 * Called initially with password=null; retried with the user-supplied password.
 */
function _loadArchivePreview(body, itemPath, password) {
    const url = `/archive_preview/${encodePathForUrl(itemPath)}` +
        (password != null ? `?password=${encodeURIComponent(password)}` : '');

    fetch(url)
        .then(r => r.json())
        .then(data => {
            if (data.error === 'password_required') {
                _renderArchivePasswordPrompt(body, itemPath, false);
                return;
            }
            if (data.error === 'wrong_password') {
                _renderArchivePasswordPrompt(body, itemPath, true);
                return;
            }
            if (data.error) {
                body.innerHTML = `
                    <p class="viewer-error">
                        <i class="fas fa-exclamation-triangle"></i>
                        ${escapeHtml(data.error)}
                    </p>`;
                return;
            }
            _renderArchivePreview(body, data);
        })
        .catch(err => {
            body.innerHTML = `
                <p class="viewer-error">
                    <i class="fas fa-exclamation-triangle"></i>
                    Could not load archive: ${escapeHtml(err.message)}
                </p>`;
        });
}

// ── Archive preview: password prompt ─────────────────────────────────────────

function _renderArchivePasswordPrompt(body, itemPath, wrongPassword) {
    body.innerHTML = '';
    body.classList.add('viewer-archive');

    const wrap = document.createElement('div');
    wrap.className = 'archive-password-wrap';
    wrap.innerHTML = `
        <div class="archive-password-icon">
            <i class="fas fa-lock"></i>
        </div>
        <div class="archive-password-title">Password Protected Archive</div>
        <div class="archive-password-subtitle">
            Enter the password to browse the archive contents.
        </div>
        ${wrongPassword ? `
            <div class="archive-password-error">
                <i class="fas fa-exclamation-circle"></i> Incorrect password — please try again.
            </div>` : ''}
        <div class="archive-password-form">
            <div class="archive-password-input-wrap">
                <i class="fas fa-key archive-password-input-icon"></i>
                <input
                    type="password"
                    id="archivePasswordInput"
                    class="archive-password-input"
                    placeholder="Archive password"
                    autocomplete="current-password"
                >
            </div>
            <button class="btn btn-primary archive-password-btn" id="archivePasswordBtn">
                <i class="fas fa-unlock-alt"></i> Unlock
            </button>
        </div>
    `;
    body.appendChild(wrap);

    const input = wrap.querySelector('#archivePasswordInput');
    const btn = wrap.querySelector('#archivePasswordBtn');

    const tryPassword = () => {
        const pw = input.value.trim();
        if (!pw) { input.focus(); input.classList.add('archive-input-shake'); setTimeout(() => input.classList.remove('archive-input-shake'), 500); return; }

        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Unlocking…';
        // Show inline spinner while re-fetching
        body.innerHTML = `<div class="viewer-archive-loading">
            <i class="fas fa-circle-notch fa-spin"></i> Unlocking…
        </div>`;
        _loadArchivePreview(body, itemPath, pw);
    };

    btn.addEventListener('click', tryPassword);
    input.addEventListener('keydown', e => { if (e.key === 'Enter') tryPassword(); });

    // Prevent viewer Escape handler from eating keystrokes inside the input
    input.addEventListener('keydown', e => e.stopPropagation(), true);

    input.focus();
}

// ── Archive preview: main renderer ───────────────────────────────────────────

function _renderArchivePreview(body, data) {
    body.innerHTML = '';
    body.classList.add('viewer-archive');

    // ── Helpers ──────────────────────────────────────────────────────────────
    const fmtSize = (bytes) => {
        if (bytes == null || bytes < 0) return '—';
        if (bytes === 0) return '0 B';
        if (bytes >= 1e12) return (bytes / 1e12).toFixed(2) + ' TB';
        if (bytes >= 1e9) return (bytes / 1e9).toFixed(2) + ' GB';
        if (bytes >= 1e6) return (bytes / 1e6).toFixed(1) + ' MB';
        if (bytes >= 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return bytes + ' B';
    };

    const fileIcon = (name) => {
        const ext = (name.split('.').pop() || '').toLowerCase();
        const map = {
            // images
            jpg: 'fa-file-image', jpeg: 'fa-file-image', png: 'fa-file-image', gif: 'fa-file-image',
            bmp: 'fa-file-image', webp: 'fa-file-image', svg: 'fa-file-image', avif: 'fa-file-image',
            // video
            mp4: 'fa-file-video', avi: 'fa-file-video', mov: 'fa-file-video',
            mkv: 'fa-file-video', webm: 'fa-file-video', wmv: 'fa-file-video',
            // audio
            mp3: 'fa-file-audio', wav: 'fa-file-audio', flac: 'fa-file-audio',
            aac: 'fa-file-audio', ogg: 'fa-file-audio', m4a: 'fa-file-audio',
            // docs
            pdf: 'fa-file-pdf',
            doc: 'fa-file-word', docx: 'fa-file-word',
            xls: 'fa-file-excel', xlsx: 'fa-file-excel',
            ppt: 'fa-file-powerpoint', pptx: 'fa-file-powerpoint',
            // code / text
            js: 'fa-file-code', ts: 'fa-file-code', jsx: 'fa-file-code', tsx: 'fa-file-code',
            py: 'fa-file-code', java: 'fa-file-code', cpp: 'fa-file-code', c: 'fa-file-code',
            cs: 'fa-file-code', go: 'fa-file-code', rb: 'fa-file-code', php: 'fa-file-code',
            html: 'fa-file-code', css: 'fa-file-code', json: 'fa-file-code', xml: 'fa-file-code',
            sh: 'fa-file-code', bat: 'fa-file-code',
            txt: 'fa-file-alt', md: 'fa-file-alt', csv: 'fa-file-alt', log: 'fa-file-alt',
            // archives
            zip: 'fa-file-archive', rar: 'fa-file-archive', '7z': 'fa-file-archive',
            tar: 'fa-file-archive', gz: 'fa-file-archive', bz2: 'fa-file-archive',
        };
        return map[ext] || 'fa-file';
    };

    // ── Build tree from flat entry list ──────────────────────────────────────
    // Each node: { name, is_dir, size, compressed_size, modified, children: {} }
    const root = { children: {} };

    for (const entry of data.entries) {
        // Normalise separators and strip leading slash
        const parts = entry.name.replace(/\\/g, '/').split('/').filter(p => p.length > 0);
        if (!parts.length) continue;

        let node = root;
        for (let i = 0; i < parts.length; i++) {
            const part = parts[i];
            const isLast = i === parts.length - 1;

            if (!node.children[part]) {
                node.children[part] = {
                    name: part,
                    is_dir: !isLast || entry.is_dir,
                    size: 0, compressed_size: 0, modified: '',
                    children: {},
                };
            }
            if (isLast) {
                const n = node.children[part];
                n.is_dir = entry.is_dir;
                n.size = entry.size || 0;
                n.compressed_size = entry.compressed_size || 0;
                n.modified = entry.modified || '';
            }
            node = node.children[part];
        }
    }

    // ── Header bar ───────────────────────────────────────────────────────────
    const fileCt = data.entries.filter(e => !e.is_dir).length;
    const dirCt = data.entries.filter(e => e.is_dir).length;

    const typeBadgeClass = { zip: 'archive-type-badge-zip', rar: 'archive-type-badge-rar', '7z': 'archive-type-badge-7z', tar: 'archive-type-badge-tar' };
    const badgeClass = typeBadgeClass[data.type] || 'archive-type-badge-default';

    const header = document.createElement('div');
    header.className = 'archive-header';
    header.innerHTML = `
        <span class="archive-type-badge ${badgeClass}">${escapeHtml(data.type.toUpperCase())}</span>
        <span class="archive-stat"><i class="fas fa-file"></i> ${fileCt.toLocaleString()} file${fileCt !== 1 ? 's' : ''}</span>
        <span class="archive-stat"><i class="fas fa-folder"></i> ${dirCt.toLocaleString()} folder${dirCt !== 1 ? 's' : ''}</span>
        <span class="archive-stat"><i class="fas fa-weight-hanging"></i> ${fmtSize(data.total_size)}</span>
        ${data.encrypted ? `<span class="archive-stat archive-stat-lock"><i class="fas fa-lock"></i> Encrypted</span>` : ''}
        ${data.truncated ? `<span class="archive-stat archive-stat-warn">
            <i class="fas fa-exclamation-triangle"></i>
            Showing first 10,000 of ${data.total_entries.toLocaleString()} entries
        </span>` : ''}
    `;
    body.appendChild(header);

    // ── Tree ─────────────────────────────────────────────────────────────────
    const treeWrap = document.createElement('div');
    treeWrap.className = 'archive-tree';
    body.appendChild(treeWrap);

    const renderNode = (node, container, depth) => {
        const sorted = Object.values(node.children).sort((a, b) => {
            if (a.is_dir !== b.is_dir) return a.is_dir ? -1 : 1;
            return a.name.localeCompare(b.name, undefined, { sensitivity: 'base' });
        });

        for (const child of sorted) {
            const hasChildren = Object.keys(child.children).length > 0;

            const row = document.createElement('div');
            row.className = 'archive-entry' + (child.is_dir ? ' archive-entry-dir' : '');
            row.style.paddingLeft = (depth * 16 + 10) + 'px';

            // Compression ratio label
            let ratioHtml = '';
            if (!child.is_dir && child.size > 0 && child.compressed_size > 0 && child.compressed_size < child.size) {
                const pct = Math.round((1 - child.compressed_size / child.size) * 100);
                if (pct > 0) ratioHtml = `<span class="archive-entry-ratio">${pct}% saved</span>`;
            }

            row.innerHTML = `
                <span class="archive-entry-toggle">
                    ${child.is_dir
                    ? `<i class="fas ${hasChildren ? 'fa-chevron-right' : 'fa-minus'} archive-chevron${hasChildren ? '' : ' archive-chevron-empty'}"></i>`
                    : ''}
                </span>
                <i class="fas ${child.is_dir ? 'fa-folder' : fileIcon(child.name)} archive-entry-icon ${child.is_dir ? 'archive-icon-dir' : 'archive-icon-file'}"></i>
                <span class="archive-entry-name">${escapeHtml(child.name)}</span>
                <span class="archive-entry-meta">
                    ${child.modified ? `<span class="archive-entry-date">${escapeHtml(child.modified)}</span>` : ''}
                    ${!child.is_dir && child.size >= 0 ? `<span class="archive-entry-size">${fmtSize(child.size)}</span>` : ''}
                    ${ratioHtml}
                </span>
            `;

            container.appendChild(row);

            if (child.is_dir && hasChildren) {
                const childContainer = document.createElement('div');
                childContainer.className = 'archive-children';
                childContainer.style.display = 'none';
                renderNode(child, childContainer, depth + 1);
                container.appendChild(childContainer);

                // Toggle expand/collapse on click
                row.style.cursor = 'pointer';
                row.addEventListener('click', () => {
                    const chevron = row.querySelector('.archive-chevron:not(.archive-chevron-empty)');
                    const open = childContainer.style.display !== 'none';
                    childContainer.style.display = open ? 'none' : '';
                    if (chevron) {
                        chevron.classList.toggle('fa-chevron-right', open);
                        chevron.classList.toggle('fa-chevron-down', !open);
                    }
                    row.classList.toggle('archive-entry-open', !open);
                    // Update folder icon
                    const folderIcon = row.querySelector('.fa-folder, .fa-folder-open');
                    if (folderIcon) {
                        folderIcon.classList.toggle('fa-folder', open);
                        folderIcon.classList.toggle('fa-folder-open', !open);
                    }
                });
            }
        }
    };

    renderNode(root, treeWrap, 0);

    // Auto-expand if the archive has only one top-level folder
    const topLevelKeys = Object.keys(root.children);
    if (topLevelKeys.length === 1) {
        const firstRow = treeWrap.querySelector('.archive-entry-dir');
        if (firstRow) firstRow.click();
    }
}
// ─────────────────────────────────────────────────────────────────────────────
// HLS Adaptive Streaming helpers  (@videojs/html web-component + ffmpeg backend)
// Served locally from static/js/video.js + static/css/video.css — no CDN.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Append seek overlay buttons on top of the player area.
 * Uses MutationObserver on video-skin's shadow root to sync
 * visibility with Video.js controls (media-controls visible state).
 */
/**
 * Mobile double-tap to seek: tap left third = -10s, tap right third = +10s.
 * Works in normal and fullscreen. Single tap passes through to Video.js controls.
 */
function _initMobileDoubleTapSeek(area) {
    if (!area) return;
    let lastTap = 0, lastX = 0;

    area.addEventListener('touchend', function (e) {
        // Ignore taps on buttons/controls
        if (e.target.closest('button, input, select, a, media-controls')) return;
        const now = Date.now();
        const touch = e.changedTouches[0];
        const rect = area.getBoundingClientRect();
        const x = touch.clientX - rect.left;
        const isDouble = (now - lastTap) < 300 && Math.abs(touch.clientX - lastX) < 80;
        lastTap = now;
        lastX = touch.clientX;
        if (!isDouble) return;
        // Left third = back, right third = forward
        const third = rect.width / 3;
        if (x < third) _hlsSkip(-10);
        else if (x > rect.width - third) _hlsSkip(10);
    }, { passive: true });
}

/**
 * Inject a responsive @media CSS rule into video-skin's shadow root
 * to hide the playback rate button on mobile. Uses @media so it
 * responds to resize without re-injecting.
 */
function _injectMobileSpeedHide(playerEl) {
    if (!playerEl) return;
    // Previously this built two inline <style> elements from template
    // literals and appended them into the <video-skin> shadow root.
    // style-src-elem 'self' (no inline hashes for this rule) silently
    // dropped both. Loading the same rules from an external same-origin
    // stylesheet via <link> satisfies 'self' directly, needs no CSP hash
    // at all, and — unlike a hardcoded sha256 hash — keeps working if
    // this CSS is ever edited later without touching app.py.
    const HREF = '/static/css/video-skin-overrides.css';

    function _addLinkOnce(root) {
        if (!root || root.querySelector('link[data-skin-overrides]')) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = HREF;
        link.setAttribute('data-skin-overrides', '1');
        root.appendChild(link);
    }

    let attempts = 0;
    const iv = setInterval(() => {
        attempts++;
        const skin = playerEl.querySelector('video-skin');
        if (skin && skin.shadowRoot) {
            _addLinkOnce(skin.shadowRoot);
            clearInterval(iv);
            return;
        }
        if (playerEl.shadowRoot) {
            const skin2 = playerEl.shadowRoot.querySelector('video-skin');
            if (skin2 && skin2.shadowRoot) {
                _addLinkOnce(skin2.shadowRoot);
                clearInterval(iv);
                return;
            }
        }
        if (attempts >= 40) clearInterval(iv);
    }, 100);
}

async function _hlsStartStream(itemPath, wrapperId) {
    window._hlsPollCancel = false;
    window._vjsCurrentPlayer = null;

    const $id = id => document.getElementById(id);

    function _setStatus(txt) { const e = $id('hls-status-msg'); if (e) e.textContent = txt; }
    function _setProgress(pct) {
        const pw = $id('hls-progress-wrap'); if (pw) pw.style.display = 'block';
        const pb = $id('hls-progress-bar'); if (pb) pb.style.width = pct + '%';
        const bl = $id('hls-btn-label'); if (bl) bl.textContent = `Processing\u2026 ${pct}%`;
    }
    function _setStreamReady() {
        const bs = $id('hls-btn-spinner'); if (bs) bs.style.display = 'none';
        const bl = $id('hls-btn-label'); if (bl) bl.textContent = '\u26a1 Stream HLS';
        const bt = $id('hls-btn-stream'); if (bt) { bt.disabled = false; bt.title = 'Play adaptive bitrate stream'; }
        const pw = $id('hls-progress-wrap'); if (pw) pw.style.display = 'none';
        _setStatus('');
    }
    function _hideStreamBtn() {
        const bt = $id('hls-btn-stream'); if (bt) bt.style.display = 'none';
        const pw = $id('hls-progress-wrap'); if (pw) pw.style.display = 'none';
    }
    function _hideQualityRow() {
        const qr = $id('hls-quality-row'); if (qr) qr.style.display = 'none';
    }

    // Tear down whatever is currently in hls-player-area before mounting
    // a new player. Pausing and nulling src on the <video> releases the
    // MediaSource; removing the web component from the DOM cleans up the rest.
    function _destroyCurrentPlayer() {
        const area = $id('hls-player-area');
        if (!area) return;
        area.querySelectorAll('video, audio').forEach(m => {
            try { m.pause(); m.removeAttribute('src'); m.load(); } catch (_) { }
        });
        // Destroy the external HLS.js audio instance used for audio track switching
        _destroyAudioTrackEl();
        // Remove audio/subtitle selector rows and overlay so they're rebuilt fresh on next mount
        ['hls-audio-row', 'hls-subtitle-row', 'hls-subtitle-overlay'].forEach(id => {
            const el = $id(id);
            if (el) el.remove();
        });
        // Shadow-root overlay is removed with the player element itself (innerHTML = '')
        area.innerHTML = '';
    }

    function _destroyAudioTrackEl() {
        if (window._audioTrackHls) {
            try { window._audioTrackHls.destroy(); } catch (_) { }
            window._audioTrackHls = null;
        }
        if (window._audioTrackEl) {
            try { window._audioTrackEl.pause(); window._audioTrackEl.remove(); } catch (_) { }
            window._audioTrackEl = null;
        }
        if (window._audioTrackSync) {
            clearInterval(window._audioTrackSync);
            window._audioTrackSync = null;
        }
        window._audioTrackIdx = null;
    }

    function _mountRawPlayer(src, autoplay) {
        const area = $id('hls-player-area');
        if (!area) return;
        _destroyCurrentPlayer();
        area.style.cssText = 'width:100%;min-height:300px;flex:1 1 auto;position:relative;';
        const ap = autoplay ? 'autoplay muted' : '';
        area.insertAdjacentHTML('afterbegin', `
          <video-player class="vjs-cloudinator-player" style="width:100%;height:100%;display:block;">
            <video-skin>
              <video slot="media" src="${escapeHtml(src)}" ${ap} playsinline style="width:100%;height:100%;"></video>
            </video-skin>
          </video-player>`);
        const playerEl = area.querySelector('video-player');
        window._vjsCurrentPlayer = playerEl;
        if (autoplay) _unmuteWhenReady(playerEl);
        _hideQualityRow();
        _injectMobileSpeedHide(playerEl);
        _initMobileDoubleTapSeek(area);
    }

    function _mountHlsPlayer(masterUrl, autoplay, audioMeta, subMeta, cacheKey) {
        const area = $id('hls-player-area');
        if (!area) return;
        _destroyCurrentPlayer();
        area.style.cssText = 'width:100%;min-height:300px;flex:1 1 auto;position:relative;';

        // `autoplay muted` is required — without autoplay, VHS never starts
        // buffering and canplay never fires, leaving the video permanently paused.
        // The old NotSupportedError race (browser autoplay vs HLS.js MSE setup)
        // no longer applies with fMP4 segments and the current VHS version.
        // _unmuteWhenReady handles unmuting once VHS has buffered enough data.
        // NOTE: <track> elements are intentionally omitted here — they are injected
        // dynamically inside _buildTrackSelectors._getVideo, AFTER the change
        // listener is active. This ensures tracks are never in the DOM before
        // we can synchronously disable them, eliminating the subtitle flash.
        const ap = autoplay ? 'autoplay muted' : '';
        area.insertAdjacentHTML('afterbegin', `
          <video-player class="vjs-cloudinator-player" style="width:100%;height:100%;display:block;">
            <video-skin>
              <video slot="media"
                     src="${escapeHtml(masterUrl)}"
                     type="application/x-mpegURL"
                     ${ap}
                     playsinline
                     style="width:100%;height:100%;">
              </video>
            </video-skin>
          </video-player>`);
        const playerEl = area.querySelector('video-player');
        window._vjsCurrentPlayer = playerEl;
        // Store the original master URL so audio switching can reset to it
        // if quality buttons have changed video.src to a variant URL.
        window._hlsMasterUrl = masterUrl;
        window._hlsCacheKey = cacheKey;
        window._hlsAudioIdx = 0;
        if (autoplay) _unmuteWhenReady(playerEl);
        _attachQualitySelector(playerEl);
        _injectMobileSpeedHide(playerEl);
        _initMobileDoubleTapSeek(area);
        _buildTrackSelectors(playerEl, audioMeta || [], subMeta || [], cacheKey);
    }

    // Web-native formats browsers can decode directly without transcoding.
    // Non-native formats (mkv, avi, wmv, flv, etc.) must go through HLS because
    // browsers cannot decode x265/HEVC or many other codecs natively.
    const _WEB_NATIVE_EXTS = new Set(['mp4', 'webm', 'mov', 'm4v', 'ogv']);
    const _itemExt = itemPath.split('.').pop().toLowerCase();
    const _isWebNative = _WEB_NATIVE_EXTS.has(_itemExt);

    const rawBtn = $id('hls-btn-raw');
    if (rawBtn) {
        rawBtn.addEventListener('click', () => {
            _destroyCurrentPlayer();
            _mountRawPlayer(`/view/${encodePathForUrl(itemPath)}`, false);
            rawBtn.classList.add('hls-btn-active');
            const sb = $id('hls-btn-stream'); if (sb) sb.classList.remove('hls-btn-active');
            if (!_isWebNative) {
                _setStatus('\u26a0\ufe0f This format is not supported by the browser \u2014 video will not play, audio only');
            } else {
                _setStatus('');
            }
        });
    }

    // ── Check HLS status FIRST before mounting anything ───────────────────────
    // If HLS cache is already ready, go straight to HLS — never flash raw first.
    // Only fall back to raw if HLS is unavailable or still transcoding.
    let startData;
    try {
        _setStatus('Checking stream\u2026');
        const r = await fetch(`/hls_start/${encodePathForUrl(itemPath)}`, { cache: 'no-store' });
        startData = await r.json();
    } catch (err) {
        _setStatus('');
        _hideStreamBtn();
        // Fetch failed entirely — fall back to raw
        _mountRawPlayer(`/view/${encodePathForUrl(itemPath)}`, true);
        const rb = $id('hls-btn-raw'); if (rb) rb.classList.add('hls-btn-active');
        return;
    }

    if (!startData.hls_available) {
        // No HLS (ffmpeg missing/disabled or unsupported format)
        _hideStreamBtn();
        if (!_isWebNative) {
            // Non-native codec, no HLS — mount raw (audio only; video won't decode)
            const rb = $id('hls-btn-raw');
            if (rb) { rb.style.opacity = ''; rb.style.pointerEvents = ''; rb.title = 'Play without transcoding'; }
            _mountRawPlayer(`/view/${encodePathForUrl(itemPath)}`, false);
            if (rb) rb.classList.add('hls-btn-active');
            if (startData.reason === 'ffmpeg_not_installed') {
                _setStatus('\u26a0\ufe0f ffmpeg not found \u2014 this format is not supported by the browser, audio only');
            } else {
                // ffmpeg_disabled or any other reason — still warn about codec support
                _setStatus('\u26a0\ufe0f This format is not supported by the browser \u2014 video will not play, audio only');
            }
        } else {
            _setStatus('');
            _mountRawPlayer(`/view/${encodePathForUrl(itemPath)}`, true);
            const rb = $id('hls-btn-raw'); if (rb) rb.classList.add('hls-btn-active');
        }
        return;
    }

    const cacheKey = startData.cache_key;

    if (startData.status === 'ready') {
        // HLS already cached — go straight to HLS, never flash raw first.
        // Raw button is left enabled for audio-only access (e.g. x265 MKV).
        _setStreamReady();
        _wireStreamButton(cacheKey, startData.profiles, startData.audio_tracks, startData.sub_tracks);
        _setStatus('');
        _mountHlsPlayer(`/hls_files/${cacheKey}/master.m3u8`, true, startData.audio_tracks, startData.sub_tracks, cacheKey);
        const rb2 = $id('hls-btn-raw');
        if (rb2) {
            rb2.classList.remove('hls-btn-active');
            rb2.style.opacity = '';
            rb2.style.pointerEvents = '';
            if (!_isWebNative) rb2.title = 'Play raw \u2014 audio only (video codec not supported by browser)';
        }
        const sb = $id('hls-btn-stream'); if (sb) sb.classList.add('hls-btn-active');
        _buildQualityBar(startData.profiles, cacheKey, startData.audio_tracks || []);
        return;
    }

    // HLS is still transcoding — mount appropriate fallback while we wait
    if (_isWebNative) {
        // Web-native: raw plays fine while HLS processes in background
        _mountRawPlayer(`/view/${encodePathForUrl(itemPath)}`, true);
        const rb = $id('hls-btn-raw'); if (rb) rb.classList.add('hls-btn-active');
    } else {
        // Non-native: show placeholder — raw won't work, HLS will autoplay when ready
        const area = $id('hls-player-area');
        if (area) {
            area.style.cssText = 'width:100%;min-height:300px;flex:1 1 auto;display:flex;align-items:center;justify-content:center;background:#111;border-radius:8px;';
            area.innerHTML = `
              <div style="text-align:center;color:rgba(255,255,255,0.6);padding:32px;">
                <div style="font-size:32px;margin-bottom:12px;">⚙️</div>
                <div style="font-size:14px;font-weight:600;margin-bottom:6px;">Preparing stream…</div>
                <div style="font-size:12px;opacity:0.7;">This format requires transcoding for browser playback.<br>HLS stream will start automatically when ready.</div>
              </div>`;
        }
        _setStatus('Transcoding for browser compatibility\u2026');
        const rb = $id('hls-btn-raw');
        if (rb) {
            rb.title = 'Raw playback unavailable — codec not supported by browser';
            rb.style.opacity = '0.4';
            rb.style.pointerEvents = 'none';
        }
    }

    const MAX_POLLS = 300;
    let polls = 0;
    while (!window._hlsPollCancel) {
        if (++polls > MAX_POLLS) { _hideStreamBtn(); _setStatus(''); return; }
        let st;
        try {
            const r = await fetch(`/hls_status/${cacheKey}`, { cache: 'no-store' });
            st = await r.json();
        } catch (_) { await _hlsSleep(2000); continue; }

        if (st.status === 'ready') {
            _setStreamReady();
            _wireStreamButton(cacheKey, st.profiles, st.audio_tracks, st.sub_tracks);
            _buildQualityBar(st.profiles, cacheKey, st.audio_tracks || []);
            if (!_isWebNative) {
                // Non-native format: auto-switch to HLS.
                // Re-enable raw button — usable for audio-only (e.g. x265/HEVC MKV).
                _mountHlsPlayer(`/hls_files/${cacheKey}/master.m3u8`, true, st.audio_tracks, st.sub_tracks, cacheKey);
                const rb3 = $id('hls-btn-raw');
                if (rb3) {
                    rb3.classList.remove('hls-btn-active');
                    rb3.style.opacity = '';
                    rb3.style.pointerEvents = '';
                    rb3.title = 'Play raw \u2014 audio only (video codec not supported by browser)';
                }
                const sb3 = $id('hls-btn-stream'); if (sb3) sb3.classList.add('hls-btn-active');
                _setStatus('');
            } else {
                _setStatus('HLS ready \u2014 click \u26a1 Stream HLS to switch');
            }
            return;
        }
        if (st.status === 'error') {
            _hideStreamBtn();
            _setStatus('');
            // For non-native formats, show error in the placeholder area
            if (!_isWebNative) {
                const area = $id('hls-player-area');
                if (area && !area.querySelector('video')) {
                    area.innerHTML = `<div style="text-align:center;color:rgba(255,100,100,0.8);padding:32px;"><div style="font-size:28px;margin-bottom:10px;">\u274c</div><div style="font-size:13px;">Transcoding failed. Try downloading the file.</div></div>`;
                }
            }
            return;
        }

        const pct = typeof st.progress === 'number' ? st.progress : 0;
        _setProgress(pct);
        _setStatus('Pre-processing adaptive bitrate stream\u2026');
        await _hlsSleep(2000);
    }
}

function _wireStreamButton(cacheKey, profiles, audioMeta, subMeta) {
    const btn = document.getElementById('hls-btn-stream');
    if (!btn) return;
    const fresh = btn.cloneNode(true);
    btn.parentNode.replaceChild(fresh, btn);

    fresh.addEventListener('click', () => {
        const masterUrl = `/hls_files/${cacheKey}/master.m3u8`;
        const area = document.getElementById('hls-player-area');
        if (!area) return;

        area.querySelectorAll('video, audio').forEach(m => {
            try { m.pause(); m.removeAttribute('src'); m.load(); } catch (_) { }
        });
        ['hls-audio-row', 'hls-subtitle-row', 'hls-subtitle-overlay'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.remove();
        });

        area.style.cssText = 'width:100%;min-height:300px;flex:1 1 auto;position:relative;';
        // NOTE: <track> elements are intentionally omitted — injected dynamically
        // inside _buildTrackSelectors._getVideo after the change listener is active.
        area.innerHTML = `
          <video-player class="vjs-cloudinator-player" style="width:100%;height:100%;display:block;">
            <video-skin>
              <video slot="media"
                     src="${masterUrl}"
                     type="application/x-mpegURL"
                     playsinline
                     style="width:100%;height:100%;">
              </video>
            </video-skin>
          </video-player>`;
        const playerEl = area.querySelector('video-player');
        window._vjsCurrentPlayer = playerEl;
        window._hlsMasterUrl = masterUrl;
        _unmuteWhenReady(playerEl);
        _buildQualityBar(profiles, cacheKey, audioMeta || []);
        _buildTrackSelectors(playerEl, audioMeta || [], subMeta || [], cacheKey);
        fresh.classList.add('hls-btn-active');
        const rawBtn = document.getElementById('hls-btn-raw');
        if (rawBtn) rawBtn.classList.remove('hls-btn-active');
        const sm = document.getElementById('hls-status-msg');
        if (sm) sm.textContent = '';
    });
}


/**
 * Unmute the <video> element inside <video-player> after autoplay starts.
 * Browsers require muted for programmatic autoplay.
 */
function _unmuteWhenReady(playerEl) {
    if (!playerEl) return;
    let attempts = 0;
    const poll = setInterval(() => {
        if (++attempts > 100) { clearInterval(poll); return; }
        const video = playerEl.querySelector('video[slot="media"]');
        if (!video) return;
        clearInterval(poll);

        function doPlayUnmuted() {
            // Restore seek position saved before a remount (e.g. audio track switch)
            if (window._hlsRestoreTime > 0) {
                try { video.currentTime = window._hlsRestoreTime; } catch (_) { }
                window._hlsRestoreTime = 0;
            }
            video.muted = false;
            video.volume = 1;
            video.play().catch(() => {
                // Browser blocked unmuted autoplay — play muted as fallback
                video.muted = true;
                video.play().catch(() => { });
            });
        }

        // Wait for canplay — fires AFTER HLS.js has attached to MSE and the
        // browser confirms it can decode. readyState >= 1 (loadedmetadata) is
        // too early on VHS-managed elements: HLS.js may not have handed off the
        // MSE source buffer yet, so play() throws NotSupportedError.
        if (video.readyState >= 3) {
            doPlayUnmuted();
        } else {
            video.addEventListener('canplay', doPlayUnmuted, { once: true });
        }
    }, 50);
}

// ─────────────────────────────────────────────────────────────────────────────
// Audio track switching via a separate HLS.js-backed <audio> element.
//
// Problem: VHS (the HLS engine inside @videojs/html) lives in a CLOSED shadow
// root. We have zero API access to it. Changing video.src or video.load()
// externally causes VHS to throw NotSupportedError. XHR/fetch interception
// also fails because VHS never re-fetches master.m3u8 after initialisation.
//
// Solution: leave the <video> element (and VHS) completely alone for picture.
//           Mute the video, then play the desired audio rendition in a hidden
//           <audio> element backed by our own HLS.js instance. Sync playback
//           via periodic currentTime checks.
// ─────────────────────────────────────────────────────────────────────────────

let _hlsJsPromise = null; // kept for compat but no longer used

/**
 * Switch the audio track using the Web Audio API.
 *
 * WHY Web Audio instead of HLS.js on a separate element:
 *   The main VHS player occupies an MSE MediaSource. When our HLS.js instance
 *   tries to create its own MSE SourceBuffer, Chrome's per-page MSE quota
 *   causes perpetual bufferAppendError regardless of <audio> or <video>.
 *   The Web Audio API bypasses MSE entirely: we fetch segments, demux
 *   MPEG-TS to raw AAC ADTS, decode with AudioContext.decodeAudioData(),
 *   and schedule AudioBufferSourceNodes. No MSE involved at all.
 */
async function _switchAudioTrack(video, idx, audioMeta, cacheKey) {
    // Once createMediaElementSource(video) is called, the video element's native
    // audio output is permanently routed through that AudioContext. Closing the
    // AudioContext severs the connection forever — even after creating a new one.
    // Solution: create the AudioContext + capture ONCE per video element session,
    // then just adjust gain values to switch between VHS audio and our segments.

    function stopLoop() {
        window._audioRunning = false;
        if (window._audioTrackSync) { clearInterval(window._audioTrackSync); window._audioTrackSync = null; }
        // Stop all scheduled nodes so they don't keep playing after a track switch
        if (window._audioActiveNodes) {
            window._audioActiveNodes.forEach(n => { try { n.stop(0); } catch (_) { } });
            window._audioActiveNodes = [];
        }
    }

    // Initialise the shared AudioContext + gain nodes on first call
    if (!window._audioCtx || window._audioCtx.state === 'closed') {
        const ctx = new AudioContext();
        window._audioCtx = ctx;

        // GainNode for VHS audio (default: fully on)
        window._videoGain = ctx.createGain();
        window._videoGain.gain.value = 1;
        window._videoGain.connect(ctx.destination);

        // GainNode for our audio segments (default: silent)
        window._audioGain = ctx.createGain();
        window._audioGain.gain.value = 0;
        window._audioGain.connect(ctx.destination);

        // Capture video element audio permanently — routes ALL VHS audio through
        // Web Audio API so we can control it without touching video.muted
        try {
            const vSrc = ctx.createMediaElementSource(video);
            vSrc.connect(window._videoGain);
            window._videoGainCapture = true;
        } catch (e) {
            console.warn('[audio] createMediaElementSource failed:', e.message);
            window._videoGainCapture = false;
        }

        // Mirror player volume/mute to whichever gain is active
        video.addEventListener('volumechange', () => {
            const v = video.muted ? 0 : video.volume;
            if (window._audioRunning) {
                if (window._audioGain) window._audioGain.gain.value = v;
            } else {
                if (window._videoGain) window._videoGain.gain.value = v;
            }
        });
    }

    const audioCtx = window._audioCtx;
    const gainNode = window._audioGain;

    // idx === 0 means "default track":
    // - In Auto/master mode: VHS handles audio natively, restore gain routing and return.
    // - In variant mode (a specific quality stream loaded directly): VHS has no audio
    //   because variant playlists carry no audio rendition. Detect this and fall through
    //   to the Web Audio segment engine, loading audioUris[0] (the default rendition).
    if (idx === 0) {
        stopLoop();
        window._audioTrackEl = null;

        const _currentSrc = video.src || '';
        const _masterUrl = window._hlsMasterUrl || '';
        const _variantMode = _masterUrl &&
            !_currentSrc.endsWith('/master.m3u8') &&
            !_currentSrc.includes('/master.m3u8');

        if (!_variantMode) {
            // Master / Auto mode — VHS owns audio, restore gain routing.
            if (window._videoGainCapture) {
                window._videoGain.gain.value = video.volume;
                window._audioGain.gain.value = 0;
                video.muted = false;
                if (window._audioCtx && window._audioCtx.state === 'suspended') {
                    window._audioCtx.resume().catch(() => { });
                }
                if (window._audioCtxResumeListener) {
                    video.removeEventListener('play', window._audioCtxResumeListener);
                }
                window._audioCtxResumeListener = () => {
                    if (window._audioCtx && window._audioCtx.state === 'suspended') {
                        window._audioCtx.resume().catch(() => { });
                    }
                };
                video.addEventListener('play', window._audioCtxResumeListener);
            } else {
                video.muted = false;
                video.volume = 1;
            }
            return;
        }
        // Variant mode: fall through with idx=0 to load audioUris[0]
        // (the default audio rendition from the master) via Web Audio.
        console.log('[audio] variant mode — loading default rendition via Web Audio');
    }

    // Switching to custom track: silence VHS, activate our segments
    stopLoop();
    // Increment generation so stale async continuations from a previous call bail out
    // before creating audio nodes — prevents double-audio on rapid quality switches.
    window._audioGeneration = (window._audioGeneration || 0) + 1;
    const _gen = window._audioGeneration;
    if (window._videoGainCapture) {
        window._videoGain.gain.value = 0;
        window._audioGain.gain.value = video.volume;
    } else {
        video.muted = true;
    }
    window._audioRunning = true;
    window._audioTrackEl = {};

    try {
        const masterUrl = window._hlsMasterUrl || `/hls_files/${cacheKey}/master.m3u8`;
        const masterBase = masterUrl.slice(0, masterUrl.lastIndexOf('/') + 1);
        const masterText = await fetch(masterUrl, { cache: 'no-store' }).then(r => r.text());
        if (_gen !== window._audioGeneration || !window._audioRunning) return; // superseded

        const audioUris = masterText.split('\n')
            .filter(l => l.startsWith('#EXT-X-MEDIA:TYPE=AUDIO'))
            .map(l => { const m = l.match(/URI="([^"]+)"/); return m ? m[1].replace(/\\/g, '/') : null; })
            .filter(Boolean);

        if (idx >= audioUris.length) {
            console.error('[audio] idx out of range');
            window._videoGain.gain.value = video.volume;
            window._audioGain.gain.value = 0;
            window._audioRunning = false;
            return;
        }

        const renditionUrl = masterBase + audioUris[idx];
        const renditionBase = renditionUrl.slice(0, renditionUrl.lastIndexOf('/') + 1);
        const playlistText = await fetch(renditionUrl, { cache: 'no-store' }).then(r => r.text());
        if (_gen !== window._audioGeneration || !window._audioRunning) return; // superseded
        const segments = playlistText.split('\n').filter(l => l.trim() && !l.startsWith('#')).map(l => renditionBase + l.trim());
        const targetDuration = parseFloat(playlistText.match(/#EXT-X-TARGETDURATION:(\d+(?:\.\d+)?)/)?.[1] || '6');

        console.log('[audio] switching to', renditionUrl, '—', segments.length, 'segments');

        const initUriRaw = playlistText.match(/#EXT-X-MAP:URI="([^"]+)"/)?.[1];
        let initData = null;
        if (initUriRaw) {
            const initFilename = initUriRaw.replace(/\\/g, '/').split('/').pop();
            const initUrl = renditionBase + initFilename;
            console.log('[audio] init segment:', initUrl);
            initData = await fetch(initUrl).then(r => r.arrayBuffer()).catch(e => {
                console.error('[audio] init fetch failed:', e.message); return null;
            });
            if (_gen !== window._audioGeneration || !window._audioRunning) return; // superseded
        }

        async function fetchSegment(url) {
            const segData = await fetch(url).then(r => r.arrayBuffer());
            if (!initData) return segData;
            const combined = new Uint8Array(initData.byteLength + segData.byteLength);
            combined.set(new Uint8Array(initData), 0);
            combined.set(new Uint8Array(segData), initData.byteLength);
            return combined.buffer;
        }

        let segIdx = Math.max(0, Math.floor(video.currentTime / targetDuration));

        async function loadNext() {
            if (_gen !== window._audioGeneration || !window._audioRunning || segIdx >= segments.length) return;
            const si = segIdx++;
            const segMediaStart = si * targetDuration;
            try {
                const buf = await fetchSegment(segments[si]);
                if (_gen !== window._audioGeneration || !window._audioRunning) return; // superseded during fetch
                const decoded = await audioCtx.decodeAudioData(buf);
                if (_gen !== window._audioGeneration || !window._audioRunning || audioCtx.state === 'closed') return; // superseded during decode

                const videoNow = video.currentTime;
                const ctxNow = audioCtx.currentTime;
                const mediaOffset = segMediaStart - videoNow;
                if (mediaOffset < -decoded.duration) { loadNext(); return; }

                const playOffset = Math.max(0, -mediaOffset);
                const when = Math.max(ctxNow + 0.02, ctxNow + mediaOffset);
                const node = audioCtx.createBufferSource();
                node.buffer = decoded;
                node.connect(gainNode);
                if (!window._audioActiveNodes) window._audioActiveNodes = [];
                window._audioActiveNodes.push(node);
                node.onended = () => {
                    const i = window._audioActiveNodes ? window._audioActiveNodes.indexOf(node) : -1;
                    if (i >= 0) window._audioActiveNodes.splice(i, 1);
                };
                node.start(when, playOffset);

                const segEndCtx = when + decoded.duration - playOffset;
                if (_gen === window._audioGeneration && window._audioRunning)
                    setTimeout(loadNext, Math.max(0, (segEndCtx - audioCtx.currentTime - 2) * 1000));
            } catch (e) {
                console.error('[audio] seg error:', segments[si], e.message);
                if (_gen === window._audioGeneration && window._audioRunning) setTimeout(loadNext, 500);
            }
        }

        loadNext(); loadNext();

        video.addEventListener('seeked', function onSeeked() {
            if (!window._audioRunning) { video.removeEventListener('seeked', onSeeked); return; }
            video.removeEventListener('seeked', onSeeked);
            stopLoop();
            window._audioRunning = false;
            _switchAudioTrack(video, idx, audioMeta, cacheKey);
        });

        window._audioTrackSync = setInterval(() => {
            if (!window._audioRunning) return;
            if (!window._videoGainCapture && !video.muted) video.muted = true;
            if (video.paused && audioCtx.state === 'running') audioCtx.suspend().catch(() => { });
            if (!video.paused && audioCtx.state === 'suspended') audioCtx.resume().catch(() => { });
        }, 200);

    } catch (e) {
        console.error('[audio track] setup failed:', e);
        if (window._videoGain) window._videoGain.gain.value = video.volume;
        if (window._audioGain) window._audioGain.gain.value = 0;
        window._audioRunning = false;
    }
}



/**
 * Build Auto/1080p/720p/360p quality bar using direct <video> src swaps.
 * No VJS API needed — the <video> element is in the light DOM.
 */
function _buildQualityBar(profiles, cacheKey, audioMeta) {
    const row = document.getElementById('hls-quality-row');
    if (!row || !profiles || profiles.length < 2) return;

    row.style.cssText = 'display:flex;align-items:center;gap:6px;padding:4px 8px;flex-wrap:wrap;';
    row.innerHTML = '';

    const label = document.createElement('span');
    label.textContent = 'Quality:';
    label.style.cssText = 'color:rgba(255,255,255,0.55);font-size:12px;user-select:none;margin-right:2px;';
    row.appendChild(label);

    function makeBtn(text, src) {
        const btn = document.createElement('button');
        btn.className = 'hls-quality-btn' + (text === 'Auto' ? ' hls-quality-active' : '');
        btn.textContent = text;
        btn.addEventListener('click', () => {
            const playerEl = document.querySelector('#hls-player-area video-player');
            if (!playerEl) return;
            const video = playerEl.querySelector('video[slot="media"]');
            if (!video) return;
            const currentTime = video.currentTime;

            video.src = src;
            video.load();
            video.addEventListener('canplay', () => {
                if (currentTime > 0) { try { video.currentTime = currentTime; } catch (_) { } }

                if (text === 'Auto') {
                    // Back to master.m3u8 — VHS handles audio natively again.
                    // Stop any Web Audio that was running for a specific variant.
                    if (window._audioRunning) {
                        window._audioRunning = false;
                        if (window._audioTrackSync) { clearInterval(window._audioTrackSync); window._audioTrackSync = null; }
                        if (window._audioActiveNodes) {
                            window._audioActiveNodes.forEach(n => { try { n.stop(0); } catch (_) { } });
                            window._audioActiveNodes = [];
                        }
                        window._audioTrackEl = null;
                        if (window._videoGainCapture) {
                            window._videoGain.gain.value = video.volume;
                            window._audioGain.gain.value = 0;
                        }
                        video.muted = false;
                        video.volume = 1;
                    }
                } else if (audioMeta && audioMeta.length > 0) {
                    // Specific variant — video-only stream, start Web Audio for audio.
                    const audioIdx = window._hlsUserAudioIdx ?? 0;
                    _switchAudioTrack(video, audioIdx, audioMeta, cacheKey);
                }

                if (window._audioTrackEl) {
                    // External audio track is active.
                    // If using createMediaElementSource (capture mode), video MUST stay
                    // unmuted so VHS audio flows through the Web Audio capture graph —
                    // _videoGain (gain=0) silences it, not video.muted.
                    // Only set video.muted=true in the legacy fallback path.
                    if (!window._videoGainCapture) video.muted = true;
                    video.play().catch(() => { });
                    return;
                }
                video.removeAttribute('muted');
                video.muted = false;
                video.volume = 1;
                video.play().catch(() => {
                    video.muted = true;
                    video.play().catch(() => { });
                });
                let polls = 0;
                const unmutePoll = setInterval(() => {
                    if (!window._audioTrackEl && video.muted) {
                        video.removeAttribute('muted'); video.muted = false; video.volume = 1;
                    }
                    if (++polls >= 6) clearInterval(unmutePoll);
                }, 250);
            }, { once: true });
            row.querySelectorAll('.hls-quality-btn').forEach(b => b.classList.remove('hls-quality-active'));
            btn.classList.add('hls-quality-active');
        });
        return btn;
    }

    // Sort: highest resolution first; at same height, HFR (60fps) before standard.
    // e.g.  2160p60 > 2160p > 1440p60 > 1440p > 1080p60 > 1080p > 720p60 > 720p > 480p > …
    function profileSortKey(name) {
        const m = name.match(/^(\d+)p(\d+)?/);
        const height = m ? parseInt(m[1], 10) : 0;
        const fps = m && m[2] ? parseInt(m[2], 10) : 0;
        return height * 1000 + fps;   // higher is "better"
    }


    row.appendChild(makeBtn('Auto', `/hls_files/${cacheKey}/master.m3u8`));
    const sorted = [...profiles].sort((a, b) => profileSortKey(b) - profileSortKey(a));
    sorted.forEach(p => row.appendChild(makeBtn(p, `/hls_files/${cacheKey}/${p}/index.m3u8`)));
}

function _attachQualitySelector(playerEl) {
    // no-op stub — quality bar is built via _buildQualityBar(profiles, cacheKey)
}

/**
 * Build audio-track and subtitle selector rows.
 *
 * Subtitles: one managed <track> element; the language dropdown and the
 * player's CC button both drive that single native TextTrack so only one
 * caption stream is ever active.
 *
 * Audio: Safari native audioTracks / HLS.js audioTrack setter.
 */
function _buildTrackSelectors(playerEl, audioMeta, subMeta, cacheKey) {
    if (!playerEl) return;
    const hasAudio = Array.isArray(audioMeta) && audioMeta.length > 1;
    const hasSubs = Array.isArray(subMeta) && subMeta.length > 0;
    if (!hasAudio && !hasSubs) return;

    const LABEL_CSS = 'color:rgba(255,255,255,0.55);user-select:none;margin-right:2px;flex-shrink:0;';
    const SEL_CSS = [
        'background:rgba(255,255,255,0.1)',
        'border:1px solid rgba(255,255,255,0.25)',
        'color:#fff', 'border-radius:4px',
        'padding:3px 24px 3px 8px', 'font-size:12px',
        'cursor:pointer', 'outline:none',
        '-webkit-appearance:none', 'appearance:none',
        "background-image:url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='rgba(255,255,255,0.5)'/%3E%3C/svg%3E\")",
        'background-repeat:no-repeat', 'background-position:right 7px center',
        'min-width:120px',
    ].join(';');

    function _ensureRow(id, insertAfterId) {
        let row = document.getElementById(id);
        if (!row) {
            row = document.createElement('div');
            row.id = id;
            row.className = 'hls-track-row';
            row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:4px 10px;flex-wrap:wrap;font-size:12px;';
            const ref = document.getElementById(insertAfterId);
            if (ref && ref.parentNode) ref.parentNode.insertBefore(row, ref.nextSibling);
            else {
                const wrap = document.querySelector('.hls-player-outer');
                if (wrap) wrap.insertBefore(row, document.getElementById('hls-player-area'));
            }
        }
        return row;
    }

    function _getVideo(cb) {
        let tries = 0;
        const iv = setInterval(() => {
            const v = playerEl.querySelector('video[slot="media"]');
            if (v || ++tries > 20) { clearInterval(iv); if (v) cb(v); }
        }, 150);
    }

    // ── Audio row ─────────────────────────────────────────────────────────────
    if (hasAudio) {
        const row = _ensureRow('hls-audio-row', 'hls-quality-row');
        row.innerHTML = '';
        const lbl = document.createElement('span');
        lbl.textContent = '🔊 Audio:';
        lbl.style.cssText = LABEL_CSS;
        row.appendChild(lbl);
        const sel = document.createElement('select');
        sel.style.cssText = SEL_CSS;
        audioMeta.forEach((t, i) => {
            const opt = document.createElement('option');
            opt.value = i;
            opt.textContent = t.label || t.lang || `Track ${i + 1}`;
            sel.appendChild(opt);
        });
        row.appendChild(sel);
        row.style.display = 'flex';
        sel.addEventListener('change', () => {
            const idx = parseInt(sel.value, 10);
            window._hlsUserAudioIdx = idx;
            _getVideo(video => {
                _switchAudioTrack(video, idx, audioMeta, cacheKey);
            });
        });
    }

    // ── Subtitle row — one managed <track>, synced with CC button ───────────
    if (!hasSubs) return;

    const row = _ensureRow('hls-subtitle-row', hasAudio ? 'hls-audio-row' : 'hls-quality-row');
    row.innerHTML = '';
    const lbl = document.createElement('span');
    lbl.textContent = '💬 Subtitles:';
    lbl.style.cssText = LABEL_CSS;
    row.appendChild(lbl);
    const sel = document.createElement('select');
    sel.style.cssText = SEL_CSS;
    const offOpt = document.createElement('option');
    offOpt.value = '-1';
    offOpt.textContent = 'Off';
    sel.appendChild(offOpt);
    subMeta.forEach((t, i) => {
        const opt = document.createElement('option');
        opt.value = i;
        opt.textContent = t.label || t.lang || `Subtitle ${i + 1}`;
        sel.appendChild(opt);
    });
    row.appendChild(sel);
    row.style.display = 'flex';

    _getVideo(video => {
        let _activeIdx = -1;
        let _subChanging = false;
        let _loadGen = 0;
        let trackEl = null;

        // Keep native captions bottom-centred; override per-cue VTT positioning.
        if (!document.getElementById('_sub-native-fix')) {
            const s = document.createElement('style');
            s.id = '_sub-native-fix';
            s.textContent =
                'video[data-cloudinator-subs]::-webkit-media-text-track-container{' +
                '  transform:none!important;' +
                '  bottom:3em!important;top:auto!important;' +
                '  left:0!important;right:0!important;' +
                '  width:100%!important;' +
                '  text-align:center!important}' +
                'video[data-cloudinator-subs]::cue{' +
                '  text-align:center!important;' +
                '  white-space:pre-wrap}';
            document.head.appendChild(s);
        }
        video.setAttribute('data-cloudinator-subs', '');

        const _emptyVtt = URL.createObjectURL(
            new Blob(['WEBVTT\n\n'], { type: 'text/vtt' })
        );
        const _vttUrls = subMeta.map(s =>
            `/hls_files/${cacheKey}/${encodeURIComponent(s.vtt_filename)}`
        );

        const _ourTrack = () => trackEl?.track ?? null;
        let _captionsEnabled = false; // Track whether captions should be displayed

        function _allSubTracks() {
            return Array.from(video.textTracks).filter(
                t => t.kind === 'subtitles' || t.kind === 'captions'
            );
        }

        function _disableForeignTracks() {
            const ours = _ourTrack();
            _allSubTracks().forEach(t => {
                if (t !== ours) t.mode = 'disabled';
            });
        }

        function _notifyTracksChanged() {
            video.textTracks.dispatchEvent(new Event('change'));
        }

        function _removeTrackEl() {
            if (!trackEl) return;
            const t = trackEl.track;
            if (t) t.mode = 'hidden';
            trackEl.remove();
            trackEl = null;
        }

        // Replace the <track> element so every language gets a fresh load event.
        function _mountTrack(meta, url, onReady) {
            const gen = _loadGen;
            const oldTrackEl = trackEl; // Keep reference to old track

            const el = document.createElement('track');
            el.kind = 'subtitles';
            el.src = url;
            if (meta) {
                el.srclang = meta.lang || '';
                el.label = meta.label || meta.lang || '';
            }
            el.setAttribute('data-cloudinator-sub', '1');

            const done = () => {
                if (gen === _loadGen) {
                    // Remove the old track now that new one is loaded
                    if (oldTrackEl && oldTrackEl !== el) {
                        if (oldTrackEl.track) oldTrackEl.track.mode = 'hidden';
                        oldTrackEl.remove();
                    }
                    onReady?.();
                }
            };

            el.addEventListener('load', done, { once: true });
            el.addEventListener('error', done, { once: true });
            video.appendChild(el);

            // Immediately update trackEl reference to the new element
            trackEl = el;
        }

        function _setOff() {
            _loadGen++;
            _subChanging = true;
            _activeIdx = -1;
            _captionsEnabled = false;
            _syncSelect(-1);
            const t = _ourTrack();
            if (t) t.mode = 'hidden';
            _disableForeignTracks();
            _subChanging = false;
            _notifyTracksChanged();
        }

        function _syncSelect(idx) {
            sel.value = idx < 0 ? '-1' : String(idx);
        }

        function _setSubIdx(idx) {
            const meta = subMeta[idx];
            const url = _vttUrls[idx];
            if (!meta || !url) { _setOff(); return; }

            const gen = ++_loadGen;
            _subChanging = true;
            _activeIdx = idx;
            _captionsEnabled = true; // Auto-enable captions when selecting subtitle
            _syncSelect(idx);

            // Keep current track visible while loading new one
            const curTrack = _ourTrack();
            if (curTrack) curTrack.mode = 'showing';

            _mountTrack(meta, url, () => {
                if (gen !== _loadGen) return;
                _disableForeignTracks();
                _subChanging = false;
                const loaded = _ourTrack();
                if (loaded) loaded.mode = _captionsEnabled ? 'showing' : 'hidden';
                _notifyTracksChanged();
            });

            // Immediately enable captions for the new subtitle (will be shown once track loads)
            _subChanging = true;
            const newTrack = _ourTrack();
            if (newTrack) newTrack.mode = 'showing';
            _disableForeignTracks();
            _subChanging = false;
            _notifyTracksChanged();
        }

        function _applySubIdx(idx) {
            if (idx < 0) _setOff();
            else _setSubIdx(idx);
        }

        // CC button toggles all subtitle tracks — keep only our single managed track.
        video.textTracks.addEventListener('change', () => {
            if (_subChanging) return;

            const ours = _ourTrack();
            const showing = _allSubTracks().filter(t => t.mode === 'showing');

            // If captions are being enabled and we have a selected subtitle, show it
            if (showing.length > 0 && ours && showing[0] === ours && _activeIdx >= 0) {
                _captionsEnabled = true;
                _subChanging = true;
                ours.mode = 'showing';
                _subChanging = false;
                return;
            }

            // If all tracks are hidden/disabled, captions are off
            if (showing.length === 0) {
                _captionsEnabled = false;
                if (_activeIdx >= 0) {
                    // Keep the selection, just hide the subtitle
                    const t = _ourTrack();
                    if (t) t.mode = 'hidden';
                }
                return;
            }

            // If a foreign track is showing, sync to the correct subtitle
            if (showing.length > 1 || (showing.length === 1 && showing[0] !== ours)) {
                if (_activeIdx >= 0) {
                    _subChanging = true;
                    _applySubIdx(_activeIdx);
                    _subChanging = false;
                } else {
                    // No selection, load first language
                    _subChanging = true;
                    _applySubIdx(0);
                    _subChanging = false;
                }
                return;
            }

            // CC turned on while dropdown is Off — load the first language.
            if (showing[0] === ours && _activeIdx < 0) {
                _captionsEnabled = true;
                _subChanging = true;
                _applySubIdx(0);
                _subChanging = false;
            }
        });

        video.textTracks.addEventListener('addtrack', e => {
            if (e.track && e.track !== _ourTrack()) e.track.mode = 'disabled';
        });

        _mountTrack(null, _emptyVtt, () => {
            const t = _ourTrack();
            if (t) t.mode = 'hidden';
        });

        sel.addEventListener('change', () => {
            _applySubIdx(parseInt(sel.value, 10));
        });
    });
}

function _hlsSleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
// ─────────────────────────────────────────────────────────────────────────────
// End HLS helpers
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// Background glow: drives --mx/--my (cursor position) and --scroll-light
// (0..MAX_SCROLL_LIGHT, how much lighter the page gets as you scroll) on
// body::after in index.css. Both are lerped toward their target each frame
// instead of set directly, so the glow eases smoothly rather than snapping
// to the mouse or jumping on scroll.
//
// body::before/::after are position:absolute and sized to --doc-height
// (set below) rather than position:fixed/100vh, so the glow covers the
// whole document instead of only the first viewport - fixed layers only
// ever get captured for one viewport-height's worth of pixels by
// full-page/scroll-stitched screenshot tools, which is what made the glow
// vanish below the first screen in those captures even though it looked
// fine live. Because the layer is absolute now, --doc-height has to be
// measured and kept current explicitly (ResizeObserver + MutationObserver
// below) rather than relying on the browser to notice a resize on its
// own - that implicit-resize dependency is exactly what caused the
// original "background stops partway down the page" bug, so it can't be
// reintroduced here.
//
// The rAF loop only runs while values are still visibly converging, then
// goes idle. Running it forever at 60fps - even once settled - forces
// every backdrop-filter panel on the page to re-blur every frame, which
// is the likely cause of both the background seam and the table flicker
// seen under DevTools device-toolbar emulation. New pointermove/scroll
// input restarts it on demand.
// ─────────────────────────────────────────────────────────────────────────────
(function () {
    const root = document.documentElement;

    // ── Explicit document-height tracking for --doc-height ─────────────────
    // Drives body::before/::after's height in CSS. Updated on any real
    // layout-size change (ResizeObserver covers reflow from content already
    // in the DOM; MutationObserver covers nodes being added/removed, e.g.
    // rows appended by the virtual-scroll loader, since a childList mutation
    // doesn't always produce a ResizeObserver-visible size change on the
    // observed element itself until the next frame). Both are cheap and
    // idempotent - worst case is a redundant identical write to the var.
    let lastDocHeight = -1;
    function updateDocHeight() {
        // Deliberately NOT document.documentElement.scrollHeight: body::before/
        // ::after are position:absolute and sized from --doc-height, and since
        // they aren't clipped by any ancestor they still overflow into (and get
        // counted by) scrollHeight. Reading scrollHeight here would feed the
        // pseudo-elements' own previous height back into the next measurement -
        // a loop that can only ratchet the value upward, never shrink it back
        // down when real content gets shorter (e.g. switching from a taller
        // mobile layout back to desktop). Measuring the actual DOM children's
        // bottom edge instead - body::before/::after are pseudo-elements, so
        // they never appear in body.children - sidesteps that entirely.
        let h = window.innerHeight;
        for (const el of document.body.children) {
            const bottom = el.offsetTop + el.offsetHeight;
            if (bottom > h) h = bottom;
        }
        if (h !== lastDocHeight) {
            lastDocHeight = h;
            root.style.setProperty('--doc-height', h + 'px');
        }
    }

    if (window.ResizeObserver) {
        const ro = new ResizeObserver(updateDocHeight);
        ro.observe(document.body);
        ro.observe(document.documentElement);
    }
    if (window.MutationObserver) {
        const mo = new MutationObserver(updateDocHeight);
        mo.observe(document.body, { childList: true, subtree: true });
    }
    window.addEventListener('resize', updateDocHeight, { passive: true });
    updateDocHeight();

    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return; // body::after is display:none in this case anyway; skip the rAF loop entirely.
    }

    // How light the page is allowed to get at full scroll (0 = no change,
    // 1 = fully white). Kept well under 1 so it stays "lighter", not blown out.
    const MAX_SCROLL_LIGHT = 0.10;
    // Lerp factors: higher = snappier/less smoothing, lower = smoother/laggier.
    const CURSOR_EASE = 0.08;
    const SCROLL_EASE = 0.06;
    // How close cur must get to target before the loop stops itself.
    const SETTLE_PX = 0.5;
    const SETTLE_SCROLL = 0.000;

    // Document-space (not viewport-space) coordinates, since the glow layer
    // now spans the whole document. lastClientX/Y remember the last real
    // pointer position in viewport terms so a scroll event (mouse not
    // moving) can still recompute the correct document-space target - see
    // updateScrollTarget below.
    let lastClientX = window.innerWidth / 2;
    let lastClientY = window.innerHeight / 2;
    let targetX = lastClientX + window.scrollX;
    let targetY = lastClientY + window.scrollY;
    let curX = targetX;
    let curY = targetY;

    let targetScroll = 0;
    let curScroll = 0;

    let rafId = null;

    function lerp(a, b, t) {
        return a + (b - a) * t;
    }

    function isSettled() {
        return (
            Math.abs(targetX - curX) < SETTLE_PX &&
            Math.abs(targetY - curY) < SETTLE_PX &&
            Math.abs(targetScroll - curScroll) < SETTLE_SCROLL
        );
    }

    function applyVars() {
        // body::before/::after are position:absolute and span the full
        // document height via --doc-height (see CSS comment), so --mx/--my
        // must be document-relative pointer coordinates, not plain
        // viewport-relative ones - curX/curY already include the scroll
        // offset (see onPointerMove/updateScrollTarget below).
        root.style.setProperty('--mx', curX + 'px');
        root.style.setProperty('--my', curY + 'px');
        root.style.setProperty('--scroll-light', curScroll.toFixed(4));
    }

    function tick() {
        curX = lerp(curX, targetX, CURSOR_EASE);
        curY = lerp(curY, targetY, CURSOR_EASE);
        curScroll = lerp(curScroll, targetScroll, SCROLL_EASE);

        if (isSettled()) {
            // Snap exactly to target instead of idling fractions of a px
            // short of it, then stop the loop until something moves again.
            curX = targetX;
            curY = targetY;
            curScroll = targetScroll;
            applyVars();
            rafId = null;
            return;
        }

        applyVars();
        rafId = requestAnimationFrame(tick);
    }

    function ensureRunning() {
        if (rafId === null) {
            rafId = requestAnimationFrame(tick);
        }
    }

    function onPointerMove(e) {
        lastClientX = e.clientX;
        lastClientY = e.clientY;
        targetX = lastClientX + window.scrollX;
        targetY = lastClientY + window.scrollY;
        ensureRunning();
    }

    function updateScrollTarget() {
        const doc = document.documentElement;
        const scrollable = Math.max(doc.scrollHeight - doc.clientHeight, 1);
        const progress = Math.min(Math.max(window.scrollY / scrollable, 0), 1);
        targetScroll = progress * MAX_SCROLL_LIGHT;

        // Re-anchor the glow to the cursor's document position on scroll
        // too, not just on pointermove - otherwise scrolling with the
        // mouse stationary would leave the glow's document-space target
        // unchanged while the page moves underneath it, making it drift
        // out from under the cursor instead of tracking it.
        targetX = lastClientX + window.scrollX;
        targetY = lastClientY + window.scrollY;

        ensureRunning();
    }

    // pointermove (not mousemove) so this also tracks correctly under
    // touch/device-toolbar emulation, where plain hover mousemove mostly
    // doesn't fire and the glow would otherwise get stuck at the last
    // real coordinate it received.
    window.addEventListener('pointermove', onPointerMove, { passive: true });
    window.addEventListener('scroll', updateScrollTarget, { passive: true });
    window.addEventListener('resize', updateScrollTarget, { passive: true });

    applyVars();
    updateScrollTarget();
})();

// ─────────────────────────────────────────────────────────────────────────────
// Modal spotlight: the same cursor-glow as body::after (identical size/color
// in index.css), painted a second time directly onto whichever .modal-content
// is open, so it reads as one continuous light source sitting on the panel's
// own glass surface rather than two different-looking effects. Same easing
// speed as the page-level glow too (CURSOR_EASE = 0.08, matching the
// "Background glow" block above) so both move in sync - only the coordinate
// space differs: --hx/--hy here are panel-local px, not document-space.
// ─────────────────────────────────────────────────────────────────────────────
(function () {
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return; // .modal-content::before is display:none in this case; skip entirely.
    }

    // Same value as CURSOR_EASE in the "Background glow" block above -
    // keep these in sync so the two glows move at the same speed.
    const CURSOR_EASE = 0.08;
    const SETTLE_PX = 0.5;

    let activeEl = null;
    let targetX = 0, targetY = 0, curX = 0, curY = 0;
    let rafId = null;

    // Last real pointer position in viewport coordinates. Needed because a
    // modal can appear under a cursor that isn't moving (opened via click,
    // keyboard shortcut, or triggered from code) - a pointermove-only check
    // would leave the spotlight off until the person happens to nudge the
    // mouse afterward. Keeping this updated lets the MutationObserver below
    // re-evaluate against where the cursor already is the instant a modal
    // becomes visible, instead of waiting for the next move.
    let lastPointerX = window.innerWidth / 2;
    let lastPointerY = window.innerHeight / 2;

    function lerp(a, b, t) {
        return a + (b - a) * t;
    }

    function applyVars() {
        if (activeEl) {
            activeEl.style.setProperty('--hx', curX + 'px');
            activeEl.style.setProperty('--hy', curY + 'px');
        }
    }

    function isSettled() {
        return Math.abs(targetX - curX) < SETTLE_PX && Math.abs(targetY - curY) < SETTLE_PX;
    }

    function tick() {
        if (!activeEl) {
            rafId = null;
            return;
        }
        curX = lerp(curX, targetX, CURSOR_EASE);
        curY = lerp(curY, targetY, CURSOR_EASE);
        if (isSettled()) {
            curX = targetX;
            curY = targetY;
            applyVars();
            rafId = null;
            return;
        }
        applyVars();
        rafId = requestAnimationFrame(tick);
    }

    function ensureRunning() {
        if (rafId === null) {
            rafId = requestAnimationFrame(tick);
        }
    }

    function clearActive() {
        if (activeEl) {
            activeEl.classList.remove('spotlight-active');
            activeEl = null;
        }
    }

    // Core check, reused by real pointer movement AND by the modal-open
    // observer below - elementFromPoint(x, y) is what e.target already
    // resolves to for a real pointer event at that position, so both paths
    // behave identically.
    function evaluate(x, y) {
        const el = document.elementFromPoint(x, y);
        // .modal.show is the fullscreen backdrop (100vw/100vh), so a point
        // can be "inside the open modal" without being over .modal-content
        // itself - e.g. the letterboxed backdrop around a panel that isn't
        // maximized. Resolve the open modal first, then grab its panel,
        // instead of requiring the hit-tested element to be a descendant of
        // .modal-content. localX/localY below can end up negative or past
        // the panel's width/height when the cursor is over the backdrop -
        // that's fine, it just positions the radial-gradient center outside
        // the visible box, same as any off-panel gradient origin.
        const openModal = el && el.closest && el.closest('.modal.show');
        const target = openModal && openModal.querySelector('.modal-content');

        if (!target) {
            clearActive();
            return;
        }

        const rect = target.getBoundingClientRect();
        const localX = x - rect.left;
        const localY = y - rect.top;

        if (target !== activeEl) {
            clearActive();
            activeEl = target;
            activeEl.classList.add('spotlight-active');
            // Snap to the entry point instead of easing in from the panel's
            // last position/center - matches how the page glow starts
            // exactly under the cursor the first time it moves.
            curX = localX;
            curY = localY;
        }

        targetX = localX;
        targetY = localY;
        applyVars();
        ensureRunning();
    }

    function onMove(e) {
        lastPointerX = e.clientX;
        lastPointerY = e.clientY;
        evaluate(e.clientX, e.clientY);
    }

    // The main-page glow (body::after, "Background glow" block above) has
    // no leave-clearing logic at all - it just holds its last position
    // when the cursor exits the window, and picks back up on the next
    // pointermove. This spotlight used to clear on pointerleave to handle
    // the cursor exiting the viewport entirely (e.g. up into the tab bar),
    // but that made it behave inconsistently with the main-page glow -
    // vanishing instead of holding position. Dropped to match: no listener
    // here means --hx/--hy simply stay wherever they last were, and the
    // next pointermove (or the pointerup handler below, if the modal
    // closed while the cursor was away) re-syncs it.
    document.addEventListener('pointermove', onMove, { passive: true });

    // A modal closing out from under the cursor (Esc, clicking the backdrop,
    // a save/cancel button) should also clear the spotlight immediately
    // rather than waiting for the next pointermove.
    document.addEventListener('pointerup', () => {
        if (activeEl && !activeEl.closest('.modal.show')) {
            clearActive();
        }
    });

    // Re-check the last known pointer position the instant any .modal gains
    // the 'show' class, so a modal opening under an already-stationary
    // cursor lights up immediately instead of waiting on the next move.
    // rAF-deferred one frame so display:flex/centering has actually applied
    // and getBoundingClientRect() reflects the modal's final layout.
    const modalOpenObserver = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            const el = mutation.target;
            if (el.classList && el.classList.contains('modal') && el.classList.contains('show')) {
                requestAnimationFrame(() => evaluate(lastPointerX, lastPointerY));
                return;
            }
        }
    });
    document.querySelectorAll('.modal').forEach((modalEl) => {
        modalOpenObserver.observe(modalEl, { attributes: true, attributeFilter: ['class'] });
    });
})();