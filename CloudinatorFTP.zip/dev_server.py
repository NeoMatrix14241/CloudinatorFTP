#!/usr/bin/env python3
"""
Development Server for CloudinatorFTP
Runs Quart's built-in dev server (Hypercorn under the hood) for testing
and debugging. Plain HTTP by default — no HTTP/2/3 here, TLS setup adds
friction that isn't worth it for fast local iteration; use prod_server.py
if you specifically need to test HTTP/2 or HTTP/3 behaviour locally.
"""

import os
import sys
import signal

# get_local_ip() lives in helpers/net_utils.py, not app.py (2026-09-25) — a
# small, side-effect-free module (see its docstring). This used to be
# `from app import get_local_ip`, which happened to be the line that
# first triggered app.py's full module-level init (file_monitor,
# search index, etc.) in this file, ahead of the `from app import app`
# import further down. Checked before switching: app.py doesn't read
# QUART_ENV/QUART_DEBUG (set below) at import time, so there was no
# real ordering dependency here — app.py's heavy init now happens at
# the `from app import app` line instead, which is where the comment
# already at that import correctly says it belongs.
from helpers.net_utils import get_local_ip

LOCAL_IP = get_local_ip()

# Add the application directory to Python path
sys.path.insert(0, os.path.dirname(__file__))

os.environ["PYTHONUNBUFFERED"] = "1"
os.environ["QUART_ENV"] = "development"
os.environ["QUART_DEBUG"] = "1"

# ---------------------------------------------------------------------------
# Background-service mode  (set by manage.sh launcher)
#   _BG = True  → SIGINT ignored; use_reloader disabled (the reloader spawns
#                 a watchdog subprocess with its own signal wiring that
#                 would override SIG_IGN — disabling it is the only safe fix)
#   _BG = False → running directly; Ctrl+C and the reloader work as normal
# ---------------------------------------------------------------------------
_BG = os.environ.get("CLOUDINATOR_BG") == "1"
if _BG:
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    if hasattr(signal, "SIGBREAK"):
        signal.signal(signal.SIGBREAK, signal.SIG_IGN)

# ---------------------------------------------------------------------------
# Graceful-stop request from manage.sh (2026-10-16) - see prod_server.py for
# the full reasoning. manage.sh stop creates .manage_pids/dev.stop; the
# watcher thread started in __main__ below stops WebDAV/SFTP/FTP/SMB and the
# Version Engine, then exits. A stale file from a crashed run is removed
# here so it cannot shut the new server down immediately.
# ---------------------------------------------------------------------------
_STOP_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), ".manage_pids", "dev.stop"
)


def _clear_stop_file() -> None:
    try:
        os.remove(_STOP_FILE)
    except OSError:
        # No stop file present (the normal case).
        pass


_clear_stop_file()

# ensure_dirs() is called inside app.py before anything else loads.
# NOTE (2026-09-15): app.py's module-level code sets up logging_setup's
# shared "cloudinatorftp" logger (console + logs/prod_server_YYYY-MM-DD.log)
# on import — this line is what pulls that in, so request logging and the
# daily-dated log file both apply here too, same as under prod_server.py.
# Not changed here: Quart's app.run() below builds its own internal
# Hypercorn Config for the dev server and doesn't expose a documented way
# to hand it a custom errorlog logger the way prod_server.py's manual
# hyper_cfg.errorlog assignment does — so Hypercorn's own dev-mode startup
# banner/error output still only goes to the console here, same as
# dev_server.py's own print()-based banner below. Low priority to fix:
# this file runs single-process, in the foreground, for local iteration —
# the "did I miss it because nobody was watching the console" problem the
# daily log file solves doesn't really apply the same way it does to a
# detached prod_server.py process.
from app import app

# Start WebDAV / SFTP / FTP protocol servers in background threads.
import protocol_manager

protocol_manager.start_all()

# Start the Version Engine — a separate OS process (see version_engine.py's
# module docstring), independent of protocol_manager.py by design. No-op if
# config.VERSION_ENGINE_ENABLED is False.
import version_engine

version_engine.start()


def _save_coverage_data() -> None:
    """Write this process's coverage.py data when (and only when) it is being measured.

    `python tests/qa.py coverage` measures every scratch server through coverage.py's
    `patch = subprocess`. Coverage saves its data from an `atexit` hook, and the stop request
    below ends the process with `os._exit()`, which skips every `atexit` hook: the whole
    server's data (core, storage, routes, middleware ...) was lost and the Linux report read
    about 39 % for code the tests really run (5.44.3). `sys.modules` is only looked at, never
    imported into: a normal start does not load coverage and nothing changes for it."""
    cov_module = sys.modules.get("coverage")
    if cov_module is None:
        return
    try:
        cov = cov_module.Coverage.current()
        if cov is not None:
            cov.stop()
            cov.save()
    except Exception as e:
        print(f"   ⚠️  Could not save coverage data: {e}", flush=True)


def _stop_file_watcher():
    """Daemon thread: wait for manage.sh's stop request, clean up the child
    processes the same way the KeyboardInterrupt path below does, then exit
    the process (Quart's app.run() has no hook for an external stop)."""
    import logging
    import time

    while True:
        time.sleep(0.5)
        if os.path.exists(_STOP_FILE):
            break
    _clear_stop_file()  # manage.sh sees the file vanish = acknowledged
    print("\n🛑 Stop requested by manage.sh — stopping development server…", flush=True)
    for label, fn in (
        ("protocol servers", protocol_manager.stop_all),
        ("Version Engine", version_engine.stop),
    ):
        try:
            fn()
        except Exception as e:
            print(f"   ⚠️  Error stopping {label}: {e}", flush=True)
    print("👋 Development server stopped.", flush=True)
    logging.shutdown()
    _save_coverage_data()  # os._exit() below skips atexit, where coverage saves
    os._exit(0)


if __name__ == "__main__":

    import threading as _threading

    from config import ROOT_DIR, HOST, PORT, PERMANENT_SESSION_LIFETIME

    _threading.Thread(
        target=_stop_file_watcher, name="stop-file-watcher", daemon=True
    ).start()

    # ── Quart app config ─────────────────────────────────────────────────────
    app.config.update(
        MAX_CONTENT_LENGTH=None,  # intentionally unlimited — chunked uploads
        # bypass this anyway (each chunk is well under any reasonable cap),
        # and the person building this app decided unlimited total upload
        # size is fine. Overrides config.py's MAX_CONTENT_LENGTH on purpose.
        PERMANENT_SESSION_LIFETIME=PERMANENT_SESSION_LIFETIME,
        SEND_FILE_MAX_AGE_DEFAULT=0,
        TESTING=False,
        DEBUG=True,
        TEMPLATES_AUTO_RELOAD=True,
    )

    # ── Startup banner ───────────────────────────────────────────────────────
    print("🧪 Starting CloudinatorFTP Development Server...")
    print("⚠️  WARNING: This is for DEVELOPMENT/TESTING only!")
    print(f"🌐 Server running on http://{LOCAL_IP}:{PORT}")
    if _BG:
        print("🔒 Background service mode (managed by manage.sh)")
        print("   • Ctrl+C disabled — use './manage.sh stop' (graceful, then forced)")
        print("   • Auto-reloader disabled (not usable in detached mode)")
    print("🔧 Configuration:")
    print("   • Debug mode: ON  |  Upload limit: NONE  |  HTTP/1.1 only")
    print("   • Auto-reload:", "OFF (BG mode)" if _BG else "ON")
    if not _BG:
        print("📁 Press Ctrl+C to stop the server")
    print()

    print(f"📋 Storage directory: {ROOT_DIR}")
    print()

    print(f"🌐 Local network:  http://{LOCAL_IP}:{PORT}")
    print(f"🔁 Localhost:      http://localhost:{PORT}")
    print()

    # ── Serve ────────────────────────────────────────────────────────────────
    try:
        app.run(
            host=HOST,
            port=PORT,
            debug=True,
            # The reloader spawns a watchdog subprocess with its own signal
            # wiring. Must be off in BG mode so signal.SIG_IGN cannot be
            # overridden.
            use_reloader=not _BG,
        )

    except KeyboardInterrupt:
        import threading as _t

        print("\n🛑 Stopping development server…")

        # 2026-09-16: ignore further Ctrl+C for the rest of this cleanup
        # block. Quart's app.run() above already handled the FIRST Ctrl+C
        # internally (its own graceful async teardown, then it re-raises
        # KeyboardInterrupt to us here) — this only takes over AFTER that,
        # so it can't conflict with app.run()'s own signal handling. What
        # it protects against: a second/third rapid Ctrl+C landing while
        # protocol_manager.stop_all() below is still mid-cleanup (e.g.
        # during its terminate()+wait(timeout=5) for the WebDAV
        # subprocess) would otherwise raise a fresh, uncaught
        # KeyboardInterrupt right there, aborting stop_all() before it
        # reaches WebDAV — which, unlike the SFTP/FTP/SMB threads, is a
        # genuinely separate OS process that survives as an orphan if
        # never explicitly told to stop. Worst case with this in place:
        # a few seconds of Ctrl+C not doing anything while cleanup
        # finishes, rather than a silently orphaned process needing a
        # manual Task Manager kill.
        signal.signal(signal.SIGINT, signal.SIG_IGN)

        # Stop WebDAV / SFTP / FTP / SMB protocol servers cleanly. SMB itself
        # never touches Windows' native file sharing (LanmanServer) — that's
        # a separate, one-time, manually-run setup (smb_setup.py), not
        # something tied to this server's start/stop.
        protocol_manager.stop_all()

        # Stop the Version Engine child process the same way — it's a
        # genuinely separate OS process (like WebDAV) that does not exit
        # just because this one does.
        version_engine.stop()

        active = [
            t for t in _t.enumerate() if t is not _t.main_thread() and t.is_alive()
        ]
        if active:
            print(f"   ⏳ {len(active)} thread(s) still running:")
            for t in active:
                tag = "[daemon]" if t.daemon else "[active]"
                print(f"      • {t.name} {tag}")

        print("👋 Development server stopped.")
        sys.exit(0)

    except Exception as e:
        print(f"💥 Server error: {e}")
        print("🔍 Check your Quart app and dependencies")
        sys.exit(1)
