import importlib
import os
import platform
import json
import time

# Anchor server_config.json to the directory that contains this file,
# not the process CWD — consistent with how paths.py handles storage_config.json.
_HERE = os.path.dirname(os.path.abspath(__file__))
_SERVER_CONFIG_FILE = os.path.join(_HERE, "server_config.json")

# Server configuration
PORT = 5000
CHUNK_SIZE = 10 * 1024 * 1024  # 10 MB adjustable chunk size
ENABLE_CHUNKED_UPLOADS = True
# Upload performance (5.41) and download performance (5.42). All four are saved in
# server_config.json like CHUNK_SIZE and are shown in the settings view; the last three have a menu
# entry (Server Configuration > 14, 5.43). A running server needs a restart for a change.
# BODY_TIMEOUT: seconds Quart gives ONE request body (a 10 MB upload chunk) to arrive and be
# parsed. Quart's own default is 60 and it covers the WHOLE body, not each piece of data, so a
# chunk that needed more than a minute (slow link, busy disk, a stalled event loop) failed with
# "408 Request Timeout" and the browser stopped the whole upload. 0 = no limit. (core.py already
# sets RESPONSE_TIMEOUT = None for the same reason on downloads.)
BODY_TIMEOUT = 600
# Log the time of every upload stage per chunk and how late the event loop wakes up. Off = no cost.
# With UPLOAD_CHUNKS_IN_MEMORY on, the line also splits "receive+parse (RAM)" into the time the
# body took to arrive and the time the parse itself took (5.43).
UPLOAD_TIMING_ENABLED = False
# Parse an upload chunk (a request body up to CHUNK_SIZE + 1 MiB) in RAM instead of in a temp file
# in the system temp folder: one 10 MB write and one read less per chunk, at the price of up to
# that much RAM per chunk being received at the same moment. ON by default since 5.43: on the
# owner's Windows PC (hard disk, scratch server) it took one client from 9.9 to 15.7 MB/s and four
# clients from 14.2 to 16.7 MB/s in total. A server_config.json that already holds a saved value
# keeps it: switch it with the menu (Server Configuration > 14) or by editing the JSON.
UPLOAD_CHUNKS_IN_MEMORY = True
# Download read size (5.42): bytes read per step when a file is sent (/download, /view). Quart's own
# 8 KiB costs two thread hand-offs per 8 KiB, which held a RAM-cached 32 MB file to 2.6 MB/s on the
# owner's Windows PC (helpers/file_body.py has the numbers). 8192 to 16 MiB; the price is this much
# RAM per download in flight.
DOWNLOAD_BUFFER_SIZE = 1048576
HOST = "0.0.0.0"  # Listen on all interfaces
MAX_CONTENT_LENGTH = 16 * 1024 * 1024 * 1024  # 16GB max file size
ALLOWED_EXTENSIONS = None  # None = allow all file types.
# To restrict uploads, set a lowercase set/list of extensions WITHOUT dots,
# e.g. {"jpg", "jpeg", "png", "mp4", "pdf"}. Now enforced in app.py's upload()
# route (previously imported nowhere and never checked).
PERMANENT_SESSION_LIFETIME = 31536000  # 365 days — effectively no idle timeout.
# NOTE: this value is now actually wired into app.py's Flask session config
# (it previously wasn't — app.py hardcoded its own 86400s and ignored this).
# Change this via the setup wizard (configure_session_timeout) if you want a
# real timeout back; whatever you set here is now what actually applies.

# HLS streaming configuration
# Files smaller than HLS_MIN_SIZE skip HLS for web-native formats (play raw instead)
HLS_MIN_SIZE = 50 * 1024 * 1024  # 50 MB default
# These formats always get HLS regardless of size — browser can't play them raw
HLS_FORCE_FORMATS = {
    "mkv",
    "avi",
    "wmv",
    "flv",
    "mpg",
    "mpeg",
    "m2ts",
    "mts",
    "3gp",
    "ogv",
}

# Feature toggles — both default to True (enabled).
# When True and the tool IS installed     → full functionality (HLS / WebP conversion).
# When True and the tool is NOT installed → existing graceful fallback (raw playback /
#                                           raw image serving) — no change in behaviour.
# When False                              → intentionally disabled regardless of whether
#                                           the binary is present; raw fallback is used
#                                           and a "requires processing" notice is shown
#                                           for formats that cannot be displayed raw.
ENABLE_FFMPEG = True  # False → skip HLS transcoding entirely, use raw playback only
ENABLE_LIBVIPS = True  # False → skip image conversion entirely, use raw serving only
ENABLE_SEARCH_INDEX = (
    True  # False → skip SQLite search index, always use os.walk fallback
)

# Image preview / WebP compression configuration
# Native images (jpg/png/gif/etc.) smaller than this are served raw with no conversion.
# Above this threshold they are compressed to lossy WebP to save bandwidth.
IMG_COMPRESS_MIN_SIZE = 1 * 1024 * 1024  # 1 MB default
# Quality used for lossy WebP encoding (1-100). Lower = smaller file, more artefacts.
IMG_WEBP_QUALITY = 50  # default

# Protocol servers — all loaded from / saved to server_config.json.
# Set any ENABLED flag to False to disable that server without removing its code.
# Ports must not conflict with the main Flask server (5000) or each other.
WEBDAV_ENABLED = False  # http://HOST:8080/  ⚠️  plaintext — Basic Auth creds
# travel unencrypted (this is what ZAP's "Cleartext Transmission of Sensitive
# Information via HTTP" finding flags). Off by default, AND ignored outright
# whenever WEBDAV_HTTPS_ENABLED is on and its cert loads fine — HTTPS runs
# exclusively in that case, :8080 never opens alongside it, no matter what
# this flag says. This only takes effect when HTTPS is disabled, or as an
# automatic fallback if the HTTPS cert can't be prepared (e.g. the
# `cryptography` package is missing) — set it True for either of those
# cases, not to run both listeners at once, which webdav_server.py won't do.
WEBDAV_PORT = 8080
WEBDAV_HTTPS_ENABLED = True  # https://HOST:8443/ — no registry edit needed,
# used by default instead of WEBDAV_ENABLED above; this is the one you want.
WEBDAV_HTTPS_PORT = 8443  # cert auto-generated in db/webdav.crt on first run
SFTP_ENABLED = True  # sftp://HOST:2222/ — WinSCP, FileZilla, sshfs
SFTP_PORT = 2222
FTP_ENABLED = True  # ftp://HOST:2121/  — legacy FTP clients
FTP_PORT = 2121
FTP_TLS_ENABLED = True  # explicit FTPS (AUTH TLS), reuses the WebDAV HTTPS cert.
# Auto-falls back to plaintext FTP if pyOpenSSL isn't installed — see ftp_server.py.
FTP_TLS_REQUIRE_DATA = True  # False → allow plaintext data channel for a legacy
# client that can't do TLS on the data connection (control channel/creds are
# still always TLS-required whenever FTP_TLS_ENABLED and pyOpenSSL are both on).
SMB_ENABLED = False  # \\HOST\ShareName — off by default even with impacket installed.
# Unlike WebDAV/SFTP/FTP, having the library installed isn't enough to be useful —
# port 445 needs a one-time machine setup first. Run `python tools/smb_setup.py` (or
# `./manage.sh setup-smb`) once, then flip this to True (it can do that for you).
SMB_PORT = 445  # standard SMB port; see smb_setup.py for how to actually claim it
SMB_FALLBACK_PORT = 8445  # used automatically when 445 can't be bound
SMB_SHARE_NAME = "SharedFolder"  # the name clients see, e.g. \\HOST\SharedFolder

# Path exports — create=False so importing config never creates directories.
from paths import (  # noqa: E402  (kept next to the path settings it re-exports)
    get_db_dir,
    get_cache_dir,
    get_hls_cache_dir,
    get_img_cache_dir,
    get_versions_dir,
    set_db_dir,
    set_cache_dir,
    set_hls_cache_dir,
    set_img_cache_dir,
    set_versions_dir,
    reset_db_dir,
    reset_cache_dir,
    reset_hls_cache_dir,
    reset_img_cache_dir,
    reset_versions_dir,
)

DB_DIR = get_db_dir(create=False)
CACHE_DIR = get_cache_dir(create=False)
HLS_CACHE_DIR = get_hls_cache_dir(create=False)
IMG_CACHE_DIR = get_img_cache_dir(create=False)

# ── Version Engine ──────────────────────────────────────────────────────
# Master switch — when False, neither launcher starts the Version Engine
# child process and nothing else in the app changes (Quart, Hypercorn,
# uploads, downloads, browsing, WebDAV, SFTP, FTP, FTPS, SMB, and existing
# file storage are all unaffected). See version_engine.py.
VERSION_ENGINE_ENABLED = True

# Storage — a dedicated sibling of db/ and cache/, resolved the same way
# DB_DIR/CACHE_DIR are (create=False: importing config never creates dirs).
VERSION_STORAGE_DIR = get_versions_dir(create=False)
VERSION_DB_FILENAME = "version_engine.sqlite3"

# Hybrid storage thresholds. VERSION_CHUNK_SIZE is intentionally its own
# setting, unrelated to CHUNK_SIZE above (which is the existing chunked-
# UPLOAD size) — changing one must never affect the other.
VERSION_SMALL_FILE_THRESHOLD = 4 * 1024 * 1024  # 4 MB — below this: full-object storage
VERSION_CHUNK_SIZE = 8 * 1024 * 1024  # 8 MB — NOT config.CHUNK_SIZE
VERSION_CHUNKING_ALGORITHM = (
    "fixed"  # "fixed" today; "cdc" reserved for a future ContentDefinedChunker
)

# Workers / concurrency — default low (1) since Termux devices are
# resource-constrained phones/tablets, not servers (see version_engine.py).
VERSION_WORKER_COUNT = 1
VERSION_MAX_CONCURRENT_SNAPSHOTS = 2

# Watcher + periodic reconciliation scanner. The engine must keep working
# correctly with the watcher disabled — the scanner alone still catches
# everything, just less promptly.
VERSION_WATCH_ENABLED = True
VERSION_SCAN_ENABLED = True
VERSION_SCAN_INTERVAL = 300  # seconds

# Tracking scope. Every list defaults EMPTY — nothing is tracked until an
# admin explicitly adds an entry. This (not VERSION_TRACK_ALL_FILES, which
# itself defaults False) is the actual mechanism preventing an admin from
# accidentally versioning an entire drive.
VERSION_TRACK_FILES = []
VERSION_TRACK_DIRECTORIES = []
VERSION_TRACK_ROOTS = []
VERSION_TRACK_ALL_FILES = False

VERSION_EXCLUDE_DIRECTORIES = []
VERSION_EXCLUDE_PATTERNS = ["*.tmp", "*.part", "~$*"]

# Retention & GC
VERSION_RETENTION_ENABLED = True
VERSION_MAX_VERSIONS = 50
VERSION_GC_ENABLED = True
VERSION_GC_GRACE_PERIOD = (
    24 * 60 * 60
)  # seconds — 24h before deleting unreferenced objects

# Reliability
VERSION_RETRY_COUNT = 3
VERSION_RETRY_DELAY = 2  # seconds

# Object compression (5.46 reads it, 5.47 writes it; VERSION_COMPRESSION_PLAN.md). The switch
# only controls WRITING: the Version Engine's own `ve-compress` thread (never the web server,
# never asyncio) converts raw objects to zstd files, one verified object at a time. READING
# always works on whatever is on disk, whatever the switch says, so turning it off or on can
# never strand data. OFF by default; the owner turns it on in server_config.json (a real JSON
# true: a string "true" means off). The level defaults to the MAXIMUM, 22 (owner's decision),
# even where it gains nothing over 19. Changes need a restart of the Version Engine; not
# editable by hand in server_config.json OR (5.47.7) from the config menu: Version Engine >
# Engine settings > 13 (see VERSION_COMPRESSION_SETTINGS below; the menu writes only the keys it
# changed and keeps every other key of the file as it is).
VERSION_COMPRESSION_ENABLED = False
VERSION_COMPRESSION_LEVEL = 22  # zstd level, 1 to 22
VERSION_COMPRESSION_MIN_SAVING_PERCENT = (
    5  # keep the compressed form only if it is at least this much smaller (0 to 50)
)
VERSION_COMPRESSION_BUSY_PERCENT = (
    25  # duty cycle of the compress thread, 5 to 100 (100 = no pauses)
)
VERSION_COMPRESSION_INTERVAL = (
    600  # seconds between two looks when nothing is left to compress (60 to 86400)
)
# 5.47.1 (Phase 4): a CHANGED chunk of a file may be stored as a delta against the same chunk of
# the previous version (zstd with the old chunk as a raw dictionary): a small change then costs
# a few KB instead of a whole compressed chunk. Its own switch (a real JSON true; OFF by
# default), only used while VERSION_COMPRESSION_ENABLED is on. READING deltas works whatever
# either switch says. The delta must be at least this much smaller than the plain compressed
# chunk (quick attempt at level 3) to be worth the dependency on the old chunk.
VERSION_COMPRESSION_DELTA_ENABLED = False
VERSION_COMPRESSION_DELTA_MIN_GAIN_PERCENT = 20  # 1 to 90

# 5.47.7: the ONE table of the seven compression settings: key, kind ("bool" or "int"), the
# default (captured HERE, before load_server_config() overwrites the globals above), the loader's
# own bounds, and the texts the config menu shows. load_server_config() reads its bounds from
# this table and configure_version_compression() validates against it, so the loader and the
# menu can never disagree (tests/unit/test_config_compression_menu.py pins it).
VERSION_COMPRESSION_SETTINGS = (
    {
        "key": "VERSION_COMPRESSION_ENABLED",
        "kind": "bool",
        "default": VERSION_COMPRESSION_ENABLED,
        "low": None,
        "high": None,
        "unit": "",
        "label": "Compression (ve-compress thread)",
        "help": "starts the thread that writes compressed objects; reading always works",
    },
    {
        "key": "VERSION_COMPRESSION_LEVEL",
        "kind": "int",
        "default": VERSION_COMPRESSION_LEVEL,
        "low": 1,
        "high": 22,
        "unit": "",
        "label": "zstd level",
        "help": "22 is the maximum; slower levels only cost background CPU",
    },
    {
        "key": "VERSION_COMPRESSION_MIN_SAVING_PERCENT",
        "kind": "int",
        "default": VERSION_COMPRESSION_MIN_SAVING_PERCENT,
        "low": 0,
        "high": 50,
        "unit": " %",
        "label": "Minimum saving",
        "help": "keep the compressed form only if it is at least this much smaller",
    },
    {
        "key": "VERSION_COMPRESSION_BUSY_PERCENT",
        "kind": "int",
        "default": VERSION_COMPRESSION_BUSY_PERCENT,
        "low": 5,
        "high": 100,
        "unit": " %",
        "label": "Busy share (duty cycle)",
        "help": "how much of the time the thread may work; 100 = no pauses",
    },
    {
        "key": "VERSION_COMPRESSION_INTERVAL",
        "kind": "int",
        "default": VERSION_COMPRESSION_INTERVAL,
        "low": 60,
        "high": 86400,
        "unit": " s",
        "label": "Idle look interval",
        "help": "seconds between two looks when nothing is left to compress",
    },
    {
        "key": "VERSION_COMPRESSION_DELTA_ENABLED",
        "kind": "bool",
        "default": VERSION_COMPRESSION_DELTA_ENABLED,
        "low": None,
        "high": None,
        "unit": "",
        "label": "Previous-version delta",
        "help": "store a changed chunk against the previous version's chunk; only used while compression is on",
    },
    {
        "key": "VERSION_COMPRESSION_DELTA_MIN_GAIN_PERCENT",
        "kind": "int",
        "default": VERSION_COMPRESSION_DELTA_MIN_GAIN_PERCENT,
        "low": 1,
        "high": 90,
        "unit": " %",
        "label": "Delta minimum gain",
        "help": "a delta is used only if it is at least this much smaller than the plain chunk",
    },
)
VERSION_COMPRESSION_BOUNDS = {
    s["key"]: (s["low"], s["high"])
    for s in VERSION_COMPRESSION_SETTINGS
    if s["kind"] == "int"
}
VERSION_FOLLOW_SYMLINKS = False
VERSION_ALLOW_RESTORE_OVERWRITE = False
VERSION_SHUTDOWN_TIMEOUT = 30  # seconds — graceful drain window before proc.kill()

# Background purge of versions whose file no longer exists (5.45). ON by default (owner's decision; set it to false in server_config.json to switch it off). Runs in the
# Version Engine's own `ve-purge` thread (never in the web server, never on its event loop or
# thread pool), one bounded pass at a time; see docs/CONFIG_PY_REFERENCE.md. The engine does not
# age out the versions of a deleted file by itself (retention only runs when the same file gets
# a new snapshot); this does it slowly, with an undo file per pass, and the GC frees the chunks
# after VERSION_GC_GRACE_PERIOD. Changes need a restart of the Version Engine.
VERSION_PURGE_MISSING_ENABLED = True
VERSION_PURGE_MISSING_MIN_AGE_DAYS = (
    30  # newest version at least this old (0 = no margin)
)
VERSION_PURGE_MISSING_INTERVAL = 3600  # seconds between two passes (minimum 60)
VERSION_PURGE_MISSING_MAX_FILES_PER_PASS = (
    5000  # files looked at per pass (1 to 100000)
)
VERSION_PURGE_MISSING_BATCH_PAUSE = (
    0.05  # seconds paused after each write batch (0 to 5)
)

# Size limit of the Version Engine database's write-ahead log, `version_engine.sqlite3-wal`
# (5.45.1). SQLite never shrinks that file by itself: it keeps the size of the biggest burst of
# writes it ever saw (2.9 GB after a purge and a GC on the owner's server).
# The limit does two things inside the engine process: every connection sets
# `PRAGMA journal_size_limit` to it, and a garbage-collection or purge pass that ends with the
# file above it runs `wal_checkpoint(TRUNCATE)`. NEVER above 64 MB (a larger value in
# server_config.json falls back to 64); 0 switches both off. `./manage.sh version-manage wal`
# shows the sizes and runs the checkpoint by hand. Changes need a restart of the Version Engine.
VERSION_WAL_SIZE_LIMIT_MB = 64  # 0 = off, 1 to 64


def detect_platform():
    """Detect the current platform and return appropriate info"""
    system = platform.system().lower()

    # Check if running in Termux
    if "TERMUX_VERSION" in os.environ or os.path.exists("/data/data/com.termux"):
        return "termux"
    elif system == "linux":
        return "linux"
    elif system == "windows":
        return "windows"
    elif system == "darwin":
        return "macos"
    else:
        return "unknown"


def get_windows_documents_path():
    """Get the proper Windows Documents folder path"""
    try:
        # Try using the USERPROFILE environment variable first
        userprofile = os.environ.get("USERPROFILE")
        if userprofile:
            documents_path = os.path.join(userprofile, "Documents")
            if os.path.exists(documents_path):
                return documents_path

        # Try using Windows registry
        try:
            import winreg

            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders",
            ) as key:
                documents_path = winreg.QueryValueEx(key, "Personal")[0]
                if os.path.exists(documents_path):
                    return documents_path
        except (ImportError, OSError, FileNotFoundError):
            # No Shell Folders registry value (or not Windows); fall through to the other lookups.
            pass

        # Fallback methods
        fallbacks = [
            os.path.join(os.path.expanduser("~"), "Documents"),
            os.path.join(
                os.environ.get("HOMEDRIVE", "C:"),
                os.environ.get(
                    "HOMEPATH", "\\Users\\" + os.environ.get("USERNAME", "User")
                ),
                "Documents",
            ),
            os.path.expanduser("~"),
        ]

        for path in fallbacks:
            if os.path.exists(path):
                return path

    except Exception as e:
        print(f"Error detecting Windows Documents folder: {e}")

    # Final fallback
    return os.getcwd()


def get_accessible_storage_path():
    """Get an accessible storage path based on the platform"""
    platform_type = detect_platform()

    if platform_type == "termux":
        # Check if termux-setup-storage has been run
        shared_storage = "/storage/emulated/0"  # Internal storage root
        downloads = os.path.join(shared_storage, "Download")
        documents = os.path.join(shared_storage, "Documents")

        # Try to find the best accessible location
        if os.path.exists(downloads) and os.access(downloads, os.W_OK):
            return os.path.join(downloads, "CloudinatorFTP")
        elif os.path.exists(documents) and os.access(documents, os.W_OK):
            return os.path.join(documents, "CloudinatorFTP")
        elif os.path.exists(shared_storage) and os.access(shared_storage, os.W_OK):
            return os.path.join(shared_storage, "CloudinatorFTP")
        else:
            # Fallback to termux home if shared storage not accessible
            print(
                "⚠️  Warning: Shared storage not accessible. Files will be saved to Termux directory."
            )
            print(
                "   Run 'termux-setup-storage' and grant permissions to save to internal storage."
            )
            return os.path.join(os.path.expanduser("~"), "uploads")

    elif platform_type == "linux":
        # Linux: try user's home directory
        home = os.path.expanduser("~")
        return os.path.join(home, "CloudinatorFTP")

    elif platform_type == "windows":
        # Windows: use improved Documents folder detection
        documents_path = get_windows_documents_path()
        return os.path.join(documents_path, "CloudinatorFTP")

    elif platform_type == "macos":
        # macOS: use user's home directory
        home = os.path.expanduser("~")
        return os.path.join(home, "CloudinatorFTP")

    else:
        # Unknown platform: use current directory
        return os.path.join(os.getcwd(), "uploads")


def setup_storage_directory():
    """Create and verify the storage directory"""
    custom_path = None

    # 1. Check environment variable
    if "CLOUDINATOR_FTP_ROOT" in os.environ:
        custom_path = os.environ["CLOUDINATOR_FTP_ROOT"]
        print(f"🔧 Using environment variable path: {custom_path}")

    # 2. Read from storage_config.json via paths._load() — same file/path
    #    that set_db_dir/set_cache_dir write to, so they're always in sync.
    else:
        from paths import _load as _paths_load

        cfg = _paths_load()
        custom_path = cfg.get("storage_path")
        if custom_path:
            print(f"📋 Using saved configuration: {custom_path}")

    # 3. Use custom path if provided, otherwise auto-detect
    storage_path = custom_path if custom_path else get_accessible_storage_path()
    platform_type = detect_platform()

    try:
        os.makedirs(storage_path, exist_ok=True)

        # Test write permissions
        test_file = os.path.join(storage_path, ".write_test")
        with open(test_file, "w") as f:
            f.write("test")
        os.remove(test_file)

        print(f"✅ Storage directory ready: {storage_path}")

        # Platform-specific feedback
        if platform_type == "termux":
            if "/storage/emulated/0" in storage_path:
                print("✅ Files will be accessible from Android file managers")
                if "Download" in storage_path:
                    print("📁 Android location: Files app → Downloads → CloudinatorFTP")
                elif "Documents" in storage_path:
                    print("📁 Android location: Files app → Documents → CloudinatorFTP")
                else:
                    print(
                        "📁 Android location: Files app → Internal Storage → CloudinatorFTP"
                    )
            else:
                print("⚠️  Files will only be accessible within Termux")
                print("   Run 'termux-setup-storage' for broader access")

        elif platform_type == "windows":
            print(f"📁 Windows location: {storage_path}")
            print("💡 Access via File Explorer or any file manager")

        elif platform_type == "linux":
            print(f"📁 Linux location: {storage_path}")
            print("💡 Access via file manager or terminal")

        elif platform_type == "macos":
            print(f"📁 macOS location: {storage_path}")
            print("💡 Access via Finder")

        return storage_path

    except PermissionError:
        print(f"❌ Permission denied: {storage_path}")
        # Fallback to current directory
        fallback = os.path.join(os.getcwd(), "uploads")
        os.makedirs(fallback, exist_ok=True)
        print(f"📁 Using fallback directory: {fallback}")
        return fallback
    except Exception as e:
        print(f"❌ Error creating storage directory: {e}")
        # Fallback to current directory
        fallback = os.path.join(os.getcwd(), "uploads")
        os.makedirs(fallback, exist_ok=True)
        print(f"📁 Using fallback directory: {fallback}")
        return fallback


# Set ROOT_DIR based on platform detection
ROOT_DIR = setup_storage_directory()


def print_platform_info():
    """Print information about the current platform and storage"""
    platform_type = detect_platform()

    print(f"🖥️  Platform: {platform_type.title()}")
    print(f"📁 Storage location: {os.path.abspath(ROOT_DIR)}")

    if platform_type == "termux":
        shared_storage = "/storage/emulated/0"
        if ROOT_DIR.startswith(shared_storage):
            print("✅ Files accessible from Android file managers")
        else:
            print("⚠️  Files only accessible within Termux")
            print("💡 Tip: Run 'termux-setup-storage' for broader access")

    elif platform_type == "windows":
        print("💡 Open File Explorer and navigate to the storage location above")

    elif platform_type == "linux":
        print('💡 Use your file manager or: cd "' + ROOT_DIR + '"')

    elif platform_type == "macos":
        print("💡 Open Finder and navigate to the storage location above")

    # Check available space
    try:
        if platform_type == "windows":
            import shutil

            free = shutil.disk_usage(ROOT_DIR).free
        else:
            stat = os.statvfs(ROOT_DIR)
            free = stat.f_bavail * stat.f_frsize

        print(f"💾 Available space: {format_bytes(free)}")

    except Exception:
        print("💾 Available space: Unknown")


def format_bytes(bytes):
    """Format bytes into human readable format"""
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if bytes < 1024:
            return f"{bytes:.1f} {unit}"
        bytes /= 1024
    return f"{bytes:.1f} PB"


def set_custom_storage_path(custom_path, use_subfolder=True):
    """
    Set the storage path. If use_subfolder is True, append 'CloudinatorFTP' to the path.
    If False, use the path as-is (for custom user input).
    """
    global ROOT_DIR

    try:
        # Expand user paths like ~/Documents
        expanded_path = os.path.expanduser(custom_path)

        # The path is used exactly as given. (`use_subfolder` is accepted for
        # backward compatibility only: the preset paths already end in
        # "CloudinatorFTP", and a subfolder was never actually appended.)

        # Create directory
        os.makedirs(expanded_path, exist_ok=True)

        # Test write permissions
        test_file = os.path.join(expanded_path, ".write_test")
        with open(test_file, "w") as f:
            f.write("test")
        os.remove(test_file)

        # Save via paths._save() — merge-write so db_path/cache_path
        # already in storage_config.json are never overwritten.
        try:
            from paths import _save

            _save(
                {
                    "storage_path": expanded_path,
                    "platform": detect_platform(),
                    "set_at": (
                        str(os.path.getctime(expanded_path))
                        if os.path.exists(expanded_path)
                        else None
                    ),
                }
            )
            print("📋 Saved storage configuration")
        except Exception as e:
            print(f"⚠️  Could not save config: {e}")

        ROOT_DIR = expanded_path
        print(f"✅ Custom storage path set: {ROOT_DIR}")
        return True

    except Exception as e:
        print(f"❌ Cannot use custom path {custom_path}: {e}")
        return False


# Custom storage paths for quick setup
PRESET_PATHS = {
    "termux": {
        "downloads": "/storage/emulated/0/Download/CloudinatorFTP",
        "documents": "/storage/emulated/0/Documents/CloudinatorFTP",
        "internal": "/storage/emulated/0/CloudinatorFTP",
        "dcim": "/storage/emulated/0/DCIM/CloudinatorFTP",
        "termux_home": os.path.join(os.path.expanduser("~"), "uploads"),
    },
    "linux": {
        "home": os.path.join(os.path.expanduser("~"), "CloudinatorFTP"),
        "desktop": os.path.join(os.path.expanduser("~"), "Desktop", "CloudinatorFTP"),
        "documents": os.path.join(
            os.path.expanduser("~"), "Documents", "CloudinatorFTP"
        ),
        "downloads": os.path.join(
            os.path.expanduser("~"), "Downloads", "CloudinatorFTP"
        ),
    },
    "windows": {
        "documents": os.path.join(get_windows_documents_path(), "CloudinatorFTP"),
        "desktop": os.path.join(os.path.expanduser("~"), "Desktop", "CloudinatorFTP"),
        "downloads": os.path.join(
            os.path.expanduser("~"), "Downloads", "CloudinatorFTP"
        ),
        "userprofile": os.path.join(os.path.expanduser("~"), "CloudinatorFTP"),
    },
    "macos": {
        "documents": os.path.join(
            os.path.expanduser("~"), "Documents", "CloudinatorFTP"
        ),
        "desktop": os.path.join(os.path.expanduser("~"), "Desktop", "CloudinatorFTP"),
        "downloads": os.path.join(
            os.path.expanduser("~"), "Downloads", "CloudinatorFTP"
        ),
    },
}


def set_preset_path(preset_key):
    """Set storage path using a preset key"""
    platform_type = detect_platform()

    if platform_type in PRESET_PATHS and preset_key in PRESET_PATHS[platform_type]:
        preset_path = PRESET_PATHS[platform_type][preset_key]
        return set_custom_storage_path(preset_path)
    else:
        print(f"❌ Invalid preset '{preset_key}' for platform '{platform_type}'")
        available = list(PRESET_PATHS.get(platform_type, {}).keys())
        if available:
            print(f"Available presets: {', '.join(available)}")
        return False


def list_available_presets():
    """List all available preset paths for the current platform"""
    platform_type = detect_platform()

    print(f"\n📍 Available preset locations for {platform_type.title()}:")
    print("-" * 50)

    if platform_type in PRESET_PATHS:
        for key, path in PRESET_PATHS[platform_type].items():
            try:
                parent = os.path.dirname(path)
                accessible = (
                    "✅"
                    if os.path.exists(parent) and os.access(parent, os.W_OK)
                    else "❌"
                )
                print(f"{accessible} {key}: {path}")
            except Exception:
                print(f"❌ {key}: {path}")
    else:
        print(f"❌ No presets available for {platform_type}")

    print(f"\n🔧 Current location: {ROOT_DIR}")
    print("\n💡 To change storage location:")
    print("   Python: from config import set_preset_path; set_preset_path('documents')")
    print("   Env Var: set CLOUDINATOR_FTP_ROOT=C:\\path\\to\\your\\folder")
    print(
        "   Direct: from config import set_custom_storage_path; set_custom_storage_path('C:\\path\\to\\folder')"
    )


def configure_server_settings():
    """Interactive server configuration"""
    global PORT, CHUNK_SIZE, ENABLE_CHUNKED_UPLOADS, SESSION_SECRET
    global HOST, MAX_CONTENT_LENGTH, PERMANENT_SESSION_LIFETIME
    global ENABLE_FFMPEG, ENABLE_LIBVIPS

    print("\n🔧 Server Configuration")
    print("=" * 50)

    while True:
        print("\nCurrent Settings:")
        print(f"1. Port: {PORT}")
        print(f"2. Chunk Size: {format_bytes(CHUNK_SIZE)}")
        print(
            f"3. Chunked Uploads: {'Enabled' if ENABLE_CHUNKED_UPLOADS else 'Disabled'}"
        )
        print(f"4. Max File Size: {format_bytes(MAX_CONTENT_LENGTH)}")
        print(f"5. Session Timeout: {PERMANENT_SESSION_LIFETIME//60} minutes")
        print(f"6. Host Binding: {HOST}")
        print("7. Generate New Session Secret")
        print(
            f"8. HLS Settings    (min size: {format_bytes(HLS_MIN_SIZE) if HLS_MIN_SIZE else 'always'})"
        )
        print(
            f"9. Image Settings  (compress >{format_bytes(IMG_COMPRESS_MIN_SIZE)}, WebP Q={IMG_WEBP_QUALITY})"
        )
        print(f"11. ffmpeg (HLS):  {'✅ Enabled' if ENABLE_FFMPEG else '🚫 Disabled'}")
        print(f"12. libvips (img): {'✅ Enabled' if ENABLE_LIBVIPS else '🚫 Disabled'}")
        print("13. Protocol Servers (WebDAV / SFTP / FTP)")
        print(
            f"14. Upload / Download Performance (chunks in RAM: "
            f"{'On' if UPLOAD_CHUNKS_IN_MEMORY else 'Off'}, "
            f"download read size: {format_bytes(DOWNLOAD_BUFFER_SIZE)})"
        )
        print("10. Save & Exit")
        print("0. Exit Without Saving")

        choice = input("\nSelect option to configure (0-14): ").strip()

        if choice == "1":
            configure_port()
        elif choice == "2":
            configure_chunk_size()
        elif choice == "3":
            configure_chunked_uploads()
        elif choice == "4":
            configure_max_file_size()
        elif choice == "5":
            configure_session_timeout()
        elif choice == "6":
            configure_host_binding()
        elif choice == "7":
            generate_session_secret()
        elif choice == "8":
            configure_hls_settings()
        elif choice == "9":
            configure_image_settings()
        elif choice == "11":
            _toggle_ffmpeg()
        elif choice == "12":
            _toggle_libvips()
        elif choice == "13":
            configure_protocol_settings()
        elif choice == "14":
            configure_transfer_performance()
        elif choice == "10":
            save_server_config()
            print("✅ Server configuration saved!")
            break
        elif choice == "0":
            print("❌ Configuration cancelled")
            break
        else:
            print("❌ Invalid option. Please choose 0-14.")


def configure_port():
    """Configure server port"""
    global PORT
    print(f"\nCurrent port: {PORT}")
    print("Common ports: 80 (HTTP), 8080 (Alt HTTP), 5000 (Flask default)")
    print("Note: Ports below 1024 may require root privileges")

    while True:
        try:
            new_port = input(
                "Enter new port (1-65535) or press Enter to keep current: "
            ).strip()
            if not new_port:
                break
            port_num = int(new_port)
            if 1 <= port_num <= 65535:
                PORT = port_num
                print(f"✅ Port set to {PORT}")
                break
            else:
                print("❌ Port must be between 1 and 65535")
        except ValueError:
            print("❌ Please enter a valid number")


def configure_chunk_size():
    """Configure upload chunk size"""
    global CHUNK_SIZE
    print(f"\nCurrent chunk size: {format_bytes(CHUNK_SIZE)}")
    print("Recommended: 1MB-50MB (larger = faster uploads, more memory usage)")

    size_options = {
        "1": 1 * 1024 * 1024,  # 1MB
        "2": 5 * 1024 * 1024,  # 5MB
        "3": 10 * 1024 * 1024,  # 10MB
        "4": 25 * 1024 * 1024,  # 25MB
        "5": 50 * 1024 * 1024,  # 50MB
        "6": 100 * 1024 * 1024,  # 100MB
    }

    print("\nPreset options:")
    for key, value in size_options.items():
        print(f"{key}. {format_bytes(value)}")
    print("7. Custom size")
    print("8. Keep current")

    choice = input("\nSelect option (1-8): ").strip()

    if choice in size_options:
        CHUNK_SIZE = size_options[choice]
        print(f"✅ Chunk size set to {format_bytes(CHUNK_SIZE)}")
    elif choice == "7":
        configure_custom_chunk_size()
    elif choice == "8":
        print("✅ Keeping current chunk size")
    else:
        print("❌ Invalid option")


def configure_custom_chunk_size():
    """Configure custom chunk size"""
    global CHUNK_SIZE
    while True:
        try:
            size_input = input("Enter chunk size in MB (e.g., 15 for 15MB): ").strip()
            if not size_input:
                break
            size_mb = float(size_input)
            if 0.1 <= size_mb <= 1024:  # 0.1MB to 1GB
                CHUNK_SIZE = int(size_mb * 1024 * 1024)
                print(f"✅ Chunk size set to {format_bytes(CHUNK_SIZE)}")
                break
            else:
                print("❌ Size must be between 0.1MB and 1024MB")
        except ValueError:
            print("❌ Please enter a valid number")


def configure_chunked_uploads():
    """Toggle chunked uploads"""
    global ENABLE_CHUNKED_UPLOADS
    current = "Enabled" if ENABLE_CHUNKED_UPLOADS else "Disabled"
    print(f"\nChunked uploads currently: {current}")
    print(
        "Chunked uploads allow resumable uploads and better memory usage for large files"
    )

    choice = input("Enable chunked uploads? (y/n): ").strip().lower()
    if choice in ["y", "yes"]:
        ENABLE_CHUNKED_UPLOADS = True
        print("✅ Chunked uploads enabled")
    elif choice in ["n", "no"]:
        ENABLE_CHUNKED_UPLOADS = False
        print("✅ Chunked uploads disabled")
    else:
        print("✅ Keeping current setting")


def configure_transfer_performance():
    """Upload / download performance (5.43): chunks parsed in RAM, the timing log and the download
    read size. A change is kept in memory; "Save & Exit" of the server menu writes it to
    server_config.json, and a running server needs a restart to use it."""
    global UPLOAD_CHUNKS_IN_MEMORY, UPLOAD_TIMING_ENABLED

    while True:
        print("\n⚡ Upload / Download Performance")
        print("=" * 50)
        print(
            f"1. Parse upload chunks in RAM: {'On' if UPLOAD_CHUNKS_IN_MEMORY else 'Off'}"
        )
        print(
            f"2. Upload timing log:          {'On' if UPLOAD_TIMING_ENABLED else 'Off'}"
        )
        print(f"3. Download read size:         {format_bytes(DOWNLOAD_BUFFER_SIZE)}")
        print("0. Back")

        choice = input("\nSelect option (0-3): ").strip()
        if choice == "1":
            UPLOAD_CHUNKS_IN_MEMORY = not UPLOAD_CHUNKS_IN_MEMORY
            state = "On" if UPLOAD_CHUNKS_IN_MEMORY else "Off"
            print(
                f"✅ Parse upload chunks in RAM: {state} (up to one chunk of RAM each)"
            )
        elif choice == "2":
            UPLOAD_TIMING_ENABLED = not UPLOAD_TIMING_ENABLED
            state = "On" if UPLOAD_TIMING_ENABLED else "Off"
            print(f"✅ Upload timing log: {state}")
        elif choice == "3":
            _configure_download_buffer()
        elif choice == "0":
            break
        else:
            print("❌ Invalid option. Please choose 0-3.")


def _configure_download_buffer():
    """Choose how many bytes are read per step when a file is sent (8 KB to 16 MB)."""
    global DOWNLOAD_BUFFER_SIZE
    presets = {
        "1": 64 * 1024,
        "2": 256 * 1024,
        "3": 1024 * 1024,
        "4": 4 * 1024 * 1024,
    }
    print(f"\nCurrent download read size: {format_bytes(DOWNLOAD_BUFFER_SIZE)}")
    print(
        "Quart's own 8 KB per step is slow; each download in flight uses this much RAM."
    )
    for key, value in presets.items():
        print(f"{key}. {format_bytes(value)}")
    print("5. Custom size (KB)")
    print("6. Keep current")

    choice = input("\nSelect option (1-6): ").strip()
    if choice in presets:
        DOWNLOAD_BUFFER_SIZE = presets[choice]
        print(f"✅ Download read size set to {format_bytes(DOWNLOAD_BUFFER_SIZE)}")
    elif choice == "5":
        raw = input("Enter size in KB (8 to 16384): ").strip()
        accepted = None
        if raw.isdigit():
            accepted = _buffer_size_or_default(int(raw) * 1024, None)
        if accepted is None:
            print("❌ Size must be a whole number from 8 to 16384 KB")
        else:
            DOWNLOAD_BUFFER_SIZE = accepted
            print(f"✅ Download read size set to {format_bytes(DOWNLOAD_BUFFER_SIZE)}")
    elif choice == "6":
        print("✅ Keeping current download read size")
    else:
        print("❌ Invalid option")


def configure_max_file_size():
    """Configure maximum file size"""
    global MAX_CONTENT_LENGTH
    print(f"\nCurrent max file size: {format_bytes(MAX_CONTENT_LENGTH)}")

    size_options = {
        "1": 1 * 1024 * 1024 * 1024,  # 1GB
        "2": 4 * 1024 * 1024 * 1024,  # 4GB
        "3": 8 * 1024 * 1024 * 1024,  # 8GB
        "4": 16 * 1024 * 1024 * 1024,  # 16GB
        "5": 32 * 1024 * 1024 * 1024,  # 32GB
        "6": 64 * 1024 * 1024 * 1024,  # 64GB
    }

    print("\nPreset options:")
    for key, value in size_options.items():
        print(f"{key}. {format_bytes(value)}")
    print("7. Custom size")
    print("8. Keep current")

    choice = input("\nSelect option (1-8): ").strip()

    if choice in size_options:
        MAX_CONTENT_LENGTH = size_options[choice]
        print(f"✅ Max file size set to {format_bytes(MAX_CONTENT_LENGTH)}")
    elif choice == "7":
        configure_custom_max_size()
    elif choice == "8":
        print("✅ Keeping current max file size")
    else:
        print("❌ Invalid option")


def configure_custom_max_size():
    """Configure custom max file size"""
    global MAX_CONTENT_LENGTH
    while True:
        try:
            size_input = input(
                "Enter max file size in GB (e.g., 10 for 10GB): "
            ).strip()
            if not size_input:
                break
            size_gb = float(size_input)
            if 0.1 <= size_gb <= 1024:  # 0.1GB to 1TB
                MAX_CONTENT_LENGTH = int(size_gb * 1024 * 1024 * 1024)
                print(f"✅ Max file size set to {format_bytes(MAX_CONTENT_LENGTH)}")
                break
            else:
                print("❌ Size must be between 0.1GB and 1024GB")
        except ValueError:
            print("❌ Please enter a valid number")


def configure_session_timeout():
    """Configure session timeout"""
    global PERMANENT_SESSION_LIFETIME
    print(
        f"\nCurrent session timeout: {PERMANENT_SESSION_LIFETIME} seconds ({PERMANENT_SESSION_LIFETIME//60} minutes)"
    )

    timeout_options = {
        "1": 900,  # 15 minutes
        "2": 1800,  # 30 minutes
        "3": 3600,  # 1 hour
        "4": 7200,  # 2 hours
        "5": 14400,  # 4 hours
        "6": 28800,  # 8 hours
    }

    print("\nPreset options:")
    for key, value in timeout_options.items():
        minutes = value // 60
        print(f"{key}. {minutes} minutes")
    print("7. Custom timeout")
    print("8. Keep current")

    choice = input("\nSelect option (1-8): ").strip()

    if choice in timeout_options:
        PERMANENT_SESSION_LIFETIME = timeout_options[choice]
        minutes = PERMANENT_SESSION_LIFETIME // 60
        print(f"✅ Session timeout set to {minutes} minutes")
    elif choice == "7":
        configure_custom_timeout()
    elif choice == "8":
        print("✅ Keeping current timeout")
    else:
        print("❌ Invalid option")


def configure_custom_timeout():
    """Configure custom session timeout"""
    global PERMANENT_SESSION_LIFETIME
    while True:
        try:
            timeout_input = input(
                "Enter timeout in minutes (e.g., 90 for 1.5 hours): "
            ).strip()
            if not timeout_input:
                break
            timeout_minutes = int(timeout_input)
            if 1 <= timeout_minutes <= 1440:  # 1 minute to 24 hours
                PERMANENT_SESSION_LIFETIME = timeout_minutes * 60
                print(f"✅ Session timeout set to {timeout_minutes} minutes")
                break
            else:
                print("❌ Timeout must be between 1 and 1440 minutes (24 hours)")
        except ValueError:
            print("❌ Please enter a valid number")


def configure_host_binding():
    """Configure host binding"""
    global HOST
    print(f"\nCurrent host binding: {HOST}")
    print("0.0.0.0 = Listen on all interfaces (recommended for tunnels)")
    print("127.0.0.1 = Listen only on localhost (local access only)")

    host_options = {"1": "0.0.0.0", "2": "127.0.0.1"}

    print("\nOptions:")
    print("1. 0.0.0.0 (All interfaces)")
    print("2. 127.0.0.1 (Localhost only)")
    print("3. Custom IP")
    print("4. Keep current")

    choice = input("\nSelect option (1-4): ").strip()

    if choice in ["1", "2"]:
        HOST = host_options[choice]
        print(f"✅ Host binding set to {HOST}")
    elif choice == "3":
        custom_host = input("Enter custom IP address: ").strip()
        if custom_host:
            HOST = custom_host
            print(f"✅ Host binding set to {HOST}")
    elif choice == "4":
        print("✅ Keeping current host binding")
    else:
        print("❌ Invalid option")


def generate_session_secret():
    """Session secret is now auto-managed in db/session.secret"""
    print("ℹ️  Session secret is auto-generated and stored in db/session.secret")
    print("   Delete that file to regenerate it (logs out all active users)")


def _toggle_ffmpeg():
    """Toggle ffmpeg / HLS transcoding on or off."""
    global ENABLE_FFMPEG
    current = "Enabled" if ENABLE_FFMPEG else "Disabled"
    print(f"\n🎬 ffmpeg (HLS transcoding) — currently: {current}")
    print("  Enabled  + ffmpeg installed   → full HLS adaptive streaming")
    print(
        "  Enabled  + ffmpeg not found   → graceful raw-playback fallback (existing behaviour)"
    )
    print(
        "  Disabled                      → raw playback always, regardless of installation"
    )
    print("\n1. Enable  ffmpeg")
    print("2. Disable ffmpeg")
    print("3. Keep current")
    choice = input("\nSelect (1-3): ").strip()
    if choice == "1":
        ENABLE_FFMPEG = True
        print(
            "✅ ffmpeg enabled — HLS transcoding active (falls back to raw if not installed)"
        )
    elif choice == "2":
        ENABLE_FFMPEG = False
        print("🚫 ffmpeg disabled — raw playback only")
    else:
        print("✅ Keeping current setting")


def _toggle_libvips():
    """Toggle libvips / image conversion on or off."""
    global ENABLE_LIBVIPS
    current = "Enabled" if ENABLE_LIBVIPS else "Disabled"
    print(f"\n🖼️  libvips (image conversion) — currently: {current}")
    print("  Enabled  + libvips installed  → WebP conversion & compression")
    print(
        "  Enabled  + libvips not found  → graceful raw-serving fallback (existing behaviour)"
    )
    print(
        "  Disabled                      → raw serving always; non-native formats show"
    )
    print(
        "                                  a 'requires processing' notice instead of broken image"
    )
    print("\n1. Enable  libvips")
    print("2. Disable libvips")
    print("3. Keep current")
    choice = input("\nSelect (1-3): ").strip()
    if choice == "1":
        ENABLE_LIBVIPS = True
        print(
            "✅ libvips enabled — image conversion active (falls back to raw if not installed)"
        )
    elif choice == "2":
        ENABLE_LIBVIPS = False
        print("🚫 libvips disabled — raw fallback only")
    else:
        print("✅ Keeping current setting")


def save_server_config():
    """Save server configuration to server_config.json (next to this file)."""
    config_data = {
        # ── Core server ──────────────────────────────────────────────────
        "PORT": PORT,
        "HOST": HOST,
        "CHUNK_SIZE": CHUNK_SIZE,
        "ENABLE_CHUNKED_UPLOADS": ENABLE_CHUNKED_UPLOADS,
        "BODY_TIMEOUT": BODY_TIMEOUT,
        "UPLOAD_TIMING_ENABLED": UPLOAD_TIMING_ENABLED,
        "UPLOAD_CHUNKS_IN_MEMORY": UPLOAD_CHUNKS_IN_MEMORY,
        "DOWNLOAD_BUFFER_SIZE": DOWNLOAD_BUFFER_SIZE,
        "MAX_CONTENT_LENGTH": MAX_CONTENT_LENGTH,
        "PERMANENT_SESSION_LIFETIME": PERMANENT_SESSION_LIFETIME,
        # ── Feature toggles ───────────────────────────────────────────────
        "ENABLE_FFMPEG": ENABLE_FFMPEG,
        "ENABLE_LIBVIPS": ENABLE_LIBVIPS,
        "ENABLE_SEARCH_INDEX": ENABLE_SEARCH_INDEX,
        # ── HLS / video ───────────────────────────────────────────────────
        "HLS_MIN_SIZE": HLS_MIN_SIZE,
        "HLS_FORCE_FORMATS": sorted(HLS_FORCE_FORMATS),  # set → sorted list for JSON
        # ── Image / WebP ──────────────────────────────────────────────────
        "IMG_COMPRESS_MIN_SIZE": IMG_COMPRESS_MIN_SIZE,
        "IMG_WEBP_QUALITY": IMG_WEBP_QUALITY,
        # ── Protocol servers ──────────────────────────────────────────────
        "WEBDAV_ENABLED": WEBDAV_ENABLED,
        "WEBDAV_PORT": WEBDAV_PORT,
        "WEBDAV_HTTPS_ENABLED": WEBDAV_HTTPS_ENABLED,
        "WEBDAV_HTTPS_PORT": WEBDAV_HTTPS_PORT,
        "SFTP_ENABLED": SFTP_ENABLED,
        "SFTP_PORT": SFTP_PORT,
        "FTP_ENABLED": FTP_ENABLED,
        "FTP_PORT": FTP_PORT,
        "FTP_TLS_ENABLED": FTP_TLS_ENABLED,
        "FTP_TLS_REQUIRE_DATA": FTP_TLS_REQUIRE_DATA,
        "SMB_ENABLED": SMB_ENABLED,
        "SMB_PORT": SMB_PORT,
        "SMB_FALLBACK_PORT": SMB_FALLBACK_PORT,
        "SMB_SHARE_NAME": SMB_SHARE_NAME,
        # ── Version Engine ───────────────────────────────────────────────
        "VERSION_ENGINE_ENABLED": VERSION_ENGINE_ENABLED,
        "VERSION_DB_FILENAME": VERSION_DB_FILENAME,
        "VERSION_SMALL_FILE_THRESHOLD": VERSION_SMALL_FILE_THRESHOLD,
        "VERSION_CHUNK_SIZE": VERSION_CHUNK_SIZE,
        "VERSION_CHUNKING_ALGORITHM": VERSION_CHUNKING_ALGORITHM,
        "VERSION_WORKER_COUNT": VERSION_WORKER_COUNT,
        "VERSION_MAX_CONCURRENT_SNAPSHOTS": VERSION_MAX_CONCURRENT_SNAPSHOTS,
        "VERSION_WATCH_ENABLED": VERSION_WATCH_ENABLED,
        "VERSION_SCAN_ENABLED": VERSION_SCAN_ENABLED,
        "VERSION_SCAN_INTERVAL": VERSION_SCAN_INTERVAL,
        "VERSION_TRACK_FILES": VERSION_TRACK_FILES,
        "VERSION_TRACK_DIRECTORIES": VERSION_TRACK_DIRECTORIES,
        "VERSION_TRACK_ROOTS": VERSION_TRACK_ROOTS,
        "VERSION_TRACK_ALL_FILES": VERSION_TRACK_ALL_FILES,
        "VERSION_EXCLUDE_DIRECTORIES": VERSION_EXCLUDE_DIRECTORIES,
        "VERSION_EXCLUDE_PATTERNS": VERSION_EXCLUDE_PATTERNS,
        "VERSION_RETENTION_ENABLED": VERSION_RETENTION_ENABLED,
        "VERSION_MAX_VERSIONS": VERSION_MAX_VERSIONS,
        "VERSION_GC_ENABLED": VERSION_GC_ENABLED,
        "VERSION_GC_GRACE_PERIOD": VERSION_GC_GRACE_PERIOD,
        "VERSION_RETRY_COUNT": VERSION_RETRY_COUNT,
        "VERSION_RETRY_DELAY": VERSION_RETRY_DELAY,
        "VERSION_COMPRESSION_ENABLED": VERSION_COMPRESSION_ENABLED,
        "VERSION_COMPRESSION_LEVEL": VERSION_COMPRESSION_LEVEL,
        "VERSION_COMPRESSION_MIN_SAVING_PERCENT": VERSION_COMPRESSION_MIN_SAVING_PERCENT,
        "VERSION_COMPRESSION_BUSY_PERCENT": VERSION_COMPRESSION_BUSY_PERCENT,
        "VERSION_COMPRESSION_INTERVAL": VERSION_COMPRESSION_INTERVAL,
        "VERSION_COMPRESSION_DELTA_ENABLED": VERSION_COMPRESSION_DELTA_ENABLED,
        "VERSION_COMPRESSION_DELTA_MIN_GAIN_PERCENT": VERSION_COMPRESSION_DELTA_MIN_GAIN_PERCENT,
        "VERSION_FOLLOW_SYMLINKS": VERSION_FOLLOW_SYMLINKS,
        "VERSION_ALLOW_RESTORE_OVERWRITE": VERSION_ALLOW_RESTORE_OVERWRITE,
        "VERSION_SHUTDOWN_TIMEOUT": VERSION_SHUTDOWN_TIMEOUT,
        "VERSION_PURGE_MISSING_ENABLED": VERSION_PURGE_MISSING_ENABLED,
        "VERSION_PURGE_MISSING_MIN_AGE_DAYS": VERSION_PURGE_MISSING_MIN_AGE_DAYS,
        "VERSION_PURGE_MISSING_INTERVAL": VERSION_PURGE_MISSING_INTERVAL,
        "VERSION_PURGE_MISSING_MAX_FILES_PER_PASS": VERSION_PURGE_MISSING_MAX_FILES_PER_PASS,
        "VERSION_PURGE_MISSING_BATCH_PAUSE": VERSION_PURGE_MISSING_BATCH_PAUSE,
        "VERSION_WAL_SIZE_LIMIT_MB": VERSION_WAL_SIZE_LIMIT_MB,
        # ── Metadata ──────────────────────────────────────────────────────
        "configured_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }

    try:
        with open(_SERVER_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(config_data, f, indent=2)
        print(f"✅ Server configuration saved to {_SERVER_CONFIG_FILE}")
    except Exception as e:
        print(f"❌ Error saving configuration: {e}")


def _non_negative_number(value, default):
    """`value` when it is a number (not a bool) of at least 0, else `default`: a hand-edited
    server_config.json with "BODY_TIMEOUT": "soon" must not stop the server from starting.
    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return default
    return value if value >= 0 else default


def _bounded_number(value, default, low, high):
    """`value` when it is a number (not a bool) from `low` to `high`, else `default`: a
    hand-edited server_config.json must not be able to turn a throttle into a busy loop.
    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return default
    return value if low <= value <= high else default


def _bool_fail_safe(value, default):
    """For a switch that is ON by default and destructive-ish: a key that is missing keeps
    `default`; a real JSON true/false is taken as written; anything else (a string \"false\",
    0, null, a typo) means OFF, so a hand-edited server_config.json can never leave the feature
    running when the owner meant to switch it off."""
    if value is None:
        return default
    return value if isinstance(value, bool) else False


def _buffer_size_or_default(value, default):
    """`value` when it is a whole number (not a bool) from 8192 to 16 MiB, else `default`: a
    hand-edited server_config.json must not be able to switch downloads off or ask for a
    gigabyte per download."""
    if isinstance(value, bool) or not isinstance(value, int):
        return default
    return value if 8192 <= value <= 16 * 1024 * 1024 else default


def load_server_config():
    """Load server configuration from server_config.json (next to this file)."""
    global PORT, CHUNK_SIZE, ENABLE_CHUNKED_UPLOADS
    global BODY_TIMEOUT, UPLOAD_TIMING_ENABLED, UPLOAD_CHUNKS_IN_MEMORY
    global DOWNLOAD_BUFFER_SIZE
    global HOST, MAX_CONTENT_LENGTH, PERMANENT_SESSION_LIFETIME
    global HLS_MIN_SIZE, HLS_FORCE_FORMATS
    global IMG_COMPRESS_MIN_SIZE, IMG_WEBP_QUALITY
    global ENABLE_FFMPEG, ENABLE_LIBVIPS, ENABLE_SEARCH_INDEX
    global WEBDAV_ENABLED, WEBDAV_PORT, WEBDAV_HTTPS_ENABLED, WEBDAV_HTTPS_PORT
    global SFTP_ENABLED, SFTP_PORT
    global FTP_ENABLED, FTP_PORT, FTP_TLS_ENABLED, FTP_TLS_REQUIRE_DATA
    global SMB_ENABLED, SMB_PORT, SMB_FALLBACK_PORT, SMB_SHARE_NAME
    global VERSION_ENGINE_ENABLED, VERSION_DB_FILENAME
    global VERSION_SMALL_FILE_THRESHOLD, VERSION_CHUNK_SIZE, VERSION_CHUNKING_ALGORITHM
    global VERSION_WORKER_COUNT, VERSION_MAX_CONCURRENT_SNAPSHOTS
    global VERSION_WATCH_ENABLED, VERSION_SCAN_ENABLED, VERSION_SCAN_INTERVAL
    global VERSION_TRACK_FILES, VERSION_TRACK_DIRECTORIES, VERSION_TRACK_ROOTS
    global VERSION_TRACK_ALL_FILES
    global VERSION_EXCLUDE_DIRECTORIES, VERSION_EXCLUDE_PATTERNS
    global VERSION_RETENTION_ENABLED, VERSION_MAX_VERSIONS
    global VERSION_GC_ENABLED, VERSION_GC_GRACE_PERIOD
    global VERSION_RETRY_COUNT, VERSION_RETRY_DELAY
    global VERSION_COMPRESSION_ENABLED, VERSION_FOLLOW_SYMLINKS
    global VERSION_COMPRESSION_LEVEL, VERSION_COMPRESSION_MIN_SAVING_PERCENT
    global VERSION_COMPRESSION_BUSY_PERCENT, VERSION_COMPRESSION_INTERVAL
    global VERSION_COMPRESSION_DELTA_ENABLED, VERSION_COMPRESSION_DELTA_MIN_GAIN_PERCENT
    global VERSION_ALLOW_RESTORE_OVERWRITE, VERSION_SHUTDOWN_TIMEOUT
    global VERSION_PURGE_MISSING_ENABLED, VERSION_PURGE_MISSING_MIN_AGE_DAYS
    global VERSION_PURGE_MISSING_INTERVAL, VERSION_PURGE_MISSING_MAX_FILES_PER_PASS
    global VERSION_PURGE_MISSING_BATCH_PAUSE, VERSION_WAL_SIZE_LIMIT_MB

    try:
        if os.path.exists(_SERVER_CONFIG_FILE):
            with open(_SERVER_CONFIG_FILE, "r", encoding="utf-8") as f:
                config = json.load(f)

            # ── Core server ───────────────────────────────────────────────
            PORT = config.get("PORT", PORT)
            HOST = config.get("HOST", HOST)
            CHUNK_SIZE = config.get("CHUNK_SIZE", CHUNK_SIZE)
            ENABLE_CHUNKED_UPLOADS = config.get(
                "ENABLE_CHUNKED_UPLOADS", ENABLE_CHUNKED_UPLOADS
            )
            BODY_TIMEOUT = _non_negative_number(
                config.get("BODY_TIMEOUT", BODY_TIMEOUT), BODY_TIMEOUT
            )
            UPLOAD_TIMING_ENABLED = bool(
                config.get("UPLOAD_TIMING_ENABLED", UPLOAD_TIMING_ENABLED)
            )
            UPLOAD_CHUNKS_IN_MEMORY = bool(
                config.get("UPLOAD_CHUNKS_IN_MEMORY", UPLOAD_CHUNKS_IN_MEMORY)
            )
            DOWNLOAD_BUFFER_SIZE = _buffer_size_or_default(
                config.get("DOWNLOAD_BUFFER_SIZE", DOWNLOAD_BUFFER_SIZE),
                DOWNLOAD_BUFFER_SIZE,
            )
            MAX_CONTENT_LENGTH = config.get("MAX_CONTENT_LENGTH", MAX_CONTENT_LENGTH)
            PERMANENT_SESSION_LIFETIME = config.get(
                "PERMANENT_SESSION_LIFETIME", PERMANENT_SESSION_LIFETIME
            )

            # ── Feature toggles ───────────────────────────────────────────
            ENABLE_FFMPEG = config.get("ENABLE_FFMPEG", ENABLE_FFMPEG)
            ENABLE_LIBVIPS = config.get("ENABLE_LIBVIPS", ENABLE_LIBVIPS)
            ENABLE_SEARCH_INDEX = config.get("ENABLE_SEARCH_INDEX", ENABLE_SEARCH_INDEX)

            # ── HLS / video ───────────────────────────────────────────────
            HLS_MIN_SIZE = config.get("HLS_MIN_SIZE", HLS_MIN_SIZE)
            if "HLS_FORCE_FORMATS" in config:
                HLS_FORCE_FORMATS = set(config["HLS_FORCE_FORMATS"])

            # ── Image / WebP ──────────────────────────────────────────────
            IMG_COMPRESS_MIN_SIZE = config.get(
                "IMG_COMPRESS_MIN_SIZE", IMG_COMPRESS_MIN_SIZE
            )
            IMG_WEBP_QUALITY = config.get("IMG_WEBP_QUALITY", IMG_WEBP_QUALITY)

            # ── Protocol servers ──────────────────────────────────────────
            WEBDAV_ENABLED = config.get("WEBDAV_ENABLED", WEBDAV_ENABLED)
            WEBDAV_PORT = config.get("WEBDAV_PORT", WEBDAV_PORT)
            WEBDAV_HTTPS_ENABLED = config.get(
                "WEBDAV_HTTPS_ENABLED", WEBDAV_HTTPS_ENABLED
            )
            WEBDAV_HTTPS_PORT = config.get("WEBDAV_HTTPS_PORT", WEBDAV_HTTPS_PORT)
            SFTP_ENABLED = config.get("SFTP_ENABLED", SFTP_ENABLED)
            SFTP_PORT = config.get("SFTP_PORT", SFTP_PORT)
            FTP_ENABLED = config.get("FTP_ENABLED", FTP_ENABLED)
            FTP_PORT = config.get("FTP_PORT", FTP_PORT)
            FTP_TLS_ENABLED = config.get("FTP_TLS_ENABLED", FTP_TLS_ENABLED)
            FTP_TLS_REQUIRE_DATA = config.get(
                "FTP_TLS_REQUIRE_DATA", FTP_TLS_REQUIRE_DATA
            )
            SMB_ENABLED = config.get("SMB_ENABLED", SMB_ENABLED)
            SMB_PORT = config.get("SMB_PORT", SMB_PORT)
            SMB_FALLBACK_PORT = config.get("SMB_FALLBACK_PORT", SMB_FALLBACK_PORT)
            SMB_SHARE_NAME = config.get("SMB_SHARE_NAME", SMB_SHARE_NAME)

            # ── Version Engine ──────────────────────────────────────────
            # .get(key, default) means an old server_config.json missing
            # any/all VERSION_* keys falls back to the in-code default
            # above with no migration code needed.
            VERSION_ENGINE_ENABLED = config.get(
                "VERSION_ENGINE_ENABLED", VERSION_ENGINE_ENABLED
            )
            VERSION_DB_FILENAME = config.get("VERSION_DB_FILENAME", VERSION_DB_FILENAME)
            VERSION_SMALL_FILE_THRESHOLD = config.get(
                "VERSION_SMALL_FILE_THRESHOLD", VERSION_SMALL_FILE_THRESHOLD
            )
            VERSION_CHUNK_SIZE = config.get("VERSION_CHUNK_SIZE", VERSION_CHUNK_SIZE)
            VERSION_CHUNKING_ALGORITHM = config.get(
                "VERSION_CHUNKING_ALGORITHM", VERSION_CHUNKING_ALGORITHM
            )
            VERSION_WORKER_COUNT = config.get(
                "VERSION_WORKER_COUNT", VERSION_WORKER_COUNT
            )
            VERSION_MAX_CONCURRENT_SNAPSHOTS = config.get(
                "VERSION_MAX_CONCURRENT_SNAPSHOTS", VERSION_MAX_CONCURRENT_SNAPSHOTS
            )
            VERSION_WATCH_ENABLED = config.get(
                "VERSION_WATCH_ENABLED", VERSION_WATCH_ENABLED
            )
            VERSION_SCAN_ENABLED = config.get(
                "VERSION_SCAN_ENABLED", VERSION_SCAN_ENABLED
            )
            VERSION_SCAN_INTERVAL = config.get(
                "VERSION_SCAN_INTERVAL", VERSION_SCAN_INTERVAL
            )
            VERSION_TRACK_FILES = config.get("VERSION_TRACK_FILES", VERSION_TRACK_FILES)
            VERSION_TRACK_DIRECTORIES = config.get(
                "VERSION_TRACK_DIRECTORIES", VERSION_TRACK_DIRECTORIES
            )
            VERSION_TRACK_ROOTS = config.get("VERSION_TRACK_ROOTS", VERSION_TRACK_ROOTS)
            VERSION_TRACK_ALL_FILES = config.get(
                "VERSION_TRACK_ALL_FILES", VERSION_TRACK_ALL_FILES
            )
            VERSION_EXCLUDE_DIRECTORIES = config.get(
                "VERSION_EXCLUDE_DIRECTORIES", VERSION_EXCLUDE_DIRECTORIES
            )
            VERSION_EXCLUDE_PATTERNS = config.get(
                "VERSION_EXCLUDE_PATTERNS", VERSION_EXCLUDE_PATTERNS
            )
            VERSION_RETENTION_ENABLED = config.get(
                "VERSION_RETENTION_ENABLED", VERSION_RETENTION_ENABLED
            )
            VERSION_MAX_VERSIONS = config.get(
                "VERSION_MAX_VERSIONS", VERSION_MAX_VERSIONS
            )
            VERSION_GC_ENABLED = config.get("VERSION_GC_ENABLED", VERSION_GC_ENABLED)
            VERSION_GC_GRACE_PERIOD = config.get(
                "VERSION_GC_GRACE_PERIOD", VERSION_GC_GRACE_PERIOD
            )
            VERSION_RETRY_COUNT = config.get("VERSION_RETRY_COUNT", VERSION_RETRY_COUNT)
            VERSION_RETRY_DELAY = config.get("VERSION_RETRY_DELAY", VERSION_RETRY_DELAY)
            # A real JSON true/false is taken as written; anything else (the string "true",
            # 1, null, a typo) means OFF: a hand-edited file can never start compression by
            # accident. A missing key keeps the default (off).
            VERSION_COMPRESSION_ENABLED = _bool_fail_safe(
                config.get("VERSION_COMPRESSION_ENABLED"), VERSION_COMPRESSION_ENABLED
            )
            VERSION_COMPRESSION_LEVEL = int(
                _bounded_number(
                    config.get("VERSION_COMPRESSION_LEVEL"),
                    VERSION_COMPRESSION_LEVEL,
                    *VERSION_COMPRESSION_BOUNDS["VERSION_COMPRESSION_LEVEL"],
                )
            )
            VERSION_COMPRESSION_MIN_SAVING_PERCENT = _bounded_number(
                config.get("VERSION_COMPRESSION_MIN_SAVING_PERCENT"),
                VERSION_COMPRESSION_MIN_SAVING_PERCENT,
                *VERSION_COMPRESSION_BOUNDS["VERSION_COMPRESSION_MIN_SAVING_PERCENT"],
            )
            VERSION_COMPRESSION_BUSY_PERCENT = _bounded_number(
                config.get("VERSION_COMPRESSION_BUSY_PERCENT"),
                VERSION_COMPRESSION_BUSY_PERCENT,
                *VERSION_COMPRESSION_BOUNDS["VERSION_COMPRESSION_BUSY_PERCENT"],
            )
            VERSION_COMPRESSION_INTERVAL = _bounded_number(
                config.get("VERSION_COMPRESSION_INTERVAL"),
                VERSION_COMPRESSION_INTERVAL,
                *VERSION_COMPRESSION_BOUNDS["VERSION_COMPRESSION_INTERVAL"],
            )
            VERSION_COMPRESSION_DELTA_ENABLED = _bool_fail_safe(
                config.get("VERSION_COMPRESSION_DELTA_ENABLED"),
                VERSION_COMPRESSION_DELTA_ENABLED,
            )
            VERSION_COMPRESSION_DELTA_MIN_GAIN_PERCENT = _bounded_number(
                config.get("VERSION_COMPRESSION_DELTA_MIN_GAIN_PERCENT"),
                VERSION_COMPRESSION_DELTA_MIN_GAIN_PERCENT,
                *VERSION_COMPRESSION_BOUNDS[
                    "VERSION_COMPRESSION_DELTA_MIN_GAIN_PERCENT"
                ],
            )
            VERSION_FOLLOW_SYMLINKS = config.get(
                "VERSION_FOLLOW_SYMLINKS", VERSION_FOLLOW_SYMLINKS
            )
            VERSION_ALLOW_RESTORE_OVERWRITE = config.get(
                "VERSION_ALLOW_RESTORE_OVERWRITE", VERSION_ALLOW_RESTORE_OVERWRITE
            )
            VERSION_SHUTDOWN_TIMEOUT = config.get(
                "VERSION_SHUTDOWN_TIMEOUT", VERSION_SHUTDOWN_TIMEOUT
            )
            VERSION_PURGE_MISSING_ENABLED = _bool_fail_safe(
                config.get("VERSION_PURGE_MISSING_ENABLED"),
                VERSION_PURGE_MISSING_ENABLED,
            )
            VERSION_PURGE_MISSING_MIN_AGE_DAYS = _bounded_number(
                config.get("VERSION_PURGE_MISSING_MIN_AGE_DAYS"),
                VERSION_PURGE_MISSING_MIN_AGE_DAYS,
                0,
                36500,
            )
            VERSION_PURGE_MISSING_INTERVAL = _bounded_number(
                config.get("VERSION_PURGE_MISSING_INTERVAL"),
                VERSION_PURGE_MISSING_INTERVAL,
                60,
                30 * 86400,
            )
            VERSION_PURGE_MISSING_MAX_FILES_PER_PASS = int(
                _bounded_number(
                    config.get("VERSION_PURGE_MISSING_MAX_FILES_PER_PASS"),
                    VERSION_PURGE_MISSING_MAX_FILES_PER_PASS,
                    1,
                    100000,
                )
            )
            VERSION_PURGE_MISSING_BATCH_PAUSE = _bounded_number(
                config.get("VERSION_PURGE_MISSING_BATCH_PAUSE"),
                VERSION_PURGE_MISSING_BATCH_PAUSE,
                0,
                5,
            )
            # 0 = off, 1 to 64 MB; anything else (a string, a negative number, 500) keeps
            # the default 64, so a hand-edited file can never set a limit above 64 MB.
            VERSION_WAL_SIZE_LIMIT_MB = _bounded_number(
                config.get("VERSION_WAL_SIZE_LIMIT_MB"),
                VERSION_WAL_SIZE_LIMIT_MB,
                0,
                64,
            )

            print(f"✅ Server configuration loaded from {_SERVER_CONFIG_FILE}")
            return True
    except Exception as e:
        print(f"⚠️ Could not load server config: {e}")

    return False


def _confirm_path(final_path: str, label: str) -> bool:
    """Show the resolved final path and ask user to confirm before saving."""
    print()
    print(f"  📁 {label} will be set to:")
    print(f"     {final_path}")
    print()
    while True:
        try:
            ans = input("  Confirm? (y/n): ").strip().lower()
            if ans in ("y", "yes"):
                return True
            if ans in ("n", "no"):
                print("  ↩️  Cancelled.")
                return False
        except KeyboardInterrupt:
            print("\n👋 Cancelled")
            return False


def _check_path(path):
    """Check if a path exists and is writable."""
    if not os.path.exists(path):
        return False, False
    try:
        test = os.path.join(path, ".write_test")
        with open(test, "w") as f:
            f.write("test")
        os.remove(test)
        return True, True
    except Exception:
        return True, False


def _db_cache_examples(subfolder):
    """Return suggested out-of-server-root paths for db / cache / hls / img."""
    home = os.path.expanduser("~")
    if os.name == "nt":
        return [
            os.path.join(os.environ.get("APPDATA", home), "cloudinator", subfolder),
            os.path.join(
                os.environ.get("LOCALAPPDATA", home), "cloudinator", subfolder
            ),
            os.path.join(home, ".cloudinator", subfolder),
        ]
    else:
        return [
            os.path.join(home, ".cloudinator", subfolder),
            f"/etc/cloudinator/{subfolder}",
            f"/var/lib/cloudinator/{subfolder}",
        ]


def _pick_suggested_path(kind, examples):
    """Present a numbered list of suggested paths and let the user pick one."""
    print()
    for i, ex in enumerate(examples, 1):
        exists, writable = _check_path(ex)
        if writable:
            note = "✅ exists & writable"
        elif not exists:
            note = "📁 will be created"
        else:
            note = "❌ not writable"
        print(f"{i}. {ex}  [{note}]")
    print(f"{len(examples) + 1}. ↩️  Back")
    print()
    try:
        raw = input(f"Select option (1-{len(examples) + 1}): ").strip()
        choice = int(raw)
    except (ValueError, KeyboardInterrupt):
        return
    if choice < 1 or choice > len(examples):
        return
    path = examples[choice - 1]
    label = {
        "db": "Database",
        "cache": "Cache",
        "hls": "HLS Cache",
        "img": "Image Cache",
        "versions": "Version Storage",
    }.get(kind, kind)
    if not _confirm_path(path, label):
        return
    if kind == "db":
        set_db_dir(path)
    elif kind == "cache":
        set_cache_dir(path)
    elif kind == "hls":
        set_hls_cache_dir(path)
    elif kind == "versions":
        set_versions_dir(path)
    else:
        set_img_cache_dir(path)


def _configure_custom_dir(kind):
    """Prompt user for a custom directory path for db / cache / hls / img."""
    label = {
        "db": "Database",
        "cache": "Cache",
        "hls": "HLS Cache",
        "img": "Image Cache",
        "versions": "Version Storage",
    }.get(kind, kind)
    subfolder = {
        "db": "db",
        "cache": "cache",
        "hls": "hls",
        "img": "img",
        "versions": "versions",
    }.get(kind, kind)
    print(f"\n🎯 Custom {label} Directory")
    print(f"   Enter a parent folder — '{subfolder}' will be appended automatically.")
    print(f"   Example: /srv/cloudinator  →  /srv/cloudinator/{subfolder}")
    try:
        custom = input("Path: ").strip()
        if not custom:
            return
        expanded = os.path.abspath(os.path.expanduser(custom))
        if os.path.basename(expanded).lower() != subfolder:
            final = os.path.join(expanded, subfolder)
        else:
            final = expanded
        if not _confirm_path(final, label):
            return
        if kind == "db":
            set_db_dir(expanded)
        elif kind == "cache":
            set_cache_dir(expanded)
        elif kind == "hls":
            set_hls_cache_dir(expanded)
        elif kind == "versions":
            set_versions_dir(expanded)
        else:
            set_img_cache_dir(expanded)
    except KeyboardInterrupt:
        print("\n👋 Cancelled")


def configure_files_path():
    """Configure Files storage path (ROOT_DIR)."""
    print("\n🗂️  Files Storage Path Configuration")
    print("=" * 50)
    print(f"Current: {ROOT_DIR}\n")

    platform_type = detect_platform()
    if platform_type not in PRESET_PATHS:
        # Unknown platform — fall back to custom path entry
        _configure_custom_files_path()
        return

    presets = PRESET_PATHS[platform_type]
    print(f"📍 Available File Storage Locations for {platform_type.title()}:")
    print("-" * 50)

    options = []
    for i, (key, path) in enumerate(presets.items(), 1):
        try:
            parent = os.path.dirname(path)
            status = (
                "✅"
                if os.path.exists(parent) and os.access(parent, os.W_OK)
                else ("⚠️ " if os.path.exists(parent) else "❌")
            )
        except Exception:
            status = "❌"
        print(f"{i:2d}. {status} {key.replace('_', ' ').title()}")
        print(f"      {path}")
        descs = {
            "downloads": "Recommended for easy access",
            "documents": "Good for document storage",
            "desktop": "Quick access from desktop",
            "internal": "Android internal storage root",
            "dcim": "Camera/media folder",
            "termux_home": "Termux app directory only",
        }
        if key in descs:
            print(f"      💡 {descs[key]}")
        print()
        options.append((key, path))

    print(f"{len(options) + 1}. 🎯 Enter custom path")
    print(f"{len(options) + 2}. ↩️  Back")
    print()

    try:
        raw = input(f"Select option (1-{len(options) + 2}): ").strip()
        choice = int(raw)
    except (ValueError, KeyboardInterrupt):
        return

    if choice == len(options) + 2 or choice < 1:
        return
    elif choice == len(options) + 1:
        _configure_custom_files_path()
    elif choice <= len(options):
        key, path = options[choice - 1]
        if not _confirm_path(path, "Files storage"):
            return
        if set_preset_path(key):
            print(f"✅ Files storage set to: {path}")


def _configure_custom_files_path():
    """Prompt for a fully custom Files storage path."""
    print("\n🎯 Custom Files Path")
    print("Enter the exact path where uploaded files should be stored.")
    try:
        custom = input("Path: ").strip()
        if not custom:
            return
        expanded = os.path.abspath(os.path.expanduser(custom))
        if not _confirm_path(expanded, "Files storage"):
            return
        if set_custom_storage_path(expanded, use_subfolder=False):
            print(f"✅ Files storage set to: {expanded}")
    except KeyboardInterrupt:
        print("\n👋 Cancelled")


def configure_db_path():
    """Configure Database directory (DB_DIR)."""
    print("\n🔐 Database Directory Configuration")
    print("=" * 50)
    print(f"Current: {get_db_dir()}")
    print()
    print("This directory holds three sensitive files:")
    print("  • cloudinator.db  — SQLite user accounts database")
    print("  • secret.key      — Fernet AES-128 encryption key")
    print("  • session.secret  — Flask session cookie signing key")
    print()
    print("⚠️  SECURITY: Move this OUTSIDE the server root so that")
    print("   a path traversal or misconfigured web server cannot")
    print("   serve these files to an attacker.")
    print()
    print("⚠️  After moving: copy your existing db/ files to the new")
    print("   location BEFORE restarting, or you will lose all accounts.")
    print()

    examples = _db_cache_examples("db")
    print("Suggested secure locations:")
    for ex in examples:
        print(f"  • {ex}")
    print()

    print("1. 📁 Use a suggested location")
    print("2. 🎯 Enter custom path")
    print("3. 🔄 Reset to default  (inside server root — less secure)")
    print("4. ↩️  Back")
    print()

    try:
        choice = input("Select option (1-4): ").strip()
    except KeyboardInterrupt:
        return

    if choice == "1":
        _pick_suggested_path("db", examples)
    elif choice == "2":
        _configure_custom_dir("db")
    elif choice == "3":
        reset_db_dir()
        print("🔄 Database directory reset to default.")


def configure_cache_path():
    """Configure Cache directory (CACHE_DIR)."""
    print("\n⚡ Cache Directory Configuration")
    print("=" * 50)
    print(f"Current: {get_cache_dir()}")
    print()
    print("This directory holds two auto-generated index files:")
    print("  • storage_index.json — recursive file/dir counts per folder")
    print("  • file_index.json    — cached directory listings (speeds up browsing)")
    print()
    print("These files are fully rebuilt on next server start if missing.")
    print("Moving cache outside the server root prevents directory-structure")
    print("metadata from leaking via a misconfigured web server.")
    print()

    examples = _db_cache_examples("cache")
    print("Suggested locations:")
    for ex in examples:
        print(f"  • {ex}")
    print()

    print("1. 📁 Use a suggested location")
    print("2. 🎯 Enter custom path")
    print("3. 🔄 Reset to default  (inside server root)")
    print("4. ↩️  Back")
    print()

    try:
        choice = input("Select option (1-4): ").strip()
    except KeyboardInterrupt:
        return

    if choice == "1":
        _pick_suggested_path("cache", examples)
    elif choice == "2":
        _configure_custom_dir("cache")
    elif choice == "3":
        reset_cache_dir()
        print("🔄 Cache directory reset to default.")


def configure_versions_path():
    """Configure Version Engine storage directory (VERSION_STORAGE_DIR)."""
    print("\n🕓 Version Storage Directory Configuration")
    print("=" * 50)
    print(f"Current: {get_versions_dir()}")
    print()
    print("This directory holds the Version Engine's content-addressed")
    print("object/chunk store — the actual byte content of every historical")
    print("version of every tracked file. It is irreplaceable if lost (unlike")
    print("cache/, which is fully rebuildable), so it deserves its own tier.")
    print()
    print("⚠️  This directory is NEVER served over WebDAV/SFTP/FTP/SMB —")
    print("   it is intentionally kept separate from ROOT_DIR.")
    print()
    print("⚠️  After moving: copy your existing versions/ files to the new")
    print("   location BEFORE restarting, or version history is unreachable.")
    print()

    examples = _db_cache_examples("versions")
    print("Suggested secure locations:")
    for ex in examples:
        print(f"  • {ex}")
    print()

    print("1. 📁 Use a suggested location")
    print("2. 🎯 Enter custom path")
    print("3. 🔄 Reset to default  (inside server root)")
    print("4. ↩️  Back")
    print()

    try:
        choice = input("Select option (1-4): ").strip()
    except KeyboardInterrupt:
        return

    if choice == "1":
        _pick_suggested_path("versions", examples)
    elif choice == "2":
        _configure_custom_dir("versions")
    elif choice == "3":
        reset_versions_dir()
        print("🔄 Version storage directory reset to default.")


def configure_version_engine_settings():
    """Configure single-value Version Engine settings."""
    global VERSION_ENGINE_ENABLED, VERSION_SMALL_FILE_THRESHOLD, VERSION_CHUNK_SIZE
    global VERSION_WORKER_COUNT, VERSION_SCAN_ENABLED, VERSION_SCAN_INTERVAL
    global VERSION_WATCH_ENABLED, VERSION_MAX_VERSIONS, VERSION_RETENTION_ENABLED
    global VERSION_GC_ENABLED, VERSION_GC_GRACE_PERIOD
    global VERSION_ALLOW_RESTORE_OVERWRITE, VERSION_FOLLOW_SYMLINKS

    print("\n🕓 Version Engine Settings")
    print("=" * 50)

    while True:

        def _yon(v):
            return "✅ Enabled" if v else "🚫 Disabled"

        print("\nCurrent Settings:")
        print(f" 1. Version Engine:        {_yon(VERSION_ENGINE_ENABLED)}")
        print(
            f" 2. Small-file threshold:  {format_bytes(VERSION_SMALL_FILE_THRESHOLD)}  (below: full-object; above: chunked)"
        )
        print(
            f" 3. Chunk size:            {format_bytes(VERSION_CHUNK_SIZE)}  (independent of upload CHUNK_SIZE)"
        )
        print(f" 4. Worker count:          {VERSION_WORKER_COUNT}")
        print(f" 5. Watcher:               {_yon(VERSION_WATCH_ENABLED)}")
        print(
            f" 6. Scanner:               {_yon(VERSION_SCAN_ENABLED)}  every {VERSION_SCAN_INTERVAL}s"
        )
        print(
            f" 7. Retention:             {_yon(VERSION_RETENTION_ENABLED)}  max {VERSION_MAX_VERSIONS} versions/file"
        )
        print(
            f" 8. Garbage collection:    {_yon(VERSION_GC_ENABLED)}  grace period {VERSION_GC_GRACE_PERIOD}s"
        )
        print(f" 9. Allow restore overwrite: {_yon(VERSION_ALLOW_RESTORE_OVERWRITE)}")
        print(f"10. Follow symlinks:       {_yon(VERSION_FOLLOW_SYMLINKS)}")
        print(
            f"13. Compression (zstd):    {_yon(VERSION_COMPRESSION_ENABLED)}  level {VERSION_COMPRESSION_LEVEL}"
            f"  → opens its own menu; it saves only the keys it changes"
        )
        print("11. Save & Exit")
        print("12. Exit Without Saving")
        print()

        choice = input("Select option (1-13): ").strip()

        if choice == "1":
            VERSION_ENGINE_ENABLED = not VERSION_ENGINE_ENABLED
        elif choice == "2":
            try:
                mb = float(input("Small-file threshold in MB: ").strip())
                if mb > 0:
                    VERSION_SMALL_FILE_THRESHOLD = int(mb * 1024 * 1024)
            except ValueError:
                print("❌ Invalid number")
        elif choice == "3":
            try:
                mb = float(input("Chunk size in MB: ").strip())
                if mb > 0:
                    VERSION_CHUNK_SIZE = int(mb * 1024 * 1024)
            except ValueError:
                print("❌ Invalid number")
        elif choice == "4":
            try:
                n = int(
                    input(
                        "Worker count (1 recommended on Termux/low-power devices): "
                    ).strip()
                )
                if n >= 1:
                    VERSION_WORKER_COUNT = n
            except ValueError:
                print("❌ Invalid number")
        elif choice == "5":
            VERSION_WATCH_ENABLED = not VERSION_WATCH_ENABLED
        elif choice == "6":
            VERSION_SCAN_ENABLED = not VERSION_SCAN_ENABLED
        elif choice == "7":
            VERSION_RETENTION_ENABLED = not VERSION_RETENTION_ENABLED
        elif choice == "8":
            VERSION_GC_ENABLED = not VERSION_GC_ENABLED
        elif choice == "9":
            VERSION_ALLOW_RESTORE_OVERWRITE = not VERSION_ALLOW_RESTORE_OVERWRITE
        elif choice == "10":
            VERSION_FOLLOW_SYMLINKS = not VERSION_FOLLOW_SYMLINKS
        elif choice == "13":
            configure_version_compression()
        elif choice == "11":
            save_server_config()
            print("✅ Version Engine configuration saved!")
            break
        elif choice == "12":
            print("↩️  Cancelled")
            break
        else:
            print("❌ Invalid option")


def _read_server_config_file():
    """(settings dict, None) for a readable server_config.json, (None, None) when the file does
    not exist, (None, error text) when it exists but is not a JSON object. Never writes.
    """
    try:
        with open(_SERVER_CONFIG_FILE, encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return None, None
    except (OSError, ValueError) as e:
        return None, str(e)
    if not isinstance(data, dict):
        return None, "the file does not hold a JSON object"
    return data, None


def save_server_config_keys(updates):
    """Write ONLY the keys in `updates` into server_config.json and keep everything else.

    save_server_config() rebuilds the whole file from the module's variables (it drops a key
    config.py does not know, turns a value the loader refused into the default, adds every
    missing key and refreshes configured_at). This function is the other way: it reads the file
    as it is on disk, changes the named keys, and leaves every other key, its value and its
    position alone (configured_at too). An absent key stays absent unless it is in `updates`.
    A file that is not valid JSON is never overwritten. A missing file is created with just
    these keys (the loader takes every other key from its defaults). The new text is checked
    (parsed and compared with what was intended) in a temporary file next to the real one, then
    put in place with os.replace, so a failed write leaves the old file untouched. LF line
    endings. Returns True when the file now holds the new values."""
    current, error = _read_server_config_file()
    if error is not None:
        print(f"❌ {_SERVER_CONFIG_FILE} cannot be read ({error}).")
        print("   Nothing was written: fix or restore the file first.")
        return False
    merged = dict(current) if current is not None else {}
    merged.update(updates)
    text = json.dumps(merged, indent=2)
    tmp_path = _SERVER_CONFIG_FILE + ".tmp"
    try:
        with open(tmp_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        with open(tmp_path, encoding="utf-8") as f:
            if json.load(f) != merged:
                raise ValueError("the temporary file does not hold what was intended")
        os.replace(tmp_path, _SERVER_CONFIG_FILE)
    except Exception as e:
        print(f"❌ Error saving configuration: {e}")
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError as cleanup_error:
                print(f"⚠️  Could not remove {tmp_path}: {cleanup_error}")
        return False
    print(f"✅ Saved {', '.join(sorted(updates))} to {_SERVER_CONFIG_FILE}")
    return True


def parse_compression_value(key, text):
    """(value, None) for a valid entry, (None, error text) otherwise. Whole numbers only, inside
    the loader's own bounds (VERSION_COMPRESSION_BOUNDS): the menu can never write what the
    loader would refuse."""
    low, high = VERSION_COMPRESSION_BOUNDS[key]
    raw = text.strip()
    if not (raw.isascii() and raw.isdigit()):
        return None, f"enter a whole number from {low} to {high}"
    value = int(raw)
    if not low <= value <= high:
        return None, f"{value} is outside {low} to {high}"
    return value, None


def _ask(prompt):
    """input() that returns None on Ctrl-C / Ctrl-D / closed stdin instead of a traceback."""
    try:
        return input(prompt)
    except (KeyboardInterrupt, EOFError):
        print()
        return None


def _compression_value_text(setting, value):
    if setting["kind"] == "bool":
        return "✅ ON" if value else "🚫 OFF"
    return f"{value}{setting['unit']}"


def _compression_file_note(setting, file_cfg):
    """Where the value comes from: the file, the default, or a file value the loader ignores."""
    key = setting["key"]
    if file_cfg is None:
        return "no server_config.json: default applies"
    if key not in file_cfg:
        return "not in server_config.json: default applies"
    raw = file_cfg[key]
    if setting["kind"] == "bool":
        if raw is None or isinstance(raw, bool):
            return "in server_config.json"
        return f"⚠️ file holds {raw!r}: only a real true/false counts, this is OFF"
    low, high = setting["low"], setting["high"]
    if _bounded_number(raw, None, low, high) is None:
        return f"⚠️ file holds {raw!r}: not a number from {low} to {high}, the default is used"
    return "in server_config.json"


def configure_version_compression():
    """Version Engine > Engine settings > 13: the seven VERSION_COMPRESSION_* settings.

    Shows the current value, the default, the allowed range and where the value comes from.
    Changes are held until "Save & Back", which writes ONLY the keys that were changed
    (save_server_config_keys): every other key of server_config.json stays as it is, and a key
    that is absent stays absent. A running Version Engine reads these settings at start, so a
    change needs a restart of the Version Engine."""
    pending = {}
    print("\n🗜️  Version Engine — Compression settings (zstd)")
    print("=" * 50)
    print("A change needs a RESTART of the Version Engine (./manage.sh restart).")
    print(
        "Reading compressed objects always works; these settings only control writing."
    )

    while True:
        file_cfg, file_error = _read_server_config_file()
        if file_error is not None:
            print(
                f"\n⚠️  server_config.json cannot be read ({file_error}): saving is blocked."
            )
        print("\nSettings (* = changed, not saved yet):")
        for n, setting in enumerate(VERSION_COMPRESSION_SETTINGS, 1):
            key = setting["key"]
            value = pending.get(key, globals()[key])
            mark = "*" if key in pending else " "
            print(
                f"{mark}{n}. {setting['label']}: {_compression_value_text(setting, value)}"
            )
            if setting["kind"] == "bool":
                allowed = "on / off"
            else:
                allowed = f"{setting['low']} to {setting['high']}"
            print(
                f"      default {_compression_value_text(setting, setting['default'])}"
                f" · allowed {allowed} · {key}"
            )
            print(f"      {setting['help']}")
            print(f"      [{_compression_file_note(setting, file_cfg)}]")
        print("8. Save & Back   (writes only the changed keys)")
        print("9. Back Without Saving")
        print()

        choice = _ask("Select option (1-9): ")
        if choice is None:
            print("↩️  Back (nothing saved)")
            return
        choice = choice.strip()

        if choice in {"1", "2", "3", "4", "5", "6", "7"}:
            setting = VERSION_COMPRESSION_SETTINGS[int(choice) - 1]
            key = setting["key"]
            if setting["kind"] == "bool":
                new_value = not pending.get(key, globals()[key])
                print(
                    f"{setting['label']}: {'ON' if new_value else 'OFF'}"
                    " (takes effect when the Version Engine restarts)"
                )
            else:
                current = pending.get(key, globals()[key])
                answer = _ask(
                    f"{setting['label']} ({setting['low']} to {setting['high']}"
                    f"{setting['unit']}), Enter keeps {current}: "
                )
                if answer is None or not answer.strip():
                    continue
                new_value, error = parse_compression_value(key, answer)
                if error:
                    print(f"❌ {error}: nothing changed")
                    continue
            if new_value == globals()[key]:
                pending.pop(key, None)
            else:
                pending[key] = new_value
        elif choice == "8":
            if not pending:
                print("ℹ️  Nothing changed: nothing written.")
                return
            if save_server_config_keys(pending):
                for key, value in pending.items():
                    globals()[key] = value
                print(
                    "✅ Compression settings saved. Restart the Version Engine to apply."
                )
                return
        elif choice == "9":
            print("↩️  Back (nothing saved)")
            return
        else:
            print("❌ Invalid option")


def _version_list_menu(title, getter_name):
    """Generic view/add/remove/clear sub-menu for one VERSION_TRACK_*/
    VERSION_EXCLUDE_* list setting. `getter_name` is the global var name."""
    while True:
        current = globals()[getter_name]
        print(f"\n{title}  ({len(current)} entr{'y' if len(current) == 1 else 'ies'})")
        for i, item in enumerate(current, 1):
            print(f"   {i}. {item}")
        if not current:
            print("   (empty — nothing configured)")
        print("\n1. ➕ Add entry")
        print("2. ➖ Remove entry")
        print("3. 🧹 Clear all")
        print("4. ↩️  Back")

        choice = input("\nSelect option (1-4): ").strip()

        if choice == "1":
            try:
                entry = input("Path / pattern to add: ").strip()
            except KeyboardInterrupt:
                continue
            if entry and entry not in current:
                current.append(entry)
                print(f"✅ Added: {entry}")
        elif choice == "2":
            if not current:
                print("Nothing to remove.")
                continue
            try:
                idx = int(input("Entry number to remove: ").strip())
            except ValueError:
                print("❌ Invalid number")
                continue
            if 1 <= idx <= len(current):
                removed = current.pop(idx - 1)
                print(f"✅ Removed: {removed}")
            else:
                print("❌ Out of range")
        elif choice == "3":
            current.clear()
            print("✅ Cleared")
        elif choice == "4":
            break
        else:
            print("❌ Invalid option")


def configure_version_tracking():
    """Sub-menu for the five list-value Version Engine settings.

    Unlike every other VERSION_* setting, these are lists, not single
    values — none of the existing configure_*() single-prompt patterns
    apply, so this gets its own view/add/remove/clear shape.
    """
    print("\n🕓 Version Tracking Scope")
    print("=" * 50)
    print("Nothing is tracked until you explicitly add an entry below.")
    print("VERSION_TRACK_ALL_FILES only applies recursively under whatever")
    print("roots you list in 'Tracking roots' — it never means the whole machine.")

    while True:
        global VERSION_TRACK_ALL_FILES

        def _yon(v):
            return "✅ Enabled" if v else "🚫 Disabled"

        print("\n1. Tracked files            (VERSION_TRACK_FILES)")
        print("2. Tracked directories       (VERSION_TRACK_DIRECTORIES)")
        print("3. Tracking roots            (VERSION_TRACK_ROOTS)")
        print(f"4. Track ALL files under roots  {_yon(VERSION_TRACK_ALL_FILES)}")
        print("5. Excluded directories      (VERSION_EXCLUDE_DIRECTORIES)")
        print("6. Excluded patterns         (VERSION_EXCLUDE_PATTERNS)")
        print("7. Save & Exit")
        print("8. Exit Without Saving")

        choice = input("\nSelect option (1-8): ").strip()

        if choice == "1":
            _version_list_menu("Tracked files", "VERSION_TRACK_FILES")
        elif choice == "2":
            _version_list_menu("Tracked directories", "VERSION_TRACK_DIRECTORIES")
        elif choice == "3":
            _version_list_menu("Tracking roots", "VERSION_TRACK_ROOTS")
        elif choice == "4":
            VERSION_TRACK_ALL_FILES = not VERSION_TRACK_ALL_FILES
        elif choice == "5":
            _version_list_menu("Excluded directories", "VERSION_EXCLUDE_DIRECTORIES")
        elif choice == "6":
            _version_list_menu("Excluded patterns", "VERSION_EXCLUDE_PATTERNS")
        elif choice == "7":
            save_server_config()
            print("✅ Version tracking configuration saved!")
            break
        elif choice == "8":
            print("↩️  Cancelled")
            break
        else:
            print("❌ Invalid option")


def configure_hls_cache_path():
    """Configure HLS Cache directory (HLS_CACHE_DIR)."""
    print("\n🎬 HLS Cache Directory Configuration")
    print("=" * 50)
    print(f"Current: {get_hls_cache_dir()}")
    print()
    print("This directory holds ffmpeg-transcoded HLS segments:")
    print("  • <cache_key>/master.m3u8  — adaptive bitrate playlist")
    print("  • <cache_key>/<quality>/   — .ts segment files")
    print("  • <cache_key>/.status.json — transcode progress/state")
    print()
    print("It can grow large for long videos. Point it at a drive")
    print("with plenty of free space. Safe to delete at any time —")
    print("videos will simply be re-transcoded on next play.")
    print()

    examples = _db_cache_examples("hls")
    print("Suggested locations:")
    for ex in examples:
        print(f"  • {ex}")
    print()

    print("1. 📁 Use a suggested location")
    print("2. 🎯 Enter custom path")
    print("3. 🔄 Reset to default  (inside cache dir)")
    print("4. ↩️  Back")
    print()

    try:
        choice = input("Select option (1-4): ").strip()
    except KeyboardInterrupt:
        return

    if choice == "1":
        _pick_suggested_path("hls", examples)
    elif choice == "2":
        _configure_custom_dir("hls")
    elif choice == "3":
        reset_hls_cache_dir()
        print("🔄 HLS Cache directory reset to default.")


def configure_img_cache_path():
    """Configure Image Cache directory (IMG_CACHE_DIR)."""
    print("\n🖼️  Image Cache Directory Configuration")
    print("=" * 50)
    print(f"Current: {get_img_cache_dir()}")
    print()
    print("This directory holds pyvips-converted image previews:")
    print("  • <cache_key>.webp        — lossless or lossy WebP preview")
    print("  • <cache_key>.jpg         — JPEG fallback for oversized images")
    print("  • <cache_key>.meta.json   — conversion metadata (size, format, quality)")
    print()
    print("Safe to delete at any time — previews are regenerated on next view.")
    print()

    examples = _db_cache_examples("img")
    print("Suggested locations:")
    for ex in examples:
        print(f"  • {ex}")
    print()

    print("1. 📁 Use a suggested location")
    print("2. 🎯 Enter custom path")
    print("3. 🔄 Reset to default  (inside cache dir)")
    print("4. ↩️  Back")
    print()

    try:
        choice = input("Select option (1-4): ").strip()
    except KeyboardInterrupt:
        return

    if choice == "1":
        _pick_suggested_path("img", examples)
    elif choice == "2":
        _configure_custom_dir("img")
    elif choice == "3":
        reset_img_cache_dir()
        print("🔄 Image cache directory reset to default.")


def configure_storage_path():
    """Storage path submenu — covers all five storage directories."""
    while True:
        print("\n🗄️  Storage Configuration")
        print("=" * 50)
        print(f"  🗂️  Files   (ROOT_DIR)    : {ROOT_DIR}")
        print(f"  🔐 Database (DB_DIR)     : {get_db_dir()}")
        print(f"  ⚡ Cache    (CACHE_DIR)  : {get_cache_dir()}")
        print(f"  🎬 HLS Cache             : {get_hls_cache_dir()}")
        print(f"  🖼️  Image Cache           : {get_img_cache_dir()}")
        print()
        print("1. 🗂️  Configure Files storage path   (ROOT_DIR)")
        print("2. 🔐 Configure Database directory    (DB_DIR)  ← keys & secrets")
        print("3. ⚡ Configure Cache directory       (CACHE_DIR)")
        print("4. 🎬 Configure HLS Cache directory   (HLS_CACHE_DIR)")
        print("5. 🖼️  Configure Image Cache directory (IMG_CACHE_DIR)")
        print("6. ↩️  Back")
        print()

        try:
            choice = input("Select option (1-6): ").strip()
        except KeyboardInterrupt:
            break

        if choice == "1":
            configure_files_path()
            input("\nPress Enter to continue...")
        elif choice == "2":
            configure_db_path()
            input("\nPress Enter to continue...")
        elif choice == "3":
            configure_cache_path()
            input("\nPress Enter to continue...")
        elif choice == "4":
            configure_hls_cache_path()
            input("\nPress Enter to continue...")
        elif choice == "5":
            configure_img_cache_path()
            input("\nPress Enter to continue...")
        elif choice == "6":
            break
        else:
            print("❌ Invalid option. Please choose 1-6.")


def main_configuration_menu():
    """Main configuration menu"""
    print("\n🏠 Cloudinator Configuration")
    print("=" * 50)

    while True:
        print("\nConfiguration Options:")
        print("1. Storage Path Configuration")
        print("2. Server Settings Configuration")
        print("3. Version History / Version Engine")
        print("4. View Current Settings")
        print("5. Exit")

        choice = input("\nSelect option (1-5): ").strip()

        if choice == "1":
            configure_storage_path()
        elif choice == "2":
            configure_server_settings()
        elif choice == "3":
            _version_engine_menu()
        elif choice == "4":
            view_current_settings()
        elif choice == "5":
            print("✅ Configuration complete!")
            break
        else:
            print("❌ Invalid option. Please choose 1-5.")


def _version_engine_menu():
    """Version History / Version Engine section of the main config menu."""
    while True:
        print("\n🕓 Version History / Version Engine")
        print("=" * 50)
        print(f"1. Version storage path       (currently: {get_versions_dir()})")
        print(
            "2. Engine settings            (enable, chunking, workers, retention, GC…)"
        )
        print("3. Tracking scope             (which files/dirs/roots to version)")
        print("4. ↩️  Back")

        choice = input("\nSelect option (1-4): ").strip()

        if choice == "1":
            configure_versions_path()
        elif choice == "2":
            configure_version_engine_settings()
        elif choice == "3":
            configure_version_tracking()
        elif choice == "4":
            break
        else:
            print("❌ Invalid option")


def configure_hls_settings():
    """Configure HLS streaming thresholds"""
    global HLS_MIN_SIZE, HLS_FORCE_FORMATS

    print("\n🎬 HLS Streaming Configuration")
    print("=" * 50)

    while True:
        print("\nCurrent Settings:")
        print(f"1. Min size for HLS:    {format_bytes(HLS_MIN_SIZE)}")
        print("   (web-native files smaller than this play raw instead)")
        print(f"2. Always-HLS formats:  {', '.join(sorted(HLS_FORCE_FORMATS))}")
        print("   (these always get HLS regardless of size)")
        print("3. Save & Exit")
        print("4. Exit Without Saving")
        print()

        choice = input("Select option (1-4): ").strip()

        if choice == "1":
            _configure_hls_min_size()
        elif choice == "2":
            _configure_hls_force_formats()
        elif choice == "3":
            save_server_config()
            print("✅ HLS configuration saved!")
            break
        elif choice == "4":
            print("↩️  Cancelled")
            break
        else:
            print("❌ Invalid option")


def _configure_hls_min_size():
    """Configure minimum file size to trigger HLS for web-native formats"""
    global HLS_MIN_SIZE

    size_options = {
        "1": (0, "Always use HLS for all videos"),
        "2": (10 * 1024 * 1024, "10 MB"),
        "3": (25 * 1024 * 1024, "25 MB"),
        "4": (50 * 1024 * 1024, "50 MB  (default)"),
        "5": (100 * 1024 * 1024, "100 MB"),
        "6": (250 * 1024 * 1024, "250 MB"),
        "7": (500 * 1024 * 1024, "500 MB"),
    }

    print(f"\nCurrent: {format_bytes(HLS_MIN_SIZE)}")
    print("Files below this threshold play raw (for mp4/webm/mov/m4v).")
    print("Non-web-native formats (mkv, avi, etc.) always use HLS regardless.\n")
    for key, (val, label) in size_options.items():
        marker = " ◀ current" if val == HLS_MIN_SIZE else ""
        print(f"{key}. {label}{marker}")
    print("8. Custom size")
    print("9. Keep current")

    choice = input("\nSelect option (1-9): ").strip()

    if choice in size_options:
        HLS_MIN_SIZE = size_options[choice][0]
        print(
            f"✅ HLS min size set to {format_bytes(HLS_MIN_SIZE) if HLS_MIN_SIZE else 'always HLS'}"
        )
    elif choice == "8":
        while True:
            try:
                raw = input("Enter size in MB (e.g. 75): ").strip()
                if not raw:
                    break
                mb = float(raw)
                if 0 <= mb <= 10240:
                    HLS_MIN_SIZE = int(mb * 1024 * 1024)
                    print(f"✅ HLS min size set to {format_bytes(HLS_MIN_SIZE)}")
                    break
                else:
                    print("❌ Enter a value between 0 and 10240 MB")
            except ValueError:
                print("❌ Please enter a valid number")
    elif choice == "9":
        print("✅ Keeping current setting")
    else:
        print("❌ Invalid option")


def _configure_hls_force_formats():
    """Configure which formats always get HLS regardless of file size"""
    global HLS_FORCE_FORMATS

    all_formats = sorted(
        {
            "mkv",
            "avi",
            "wmv",
            "flv",
            "mpg",
            "mpeg",
            "m2ts",
            "mts",
            "3gp",
            "ogv",
            "mov",
            "ts",
        }
    )

    print(f"\nCurrent always-HLS formats: {', '.join(sorted(HLS_FORCE_FORMATS))}")
    print("These formats can't be played raw in most browsers, so they")
    print("always get transcoded to HLS regardless of file size.\n")
    print("Available formats:")
    for i, fmt in enumerate(all_formats, 1):
        marker = "✅" if fmt in HLS_FORCE_FORMATS else "  "
        print(f"  {marker} {i:2d}. {fmt}")

    print(
        "\nEnter format numbers to toggle (comma-separated), or press Enter to cancel:"
    )
    raw = input("> ").strip()
    if not raw:
        print("↩️  Cancelled")
        return

    try:
        indices = [int(x.strip()) - 1 for x in raw.split(",")]
        toggled = []
        for idx in indices:
            if 0 <= idx < len(all_formats):
                fmt = all_formats[idx]
                if fmt in HLS_FORCE_FORMATS:
                    HLS_FORCE_FORMATS.discard(fmt)
                    toggled.append(f"removed {fmt}")
                else:
                    HLS_FORCE_FORMATS.add(fmt)
                    toggled.append(f"added {fmt}")
        if toggled:
            print("✅ " + ", ".join(toggled))
            print(f"   Always-HLS formats now: {', '.join(sorted(HLS_FORCE_FORMATS))}")
    except ValueError:
        print("❌ Please enter valid numbers")


def configure_image_settings():
    """Configure image preview / WebP compression thresholds"""
    global IMG_COMPRESS_MIN_SIZE, IMG_WEBP_QUALITY

    print("\n🖼️  Image Preview / WebP Compression Configuration")
    print("=" * 50)

    while True:
        thresh = (
            format_bytes(IMG_COMPRESS_MIN_SIZE)
            if IMG_COMPRESS_MIN_SIZE
            else "Always compress"
        )
        print("\nCurrent Settings:")
        print(f"1. Compress threshold: {thresh}")
        print("   (native images above this size are compressed to lossy WebP)")
        print(
            f"2. Lossy WebP quality: {IMG_WEBP_QUALITY}  (1–100, lower = smaller file)"
        )
        print("   (non-native formats always convert to lossless WebP regardless)")
        print("3. Save & Exit")
        print("4. Exit Without Saving")
        print()

        choice = input("Select option (1-4): ").strip()

        if choice == "1":
            _configure_img_compress_min_size()
        elif choice == "2":
            _configure_img_webp_quality()
        elif choice == "3":
            save_server_config()
            print("✅ Image configuration saved!")
            break
        elif choice == "4":
            print("↩️  Cancelled")
            break
        else:
            print("❌ Invalid option")


def _configure_img_compress_min_size():
    """Configure the file-size threshold above which native images are compressed to WebP"""
    global IMG_COMPRESS_MIN_SIZE

    size_options = {
        "1": (0, "Always compress (all native images)"),
        "2": (1 * 1024 * 1024, "1 MB  (default)"),
        "3": (3 * 1024 * 1024, "3 MB"),
        "4": (5 * 1024 * 1024, "5 MB"),
        "5": (10 * 1024 * 1024, "10 MB"),
        "6": (15 * 1024 * 1024, "15 MB"),
        "7": (25 * 1024 * 1024, "25 MB"),
    }

    current_label = (
        format_bytes(IMG_COMPRESS_MIN_SIZE)
        if IMG_COMPRESS_MIN_SIZE
        else "Always compress"
    )
    print(f"\nCurrent: {current_label}")
    print("Native images (jpg/png/gif/webp/etc.) below this threshold are served raw.")
    print("Non-native formats (tiff/heic/psd/raw/…) always convert regardless.\n")
    for key, (val, label) in size_options.items():
        marker = " ◀ current" if val == IMG_COMPRESS_MIN_SIZE else ""
        print(f"{key}. {label}{marker}")
    print("8. Custom size")
    print("9. Keep current")

    choice = input("\nSelect option (1-9): ").strip()

    if choice in size_options:
        IMG_COMPRESS_MIN_SIZE = size_options[choice][0]
        label = (
            format_bytes(IMG_COMPRESS_MIN_SIZE)
            if IMG_COMPRESS_MIN_SIZE
            else "always compress"
        )
        print(f"✅ Image compress threshold set to {label}")
    elif choice == "8":
        while True:
            try:
                raw = input("Enter size in MB (e.g. 20): ").strip()
                if not raw:
                    break
                mb = float(raw)
                if 0 <= mb <= 10240:
                    IMG_COMPRESS_MIN_SIZE = int(mb * 1024 * 1024)
                    print(
                        f"✅ Image compress threshold set to {format_bytes(IMG_COMPRESS_MIN_SIZE)}"
                    )
                    break
                else:
                    print("❌ Enter a value between 0 and 10240 MB")
            except ValueError:
                print("❌ Please enter a valid number")
    elif choice == "9":
        print("✅ Keeping current setting")
    else:
        print("❌ Invalid option")


def _configure_img_webp_quality():
    """Configure the lossy WebP quality used when compressing large native images"""
    global IMG_WEBP_QUALITY

    quality_options = {
        "1": (30, "30 — maximum compression, visible artefacts"),
        "2": (40, "40 — high compression"),
        "3": (50, "50 — balanced  (default)"),
        "4": (60, "60 — better quality"),
        "5": (75, "75 — high quality"),
        "6": (85, "85 — very high quality, larger files"),
        "7": (95, "95 — near-lossless"),
    }

    print(f"\nCurrent lossy WebP quality: {IMG_WEBP_QUALITY}")
    print("Applied when a native image exceeds the compress threshold.")
    print(
        "Non-native formats always use lossless WebP (this setting does not affect them).\n"
    )
    for key, (val, label) in quality_options.items():
        marker = " ◀ current" if val == IMG_WEBP_QUALITY else ""
        print(f"{key}. {label}{marker}")
    print("8. Custom quality (1–100)")
    print("9. Keep current")

    choice = input("\nSelect option (1-9): ").strip()

    if choice in quality_options:
        IMG_WEBP_QUALITY = quality_options[choice][0]
        print(f"✅ Lossy WebP quality set to {IMG_WEBP_QUALITY}")
    elif choice == "8":
        while True:
            try:
                raw = input("Enter quality (1–100): ").strip()
                if not raw:
                    break
                q = int(raw)
                if 1 <= q <= 100:
                    IMG_WEBP_QUALITY = q
                    print(f"✅ Lossy WebP quality set to {IMG_WEBP_QUALITY}")
                    break
                else:
                    print("❌ Quality must be between 1 and 100")
            except ValueError:
                print("❌ Please enter a valid integer")
    elif choice == "9":
        print("✅ Keeping current setting")
    else:
        print("❌ Invalid option")


def view_current_settings():
    """Display current configuration"""
    print("\n📋 Current Configuration")
    print("=" * 50)

    print("\n🗂️ Storage Settings:")
    print(f"   Files  (ROOT_DIR)   : {ROOT_DIR}")
    print(f"   Database (DB_DIR)   : {get_db_dir()}")
    print(f"   Cache (CACHE_DIR)   : {get_cache_dir()}")
    print(f"   HLS Cache           : {get_hls_cache_dir()}")
    print(f"   Image Cache         : {get_img_cache_dir()}")

    print("\n🔧 Server Settings:")
    print(f"   Port: {PORT}")
    print(f"   Host: {HOST}")
    print(f"   Chunk Size: {format_bytes(CHUNK_SIZE)}")
    print(f"   Chunked Uploads: {'Enabled' if ENABLE_CHUNKED_UPLOADS else 'Disabled'}")
    print(
        f"   Upload body timeout: {f'{BODY_TIMEOUT} s' if BODY_TIMEOUT else 'no limit'}"
    )
    print(f"   Upload timing log: {'On' if UPLOAD_TIMING_ENABLED else 'Off'}")
    print(f"   Upload chunks in RAM: {'On' if UPLOAD_CHUNKS_IN_MEMORY else 'Off'}")
    print(f"   Download read size: {format_bytes(DOWNLOAD_BUFFER_SIZE)}")
    print(f"   Max File Size: {format_bytes(MAX_CONTENT_LENGTH)}")
    print(f"   Session Timeout: {PERMANENT_SESSION_LIFETIME//60} minutes")
    print("   Session Secret: Managed in db/session.secret")

    print("\n🎬 HLS / Video Settings:")
    print(f"   ffmpeg (HLS):       {'✅ Enabled' if ENABLE_FFMPEG else '🚫 Disabled'}")
    print(
        f"   Min size for HLS: {format_bytes(HLS_MIN_SIZE) if HLS_MIN_SIZE else 'Always HLS'}"
    )
    print(f"   Always-HLS formats: {', '.join(sorted(HLS_FORCE_FORMATS))}")

    print("\n🖼️  Image Settings:")
    print(f"   libvips (convert):  {'✅ Enabled' if ENABLE_LIBVIPS else '🚫 Disabled'}")
    print(
        f"   Compress threshold: {format_bytes(IMG_COMPRESS_MIN_SIZE) if IMG_COMPRESS_MIN_SIZE else 'Always compress'}"
    )
    print(f"   Lossy WebP quality: {IMG_WEBP_QUALITY}  (1–100, lower = smaller file)")
    print(f"   Image Cache         : {get_img_cache_dir()}")

    print("\n🌐 Protocol Servers:")

    def _yon(v):
        return "✅ Enabled" if v else "🚫 Disabled"

    print(
        f"   WebDAV : {_yon(WEBDAV_ENABLED)}  →  http://HOST:{WEBDAV_PORT}/"
        + ("  ⚠️  plaintext" if WEBDAV_ENABLED else "")
    )
    print(
        f"            {_yon(WEBDAV_HTTPS_ENABLED)}  →  https://HOST:{WEBDAV_HTTPS_PORT}/"
    )
    print(f"   SFTP   : {_yon(SFTP_ENABLED)}  →  sftp://HOST:{SFTP_PORT}/")
    print(
        f"   FTP    : {_yon(FTP_ENABLED)}  →  ftp://HOST:{FTP_PORT}/  "
        + (
            f"🔒 FTPS ({'TLS on data+control' if FTP_TLS_REQUIRE_DATA else 'TLS on control only'})"
            if FTP_TLS_ENABLED
            else "⚠️  plaintext"
        )
    )
    print(
        f"   SMB    : {_yon(SMB_ENABLED)}  →  \\\\HOST\\{SMB_SHARE_NAME}  (port {SMB_PORT}, fallback {SMB_FALLBACK_PORT})"
    )

    print("\n🕓 Version History:")
    print(f"   Version Engine:     {_yon(VERSION_ENGINE_ENABLED)}")
    try:
        # A lookup at call time, not an import statement: version_engine.py imports THIS module
        # at its top, and a static import here closed the cycle CodeQL alert #612 reports. By now
        # this module is fully loaded, so nothing depends on the order of the two imports.
        _ve = importlib.import_module("version_engine")

        st = _ve.status()
        pid_str = st.get("pid") or "—"
        print(
            f"   Running:            {'✅ yes' if st.get('running') else '🚫 no'}  (pid {pid_str})"
        )
        print(f"   Watcher running:    {_yon(st.get('watcher_running'))}")
        print(f"   Scanner running:    {_yon(st.get('scanner_running'))}")
        print(
            f"   Jobs:               {st.get('pending_jobs', 0)} pending, "
            f"{st.get('active_jobs', 0)} active, {st.get('failed_jobs', 0)} failed"
        )
        print(f"   Last scan:          {st.get('last_scan') or 'never'}")
    except Exception as e:
        print(f"   Running:            (status unavailable: {e})")
    print(f"   Database (resolved): {os.path.join(get_db_dir(), VERSION_DB_FILENAME)}")
    print(f"   Storage (resolved):  {get_versions_dir()}")
    print(
        f"   Small-file threshold: {format_bytes(VERSION_SMALL_FILE_THRESHOLD)}   "
        f"Chunk size: {format_bytes(VERSION_CHUNK_SIZE)}"
    )
    print(f"   Worker count:        {VERSION_WORKER_COUNT}")
    print(
        f"   Watcher: {_yon(VERSION_WATCH_ENABLED)}   "
        f"Scanner: {_yon(VERSION_SCAN_ENABLED)} (every {VERSION_SCAN_INTERVAL}s)"
    )
    print(
        f"   Retention: {_yon(VERSION_RETENTION_ENABLED)} (max {VERSION_MAX_VERSIONS}/file)   "
        f"GC: {_yon(VERSION_GC_ENABLED)} (grace {VERSION_GC_GRACE_PERIOD}s)"
    )
    print(
        f"   Compression: {_yon(VERSION_COMPRESSION_ENABLED)} (zstd level {VERSION_COMPRESSION_LEVEL}, "
        f"min saving {VERSION_COMPRESSION_MIN_SAVING_PERCENT} %, busy {VERSION_COMPRESSION_BUSY_PERCENT} %, "
        f"delta: {_yon(VERSION_COMPRESSION_DELTA_ENABLED)})"
    )
    print(f"   Tracked files:       {len(VERSION_TRACK_FILES)}")
    print(f"   Tracked directories: {len(VERSION_TRACK_DIRECTORIES)}")
    print(
        f"   Tracking roots:      {len(VERSION_TRACK_ROOTS)}  "
        f"(all-files-under-roots: {_yon(VERSION_TRACK_ALL_FILES)})"
    )


def configure_protocol_settings():
    """Interactive configuration for WebDAV / SFTP / FTP protocol servers."""
    global WEBDAV_ENABLED, WEBDAV_PORT, SFTP_ENABLED, SFTP_PORT, FTP_ENABLED, FTP_PORT

    print("\n🌐 Protocol Server Configuration")
    print("=" * 50)

    while True:

        def _yon(v):
            return "✅ Enabled" if v else "🚫 Disabled"

        print("\nCurrent Settings:")
        print(f"1. WebDAV  : {_yon(WEBDAV_ENABLED)}   Port: {WEBDAV_PORT}")
        print(
            "   → native drive mapping on Windows / macOS / Linux  ⚠️  plaintext Basic Auth"
        )
        print(
            f"   → HTTPS runs separately on port {WEBDAV_HTTPS_PORT} ({_yon(WEBDAV_HTTPS_ENABLED)}) — that's the one to use"
        )
        print(f"2. SFTP    : {_yon(SFTP_ENABLED)}   Port: {SFTP_PORT}")
        print("   → WinSCP, FileZilla, sshfs")
        print(f"3. FTP     : {_yon(FTP_ENABLED)}   Port: {FTP_PORT}")
        print(
            "   → legacy FTP clients  "
            + (
                f"🔒 FTPS enabled ({'TLS on data+control' if FTP_TLS_REQUIRE_DATA else 'TLS on control only'})"
                if FTP_TLS_ENABLED
                else "⚠️  plaintext, LAN only"
            )
        )
        print(
            f"4. SMB     : {_yon(SMB_ENABLED)}   Port: {SMB_PORT} (fallback {SMB_FALLBACK_PORT})"
        )
        print(f"   → native network drive, share name: {SMB_SHARE_NAME}")
        print("5. Save & Exit")
        print("6. Exit Without Saving")

        choice = input("\nSelect option (1-6): ").strip()

        if choice == "1":
            _toggle_protocol("WEBDAV", "WebDAV")
        elif choice == "2":
            _toggle_protocol("SFTP", "SFTP")
        elif choice == "3":
            _configure_ftp()
        elif choice == "4":
            _configure_smb()
        elif choice == "5":
            save_server_config()
            print("✅ Protocol configuration saved!")
            break
        elif choice == "6":
            print("↩️  Cancelled")
            break
        else:
            print("❌ Invalid option")


def _configure_ftp():
    """Dedicated FTP sub-menu — has a TLS knob the other protocols don't."""
    global FTP_ENABLED, FTP_PORT, FTP_TLS_ENABLED, FTP_TLS_REQUIRE_DATA

    while True:

        def _yon(v):
            return "✅ Enabled" if v else "🚫 Disabled"

        print(f"\nFTP — currently {_yon(FTP_ENABLED)}  (port {FTP_PORT})")
        print(f"1. Enable / Disable         (currently {_yon(FTP_ENABLED)})")
        print(f"2. Change port              (currently {FTP_PORT})")
        print(f"3. FTPS (TLS)               (currently {_yon(FTP_TLS_ENABLED)})")
        print(f"4. Require TLS on data too  (currently {_yon(FTP_TLS_REQUIRE_DATA)})")
        print("5. Back")
        print()
        print("💡 FTPS reuses the same cert as WebDAV HTTPS (db/webdav.crt) — ")
        print(
            "   import it once as a Trusted Root and it covers both. Needs "
            "pyOpenSSL installed;"
        )
        print("   falls back to plaintext automatically if it isn't.")

        choice = input("\nSelect (1-5): ").strip()

        if choice == "1":
            FTP_ENABLED = not FTP_ENABLED
            print(f"{'✅ Enabled' if FTP_ENABLED else '🚫 Disabled'}")
        elif choice == "2":
            _set_protocol_port("FTP", "FTP", FTP_PORT)
        elif choice == "3":
            FTP_TLS_ENABLED = not FTP_TLS_ENABLED
            print(
                f"{'🔒 FTPS enabled' if FTP_TLS_ENABLED else '⚠️  FTPS disabled — plaintext FTP'}"
            )
        elif choice == "4":
            FTP_TLS_REQUIRE_DATA = not FTP_TLS_REQUIRE_DATA
            print(
                f"{'🔒 Data channel now requires TLS' if FTP_TLS_REQUIRE_DATA else '⚠️  Data channel may fall back to plaintext'}"
            )
        elif choice == "5":
            break
        else:
            print("❌ Invalid option")


def _configure_smb():
    """Dedicated SMB sub-menu — has knobs the other protocols don't (share
    name, fallback port). Port 445 itself isn't configured here — that's a
    one-time machine setup done via smb_setup.py, not a config.py toggle."""
    global SMB_ENABLED, SMB_PORT, SMB_FALLBACK_PORT, SMB_SHARE_NAME

    while True:

        def _yon(v):
            return "✅ Enabled" if v else "🚫 Disabled"

        print(f"\nSMB — currently {_yon(SMB_ENABLED)}")
        print(f"1. Enable / Disable    (currently {_yon(SMB_ENABLED)})")
        print(f"2. Preferred port       (currently {SMB_PORT})")
        print(f"3. Fallback port        (currently {SMB_FALLBACK_PORT})")
        print(f"4. Share name           (currently {SMB_SHARE_NAME!r})")
        print("5. Back")
        print()
        print(
            f"💡 Port {SMB_PORT} needs a one-time machine setup before it'll actually"
        )
        print("   bind — run `python tools/smb_setup.py` or `./manage.sh setup-smb`.")
        print(
            f"   Until then, SMB automatically falls back to port {SMB_FALLBACK_PORT}."
        )

        choice = input("\nSelect (1-5): ").strip()

        if choice == "1":
            SMB_ENABLED = not SMB_ENABLED
            print(f"{'✅ Enabled' if SMB_ENABLED else '🚫 Disabled'}")
        elif choice == "2":
            _set_protocol_port("SMB", "SMB", SMB_PORT)
        elif choice == "3":
            raw = input(
                f"Enter fallback port (currently {SMB_FALLBACK_PORT}): "
            ).strip()
            if raw.isdigit() and 1 <= int(raw) <= 65535:
                SMB_FALLBACK_PORT = int(raw)
                print(f"✅ Fallback port set to {SMB_FALLBACK_PORT}")
            elif raw:
                print("❌ Invalid port")
        elif choice == "4":
            raw = input(f"Enter share name (currently {SMB_SHARE_NAME!r}): ").strip()
            if raw:
                SMB_SHARE_NAME = raw
                print(f"✅ Share name set to {SMB_SHARE_NAME!r}")
        elif choice == "5":
            break
        else:
            print("❌ Invalid option")


def _toggle_protocol(prefix: str, label: str):
    """Toggle enable/disable and optionally change port for a protocol server."""
    global WEBDAV_ENABLED, WEBDAV_PORT, SFTP_ENABLED, SFTP_PORT, FTP_ENABLED, FTP_PORT

    enabled_var = f"{prefix}_ENABLED"
    port_var = f"{prefix}_PORT"

    # Read current values using globals()
    g = globals()
    current_enabled = g[enabled_var]
    current_port = g[port_var]

    _yon = "✅ Enabled" if current_enabled else "🚫 Disabled"
    print(f"\n{label} — currently {_yon}  (port {current_port})")
    print("1. Enable")
    print("2. Disable")
    print(f"3. Change port  (currently {current_port})")
    print("4. Keep current")

    choice = input("\nSelect (1-4): ").strip()

    if choice == "1":
        g[enabled_var] = True
        print(f"✅ {label} enabled")
    elif choice == "2":
        g[enabled_var] = False
        print(f"🚫 {label} disabled")
    elif choice == "3":
        _set_protocol_port(prefix, label, current_port)
    elif choice == "4":
        print("✅ Keeping current settings")
    else:
        print("❌ Invalid option")


def _set_protocol_port(prefix: str, label: str, current_port: int):
    """Prompt user for a new port number for a protocol server."""
    reserved = {
        5000: "Flask main server",
        8080: "WebDAV",
        2222: "SFTP",
        2121: "FTP",
        445: "SMB",
    }

    while True:
        try:
            raw = input(
                f"Enter new {label} port (1–65535), or press Enter to keep {current_port}: "
            ).strip()
            if not raw:
                break
            p = int(raw)
            if not (1 <= p <= 65535):
                print("❌ Port must be between 1 and 65535")
                continue
            if p < 1024:
                print(f"⚠️  Port {p} is below 1024 — may require root/admin privileges")
            if p in reserved and reserved[p] != label:
                print(f"⚠️  Port {p} is already used by {reserved[p]} — choose another")
                continue
            globals()[f"{prefix}_PORT"] = p
            print(f"✅ {label} port set to {p}")
            break
        except ValueError:
            print("❌ Please enter a valid integer")


# Load configuration on import
load_server_config()

if __name__ == "__main__":
    main_configuration_menu()
